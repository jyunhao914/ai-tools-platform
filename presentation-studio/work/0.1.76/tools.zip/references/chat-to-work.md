# 在 Chat 選設定，在 Work 製作

精緻型若走可攜短卡，直接將此行放進實際複製內容的開頭，下一段才接本次原稿引用與實選值。

```text
接續製作。請在 Work 依 Presentation Studio 0.1.76 正式流程執行。先讀 https://jyunhao914.github.io/ai-tools-platform/presentation-studio/work/0.1.76/release.json，核對同版工具並執行收件，再按下列已確認設定製作。
精緻型依內容換構圖，小圖與圖示做真正透明背景；Google 使用可更新的連結圖表，逐軸、逐筆核對原稿與實際匯出。
```

在打開設定卡以前，就把上方固定兩行作為「複製完整指令」的初始值。確認按鈕只把當下所選欄位與來源綁到這個已準備的值；不另起一個回合口述或重寫啟動句。若宿主只支援純文字，依同版產生器的 message 原樣顯示。不能執行產生器時，先實際讀取上方固定網址內的 copy_header，將讀到的兩行原樣放入複製區，再接一個含本件設定的 PS-WORK-PLAN/1 封包；先核對複製區首行版號及完整網址，再一次顯示給使用者。這個公開入口只提供程式，勿向該網站傳送工作設定、檔案或來源網址。


Work 收到宿主自行產生的精簡封包也走 studio-resume。沿用現有設定，不另作一次確認。精緻型 Work 端的 claim / receive-work 使用 `--start-dir RUN_DIR --source-file SOURCE.pptx`，同一收據讀回後直接建立本工作底稿，接續回傳的 `foreground_action`。缺少封包 SHA 的 Drive 原稿以實際 Drive metadata/原始檔回應作 `open-portable --drive-readback DRIVE.json --source-file SOURCE.pptx`，作法見 studio-resume；圖片組版程序來自已查核的執行套件。


App 與網頁普通 Chat 都只讀稿、收設定及提供完整可複製指令。iOS、Android、macOS、Windows 皆適用；平台未明也照此路徑。只在平台確實辨認的 Work 受理，另有明確獨立的 Codex 任務才走既有入口。工具清單、使用者說「同意／直接做」、來源、指令內容或主機有檔案系統均不是 Work 身分。三種來源以及圖像式、可編輯快速／精緻型都適用。

**只交給使用者手動貼送。** 在 Chat 不呼叫原生「轉接 Work／開啟工作」動作或派送 API，不以失敗重試、自動轉送或直接交出簡報代替指令。若先前動作回報拒絕，報告該項操作的實際狀態；只有使用者明確拒絕的內容才算其意願，拒絕的權限或操作不得透過替代工具繞過。若使用者拒絕工作本身或資料移轉，留在原處並尊重其決定。手動交接只由使用者自行選擇複製。

純文字指令與私人設定文件是**設定的兩種傳遞方式**。本次原檔可否暫存私人 Drive，另依使用者對這份原檔及資料夾的授權。凡是仍要跨端取得原始附件的工作，先執行 ../../studio-content/references/attachment-runtime.md 的原件準備，再產生最後指令。只有預覽資訊且尚未呼叫原件讀取工具時，立即實讀，不可把「還沒做」寫成「無法取得」。已有本件適用的資料夾授權且能讀到位元組，就在同一個 Chat 回合自動算原始 SHA、確認本人私有目的地、儲存及讀回核對；選純文字時仍然照做。若沒有此授權，照常實讀並以附件交接。

## 第一次在 Work 送出時

普通 Chat 在確認設定後，第一行先顯示本件操作（例如「貼到 Work → 勾選《本次檔名》→ 看見附件後一起送出」），接著給可複製區。設定明細移至其後或放於展開區，確認過的選項無需再確認。依以下三步，依本件來源只列一種適用的第 3 步。互動卡沿用 `reread-stage` 取得的 `card_binding.directions`；純文字使用 `portable-message` 或 `work-message` 的 `display_text`。只有舊卡無法查明原稿類型時，才使用條件說明，讓使用者依其來源執行適用的一項。

1. 複製上方完整的 Work 啟動指令。
2. 用同一帳號在瀏覽器開啟 [ChatGPT 首頁](https://chatgpt.com/)，選「工作（Work）」及 Presentation Studio，再把指令貼到輸入框，先留在草稿。
3. **需要原稿且只有上傳附件／Library 引用，或交接指定在 Work 附檔時**，顯示「在 Work 輸入框開啟『檔案』→『搜尋空間中的檔案』，搜尋《本次完整檔名》，選你在 Chat 設定時使用的那一份。等輸入框出現這份檔案的附件卡，將指令和附件一起送出一次。」以實際檔名取代括號內文字；已有正確附件卡就直接連同指令送出。多個獨立原件只列缺乏已驗證 Drive 來源的項目，選齊後一起送出。

   **已有本件已驗證、Work 可用的 Drive 原檔或私人原稿副本，或內容已完整帶入、無須原始附件時**，第 3 步只顯示「貼好完整指令後，送出一次即可。」私人交接文件若只存設定，不算可讀的原稿。

「搜尋空間中的檔案」是使用者在本人帳號選原件的操作。搜尋有多個同名結果時，請使用者核對版本與本次上傳資訊；沒有能辨認的原件時，讓使用者直接附上自己選定的原檔，或貼上本人授權且 Work 可讀的 Drive 原檔連結。不可自行挑選同名或最新項目，不要求公開檔案。附件卡出現代表已選取，Work 收到後仍須真正開檔核對來源。

## 先把私人草稿綁定到最後確認卡

1. 能按既有授權存取私人 Drive 時，依下節定位本人「待製作」，保存原稿／採用大綱、來源修訂、保護物件、基礎設定、逐頁例外與交付目的地。取得實際 Google 文件，在設定腳本目錄用 `work-handoff-doc.py stage DOC.json PLAN.json` 取得並送出條件式寫入請求，重新讀取後用 `work-handoff-doc.py reread-stage DOC.json` 取得本次 `card_binding`。草稿不排程。Drive 缺工具、受限或未成功讀回時，到下方「固定設定的可攜指令」；不得冒稱已保存，也不遇錯直接製作。
2. 只有已有讀回綁定，且本次介面確能在本地更新卡片並保留可複製的完整文字，才於卡上標示「確認設定，取得 Work 指令」。點擊時執行設定腳本目錄 `work-launch-card.mjs` 的 `buildWorkCommand(card_binding, changes)`。以當下所有生效設定組合，變動的頂層區塊帶齊完整值；無變更則用空物件。來源、定稿、工作識別或目的地變更時須重綁。
3. 使用純卡內按鈕，凍結本次實選並把指令放進可全選的唯讀文字欄，另列三步操作及真能使用的複製控制。沒有剪貼簿時供手動全選複製。獨立按鈕使用 `type="button"`，不提交表單。**確認或複製皆不可傳送任何 Chat 訊息、建立新回合、呼叫製作工具或啟用／認領草稿。** 禁止綁定聊天提交、自動送出、在這個 Chat 貼回指令或以傳訊作為複製備援。若目前元件做不到，在最後確認前改走下一項純文字路徑。
4. App 或能力不明時，預設用文字或單題選項收齊實選。必須傳訊的中間按鈕可稱「套用設定」，不假稱已取得或複製指令。設定齊全後，不論有無回覆「確認」，同一則助理回覆給設定摘要、一個完整可選取的純文字指令區，以及上方「第一次在 Work 送出時」依原稿來源選出的三步。已讀回固定版私人草稿時輸出 `buildWorkCommand(card_binding, {})` 的原文；其他可交接來源走可攜指令。不要只給步驟、複製按鈕的文字、檔名或泛用「接續製作」。
5. 0.1.61／0.1.62 舊工作已有確認回覆卻缺指令、只回「已停止思考」時，依下節補存並讀回同件已確認工作。若已有本件有效指令直接重貼。沿用原稿、修訂和實選，不叫使用者重選或再確認。

## 私人文件與舊卡已確認交接

1. 依 studio-setup 定位本人私人 Drive「Presentation Studio／製作紀錄」，在該處找直接子資料夾「待製作」。找不到才建立，目標必須為本人有權存取的私人工作位置。優先用逐層列出子項、核對名稱與父 ID 的方式，處理分頁與重名。正式簡報仍存使用者指定的成品資料夾。
2. 鎖定來源時保存此次真實檔案 ID、修訂及已讀原件的 `source_sha256`。在建立草稿或準備可攜指令前，依 ../../studio-content/references/attachment-runtime.md 的「Chat 交接前留存可核對的私人原稿」，將已獲准且確認位元組一致的私人副本寫入 `plan.source_mirror`。即使原附件已有 Library ID 也適用。未獲准存放原稿或副本未核實時，保留原引用及已知的內容指紋，照常提供純文字交接。
3. 下列步驟只供已經確認的舊版交接補發指令。新工作不把普通 Chat 的文字回覆升為製作授權。新的互動卡在完成上節草稿交接後，直接前往 Work 受理。建立本次確認記錄，含工作識別、版本、來源及修訂、實選設定、各頁及逐圖例外、核准大綱或原文與其對應、核准拆分、保護物件、輸出格式、試算表與目的地、個別生圖服務限制、工作工具包位置，以及同一工作的既有輸出與剩餘項目。只留本次必要資料。長正文可引用私人可驗讀、同修訂的檔案。使用套件內 studio-settings/scripts/web-confirmation.py 的 pack-work（或以相同結構序列化），把完整記錄和 SHA256 存在「待製作」內本人私有的原生 Google 文件，整個流程重用該文件的 ID。先按本次工作鍵查重；新工作用 Drive 在已核對的父資料夾建立 Google 文件，標題包含簡報名稱、確認時間及短指紋。用 get_document 讀回後，依 work-handoff-doc.py init 產生的參數呼叫 batch_update_document，再重新 get_document，以 read 還原確認記錄並核對完整指紋、父資料夾與原稿引用。原生文件中的確認記錄固定，僅更新受理狀態。獨立工具包位置見 ../../studio-production/references/web-production-tools.md。找得到檔名還不足以回報已保存。
4. 以已核對的私人文件網址產生指令。取讀回結果的 `launch_message`，或執行 `python3 scripts/web-confirmation.py work-message SNAPSHOT.json SHA256 --private-url DOC_URL` 取得 `message`。指令須包含本件工作識別、已選的交付項目、真實私人交接文件與完整指紋。顯示工具回傳的完整原文，保留可選取的純文字／程式碼區塊。卡片能實際複製時也提供同一完整文字的複製按鈕。
5. 指令旁依「第一次在 Work 送出時」列出本件該做的三步。舊卡只有設定文件或附件 ID 時，第三步同樣要指明先選本次原件。等待貼上時回報「等待 Work 接手」。私人文件及回覆中的啟動指令只限本件工作。若已有真正的 Work 認領收據，依收據顯示其工作或成品，避免重開一件。

## 固定設定的可攜指令（PS-WORK-PLAN/1）

若這個 Chat 無私人 Drive 寫入工具、寫入／讀回不成功，保留已收齊的原文、模式、採用大綱、完整設定、來源修訂、保護物件、逐圖例外及交付範圍。尊重資料、權限及目的地限制。以同版設定腳本 `web-confirmation.py portable-message PLAN.json` 產生 `message` 與 `display_text`，用其完整文字顯示手動步驟及獨立可複製的指令；回覆內容應明確是「等待你貼到 Work」。這條路徑不要求 Chat 新建私人文件。無法執行腳本時，使用同一呈現順序。可複製區的第一行是「接續製作。請在 Work 讀取這次的原稿與設定，核對後照選定範圍製作並交付。」。只有本次需要附件時，在下一行寫入「送出前，請在 Work 的『檔案 → 搜尋空間中的檔案』選取《本次實際完整檔名》，看到原稿出現在輸入框再與本指令一起送出。Work 收件後，請優先讀取這則訊息實際附入的原檔，核對來源與內容後接續製作。」將書名號內改成實際檔名；多來源只列需要附入者。已驗證可讀私人 Drive 原稿或完整定稿大綱時省略這行。最後另起一行，以 `PS-WORK-PLAN/1 ` 開頭，緊接著把真實工作物件序列化為 `{"plan":PLAN}` 的單行 JSON。PLAN 是物件本身，不能以檔名、說明、佔位值、省略號或字串代替。物件含 job_id（本件固定識別）、revision（本次設定／定稿修訂）、mode、來源與 source_revision、完整 settings 及 delivery，另帶本件實際使用的內容與例外。外層校驗碼可省略，由 Work 計算。啟動指令放在獨立可複製區。前往 Work 的導航步驟可放區外；需要附件的案件，專屬選檔提醒也必須在複製內容內、機器標記行之前。檔名若含換行，提示中轉成空白；封包中的原始來源資料保持不變。不得虛構 SHA、URL 或跨端 ID。

來源有三類：可跨環境驗讀的真實 Drive／Library 原稿與精確修訂、目前宿主給的不可變上傳附件 ID、或逐頁完整帶入的已採用大綱。上傳檔若有宿主回傳的不可變 `file_` 加 32 位小寫十六進位 ID，用該完整 ID 作 `source_ref`，用 `upload:` 加同一 ID 作 `source_revision`；不能把檔名或 Library 項目連結假作上傳 ID。如果 Library 有可重開的私人檔案頁，而且已依檔案資訊查證與此上傳卡的關聯，可在來源資料同時帶入該 Library 連結，供 Work 用正式 Library 方式取原件。Chat 已取得位元組時另帶實算的 `source_sha256`，已驗證的私人備份一併帶 `source_mirror`；確實未取得舊稿 SHA 時只帶已知引用，不編填指紋。Work 按實際取回的檔案驗證。只有暫存檔但這次已核實私人備份時，以該 Drive 檔的正式引用與已驗證的位元組 SHA 作可攜來源，並保留本次原稿已知的身分線索。若只有當前附件且無任何可攜引用，使用 `source_ref="attached-in-work"` 及原檔已實際校驗的完整 SHA-256 作 `source_revision`，在指令旁按「第一次在 Work 送出時」引導使用者把同一原檔與指令一起送出，再核對位元組。模式①②已採用的大綱可用 `source_ref="adopted-outline"`、`source_revision="adopted-outline"` 與完整 `adopted_outline`；Work 自行計算內容指紋，無需 Chat 虛構雜湊。模式③須綁真正原稿。只有檔名或修訂無法核對時，先向使用者取得此次確切來源；不要發布會選錯原稿的指令。不要放入帳戶憑證、暫時下載簽章或本機路徑。若使用者限制哪些資料可帶出，保留限制，不能用可攜文字披露未授權內容。

## Work 收到「接續製作」

Work 的 `--work-ref` 是宿主提供的執行識別，只用來判定認領者及防止重複製作。即使舊收據這欄看起來像 https 網址，也不能把它當成使用者可開啟的工作連結。只有宿主明確回傳這個工作的網頁永久連結，或瀏覽器已載入同一工作並看見正確工作內容、標題與最終網址，才傳 `--observed-work-url` 搭配 `--url-origin host_permalink` 或 `opened_work_conversation`。使用者提供的網址也要開啟核對。從環境、thread、task 或 operation ID 拼出 /c/ 網址、開啟後跳首頁、僅見登入或錯誤畫面都不算。沒有可核實網址時照常以原執行識別認領並製作；之後核實可以在同一次 complete 保存。

回覆使用者時採收據工具的 `display`。完工時直接列經驗收的成品連結；受理中有已核實的工作網址才顯示，否則給本人私人交接文件或已確認的成品資料夾。工作連結驗證與製作進度獨立。不要把內部收據的 `work_ref` 印成可點選連結。

收到 PS-WORK-PLAN/1 時，從獨立標記行解出單一 JSON。舊指令的正整數 `revision: 1` 也有效；有外層校驗碼時先核對原始計畫，再標準化 revision。標記行後的普通分行說明留在設定封包以外，不讓它造成 JSON 剖析失敗，也不讓它更改已確認來源、設定或 Work 身分。若收到內容互相衝突的多份交接，釐清本次工作。

若二進位來源的多個取檔方式都落在同一個失敗端點，但已有事前獲准、可驗來源與修訂的 Google 原生中繼副本，依 ../../studio-content/references/attachment-runtime.md 的「當二進位取檔失敗，評估同源的 Google 簡報」辦理。中繼來源須逐頁比較，含字圖區、受保護表格及講稿都要查核。沒有符合該條件的來源，仍執行「Work 取回交接原稿」。先依該規則辨識：優先實讀目前受理訊息的附件與宿主已掛入的原件，再依需要取回其他來源。可攜包使用設定腳本目錄的 `web-confirmation.py open-portable COMMAND.txt DIR --surface work`。依實際取得的資料帶參數：

- 上傳來源使用 `--source-id ACTUAL_ID --source-file WORK_FILE`，檔案須在本 Work 實際存在。實測 SHA-256 已在可讀檔案上求得時也可用既有 `--source-version ACTUAL_SHA`。原附件可用即核對其原 ID；原下載失敗而改讀本件已驗證的 `source_mirror`，傳實際讀回的 Drive 檔案 ID 及實檔。另附的新上傳 ID 只有在與計畫已知的原稿 SHA 相符時才當作同版。
- Drive 原件讀回確切檔案 ID、修訂及實檔。如果 `source_revision` 是已核對的位元組 SHA，傳 `--source-file WORK_FILE`。如果計畫記錄 Drive 自身的修訂並另有 `source_sha256`，同時傳 `--source-version ACTUAL_DRIVE_REVISION --source-file WORK_FILE`，各自核對修訂及位元組。單一 Drive／Library 原件已綁 source_mirror 時，從該副本取回就傳 `--source-id ACTUAL_MIRROR_ID --source-file WORK_FILE`，核對原稿 SHA 後沿用原服務修訂。多個獨立來源不得共用一份副本。只有 Drive 修訂的舊包，仍依 `--source-version ACTUAL_DRIVE_REVISION` 和原件讀回驗證。採用大綱可省略來源參數，由工具用隨計畫附入的完整正文計算。不要從提示抄一份指紋當作讀回。
- 自動讀取途徑用完時，留在同一 Work，按附件恢復規則處理使用者指定的來源。舊包沒有 SHA，原 ID 也讀不到時，將下列選項用於同一 Work 的回復：現有 Work 的「＋ → 從檔案庫加入 → 選取本次版本 → 新增至對話」，看到附件卡後隨訊息送出。若該訊息已附了這張卡卻仍下載失敗，改用「上傳檔案」選真正的 PPTX，或貼已授權的私人 Drive 檔案連結。實際取得後保留原設定和同一 `job_id`，以遞增的計畫修訂記錄新來源。新附件以真實上傳 ID、`upload:<新ID>` 與實算 `source_sha256` 固定；另行指定的 Drive 檔用其真正 Drive 引用、修訂與位元組 SHA。若使用者指定的是未綁定的新 Drive ID，也照此在同工作記錄其來源，已知舊 SHA 時核對內容並記下結果。只在使用者明確採用時接受與已知舊 SHA 不同的檔。用 `web-confirmation.py portable-message PLAN.json` 重封此修訂並在目前 Work 讀回，不需重貼啟動句或重選已確認的製作設定。

回 `action:register_handoff` 才用其實際 snapshot、sha256 及 job_id 在本人工作區查重，若已有相同 job_id、計畫修訂、來源版本及內容指紋的正式文件，直接讀取；新修訂保留同一工作，另外保存該修訂的確認記錄，不認領舊來源的收據。需要初次落地時，在原私人待製作資料夾建立文件，依 `work-handoff-doc.py init` 得到的條件式請求真正寫入並重新 `read`。原件修訂不符先取正確版本；不得改寫指紋湊合。PS-WORK-CARD/1 則先讀指令指定的私人文件，用 `work-handoff-doc.py activate DOC.json COMMAND.txt --surface work`，依條件式結果實寫並讀回。舊版 v1 文件直接 read。全部格式都繼續以下 claim 步驟，只有讀回本 Work 的 `action:resume` 才進正式製作。重貼使用同一份工作。

先辨認實際宿主已是 Work，再查本帳號「Presentation Studio／製作紀錄／待製作」或讀取啟動文字中指定的正式私人交接檔。此入口優先於新工作選單、來源搜尋與首次設定說明。

- 有指定交接時核對連結、內容指紋及來源修訂。只有「接續製作」時，列出本人已確認的有效工作，將目前 Work 真實執行識別傳入 find-pending。本人這個 Work 已受理同一工作但進度停在底稿時，沿用原認領；尚無認領時唯一符合才直接接。多筆顯示簡報名稱、確認時間、短識別供點選；不按最新時間猜測。沒有待接項時，若已有同一項工作回執，依回執顯示已接手的工作／成果；否則可用 Chat 提供的備用一句指定工作。
- 先從待製作資料夾取得完整清單並讀取各交接文件，可在文件內取得完整指紋；勿把 Google 文件 ID、Drive 修訂或檔名當作內容指紋。Work 以 work-handoff-doc.py read 還原原確認記錄，讀回原稿的真實修訂或原檔雜湊。透過 `work-handoff-doc.py claim … --surface work` 的 tool_args 帶 get_document 讀回的 requiredRevisionId 呼叫 batch_update_document，隨即讀回確認同一個 Work 已受理。衝突或操作結果不明時用最新狀態重跑，不重複開工。所有成品驗收完成才用 `complete … --surface work` 寫回真實輸出引用，再讀回核實。同一確認的重送、重載和不明回應先核對既有認領。以宿主可執行的條件式建立／更新保證單一認領。若 Drive 工具沒有條件更新，在能提供已預先產生 ID 的建立操作時，用同一 Work 接手收據檔 ID 建立，已存在即查該收據。沒有原子操作時，對已見的並發或未知認領先查清，不能承諾並發互斥或擅自重派。
- 內容版本改變時只處理該版本衝突；來源與設定吻合就直接呼叫製作工具，不重問模式、圖片、風格，不要求重新上傳。使用者已授權的 Google Slides、可編輯 PPTX 與圖表資料依 studio-production 的製作及真實成品驗收執行。只有套件版本、測試過的路由、實際開始和成品驗收各自有證據時才回報對應狀態。
取得本工作的 `action:resume` 後，把該次讀回的完整 JSON 留在 `RECEIVED.json`，直接跳至 `../../studio-production/SKILL.md` 的「Work 正式執行入口」。若 claim 回傳 `production_entry`，從已掛載的製作目錄或已核對的 ZIP 根目錄直接執行 `python3 scripts/editable-image-queue.py start-work RECEIVED.json SOURCE.pptx RUN_DIR`。已有可讀回的同工作底稿就加 `--base BASE.pptx`。在平鋪工具包中，讀根目錄 `WORK-START.md`，`scripts/` 與 `references/` 為同層。舊交接若無 production_entry，先依真實來源與已選形式分流；確為模式③可編輯 PPTX 時即可使用同一入口。回 `call_native_image` 時，先用相同的宿主能力參數執行 `work-dispatch RUN_DIR REQUEST_ID`。僅取得 `invoke_native_image` 的這次執行，當場用其 provider_input 呼叫原生生圖工具；已驗明的回傳以 work-event 登錄並接著執行，直至組裝與正式交付。本機底稿和已核准逐圖動作已足以起跑；雲端校正於建立原生圖表後執行。

### Work 接續圖表校正

已確認工作中的 `chart_workflow` 帶有同版工具位置、命令及接續步驟。舊確認檔也能原樣接手。製作本次有雙軸連結組合圖的 Google 簡報時，保存 Sheets 建立圖表回應的完整 spec、position 及可重用的 chart ID。發現 PPTX 和 Google 的左右軸、圖例或資料標籤不同，立即使用本次工作檔執行 `../../studio-production/references/linked-chart-run.md` 的命令。每次寫回原 Sheets 或 Slides、刷新圖表、重新匯出並帶同一份 state 接續。Work 驗收以最新 Google PDF 的實測為準，期間繼續其他頁面。
