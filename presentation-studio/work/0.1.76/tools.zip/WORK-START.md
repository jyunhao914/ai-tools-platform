# Work 正式製作入口

本件已在 Work 確認可編輯・精緻型時，先保存接收資料中的 plan 為 PLAN.json。底稿依下方 start-work 執行。當照片、去背圖和原生文字就位後，先驗 PowerPoint，再從這份定稿匯入 Google。

```sh
python3 scripts/refined-design.py check SOURCE.pptx FINAL.pptx --plan PLAN.json
```

若檢查發現可修的重複構圖或實底小圖，使用 `python3 scripts/refined-design.py repair SOURCE.pptx FINAL.pptx --plan PLAN.json --out FIXED.pptx`，重看修正頁。若回報主體缺切、背景無法安全分離或圖位待重生，Work 直接補本次新素材並重組該頁。完成後重驗實際成品。匯入時在同一件 Google 簡報核對正式原生圖表與試算表的關聯，依 references/linked-chart-run.md 實際比對來源圖與雲端渲染。漏標籤、右軸頂點或刻度不符時，套用下一個 Google 更新，刷新後再驗。這些步驟均屬本件使用者已確認的製作。

**雙軸柱線圖的 Google 試算表**。若 PowerPoint 有使用左右軸的直條加折線，先從最終 PowerPoint 和它自己的實際 PDF 建立含圖表的 XLSX。PAGE 是本件該圖的頁數。

```sh
python3 scripts/native-combo-workbook.py FINAL.pptx POWERPOINT.pdf CHARTS.xlsx --page PAGE
```

將該 XLSX 以 Google Drive 匯入為本次要交付的 Google 試算表，讀回其中的 chartId。用 Slides 的 createSheetsChart（LINKED）在原圖位放入這張圖，刷新後匯出正式 PDF，對照原圖的兩側刻度與每個數據標籤。保留匯入的原生圖表規格，讓更新試算表資料後能從投影片刷新。若轉換器未能保留圖表，或正式 PDF 仍有標籤互相蓋住，按 references/linked-chart-run.md 接著修。

此處僅供已由平台辨認的 Work。App、網頁普通 Chat 或宿主不明，應依外掛的 Chat 交接規則提供完整指令與貼上步驟。收到 PS-WORK-PLAN/1 的 Work 依 studio-resume 先 open-portable 並核對實際來源，再把正式確認封包落地讀回。新的草稿型指令先依 studio-resume 由 Work 啟用並重新讀回同一文件；若是舊版已確認交接，直接使用下列步驟。

Work 收到「接續製作」時，用已確認的設定完成本工作選定的交付項目。只有目前工作是模式③、可編輯輸出且原件為 PPTX，才使用下方的逐圖命令。已採用大綱的①②、來源 PDF、其他來源與圖像式直接使用其適用的製作流程。內文大綱的修訂可識別定稿，不必先有一份來源 PPTX。

1. 從私人交接文件取得完整指紋。用 `scripts/work-handoff-doc.py claim … --surface work` 搭配實際來源修訂及宿主 Work 識別認領。回 `write_then_reread` 時，送出其條件式更新，重新 get_document 並再次執行 claim。回 `resume` 時，把此次完整輸出保存為 `RECEIVED.json`，包含 plan 與已讀回的 receipt。完工、別的 Work 已認領或狀態未明時，按收據顯示或查原操作。舊交接若少了副檔名或 MIME，先從已確認引用讀取檔案中繼資料與原件，再依實際格式分流。
2. 解壓工具包時核對 ZIP 的版本與雜湊，從含 `scripts/` 的目錄執行。以下是模式③可編輯 PPTX 的起點。Work 缺原檔時先讀取原始引用，傳輸失敗再自動從本件 `source_mirror.file_id` 下載實檔並比對已記錄的 SHA-256。依 studio-content 的附件恢復規則在原 Work 接受使用者指定的附件或可讀 Drive 檔案；不得向使用者索取電腦本機路徑。原稿可由已確認的來源位元組 SHA，或同一授權來源的檔案引用與實際修訂驗證。RUN_DIR 固定對應本工作和修訂。原稿已確認的 SHA-256（含以 SHA-256 指定的 source_revision）可直接比對。只有檔案 ID 和修訂時，從同一授權來源讀回該修訂及下載位元組，增加 `--source-readback SOURCE.json`。檔內以 `file_id`、`revision`、`sha256` 記錄實際 ID、修訂和下載檔 SHA-256，可加位元組數 `size`。已有獨立底稿時加上 `--base BASE.pptx`。依當前生圖工具支援的欄位帶入 `--reference-key` 和 `--supports-transparent-background`，後續各次工作命令沿用。

   ```sh
   python3 scripts/editable-image-queue.py start-work RECEIVED.json SOURCE.pptx RUN_DIR
   ```

   選精緻型時先實際開啟此入口返回的 base.pptx，使用這份工作稿繼續組裝與轉檔；頁面經原生重排後應保留其構圖。公開安裝包的實作位於 skills/studio-production/scripts。純文字交接含工作工具位置時先核對同版實檔。依 `references/refined-review.md` 補排內容關係尚未展現的頁。入口會在適用頁執行 `scripts/compose-refined.py`。已有排好版的底稿、客製設計及指定模板依其實際版面接續。圖片授權只影響圖件。

3. 回 `call_native_image` 時，先呼叫 `python3 scripts/editable-image-queue.py work-dispatch RUN_DIR REQUEST_ID`。取得 `invoke_native_image` 的執行者當場以 `provider_input` 呼叫宿主真正的 ChatGPT 原生圖片工具。保存實際生成引用、原始檔與圖位，依 `references/editable-run.md` 填逐圖事件並執行 `work-event RUN_DIR record EVENT.json`。已確認失敗才用 `defer`，繼續後頁再回補。重入用 `work-next RUN_DIR`；未確定結果的同一請求先查回原操作。回 `classify_source_objects` 時依頁與 shape_id 實看並分類保護原件，以 `work-classify RUN_DIR DECISIONS.json` 接續。這些子命令都經由同一支 editable-image-queue.py 執行。
4. 回 `assemble` 時先打開此次傳回的 `files.base`。已審核的原圖／新圖與文字一同完成構圖時，沿用這份帶圖檔案。其餘已授權的局部客製或圖表接續處理；依 references/editorial-art.md 實看照片及透明物件。回 `assemble` 就把已驗收素材放進底稿，按已確認的頁序和文字政策另存可編輯成品。沿用的證據圖須保留原始裁切和顯示比例。群組內的圖要把上層群組的縮放也算入。排版可移動或等比縮放證據圖，空出的地方用留白或調整周邊文字框處理。若精緻型明確要求大圖錯落，先為可自由安排的相片頁安排不同的主體位置、占幅和相鄰文字空間，再用實際生成的照片量焦點。可依內容選用跨欄橫幅、大片出血或偏心構圖。圖框改變後仍需看得清照片主體、鎖定原文及證據。
5. 先驗本次 PowerPoint，再驗使用者會開啟的各種成品。以下兩個獨立命令可定位 `work-pptx` 指出的頁面與物件。各路徑都須指向本工作實際讀回的定稿或原件。

   ```sh
   python3 scripts/editable-image-queue.py work-pptx RUN_DIR FINAL.pptx
   python3 scripts/protected-image-geometry.py check SOURCE.pptx FINAL.pptx --run-dir RUN_DIR
   python3 scripts/photo-layout-variety.py check RUN_DIR FINAL.pptx
   ```

   - `protected-image-geometry.py` 回 `repair_required` 時，先另存修正版，再重跑整頁內容、圖表及顯示檢查。它使用這份工作的原件辨識與逐圖授權定位證據素材。

     ```sh
     python3 scripts/protected-image-geometry.py repair SOURCE.pptx FINAL.pptx --out FIXED.pptx --run-dir RUN_DIR
     ```

   - 大圖變化檢查適用於精緻型已明確要求構圖錯落、且至少三頁有可自由安排的大照片。回 `repair_layout` 時，按實際主體及保護區重新選框。依 `references/refined-photo-layout.md` 提供本次照片的 `FOCUS.json`，或直接在工作副本調整圖片與相鄰文字區。完成後用同一份定稿重跑上述檢查，並檢視整頁。如有明確限制，保留圖表、截圖、文字與主體的可讀區。

     ```sh
     python3 scripts/photo-layout-variety.py repair RUN_DIR FINAL.pptx --out REFLOW.pptx --focus FOCUS.json
     ```

   精緻型在兩份實際匯出分別執行 `python3 scripts/check-refined-type.py FINAL.pptx OUTPUT.pdf --pages 2,3`；頁碼替換為本次可修改的精緻型頁。回報標題和解釋同框同樣式時，以原文重排並重看成品。自動精緻版式另執行 `python3 scripts/check-content-panels.py SOURCE.pptx FINAL.pptx --plan PLAN.json --slides GOOGLE-EXPORT.pptx` 核對不同用途頁是否被相同卡片遮蔽；只交付 PPTX 時省略 --slides。確認需修時，用 --repair-out 寫入新的私人 PPTX 或重排受影響頁，實際開啟、重新轉檔並再次檢視兩版。原生圖表依 references/linked-chart-run.md 比對原件可見的逐點資料標籤與成品實際渲染。需要的標籤在轉檔後消失時，在同一件工作修復原生圖表並重驗。

6. 交付包含 Google 簡報時，從實際原生 ID 與同一修訂取回原生結構、PPTX 匯出和逐頁渲染，核對原生簡報上看見的物件。將實際 ID 與修訂帶入命令。

   ```sh
   python3 scripts/protected-image-geometry.py check SOURCE.pptx GOOGLE-EXPORT.pptx --run-dir RUN_DIR
   python3 scripts/photo-layout-variety.py check RUN_DIR FINAL.pptx --slides-json NATIVE.json --slides-id ID --slides-revision REV
   ```

   本機通過而 Google 仍有落差時，修正同一原生工作簡報的對應圖框，或從修正後的 PowerPoint 重新匯入工作中的成品。保留已連結的試算表、圖表引用與工作資料夾，再讀回最新修訂，重驗正文、每個證據區、圖表及各頁畫面。兩種格式都交付時，以各自最後的實檔計算與查核。

7. 以 `node scripts/work-foreground.mjs verify RUN_DIR CURRENT_EVIDENCE.json` 交叉核對實選項目；Google 的本次原生結構放在 `files.slides_json`，同版原生簡報匯出的 PPTX 放在 `files.slides_pptx`。能逐項呼叫宿主工具時，同樣要完成上述適用的實檔檢查，並保存報告與成品識別。讀到 `repair_delivery`、`repair_required` 或 `repair_layout` 即在本 Work 執行可行修正，再驗實檔。收到 `ready_to_publish` 或已完成同一批成品的逐項檢查時，送出本工作驗過的下載檔及連結，再更新並重讀正式交付收據。只要求 Google 簡報時，組裝及匯出用的 PPTX 留在工作目錄。確認一次後，原授權含這些局部排版修正與複驗。

宿主已提供實際 callable 時，可由 `scripts/work-foreground.mjs` 的 `runWorkForeground(startArgv,host)` 執行這條路徑；傳入從 start-work 開始的實際參數、連結好的工具和對話交付函式。缺少相應函式時，Work 依回傳 action 在當前對話繼續呼叫已提供的工具。
