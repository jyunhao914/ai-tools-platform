# Google 連結圖表的字級與標籤修復

### 先把 PowerPoint 的原生雙軸圖匯入圖表試算表

最終 PowerPoint 中有直條加折線、左右兩個數值軸時，先執行以下命令。PAGE 和 INDEX 分別取自本件圖表的實際頁數及該頁從零起算的圖表序號。

```sh
python3 scripts/source-chart-labels.py repair SOURCE.pptx FINAL.pptx FIXED.pptx --work RUN_DIR
# 用 FIXED.pptx 重新渲染 FIXED.pdf。
python3 scripts/native-combo-workbook.py FIXED.pptx FIXED.pdf CHARTS.xlsx --page PAGE --chart-index INDEX --source SOURCE.pptx --work RUN_DIR
```

修復時依原稿的數列名稱、類型、分類與實際數值逐一配對，承接數列及單一資料點的標籤例外。工作交接所列的筆數或概括總數只有摘要作用。只有確認原話對特定數列另有明確指定時才覆寫。每條數列的值與顯示標籤的點數分別核對。輸出保有原生圖表、內嵌工作簿原數值、三者間的範圍關聯及 PowerPoint 畫出的雙軸範圍。靠近折線標籤的數量柱會留出數字顯示空間。以 Google Drive 的 import_spreadsheet（native_google_sheets）將這份 XLSX 匯入本件工作資料夾，作為交付的圖表試算表。讀回該表的 spreadsheetId、對應分頁及 chartId，再以 Google Slides createSheetsChart、linkingMode=LINKED 放回 PowerPoint 的圖表位置。若該處已有轉檔點陣圖，先辨識對應位置，於同一批次替換並刷新。

從正式 Google 簡報的最新原生 PDF，以實際交付尺寸確認兩側所有刻度和最頂端、每個標籤的字與位置、圖例及上下圖說；同時讀回該頁的 sheetsChart 連至剛交付的試算表和圖表 ID。均通過即保留這份原生圖與源自儲存格的資料標籤，直接交付。匯入後重新送 updateChartSpec 可能清掉副軸範圍。原生標籤不合格時重新匯入可更新圖表。


### 可更新標籤的驗收

進行可編輯交付時，`work-foreground.mjs verify` 與 `linked-chart-run.py` 預設都核對工作試算表的圖表規格、實際匯出儲存格與最終 Slides 物件。原生 DATA 標籤直接讀數列。CUSTOM 標籤須指向同筆原資料，或由該資料格透過公式得出。原稿未顯示標籤的數列照原樣顯示。把數字另貼成 Slides 文字不會通過。

- 收到 `native_labels_live`，保留現有圖表並完成原生 Slides PDF 的軸、字級、標籤與可見性核對。兩者都通過即可交付。
- 收到 `remove_legacy_chart_text`，依該修訂一次送出清除本圖已辨識裝飾物件的 slides_requests，刷新同一個原生圖再驗。來源圖說及其他頁面物件維持各自歸屬。
- 收到 `reimport_native_combo`，回到上述 XLSX 原生匯入，從同工作資料夾的交付試算表讀取它真正的 chartId，將正確的原生圖放回同一頁面並清除先前本圖的工作室疊字。刷新及匯出後重驗。
- 完整 Sheets 規格可取自原生 spreadsheets.get（含 sheets.charts）或本件 Sheets 工具回傳的 updatedSpreadsheet。連接器的 charts_only 通常只有 ID。在僅支援 batchUpdate 讀回完整規格時，使用不改變儲存格的 findReplace（本次產生、整格不匹配的標記，find 與 replacement 相同，allSheets），併回傳完整試算表；無須改寫 chartSpec。另讀回同表的原生 XLSX 匯出。

製作前從實際原稿列出每張原生圖表的數列及應顯示標籤的資料點。交接資料只有頁數或沒有列圖表時也照常執行。定稿後對真正交付的 PowerPoint 再列一次。兩份清單中的數列、資料點和顯示值應對得起來；原稿刻意隱藏的資料點保持隱藏。

```sh
python3 scripts/chart-fidelity.py inventory SOURCE.pptx > source-charts.json
python3 scripts/chart-fidelity.py inventory FINAL.pptx > final-charts.json
```

對每張圖由 `plan` 量測定稿 PowerPoint 的實際渲染，依 references/visible-delivery.md 記錄該版 Google 圖表每個資料點的文字、位置、字級與圖例、刻度。重複的值依數列及資料點分別計算，同一個文字不能充當兩個不同位置。將報告以 `verified.chart_visual_audit` 交給工作驗收程式，該程式會從兩份 PPTX 讀回實際清單，並對本次 Google 原生 PDF 檢查標籤。也可單獨執行以下檢查。

```sh
python3 scripts/chart-fidelity.py verify-export slides-export.pdf chart-visual-audit.json
```

若圖表匯出成圖片，在最新原生 PDF 放大程式指出的 `rect`。只有從該位置實際讀到標籤，才在該筆 `pixel_review` 記錄這次的 `crop_sha256` 與讀到的 `transcription`。數值已經不在畫面上時，依下列流程修復同一張連結圖表；重新匯出後再驗。一張原圖有 5 個柱狀標籤與 5 個折線標籤時，驗收會逐一核對 10 個位置。圖表原來沒有資料標籤時，沿用原設定。

適用於具有一組直條與折線、左右數值軸的可編輯組合圖。每次確認製作後自行執行到 `verified`。所有寫入使用本次製作的圖表試算表和 Google 簡報。先保存 PowerPoint 中真正可編輯、包含資料活頁簿的圖表，再以該 PPTX 的最終渲染為字體與標籤基準。

```sh
python3 scripts/linked-chart-run.py final.pptx ppt-render.pdf slides-export.pdf slides.json chart.json sheet-export.xlsx chart-state.json --page 8 > packet.json
```

頁數依實際圖表調整。腳本與同目錄的 `linked-chart-text.py`、`chart-fidelity.py` 一起使用。Python 須提供 PyMuPDF、numpy、python-pptx、openpyxl 和 Pillow。

Work 對每個適用的連結圖表，都先以最新的真實成品執行上述指令驗收。兩版顯示相同刻度、標籤數目與字級時，也要確認實際資料點在兩軸的位置。即使 Sheets 的圖例和資料標籤已經關閉，仍會檢查來源右軸的顯示範圍與校正資料。上下限依本次 PowerPoint 的明示範圍與實際可見刻度取得；百分比依其實際小數寫入 Sheets。軸上的各個標籤、字級和位置在刷新後以 PowerPoint 為基準逐項投影，在最後匯出的 Google PDF 中逐項量測。來源欄、其他資料列和左軸保留。

- `ppt-render.pdf` 來自本次最終 PowerPoint。`slides-export.pdf` 來自本次 Google 簡報的原生 PDF 匯出。每次送出 Google 更新後重新匯出。
- `slides.json` 是同份簡報的最新 `presentations.get` 結果。保留簡報與 revision ID、pageSize、頁面及元素的 ID、size、transform、sheetsChart。
- `chart.json` 儲存工作試算表的完整 EmbeddedChart，含 chartId、spec、position。建立或修改圖表時使用 `includeSpreadsheetInResponse: true` 並保存回傳物件，也能直接提供含 charts 的 updatedSpreadsheet。僅有 chartId 的結果不足以使用。
- `sheet-export.xlsx` 是本次已連結 Google 試算表的實際 XLSX 匯出，內含該圖及來源數值。工具會核對數列及顏色，並找出可用的校正欄。`chart-state.json` 只供本次相同圖表接續，首次執行可不存在。

### 轉檔只留下試算表超連結時

使用者選擇可編輯簡報時，從 **同一頁定稿 PowerPoint 的可見圖表位置** 檢查 Google 簡報。讀回該處 sheetsChart 的 spreadsheetId、chartId 與 element objectId，記入各圖的驗收列 `spreadsheet_id`、`chart_id` 和 `native_object_id`。再核對該工作試算表實際列有相同 chartId。準備 pageElements 時保留疊放順序、元素類型、圖片和圖形的屬性以及群組子項。驗收同時檢查原生圖表的位置、大小及覆蓋在上面的整塊圖片。

如果該處的 image 帶工作試算表網址，對同一份工作簡報執行 `linked-chart-run.py` 加 `--sheet-meta SHEETS.json`。一個工作簿有多個圖表時加 `--chart-id ID`，並用 `--chart-index` 選擇此 PowerPoint 頁上的對應圖。若 Sheets 連接器分別提供 spreadsheetId 與圖表清單，先核對兩次讀取的工作試算表 ID，再按同一 sheetId 合併。收到 `relink` 時，以該修訂的 writeControl 一次送出 slides_requests。它會將真正 LINKED 圖表放回原框和圖層，移除已核對的轉檔圖片，並刷新圖表。重新讀回物件與原生 PDF，再接著修整數值、圖例及刻度。遇到修訂衝突或不明回應，重新讀取目前物件再執行。

原位置只有不帶連結的截圖時，先逐張對照該頁 PowerPoint 確認它確實是轉檔圖，才加 `--static-image OBJECT_ID`。原稿本來就是截圖的資料不走這條路徑。若手中只有簡短的 chartId 清單，可以先使用以下獨立入口產生重連請求；隨後為標籤修復讀回完整圖表規格。目標工作檔以外的原件照原權限保存。

```sh
node scripts/linked-chart-slot.mjs slides.json spreadsheet-with-charts.json CHART_ID pptx-chart-reference.json
```

同頁圖表縮在角落、移出畫面或被整張圖表截圖遮住時，先恢復正式圖表的位置與可見性。若 Google 的右軸刻度、圖例或來源要求的資料標籤未印出，以本頁的原生匯入法重建並刷新連結圖。調整位置時，連結圖與附加文字須一起移動。只剩一張點擊後開表的圖片時，仍在修復階段。

### 另行指定的靜態註解圖

僅在使用者明確另要靜態註解圖時，以 `--static-annotation-mode` 選用以下舊流程。涉及可更新圖表及資料標籤的交付使用上方原生匯入與驗收。

1. 收到 `prepare`，把 `sheets_requests` 送往回傳 spreadsheet_id 的 Sheets batchUpdate，並保存有完整圖表的回應。再把 `refresh_requests` 送往該 presentation_id 的 Slides batchUpdate。讀回 Google 最新簡報、原生 PDF、Sheets 圖表及 XLSX，保留同一個 state，再跑同一指令。若連接器省略完整回應，且實際 Sheets 寫入與 Slides 刷新都已成功，可搭配原先完整 chart.json 及 `--applied-prepare`。
   收到 `refresh` 表示已讀回校正範圍，但仍拿到先前同一修訂和 PDF。這時只需呼叫 `refresh_requests`，再讀回簡報的最新修訂、原生 PDF 及 XLSX，接續同一個 state。
2. 收到 `project`，把全部 `slides_requests` 連同 `write_control`（對應 API 的 writeControl）送往指定簡報的一次 batchUpdate。這會保留可更新的連結圖表，在其上加入可編輯、對應實際資料點的文字。遇到版本衝突就重讀同份簡報並重跑。更新後再次讀回匯出的原生 PDF 和目前 metadata，再跑同一指令。
   收到 `reposition` 時依同樣方式送出整批 Slides 請求。即使所有標籤文字與字級均符合，工具仍檢查頁面邊緣和圖例下方的原有圖說。空間足夠時將連結圖表與自己的校正物件一起平移，再讀回最新原生 PDF 驗收。
3. 只有 `verified` 表示已從重新匯出的畫面逐項量到預期值、字級與位置。再查看該頁完整畫面，確認圖表周圍的投影片文字與圖像也完整。若收到 `needs_review` 或偵測不到預期的圖形，保留具體缺項，修正相應圖表後使用新資料重驗。其他可完成頁面及輸出繼續製作。圖表來源資料更新後也要重新執行，以同步可編輯標籤。

### Google 忽略雙軸設定時

校正原有右軸、刷新後，程式從 Google PDF 所包含的連結圖表像素量出資料柱與折線位置，再用 PowerPoint 的刻度位置算出兩軸頂端與底端的實際差距。來源刻度與新圖吻合就繼續驗收。僅在量測超出容許誤差時啟用公式備援。

- `read_sheet_metadata` 指向原連結試算表。讀取它完整的 spreadsheetId、各分頁的 sheetId 與 title，存成 JSON，以上述命令加 `--sheet-meta sheet-meta.json` 接續；更新後重新讀取這份清單。
- `formula_axis` 提供一次 Sheets batchUpdate 所需的請求。它在同一本工作試算表新增為本圖命名的校正分頁，各欄以公式引用原始標題、分類及每個資料點。程式根據 PowerPoint 對應高度求出右軸到左軸的線性換算，保留原始表格和同一個 chartId、Slides 物件及連結。將全部請求在同一批次送出，刷新圖表，再讀回試算表、圖表與 Google 原生簡報 PDF。遇到重送或不明回應，先讀回原工作狀態。
- `restore_formula_series` 表示已驗明搬移後的真實圖表省略全部數列。將回傳的一項原圖規格更新送往同一個工作圖表，再讀回各數列、刷新並重新匯出。
- 同一個 state 保存來源、原圖規格、分頁識別與公式對應。重新執行會驗讀原始數列、每格公式與匯出的實際計算值、可見數列及圖表連結，再以原始數值和單位投影可編輯的左右刻度與資料標籤。送出 `project` 或 `reposition` 後重新匯出；直到原生圖表像素的雙軸位置與 PDF 中實際字級、標籤及邊界同時通過才完成。另檢查圖表旁原有箭頭、圖說及多餘的格線。
