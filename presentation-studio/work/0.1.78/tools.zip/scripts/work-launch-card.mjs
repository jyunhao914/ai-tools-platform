// Portable card logic. The DIL host can inline these functions without imports.
// Binding is returned by reread-stage after reading the actual private document.
const fields = [
  "settings", "delivery", "page_overrides", "object_overrides", "page_profiles",
  "requirements", "layout_instruction", "slide_size", "image_policy"
];
export const refinedLaunch = "接續製作。請在 Work 依 Presentation Studio 0.1.78 正式流程執行。先讀 https://jyunhao914.github.io/ai-tools-platform/presentation-studio/work/0.1.78/release.json，核對同版工具並執行收件，再按下列已確認設定製作。\n精緻型依內容換構圖，小圖與圖示做真正透明背景；Google 使用可更新的連結圖表；刻度及資料標籤留在圖表本身，修改試算表時數值隨刷新改變。逐軸、逐筆核對圖表本身與實際投影片。保留全部數列與資料點。可見標籤按使用者原話與原稿逐點核對，同類圖形的指定總數不乘上數列數；原本隱藏的讀值只在使用者明確指定時顯示。\n只驗收本次所選成品。從 Drive 下載實際交付的 PPTX；Google 簡報用原生 API、PDF 及圖件或頁面縮圖核對，試算表用 Sheets 讀回。沿用既有私人權限，所選檔案全部通過，就在同一回合交付各自連結。略過 Google 簡報轉回 PPTX 和瀏覽器下載授權。";
const finalAcceptance = refinedLaunch.split("\n").at(-1);
const refinedWorkEntry = "Work 請開啟 Presentation Studio 的 studio-resume，讀取本次實際安裝版本和製作工具。"
  + "未掛載時從 https://jyunhao914.github.io/ai-tools-platform/presentation-studio/release.json 核對正式安裝包和 SHA-256。"
  + "用原稿實檔執行收件 claim --start-dir RUN_DIR --source-file SOURCE.pptx，"
  + "接續 start-work 及 work-next 的實際回傳；組裝使用審核素材與 compose-refined.py --art 的構圖、交付前核對所有成品。";

export function buildWorkCommand(binding, changes = {}) {
  if (!binding || !/^https:\/\/docs\.google\.com\/document\/d\/[\w-]+\/edit$/.test(binding.doc_url) ||
      !/^[0-9a-f]{64}$/.test(binding.draft_sha256)) {
    throw new Error("請先讀回本次私人交接草稿。");
  }
  if (!changes || typeof changes !== "object" || Array.isArray(changes) ||
      Object.keys(changes).some(key => !fields.includes(key))) {
    throw new Error("原稿或定稿內容已變更，請先儲存該版本。");
  }
  const packet = {doc_url: binding.doc_url, draft_sha256: binding.draft_sha256, changes};
  let note = binding.source_note;
  if (typeof note !== "string") {
    // A previous release provided source-specific directions without a separate note.
    const oldPick = binding.directions?.split("\n").find(line => line.startsWith("按「檔案」"));
    note = oldPick ? [oldPick, sendFiles, receiveAttached].join("\n") : "";
    if (!binding.directions) note = "若這份工作需要上傳或檔案庫原稿，" + attachmentNote("這次使用的原稿");
  }
  const choices = binding.production_choices ?? {};
  let labelRules = choices.chart_label_authorizations;
  if (changes.requirements) {
    if (Object.hasOwn(changes.requirements, "chart_label_authorizations")) {
      labelRules = changes.requirements.chart_label_authorizations;
    } else if (labelRules?.length) {
      packet.changes = {...changes, requirements:{...changes.requirements, chart_label_authorizations:labelRules}};
    }
  }
  const settings = changes.settings ?? {format:choices.format, editable_profile:choices.profile};
  const profiles = changes.page_profiles ?? choices.page_profiles ?? {};
  const useRefined = (settings.format == null || settings.format === "editable") &&
                     (settings.editable_profile === "refined" || Object.values(profiles).includes("refined"));
  let folder = choices.folder;
  if (Object.hasOwn(changes,"delivery")) {
    folder = choices.fixed_folder;
    const selected = changes.delivery;
    if (typeof selected?.folder_id === "string" && /^[A-Za-z0-9_-]+$/.test(selected.folder_id)) {
      folder = "將本次 Drive 成品都存入已選工作資料夾 " + selected.folder_id + "。";
    } else if (!folder && selected?.new_folder === true) {
      folder = "依本次設定建立私人工作資料夾並取得 ID，將本次 Drive 成品存入其中。";
    }
    if (folder && folder !== choices.fixed_folder) folder += "交付前逐檔讀回 Drive parents，錯放根目錄時移入該資料夾再核對。";
  }
  return [useRefined ? (choices.launch_header || refinedLaunch) : finalAcceptance, chartLabelText(labelRules),
          "接續製作。請在網頁 Work 讀回下列私人交接文件，依本次已確認的設定製作並交付。", note, useRefined ? (choices.refined || refinedWorkEntry) : "", folder, "PS-WORK-CARD/1 " + JSON.stringify(packet)].filter(Boolean).join("\n");
}

const paste = "複製下方完整指令，在同一帳號的 ChatGPT 首頁開啟「工作（Work）」，選用 Presentation Studio，再貼上指令。";
const sendFiles = "看到檔案出現在輸入框後，將檔案和指令一起送出一次。";
const receiveAttached = "Work 收件後，請優先讀取這則訊息實際附入的原檔，核對來源與內容後接續製作。";
function chartLabelText(rules) {
  return (rules || []).map(rule => "第 " + rule.page + " 頁" + (rule.chart ? "「" + rule.chart + "」" : "") +
    "，資料標籤依使用者原話「" + rule.user_quote + "」。").join("\n");
}

function attachmentNote(name) {
  return "送出前，請在 Work 的「檔案 → 搜尋空間中的檔案」選取" + name +
         "，看到原稿出現在輸入框再與本指令一起送出。\n" + receiveAttached;
}

function pickSource(name) {
  return "按「檔案」→「搜尋空間中的檔案」（有些介面顯示「檔案庫」），選取" + name +
         "，核對檔名與版本。若檔案庫找不到，直接附上這次的原檔。";
}

// Older private draft bindings carried only the document URL and digest.
// That URL describes the settings document. It says nothing about the source.
export const workDirections = [paste, "若原稿來自上傳或檔案庫，" + pickSource("這次使用的原稿") +
  sendFiles, "已有核對的 Drive 原稿、同版私人備份，或只用簡報大綱時，將指令送出一次。"].join("\n");

function driveSource(value) {
  if (typeof value !== "string") return false;
  if (/^drive:[\w-]+$/.test(value)) return true;
  let url;
  try { url = new URL(value); } catch { return false; }
  if (url.protocol !== "https:" || url.username || url.password) return false;
  if (url.host === "drive.google.com") {
    return /^\/file\/(?:u\/\d+\/)?d\/[\w-]+(?:\/(?:view|edit|preview))?\/?$/.test(url.pathname) ||
           (url.pathname === "/open" && /^[\w-]+$/.test(url.searchParams.get("id") || ""));
  }
  return url.host === "docs.google.com" &&
         /^\/(?:document|presentation|spreadsheets)\/(?:u\/\d+\/)?d\/[\w-]+(?:\/(?:view|edit|preview))?\/?$/.test(url.pathname);
}

function requiredAttachment(plan) {
  const sources = Array.isArray(plan.sources) ? plan.sources : [];
  const fileEntries = sources.filter(item => item && typeof item === "object" ?
    ![item.url,item.reference,item.id,item.file_id].some(driveSource) : !driveSource(item));
  const {source_ref: ref, source_revision: revision, source_mirror: mirror} = plan;
  const outline = plan.adopted_outline && (!ref || ref === "adopted-outline") && !plan.source_url && !sources.length;
  const verifiedMirror = mirror && sources.length <= 1 && /^[\w-]+$/.test(mirror.file_id || "") &&
    !/^(?:file_[0-9a-f]{32}$|libfile_)/.test(mirror.file_id) && /^[0-9a-f]{64}$/.test(mirror.sha256 || "") &&
    (!plan.source_sha256 || mirror.sha256 === plan.source_sha256) &&
    (!/^[0-9a-f]{64}$/.test(revision) || mirror.sha256 === revision);
  const fromDrive = !String(revision).startsWith("upload:") && (sources.length ?
    fileEntries.length === 0 : driveSource(ref) || driveSource(plan.source_url));
  if (outline || (ref !== "attached-in-work" && (verifiedMirror || fromDrive))) {
    return null;
  }
  const names = sources.length <= 1 && plan.source_name ? [plan.source_name] : fileEntries.map(item => item?.name);
  const target = names.filter(s => typeof s === "string" && s.trim())
                      .map(s => "「" + s.trim().replace(/\s+/g, " ") + "」").join("、");
  return target || "這次使用的原稿";
}

// Host-built text packets can reach this view without running the Python sender.
function pendingSourcePreparation(plan) {
  const storage = plan.source_storage;
  if (storage === undefined) return null; // Previously confirmed packets stay readable.
  const failureCodes = ["access_denied","dns","transfer_failed","not_materialized",
                        "tool_unavailable","private_folder_unverified","copy_not_verified"];
  if (!storage || !["attachment_only","private_folder"].includes(storage.mode)) {
    throw new Error("請先套用本件原稿的暫存選擇。");
  }
  if (storage.mode === "attachment_only" && plan.source_mirror) throw new Error("這次只用附件，請移除私人副本引用。");
  if (failureCodes.includes(plan.source_read_error) && !plan.source_mirror) return null;
  if (!/^[0-9a-f]{64}$/.test(plan.source_sha256 || "")) return "read_original";
  if (storage.mode === "private_folder") {
    if (!/^[A-Za-z0-9_-]+$/.test(storage.folder_id || "")) throw new Error("缺少已授權的私人資料夾。");
    const verified = plan.source_mirror?.sha256 === plan.source_sha256 &&
                     plan.source_mirror_folder_id === storage.folder_id;
    if (!verified && !failureCodes.includes(plan.source_copy_error)) return "verify_private_source_copy";
  }
  return null;
}

// Confirm exclusively changes the local card display. The user starts production
// by pasting its output into Work. There is deliberately no host send callback.
export function confirmInChat(binding, changes, show) {
  const command = buildWorkCommand(binding, changes);
  show({command, directions: binding.directions || workDirections});
  return command;
}

// The host may render this locally, without posting a message. The text remains selectable
// when clipboard permission is unavailable in an embedded card.
export function renderWorkInstruction(container, view) {
  const doc = container.ownerDocument;
  const directions = doc.createElement("p");
  directions.textContent = view.directions;
  const field = doc.createElement("textarea");
  field.setAttribute("aria-label", "完整 Work 啟動指令");
  field.readOnly = true;
  field.rows = 8;
  field.style.width = "100%";
  field.value = view.command;
  const copy = doc.createElement("button");
  copy.type = "button";
  copy.textContent = "複製完整指令";
  copy.addEventListener("click", async () => {
    field.focus();
    field.select();
    try {
      await doc.defaultView.navigator.clipboard.writeText(field.value);
      copy.textContent = "已複製";
    } catch {
      copy.textContent = "已選取全文，可直接複製";
    }
  });
  container.replaceChildren(directions, field, copy);
}

// Parse just the first complete JSON object. Directions may follow on a new
// line; a brace inside a quoted title or a note must not end the packet.
function readPortableEnvelope(text) {
  if (!text.startsWith("{")) throw new Error("請確認交接設定完整。");
  let depth = 0;
  let quoted = false;
  let escaped = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') quoted = false;
    } else if (ch === '"') quoted = true;
    else if (ch === "{") depth++;
    else if (ch === "}" && --depth === 0) {
      const rest = text.slice(i + 1).trimStart();
      if (/^[{\[]/m.test(rest) || (rest && !/^[ \t]*[\r\n]/.test(text.slice(i+1)))) break;
      return {value:JSON.parse(text.slice(0, i + 1)), end:i + 1};
    }
  }
  throw new Error("請確認交接設定完整。");
}

// Call before choosing a final control. A host that can only post a chat message
// receives plain text. No method in this module can post, transfer or start a job.
export function finalHandoffView({binding, changes = {}, portableMessage, settingsFixed = false,
                                  localReveal = false, selectableText = false}) {
  if (binding && !settingsFixed && localReveal && selectableText) {
    const command = buildWorkCommand(binding, changes);
    return {kind: "local_button", type: "button", label: "確認設定，取得 Work 指令",
            reveal: () => ({command, directions: binding.directions || workDirections})};
  }
  if (!settingsFixed) return {kind: "collect_settings", label: "套用設定"};
  if (binding) return {kind: "copy_text", command: buildWorkCommand(binding, changes), directions: binding.directions || workDirections};
  if (Object.keys(changes).length) throw new Error("請先把最後修改合併到完整設定，再產生指令。");
  let command = typeof portableMessage === "string" ? portableMessage : portableMessage?.message;
  if (typeof command !== "string") throw new Error("請先取得本次原稿引用與設定，再提供可複製指令。");
  const markers = [...command.matchAll(/^[ \t]*PS-WORK-PLAN\/1(?=\s|$)/gm)];
  if (markers.length !== 1) throw new Error("缺少本次工作完整的可攜設定。");
  const marker = markers[0].index;
  const payload = command.slice(marker + markers[0][0].length).trimStart();
  // Some hosts put the JSON on the next line and append ordinary directions.
  const envelope = readPortableEnvelope(payload);
  const {plan} = envelope.value;
  const hashBoundUpload = /^file_[0-9a-f]{32}$/.test(plan?.source_ref) && /^[0-9a-f]{64}$/.test(plan?.source_sha256);
  if ((!plan?.source_revision && !hashBoundUpload) || !plan.settings || !plan.delivery) throw new Error("指令缺少原稿版本或已選設定。");
  const pending = pendingSourcePreparation(plan);
  if (pending) return {kind: "prepare_source", action: pending};
  const refined = (plan.settings.format == null || plan.settings.format === "editable") &&
    (plan.settings.editable_profile === "refined" || Object.values(plan.page_profiles || {}).includes("refined"));
  // The host may have added display counts in prose that it computed from the
  // number of series. Only the literal request may specify such counts. The
  // packet and data inventory remain unmodified.
  const rules = plan.requirements?.chart_label_authorizations;
  if (Array.isArray(rules) && rules.length) {
    const quoted = rules.map(rule => rule.user_quote);
    const numericPhrase = /(?:[0-9零〇一二兩三四五六七八九十百千]+\s*(?:組|條|列)\s*各\s*)?[0-9零〇一二兩三四五六七八九十百千]+\s*(?:個|筆|組|項|枚)?\s*(?:柱狀|直條|長條|折線|線形|曲線)(?:圖)?(?:的)?(?:數值|百分比|讀值|資料標籤|標籤)/g;
    const authorized = prose => prose.replace(numericPhrase, phrase => quoted.some(q => q.includes(phrase)) ? phrase : "依使用者原話指定的標籤");
    const end = command.length - payload.length + envelope.end;
    command = authorized(command.slice(0,marker)) + command.slice(marker,end) + authorized(command.slice(end));
  }
  const markerAt = command.search(/^[ \t]*PS-WORK-PLAN\/1(?=\s|$)/m);
  if (refined && !command.slice(0, markerAt).includes("compose-refined.py --art")) {
    command = command.slice(0, markerAt) + refinedWorkEntry + "\n" + command.slice(markerAt);
  }
  if (refined && !command.startsWith(refinedLaunch + "\n")) command = refinedLaunch + "\n" + command;
  if (!refined && !command.includes(finalAcceptance)) command = finalAcceptance + "\n" + command;
  const exactLabels = chartLabelText(plan.requirements?.chart_label_authorizations);
  if (exactLabels && !command.includes(exactLabels)) {
    const point = command.search(/^[ \t]*PS-WORK-PLAN\/1(?=\s|$)/m);
    command = command.slice(0,point) + exactLabels + "\n" + command.slice(point);
  }
  const target = requiredAttachment(plan);
  if (!target) return {kind: "copy_text", command, directions: paste + "\n將指令送出一次。"};
  const note = attachmentNote(target);
  const packetAt = command.search(/^[ \t]*PS-WORK-PLAN\/1(?=\s|$)/m);
  const before = command.slice(0, packetAt);
  const copied = before.includes(note + "\n") ? command : before + note + "\n" + command.slice(packetAt);
  return {kind: "copy_text", command: copied, directions: [paste, pickSource(target), sendFiles].join("\n")};
}
