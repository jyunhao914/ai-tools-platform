#!/usr/bin/env python3
"""Carry the real PowerPoint combo, ranges and labels through Google's native XLSX importer."""
import argparse
import io
import json
import math
import posixpath
import runpy
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from lxml import etree as ET
from openpyxl import load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.utils.cell import range_to_tuple
from pptx import Presentation
from pptx.opc.constants import RELATIONSHIP_TYPE as RT

NS = {"c": "http://schemas.openxmlformats.org/drawingml/2006/chart",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
C = "{"+NS["c"]+"}"
A = "{"+NS["a"]+"}"


def window(ticks, axis):
    values = sorted({item["value"] for item in ticks})
    if len(values)<2:
        raise ValueError("Read two or more actual major ticks per value axis.")
    major = (values[-1]-values[0])/(len(values)-1)
    if any(not math.isclose(b-a,major,rel_tol=2e-5,abs_tol=major*1e-7) for a,b in zip(values, values[1:])):
        raise ValueError("Uneven visible ticks require the original explicit axis settings.")
    def bound(key, fallback):
        nodes=axis.xpath("c:scaling/c:"+key+"/@val",namespaces=NS)
        return float(nodes[0]) if nodes else fallback
    return bound("min", values[0]), bound("max", values[-1]), major


def numeric(node, key, value):
    element=node.find(C+key)
    if element is None:
        element=ET.SubElement(node,C+key)
    element.set("val",format(value,".15g"))


def series_range(workbook, series):
    formulas = series.xpath("c:val/c:numRef/c:f/text()", namespaces=NS)
    if len(formulas) != 1:
        raise ValueError("Use an editable chart with a single value range for each series.")
    title, bounds = range_to_tuple(formulas[0])
    return workbook[title.replace("''", "'")], bounds


def separate_labels(workbook, groups, series, bounds, width_cm):
    """Give close numeric column and percentage labels room within their category."""
    column = next(g for g in groups if g.tag == C+"barChart")
    axis_ids = lambda g: set(g.xpath("c:axId/@val", namespaces=NS))
    plot = column.getparent()
    left, = plot.xpath("c:valAx[c:axPos[@val='l']]/c:axId/@val", namespaces=NS)
    right, = plot.xpath("c:valAx[c:axPos[@val='r']]/c:axId/@val", namespaces=NS)
    line = next(g for g in groups if g.tag == C+"lineChart")
    columns = column.findall(C+"ser")
    if len(columns) != 1 or left not in axis_ids(column) or right not in axis_ids(line):
        return
    sources = [(g, s) for g in groups for s in g.findall(C+"ser")]
    info = {id(el): row for (_, el), row in zip(sources, series)}
    bars = info[id(columns[0])]
    if not bars["labels"] or min(bars["values"]) < 0:
        return
    labeled = {label["point"] for label in bars["labels"]}
    def fraction(n, side):
        b = bounds[side]
        return (n-b["min"])/(b["max"]-b["min"])
    close = False
    for el in line.findall(C+"ser"):
        data = info[id(el)]
        for label in data["labels"]:
            i = label["point"]
            if i in labeled:
                delta = fraction(bars["values"][i], "LEFT_AXIS")-fraction(data["values"][i], "RIGHT_AXIS")
                close |= 0 <= delta <= .15
    if not close:
        return
    sheet,(x1,y1,x2,y2) = series_range(workbook, columns[0])
    cells=[sheet.cell(r,c) for r in range(y1,y2+1) for c in range(x1,x2+1)]
    # Sheets takes one label format per series. Reserve about one bar's
    # width so its native renderer moves the label above the column end.
    count = max(2,min(12,round(width_cm*96/2.54*.76/(len(cells)*13))))
    formats = {cell.number_format for cell in cells}
    if len(formats) != 1:
        return
    fmt = formats.pop()
    if fmt == "General":
        if any(not float(v).is_integer() for v in bars["values"]):
            return
        fmt = "0"
    if any(char not in "0#.," for char in fmt):
        return
    for cell in cells:
        cell.number_format = '"' + '　'*count + '"' + fmt


def theme_colors(shape):
    theme=shape.part.slide_layout.slide_master.part.part_related_by(RT.THEME)
    doc=ET.fromstring(theme.blob)
    colors={}
    for token in doc.xpath("//a:clrScheme/*",namespaces=NS):
        child=next(iter(token),None)
        if child is not None:
            colors[ET.QName(token).localname]=child.get("lastClr") or child.get("val")
    return colors


def save_workbook(pptx,pdf,page,index,destination,source=None,work=None):
    helper=runpy.run_path(str(Path(__file__).with_name("linked-chart-text.py")))
    deck=Presentation(pptx)
    shape=[s for s in deck.slides[page-1].shapes if s.has_chart][index]
    part=shape.chart.part
    original_xml=part.blob
    policy=None;patches={}
    if work is not None and source is None:
        source=Path(json.loads((work/"work.json").read_bytes())["source_file"])
    if source is not None:
        controls=runpy.run_path(str(Path(__file__).with_name("source-chart-labels.py")))
        report,patches=controls["reconcile"](source,pptx,controls["authorizations"](work,source),include_inventory=True)
        if report["issues"]:raise ValueError(str(report["issues"]))
        matches=[r for r in report["charts"] if (r["page"],r["chart_index"])==(page,index)]
        if len(matches)!=1:raise ValueError("Identify this chart in the original PowerPoint before importing its workbook.")
        policy=matches[0]
        original_xml=patches.get(str(part.partname).lstrip("/"),original_xml)
    with TemporaryDirectory() as tmp:
        reference=pptx
        if policy and policy["changed"]:
            # Use only the approved points for measuring the source axes, even
            # when the supplied rendering still contains an extra set of labels.
            reference=Path(tmp)/"source-policy.pptx"
            controls["write_copy"](pptx,reference,patches)
        region,_,series,axes,sw,sh=helper["chart_reference"](reference,pdf,page,index)
    doc=ET.fromstring(original_xml)
    groups=doc.xpath("//c:plotArea/*[c:ser]",namespaces=NS)
    if len(groups)!=2 or {ET.QName(g).localname for g in groups}!={"barChart","lineChart"}:
        raise ValueError("The native import route requires a two-axis column and line chart.")
    path=doc.find("c:externalData",NS)
    if path is None:
        raise ValueError("Embed the editable workbook in the final PowerPoint first.")
    wb=load_workbook(io.BytesIO(part.related_part(path.get("{"+NS["r"]+"}id")).blob))
    doc.remove(path)
    all_series=doc.xpath("//c:plotArea/*/c:ser",namespaces=NS)
    sheet,_=series_range(wb,all_series[0])
    for s in all_series:
        series_range(wb,s)
    if doc.xpath("//@r:id|//@r:embed|//@r:link",namespaces=NS):
        raise ValueError("Resolve external chart resources before creating a standalone workbook.")
    # PowerPoint uses fractional manual legend boxes. Sheets imports their
    # nominal side position and ignores those boxes, sometimes wrapping every
    # letter. Let Sheets reserve its own horizontal legend and plot room.
    legend=doc.find(".//c:legend",NS)
    if legend is not None:
        for node in legend.findall(C+"layout"):
            legend.remove(node)
        position=legend.find(C+"legendPos")
        if position is None:
            position=ET.Element(C+"legendPos");legend.insert(0,position)
        position.set("val","t")
    area=doc.find(".//c:plotArea",NS)
    for node in area.findall(C+"layout"):
        area.remove(node)
    colors=theme_colors(shape)
    for e in doc.xpath("//c:ser/c:spPr//a:schemeClr",namespaces=NS):
        v=colors.get(e.get("val"))
        if v:
            e.tag=A+"srgbClr";e.set("val",v)
    bounds={}
    for loc,key in [("l","LEFT_AXIS"),("r","RIGHT_AXIS")]:
        axis,=doc.xpath("//c:valAx[c:axPos[@val=$side]]",namespaces=NS,side=loc)
        if axis.find("c:scaling/c:logBase",NS) is not None:
            raise ValueError("This importer requires a linear scale.")
        low,high,unit=window(axes[key],axis)
        bounds[key]={"min":low,"max":high,"step":unit}
        # Sheets can omit the last tick when a decimal endpoint is infinitesimally
        # below its accumulated tick. This margin is one millionth of a major tick.
        render_max=high+unit*1e-6 if loc=="r" else high
        scale=axis.find(C+"scaling")
        numeric(scale,"max",render_max);numeric(scale,"min",low);numeric(axis,"majorUnit",unit)
    # Add a drawing relationship to the embedded workbook without rebuilding its data.
    shell=BarChart()
    shell.add_data(Reference(sheet,min_col=1,min_row=1,max_row=2))
    w,h=shape.width/360000,shape.height/360000
    shell.width=max(16,w);shell.height=shell.width*h/w
    # Excel and Google size a linked chart relative to different drawing
    # canvases. Keep the scale labels readable at the actual slide frame.
    factor = min(2, max(1, 1.4*shell.width/w))
    for block in doc.xpath("//c:legend|//c:valAx|//c:catAx|//c:chartSpace",namespaces=NS):
        props=block.xpath("c:txPr//a:defRPr|c:txPr//a:endParaRPr",namespaces=NS)
        default=next((int(r.get("sz")) for r in props if r.get("sz")),900)
        for prop in props:
            prop.set("sz",str(round(int(prop.get("sz",default))*factor)))
    separate_labels(wb,groups,series,bounds,shell.width)
    anchor="A"+str(sheet.max_row+3)
    sheet.add_chart(shell,anchor)
    temp=io.BytesIO();wb.save(temp)
    with ZipFile(temp) as src,ZipFile(destination,"w") as dst:
        drawing=next(d for d in reversed(src.namelist()) if d.startswith("xl/drawings/") and "/_rels/" not in d and d.endswith(".xml") and b":chart" in src.read(d))
        d=ET.fromstring(src.read(drawing));link=d.xpath("//*[local-name()='chart']/@r:id",namespaces=NS)[-1]
        relfile=posixpath.join(posixpath.dirname(drawing),"_rels",posixpath.basename(drawing)+".rels")
        target=ET.fromstring(src.read(relfile)).xpath("//*[@Id=$id]/@Target",id=link)[0]
        chartfile=target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(posixpath.dirname(drawing),target))
        for item in src.infolist():
            dst.writestr(item,ET.tostring(doc,encoding="UTF-8",xml_declaration=True,standalone=True) if item.filename==chartfile else src.read(item))
    return {"page":page,"chart_index":index,"source_label_policy":policy,"sheet":sheet.title,"ranges":bounds,"anchor":anchor,
            "chart_frame":[region.x0/sw,region.y0/sh,region.x1/sw,region.y1/sh],
            "series":[{"name":s["name"],"labels":[v["text"] for v in s["labels"]]} for s in series]}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("pptx",type=Path);p.add_argument("pdf",type=Path)
    p.add_argument("xlsx",type=Path);p.add_argument("--page",type=int,required=True)
    p.add_argument("--chart-index",type=int,default=0)
    p.add_argument("--source",type=Path,help="Original supplied PowerPoint; inherit label visibility from its actual chart.")
    p.add_argument("--work",type=Path,help="Accepted Work directory and scoped chart-label authorizations.")
    a=p.parse_args()
    if a.source is None and a.work is None:
        p.error("Supply --source ORIGINAL.pptx or --work RUN_DIR to derive mandatory label settings from the original.")
    print(json.dumps(save_workbook(a.pptx,a.pdf,a.page,a.chart_index,a.xlsx,a.source,a.work),ensure_ascii=False))
