// Drive the owned Work run using live host callables. This process cannot wake a closed web turn.
import {execFile} from "node:child_process";
import {createHash} from "node:crypto";
import {readFile, writeFile, mkdir, realpath, rename} from "node:fs/promises";
import path from "node:path";
import {fileURLToPath} from "node:url";
import {promisify} from "node:util";
import {chartWorkbookDelivery, chartArtifactIssues, chartRequirements} from "./chart-workbooks.mjs";
import {refinedDesignIssues, refinedPages} from "./refined-design.mjs";
import {visibilityIssues} from "./visible-release.mjs";

const execute = promisify(execFile);
const here = path.dirname(fileURLToPath(import.meta.url));
const hash = data => createHash("sha256").update(data).digest("hex");
const json = async file => JSON.parse(await readFile(file,"utf8"));
const valid = s => typeof s==="string" && Boolean(s.trim());

async function cli(args) {
  const {stdout} = await execute(process.env.PRESENTATION_STUDIO_PYTHON || "python3",
    ["-B",path.join(here,"editable-image-queue.py"),...args],{maxBuffer:16*1024*1024});
  return JSON.parse(stdout);
}

export function requestedOutputs(delivery) {
  const aliases = new Map([
    ["pptx","pptx"],["powerpoint","pptx"],["editable_pptx","pptx"],["downloadable_pptx","pptx"],
    ["slides","slides"],["google_slides","slides"],["google slides","slides"],["native_slides","slides"],
    ["sheets","sheets"],["google_sheets","sheets"],["google sheets","sheets"],["chart_workbooks","sheets"],
    ["chart_spreadsheet","sheets"],["chart_spreadsheets","sheets"]]);
  const found=new Set();
  const add=key=>{const normalized=aliases.get(String(key).toLowerCase());if(normalized)found.add(normalized);};
  if (Array.isArray(delivery)) {
    for(const key of delivery) add(typeof key==="string"?key:key?.format??key?.kind??key?.type);
  } else if (typeof delivery==="string") add(delivery);
  else for(const [key,v] of Object.entries(delivery??{})) {
    if (key==="formats" || key==="deliverables" || key==="outputs") {for(const f of requestedOutputs(v)) found.add(f);continue;}
    if(v===true || (v && typeof v==="object" && v.required!==false && v.enabled!==false)) add(key);
  }
  return [...found];
}

function sameDocument(url,service,id) {
  if (!valid(url) || !valid(id)) return false;
  try {
    const u=new URL(url);
    return u.origin==="https://docs.google.com" && u.pathname.split("/").slice(1,4).join("/")===[service,"d",id].join("/");
  } catch { return false; }
}

async function verifyStandaloneBooks(dir,evidence) {
  const books=[],issues=[];
  for(const item of evidence.sheet_exports??[]) {
    const file=(evidence.drive?.sheets??[]).find(s=>s.id===item.id);
    if (!valid(item.id) || !sameDocument(item.url,"spreadsheets",item.id) ||
      (file?.mimeType??file?.mime_type)!=="application/vnd.google-apps.spreadsheet" || file.trashed ||
      !(file.parents??file.parent_ids)?.includes(evidence.folder_id) || !item.xlsx || !valid(item.export_sha256)) {
      issues.push("Read the linked native spreadsheet, working parent and authenticated XLSX export."); continue;
    }
    const local=await cli(["work-xlsx",dir,item.xlsx]);
    if (local.sha256!==item.export_sha256) issues.push("The actual XLSX export bytes differ.");
    else books.push({id:item.id,url:item.url});
  }
  if (!books.length) issues.push("No read-back native spreadsheet was supplied.");
  return {books,issues};
}

async function runFileCheck(script,args,stdin) {
  try {
    const task=execute(process.env.PRESENTATION_STUDIO_PYTHON || "python3",
      ["-B",path.join(here,script),...args],{maxBuffer:16*1024*1024});
    if (stdin!==undefined) task.child.stdin.end(JSON.stringify(stdin));
    const result=await task;
    return JSON.parse(result.stdout);
  } catch(error) {
    if(error.code===2 && error.stdout?.trim()) {
      try {return JSON.parse(error.stdout);} catch {}
    }
    throw error;
  }
}

export async function verifyWorkDelivery(dir, evidence) {
  const cp=await json(path.join(dir,"work.json")), files=evidence.files??{}, v=evidence.verified??{};
  const wanted=requestedOutputs(cp.delivery),formats=wanted.filter(k=>k!=="sheets");
  if (!wanted.length) return {action:"repair_delivery",issues:["Could not resolve the requested delivery formats from the accepted packet."]};
  if (wanted.length===1 && wanted[0]==="sheets") {
    const result=await verifyStandaloneBooks(dir,evidence);
    return result.issues.length?{action:"repair_delivery",issues:result.issues}:
      {action:"ready_to_publish",job_id:cp.receipt.job_id,revision:cp.receipt.revision,outputs:{chart_workbooks:result.books},verified_complete:false};
  }
  if (!files.pptx) return {action:"repair_delivery",issues:["Read back the physical editable PowerPoint"]};
  let actual;
  try {actual=await cli(["work-pptx",dir,files.pptx]);}
  catch(error) {return {action:"repair_delivery",issues:[error.stderr?.trim() || error.message]};}
  if (actual.action==="use_repaired_pptx") return {action:"repair_delivery",issues:[actual.repair],repaired_pptx:actual.pptx,local:actual};
  if(actual.action!=="verified_local_pptx")
    return {action:"repair_delivery",issues:[actual.photo_layout_variety?.reason || actual.repair || "Repair local editable deck."],local:actual};
  const plans=[await json(path.join(dir,"assets.json"))];
  try {plans.push(await json(path.join(dir,"redraws.json")));} catch(e) {if(e.code!=="ENOENT") throw e;}
  const declared=(cp.editable_charts??[]).map(row=>({page:row.page??row.page_number??row.source_page,count:row.count??1,formats:row.formats}));
  let physical, chartChecks;
  try {
    const [source,final]=await Promise.all([cp.source_file,files.pptx].map(file=>
      runFileCheck("chart-fidelity.py",["inventory",file])));
    if (source.pptx_sha256!==cp.source_sha256 || final.pptx_sha256!==actual.pptx_sha256)
      throw new Error("圖表檢查讀到的原稿或交付檔與本次檔案指紋不符。");
    if ((cp.art_requirements?.chart_label_authorizations??[]).some(row=>row.groups?.some(group=>group.series))) {
      const policy=await runFileCheck("source-chart-labels.py",["audit",cp.source_file,files.pptx,"--work",dir]);
      for (const row of policy.expected_series) {
        const original=source.charts.find(c=>c.page===row.page && c.shape_id===row.source_shape_id);
        if (original) original.series=row.series;
      }
    }
    chartChecks=chartRequirements(declared,source,final);
    physical=final.charts;
  } catch(error) {
    return {action:"repair_delivery",issues:[error.stderr?.trim() || error.message]};
  }
  const job={id:cp.receipt.job_id,source_key:cp.source_key,revision:cp.receipt.revision,pages:cp.pages,settings:cp.settings,
    assets:[...plans.flatMap(p=>p.assets),...(plans[0].native_source_replacements??[])].map(a=>({...a,page:a.page_number})),page_profiles:cp.page_profiles,
    visual_plan:evidence.visual_plan??cp.visual_plan,deliverables:formats,editable_charts:chartChecks.required,physical_charts:physical,chart_fidelity_version:1,
    work_folder_id:evidence.folder_id};
  const issues=[...chartChecks.issues];
  if (v.content_ok!==true || !valid(v.output_revision) || v.pages!==cp.pages || v.pptx_sha256!==actual.pptx_sha256)
    issues.push("Read back the actual PowerPoint SHA, final revision, page count and content comparison.");
  const folder=evidence.folder_id, drive=evidence.drive??{};
  function filed(row,id,mime) {
    return valid(folder) && valid(id) && row?.id===id && (row.mimeType??row.mime_type)===mime &&
      row.trashed!==true && (row.parents??row.parent_ids)?.includes(folder);
  }
  const cloudFolder=valid(folder) || Boolean(cp.delivery?.new_folder) || formats.includes("slides");
  if (formats.includes("pptx") && (!valid(v.pptx_ref) || (cloudFolder && !filed(drive.pptx,v.pptx_file_id,"application/vnd.openxmlformats-officedocument.presentationml.presentation"))))
    issues.push("Bind the downloadable PPTX and its Drive file in the owned folder.");
  if (formats.includes("pptx") && valid(v.pptx_ref) && /^https:\/\/(docs|drive)\.google\.com\//i.test(v.pptx_ref)) {
    const u=new URL(v.pptx_ref),parts=u.pathname.split("/"),at=parts.indexOf("d");
    const returned=at>=0?parts[at+1]:u.searchParams.get("id");
    if (!returned || returned!==drive.pptx?.id) issues.push("PowerPoint download points to another Drive file.");
  }
  if (formats.includes("slides") && (!sameDocument(v.url,"presentation",v.native_id) ||
      !filed(drive.slides,v.native_id,"application/vnd.google-apps.presentation")))
    issues.push("Bind the native Google Slides ID and actual Drive parent.");
  const scoped = cp.layout_change_pages == null ? null : new Set(cp.layout_change_pages);
  const locked = new Set((job.visual_plan?.pages ?? []).filter(page => page.layout_locked || page.approved_original_page)
    .map(page => page.page_number));
  const typographyPages = refinedPages(job).filter(page => (!scoped || scoped.has(page)) && !locked.has(page));
  for(const format of formats) {
    const render=files[format+"_pdf"];
    if (!render || hash(await readFile(render))!==v.visible_reports?.[format]?.pdf_sha256)
      issues.push("The "+format+" per-page QA does not describe the actual final PDF.");
    else if (typographyPages.length) {
      const type = await runFileCheck("check-refined-type.py",
        [files.pptx, render, "--pages", typographyPages.join(",")]);
      issues.push(...type.issues.map(issue => ({...issue, format})));
    }
  }
  const nativeDeck=v.chart_delivery?.presentation??v.presentation;
  const nativeFile=formats.includes("slides")
    ? files.slides_json || (nativeDeck ? await saveEvent(dir,nativeDeck) : null) : null;
  if (typographyPages.length >= 3) {
    const args=[cp.source_file,files.pptx,"--plan","-"];
    if (cp.composition_sha256) args.push("--roles",path.join(dir,"refined-composition.json"),"--roles-sha256",cp.composition_sha256);
    if (formats.includes("slides") && !nativeFile && files.slides_pptx)
      args.push("--slides",files.slides_pptx);
    const outcome=await runFileCheck("check-content-panels.py",args,{
      settings:cp.settings,page_profiles:cp.page_profiles,pages:cp.design_constraints,layout_change_pages:cp.layout_change_pages,
      visual_plan:job.visual_plan
    });
    issues.push(...outcome.issues);
  }
  const chartIssues=chartArtifactIssues(job,v,formats);
  issues.push(...visibilityIssues(job,v,formats),...refinedDesignIssues(job,v),...chartIssues);
  let exportIssues=[];
  if (formats.includes("slides") && physical.length && files.slides_pdf && v.chart_visual_audit?.rows?.length) {
    try {
      const result=await runFileCheck("chart-fidelity.py",["verify-export",files.slides_pdf,"-"],v.chart_visual_audit);
      exportIssues=result.issues;
      issues.push(...result.issues);
    } catch(error) {
      issues.push(error.stderr?.trim() || error.message);
    }
  }
  if(formats.includes("slides")) {
    if(actual.photo_layout_variety?.status==="pass") {
      if(!nativeFile) issues.push("Read the native Slides object geometry from this final revision.");
      else {
        const revision=v.output_revisions?.slides??v.output_revision;
        if(!valid(revision)||!valid(v.native_id)) issues.push("Read the final Slides ID and revision for photo frames.");
        else {
          const layout=await runFileCheck("photo-layout-variety.py",["check",dir,files.pptx,"--slides-json",nativeFile,
            "--slides-id",v.native_id,"--slides-revision",revision]);
          if(layout.status!=="pass") issues.push(layout.reason || "Repair the native final photo frames.");
        }
      }
    }
    const needDesign=actual.refined_design?.checked>0;
    const needDecoration=actual.decoration_redraws?.checked>0;
    const needProtected=actual.protected_image_geometry?.checked>0;
    if (typographyPages.length>=3 || needDesign || needDecoration || needProtected) {
      if (nativeFile && files.slides_pdf) {
        const revision=v.output_revisions?.slides??v.output_revision;
        const args=[files.pptx,nativeFile,files.slides_pdf,"--id",v.native_id??"","--revision",revision??""];
        if (files.slides_media) args.push("--media",files.slides_media);
        try {
          const cloud=await runFileCheck("native-delivery-objects.py",args);
          issues.push(...cloud.issues.map(issue=>({...issue,format:"slides"})));
        } catch(error) {issues.push(error.stderr?.trim() || error.message);}
      } else if (files.slides_pptx) {
        // Compatibility with a round-trip copy already supplied by an older run.
        const plan={settings:cp.settings,page_profiles:cp.page_profiles,pages:cp.design_constraints,
          layout_change_pages:cp.layout_change_pages,requirements:cp.art_requirements,visual_plan:job.visual_plan,...cp.media_scope};
        for (const [needed,script] of [[needDesign,"refined-design.py"],[needDecoration,"source-decoration.py"]]) {
          if (needed) {
            const checked=await runFileCheck(script,["check",cp.source_file,files.slides_pptx,"--plan","-","--run-dir",dir],plan);
            issues.push(...checked.issues.map(issue=>({...issue,format:"slides"})));
          }
        }
        if (needProtected) {
          const checked=await runFileCheck("protected-image-geometry.py",["check",cp.source_file,files.slides_pptx,"--run-dir",dir]);
          if (checked.status!=="pass") issues.push({reason:"Repair protected Google image geometry.",issues:checked.issues});
        }
      } else {
        issues.push("Read this Google presentation's pageElements, ID and revision into files.slides_json (or verified.presentation) and its native PDF into files.slides_pdf.");
      }
    }
  }
  const requiredNative=cp.settings.native_icon?.required;
  if (Number.isSafeInteger(requiredNative) && requiredNative>0) {
    const rows=v.design_review?.cutout_delivery?.checked_targets??[];
    if (rows.filter(t=>t.kind==="native_icon" && formats.every(f=>t.surfaces?.[f]?.status==="pass")).length<requiredNative)
      issues.push("The requested native editable icons need real delivery object readback.");
  }
  let books=[];
  if (formats.includes("slides")) {
    const result=chartWorkbookDelivery(job,{folder_id:folder},v,formats);
    books=result.books;issues.push(...result.issues);
  }
  if (wanted.includes("sheets") && !formats.includes("slides")) {
    const separate=await verifyStandaloneBooks(dir,evidence);books=separate.books;issues.push(...separate.issues);
  }
  if (wanted.includes("sheets") && !books.length) issues.push("Read back the required linked chart spreadsheet.");
  for (const book of books) if (!sameDocument(book.url,"spreadsheets",book.id) ||
      !(drive.sheets??[]).some(s=>filed(s,book.id,"application/vnd.google-apps.spreadsheet")))
    issues.push("Chart workbook identity or Drive parent is unverified.");
  const chartJobs=[];
  if (formats.includes("slides")) {
    for (const item of physical.filter(row=>row.dual_axis_combo)) {
      const siblings=physical.filter(row=>row.page===item.page);
      const chartIndex=siblings.indexOf(item);
      const row=v.chart_visual_audit?.rows?.find(r=>r.page===item.page && r.shape_id===item.shape_id)??{};
      const args=[files.pptx, files.pptx_pdf, files.slides_pdf, "--page",String(item.page),"--chart-index",String(chartIndex)];
      const ticks=files.pptx_pdf && files.slides_pdf ? await runFileCheck("linked-chart-ticks.py",args,row) :
        {issues:[{page:item.page,issue:"Read both final renderings for the quantitative axes."}]};
      issues.push(...ticks.issues);
      const target={page:item.page,shape_id:item.shape_id,chart_index:chartIndex,
        native_object_id:row.native_object_id,charts_on_page:siblings.length,needs_visual_readback:!row.native_object_id};
      const labels=await nextChartRepair(dir,evidence,target);
      const live=labels.stage==="native_labels_live";
      if (!live) issues.push({page:item.page,stage:labels.stage,reason:labels.reason??labels.next,format:"slides"});
      if (!live || ticks.issues.length || !row.native_object_id || chartIssues.some(msg=>String(msg).includes("第 "+item.page+" 頁")) ||
          exportIssues.some(problem=>problem.page===item.page)) chartJobs.push(target);
    }
  }
  if (issues.length) return {action:"repair_delivery",issues,...(chartJobs.length?{chart_jobs:chartJobs}:{})};
  return {action:"ready_to_publish",job_id:job.id,revision:job.revision,output_revision:v.output_revision,
    pptx_sha256:actual.pptx_sha256,outputs:{...(formats.includes("pptx")?{pptx:v.pptx_ref}:{}),...(formats.includes("slides")?{google_slides:v.url}:{}),
      ...(books.length?{chart_workbooks:books}:{})},verified_complete:false};
}

async function saveEvent(dir,row) {
  const events=path.join(dir,"events");await mkdir(events,{recursive:true});
  const bytes=JSON.stringify(row);
  const file=path.join(events,hash(bytes)+".json");
  await writeFile(file,bytes);
  return file;
}

// Resolve the specialist's Google requests for this *same* chart. Only a live host may apply them.
export async function nextChartRepair(dir, evidence, job) {
  const files=evidence.files??{}, v=evidence.verified??{};
  const native=v.chart_delivery?.presentation??v.presentation??(files.slides_json?await json(files.slides_json):null);
  const links=(native?.slides?.[job.page-1]?.pageElements??[]).filter(el=>el.sheetsChart);
  const el=job.native_object_id?links.find(item=>item.objectId===job.native_object_id):
    (links.length===1 && job.charts_on_page===1?links[0]:null);
  const pointer=el?.sheetsChart;
  const record=v.chart_delivery?.workbooks?.find(item=>item.spreadsheet?.spreadsheetId===pointer?.spreadsheetId);
  const book=record?.spreadsheet;
  const exported=(evidence.sheet_exports??[]).find(x=>x.id===pointer?.spreadsheetId);
  const req={stage:"read_linked_chart",page:job.page,shape_id:job.shape_id,
    presentation_id:v.native_id,spreadsheet_id:pointer?.spreadsheetId,chart_id:pointer?.chartId};
  if (job.needs_visual_readback) return {...req,stage:"read_chart_audit",
    next:"Measure this original chart and the latest native chart before editing; bind the native object ID, each data label and both visible scales to the actual exports."};
  if (!native || native.presentationId!==v.native_id || !pointer || !book || !exported?.xlsx || !files.pptx_pdf || !files.slides_pdf)
    return {...req,next:"Read both final PDFs, latest Slides pageElements, the linked workbook's full EmbeddedChart (spec and position) and its actual XLSX in sheet_exports."};
  const owned=(file,id)=>file?.id===id && !file.trashed && (file.parents??file.parent_ids)?.includes(evidence.folder_id);
  if (!valid(evidence.folder_id) || !owned(record.drive_file,pointer.spreadsheetId) || !owned(v.chart_delivery.slides_file,v.native_id) ||
      v.pptx_sha256!==hash(await readFile(files.pptx)) || exported.export_sha256!==hash(await readFile(exported.xlsx)))
    return {...req,next:"Bind the presentation and linked spreadsheet to the current work folder, and read back the actual PowerPoint and XLSX hashes."};
  const chart=book.sheets?.flatMap(tab=>tab.charts??[]).find(c=>c.chartId===pointer.chartId);
  if (!chart?.spec || !chart.position) return {...req,next:"Read the complete EmbeddedChart, including spec and position, into the workbook record."};
  const stateDir=path.join(dir,"chart-repair");await mkdir(stateDir,{recursive:true});
  const key=hash(JSON.stringify([v.pptx_sha256,v.native_id,job.page,job.shape_id,pointer.spreadsheetId,pointer.chartId]));
  const nativeFile=await saveEvent(dir,native), bookFile=await saveEvent(dir,book);
  const args=[files.pptx,files.pptx_pdf,files.slides_pdf,nativeFile,bookFile,exported.xlsx,path.join(stateDir,key+".json"),
              "--page",String(job.page),"--chart-index",String(job.chart_index),"--chart-id",String(pointer.chartId),"--sheet-meta",bookFile];
  try {
    return {...req,...await runFileCheck("linked-chart-run.py",args)};
  } catch(error) {
    return {...req,stage:"needs_review",next:(error.stderr??error.message).trim().split("\n").at(-1)};
  }
}

function evidenceProgress(proof,result,step) {
  // Repeating the same request against unchanged rendered bytes and chart state cannot fix a delivery.
  const v=proof.verified??{};
  return hash(JSON.stringify([result.issues,step?.stage,step?.page,step?.spreadsheet_id,step?.chart_id,
    step?.sheets_requests,step?.slides_requests,step?.refresh_requests,
    v.pptx_sha256,v.visible_reports?.slides?.pdf_sha256,v.chart_delivery?.workbooks?.map(w=>w.spreadsheet?.sheets?.flatMap(s=>s.charts??[]))]));
}

export async function applyChartPacket(google, next, proof, step) {
  const responses={};
  const readBack=()=>google.readChartEvidence(next,proof,step,responses);
  const sheets=step.sheets_requests??[], slides=step.slides_requests??[], refresh=step.refresh_requests??[];
  if (!sheets.length && !slides.length && !refresh.length) return readBack();
  if (sheets.length && typeof google.batchUpdateSpreadsheet!=="function" ||
      (slides.length || refresh.length) && typeof google.batchUpdatePresentation!=="function") return null;
  if (sheets.length) {
    try {responses.sheets=await google.batchUpdateSpreadsheet(step.spreadsheet_id,{requests:sheets,includeSpreadsheetInResponse:true});}
    catch {return readBack();} // An uncertain write is reconciled against the same file before replay.
  }
  if (slides.length || refresh.length) {
    try {responses.slides=await google.batchUpdatePresentation(step.presentation_id,{requests:[...slides,...refresh],
      ...(step.write_control?{writeControl:step.write_control}:{})});}
    catch {return readBack();}
  }
  return readBack();
}

async function finishWorkDelivery(dir,next,proof,host) {
  const seen=new Set();
  let result=await verifyWorkDelivery(dir,proof);
  const limit=Math.min(128,Math.max(12,12*(result.chart_jobs?.length??1)));
  for (let i=0; i<limit && result.action==="repair_delivery"; i++) {
    const google=host.google;
    const nativeAdapter=typeof google?.readChartEvidence==="function";
    if (typeof host.repairDelivery!=="function" && typeof host.repairLinkedChart!=="function" && !nativeAdapter) return result;
    const steps=[];
    for (const job of result.chart_jobs??[]) steps.push(await nextChartRepair(dir,proof,job));
    const available=steps.filter(s=>!["verified","native_labels_live","needs_review"].includes(s.stage));
    const step=available.find(s=>!seen.has(evidenceProgress(proof,result,s)))??available[0];
    const marker=evidenceProgress(proof,result,step);
    if (seen.has(marker)) return {...result,reason:"unchanged_repair_evidence",chart_steps:steps};
    seen.add(marker);
    let fixed;
    if (step?.stage==="reimport_native_combo") {
      if (typeof host.repairLinkedChart==="function") fixed=await host.repairLinkedChart(next,proof,step);
      else if (typeof host.repairDelivery==="function") fixed=await host.repairDelivery(next,proof,result.issues,{chart_steps:steps});
    } else if (step && nativeAdapter) fixed=await applyChartPacket(google,next,proof,step);
    else if (step && typeof host.repairLinkedChart==="function") fixed=await host.repairLinkedChart(next,proof,step);
    else if (typeof host.repairDelivery==="function") fixed=await host.repairDelivery(next,proof,result.issues,{chart_steps:steps});
    if (!fixed) return {...result,chart_steps:steps};
    proof=fixed;
    result=await verifyWorkDelivery(dir,proof);
  }
  if (result.action==="repair_delivery") return {...result,reason:"repair_limit_reached"};
  if (result.action!=="ready_to_publish" || typeof host.publish!=="function") return result;
  return publishOnce(dir,result,host);
}

// start is the exact CLI argument array after editable-image-queue.py, including observed native reference capabilities.
// native.generate receives just the provider's advertised arguments; the request ID is local operation metadata.
// native.lookup and native.observe must read real operation records/files. No generator or Drive endpoint is assumed.
async function publishOnce(dir, result, host) {
  const key=hash(JSON.stringify([result.job_id,result.revision,result.output_revision,result.pptx_sha256,result.outputs]));
  const location=path.join(dir,"publication-"+key+".json");
  let receipt;
  try {
    await writeFile(location,JSON.stringify({status:"intent",key}),{flag:"wx"});
  } catch (e) {
    if (e.code!=="EEXIST") throw e;
    const stored=await json(location);
    if (stored.status==="delivered" && valid(stored.message_ref)) return {...result,action:"delivered",message_ref:stored.message_ref,verified_complete:true};
    receipt=await host.lookupPublication?.(key,result);
    if (!valid(receipt?.message_ref)) return {...result,action:"read_back_publication",publication_key:key};
  }
  if (!receipt) receipt=await host.publish(result,{key});
  if (!valid(receipt?.message_ref)) return {...result,action:"read_back_publication",publication_key:key};
  const saved={key,status:"delivered",message_ref:receipt.message_ref};
  const tmp=location+"."+process.pid+".tmp";
  await writeFile(tmp,JSON.stringify(saved));await rename(tmp,location);
  return {...result,action:"delivered",message_ref:receipt.message_ref,verified_complete:true};
}

export async function runWorkForeground(start, host) {
  let next=await cli(start);
  const dir=next.files?.run_dir;
  if (!dir) throw Error("Expected a real, privately bound Work directory.");
  const caps=[...(host.native?.flags??[])];
  const getNext=()=>cli(["work-next",dir,...caps]);
  async function saveReply(slot, reply) {
    if (!reply) return false;
    if (reply.status==="not_started" || reply.status==="failed") {
      const f=await saveEvent(dir,{...slot,reason:reply.reason??reply.status});
      next=await cli(["work-event",dir,"defer",f,...caps]);return true;
    }
    if (reply.status!=="ready" || !valid(reply.file) || !valid(reply.generation_ref)) return false;
    const f=await saveEvent(dir,{...slot,file:await realpath(reply.file),generation_ref:reply.generation_ref,visual_review:reply.visual_review});
    next=await cli(["work-event",dir,"record",f,...caps]);return true;
  }
  for (;;) {
    if (next.action==="call_native_image") {
      if (typeof host.native?.generate!=="function") return {...next,action:"native_tool_required"};
      const intent=await cli(["work-dispatch",dir,next.request_id,...caps]);
      if(intent.action!=="invoke_native_image"){next=intent;continue;}
      const slot={request_id:intent.request_id,page_number:intent.asset.page_number,name:intent.asset.name};
      let reply;
      try {
        const raw=await host.native.generate(intent.provider_input,{request_id:intent.request_id});
        reply=typeof host.native.observe==="function"?await host.native.observe(raw,slot):raw;
      } catch {
        // Transport uncertainty preserves the dispatch intent and permits work on other pages.
      }
      if (!await saveReply(slot,reply)) next=await getNext();
      continue;
    }
    if (next.action==="reconcile_native_image") {
      let changed=false;
      for (const slot of next.requests) {
        if (typeof host.native?.lookup==="function" && await saveReply(slot,await host.native.lookup(slot))) {changed=true;break;}
      }
      if (changed) continue;
      return next;
    }
    if (["hold_reference","register_reference","show_single_reference","resolve_reference"].includes(next.action) && next.asset) {
      const reference=await host.native?.resolveReference?.(next);
      if (Array.isArray(reference?.flags) && reference.flags.length) {
        caps.splice(0,caps.length,...reference.flags);next=await getNext();
        if (["register_reference","show_single_reference","resolve_reference"].includes(next.action)) return next;
        continue;
      }
      const hold={page_number:next.asset.page_number,name:next.asset.name,request_id:next.request_id,
        reason:next.reason??"No resolved native reference handle available in this runtime."};
      next=await cli(["work-event",dir,"hold-reference",await saveEvent(dir,hold),...caps]);continue;
    }
    if (next.action==="review_asset" && typeof host.reviewGenerated==="function") {
      const asset=next.asset,slot={page_number:asset.page_number,name:asset.name,request_id:next.request_id};
      const review=await host.reviewGenerated(next);
      if (!review) return next;
      if (await saveReply(slot,{...next,status:"ready",file:path.resolve(dir,next.file),visual_review:review})) {
        if(next.action==="review_asset" && next.request_id===slot.request_id) return next;
        continue;
      }
    }
    if (next.action==="classify_source_objects" && typeof host.classifySource==="function") {
      const rows=await host.classifySource(next.objects);
      if (!rows) return next;
      next=await cli(["work-classify",dir,await saveEvent(dir,rows),...caps]);continue;
    }
    if (next.action!=="assemble" || typeof host.assemble!=="function") return next;
    const proof=await host.assemble(next);
    return finishWorkDelivery(dir,next,proof,host);
  }
}

if (process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const [cmd,dir,file]=process.argv.slice(2);
  if (!["verify","chart-next"].includes(cmd) || !dir || !file) throw Error("Use verify or chart-next RUN_DIR CURRENT_EVIDENCE.json");
  const proof=await json(file);
  const result=await verifyWorkDelivery(path.resolve(dir),proof);
  if (cmd==="chart-next" && result.chart_jobs?.length) {
    result.chart_steps=[];
    for (const job of result.chart_jobs) result.chart_steps.push(await nextChartRepair(path.resolve(dir),proof,job));
  }
  process.stdout.write(JSON.stringify(result)+"\n");
  if (result.action!=="ready_to_publish") process.exitCode=2;
}
