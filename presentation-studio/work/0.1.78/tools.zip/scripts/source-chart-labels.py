"""Inherit chart label visibility from the original PowerPoint, including single-point exceptions."""
import argparse
from copy import deepcopy
from decimal import Decimal
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import runpy
from tempfile import NamedTemporaryFile
from zipfile import ZipFile

from lxml import etree
from pptx import Presentation
from pptx.oxml.ns import qn

FID = runpy.run_path(str(Path(__file__).with_name("chart-fidelity.py")))
LABELS = "c:dLbls"
POLICY = {"delete","showVal","showCatName","showSerName","showPercent","showBubbleSize","showLegendKey","numFmt","tx"}
GROUP_AFTER = {"dropLines","hiLowLines","upDownBars","marker","smooth","gapWidth","gapDepth","overlap","serLines",
               "firstSliceAng","holeSize","axId","extLst"}
SER_AFTER = {"trendline","errBars","cat","val","xVal","yVal","bubbleSize","shape","smooth","extLst"}


def local(node):
    return etree.QName(node).localname


def simple(text):
    return "".join(str(text).casefold().split())


def groups(shape):
    return shape.chart._chartSpace.xpath(".//c:plotArea/*[c:ser]")


def identity(ser):
    names=ser.xpath("c:tx//c:v/text()")
    name=simple(names[0]) if names else "idx:"+ser.xpath("c:idx/@val")[0]
    def cache(expr, numeric=False):
        return tuple((p.get("idx"), Decimal(p.findtext(qn("c:v"))) if numeric else p.findtext(qn("c:v")))
                     for p in ser.xpath(expr) if p.findtext(qn("c:v")) is not None)
    return name,cache("c:cat//c:pt|c:xVal//c:pt"),cache("c:val//c:pt|c:yVal//c:pt",True)


def group_key(group):
    return local(group),tuple(sorted(identity(s) for s in group.xpath("c:ser")))


def chart_key(shape):
    return tuple(sorted(group_key(g) for g in groups(shape)))


def child(node, tag):
    return node.find(qn("c:"+tag)) if node is not None else None


def fresh(tag):
    from pptx.oxml.xmlchemy import OxmlElement
    return OxmlElement("c:"+tag)


def labels_of(owner):
    node=owner.find(qn(LABELS))
    if node is not None:
        return node
    node=fresh("dLbls")
    after=SER_AFTER if local(owner)=="ser" else GROUP_AFTER
    index=next((i for i,item in enumerate(owner) if local(item) in after),len(owner))
    owner.insert(index,node)
    return node


def point_index(node):
    return child(node,"idx").get("val")


def set_flag(node, key, show):
    el=child(node,key)
    if el is None:
        el=fresh(key);node.append(el)
    el.set("val","1" if show else "0")


def order_labels(node):
    order=("idx","dLbl","delete","layout","tx","numFmt","spPr","txPr","dLblPos","showLegendKey",
           "showVal","showCatName","showSerName","showPercent","showBubbleSize","separator",
           "showLeaderLines","leaderLines","extLst")
    ranks={k:i for i,k in enumerate(order)}
    deleted=child(node,"delete")
    if deleted is not None:
        if deleted.get("val") in ("1","true"):
            for el in list(node):
                if local(el) not in ("idx","dLbl","delete","extLst"):node.remove(el)
        else:node.remove(deleted)
    node[:]=sorted(node,key=lambda el:ranks.get(local(el),len(order)))


def sync_policy(original, target):
    # Keep all candidate layout, colour, font and label position properties.
    # Replicate only display semantics and per-point exceptions from the source.
    origins=list(original) if original is not None else []
    for el in list(target):
        if local(el) in POLICY:
            target.remove(el)
    for el in origins:
        if local(el) in POLICY:
            at=next((i for i,v in enumerate(target) if local(v)=="extLst"),len(target))
            target.insert(at,deepcopy(el))


def sync_owner(source_owner,target_owner):
    orig=source_owner.find(qn(LABELS));dest=target_owner.find(qn(LABELS))
    if orig is None and dest is None:return
    if dest is None:
        dest=labels_of(target_owner)
    sync_policy(orig,dest)
    orig_points={point_index(d):d for d in orig.findall(qn("c:dLbl"))} if orig is not None else {}
    dest_points={point_index(d):d for d in dest.findall(qn("c:dLbl"))}
    for idx in dict.fromkeys([*orig_points,*dest_points]):
        a=orig_points.get(idx);b=dest_points.get(idx)
        if b is None:
            b=fresh("dLbl");b.append(deepcopy(child(a,"idx")))
            at=next((i for i,v in enumerate(dest) if local(v)!="dLbl"),len(dest))
            dest.insert(at,b)
        sync_policy(a,b)
        order_labels(b)
        if a is None and len(b)==1:dest.remove(b)
    order_labels(dest)
    if orig is None and len(dest)==0:target_owner.remove(dest)


def visible(shape):
    return {row["name"]: sorted((l["point"],l["text"]) for l in row["labels"])
            for row in FID["label_contract"](shape)["series"]}


def allow_named_override(row, group, series_name, count):
    # Totals and a Chat-inferred list of source series are advisory. Only an
    # explicit reference to this series and a label-change request can change it.
    quote=simple(row.get("user_quote",""))
    if simple(group.get("series",""))!=simple(series_name) or simple(series_name) not in quote:return None
    if not re.search(r"顯示|標示|標出|加上|隱藏|不顯示|移除|取消|show|hide|label",quote):return None
    indices=group.get("visible_indices")
    hiding=bool(re.search(r"隱藏|不顯示|移除|取消|hide|remove",quote))
    if indices is None:
        if not hiding and group.get("count")==count and re.search(r"全部|所有|每個|全顯示|every|all",quote):indices=list(range(count))
        elif group.get("count")==0 and re.search(r"隱藏|不顯示|移除|取消|hide|remove",quote):indices=[]
        else:return None
    if not isinstance(indices,list) or any(type(i)!=int or not 0<=i<count for i in indices) or len(set(indices))!=len(indices):
        raise ValueError("Invalid explicit per-point chart-label selection.")
    if group.get("count")!=len(indices):raise ValueError("The named series label count differs from its specified points.")
    return set(indices)


def apply_authorizations(shape,page,chart_ordinal,authorizations):
    entries=[r for r in authorizations if r.get("page")==page and r.get("chart",chart_ordinal)==chart_ordinal]
    if not entries:return []
    report=[]
    series=FID["label_contract"](shape)["series"]
    lookups={simple(r["name"]):r for r in series}
    if len(lookups)!=len(series):return []
    for entry in entries:
        for requested in entry.get("groups",[]):
            name=requested.get("series")
            if not isinstance(name,str):continue
            row=lookups.get(simple(name))
            if not row:continue
            points=allow_named_override(entry,requested,row["name"],row["point_count"])
            if points is None:continue
            for g in groups(shape):
                kind=local(g).removesuffix("Chart")
                if kind!=requested.get("kind"):continue
                for s in g.xpath("c:ser"):
                    if identity(s)[0]!=simple(name):continue
                    lbl=labels_of(s);by_idx={point_index(el):el for el in lbl.findall(qn("c:dLbl"))}
                    for i in range(row["point_count"]):
                        el=by_idx.get(str(i))
                        if el is None:
                            el=fresh("dLbl");idx=fresh("idx");idx.set("val",str(i));el.append(idx);lbl.insert(0,el)
                        set_flag(el,"delete",i not in points);set_flag(el,"showVal",i in points);order_labels(el)
                    report.append({"series":row["name"],"visible_indices":sorted(points)})
    return report


def authorizations(work=None, original=None):
    if work is None:return []
    packet=json.loads((work/"work.json").read_bytes())
    if original is not None and packet.get("source_sha256")!=sha256(Path(original).read_bytes()).hexdigest():
        raise ValueError("The accepted Work source and physical PowerPoint differ.")
    return packet.get("art_requirements",{}).get("chart_label_authorizations",[])


def reconcile(original,candidate,auth=(),include_inventory=False):
    source=Presentation(original);final=Presentation(candidate)
    changed={};issues=[];records=[];inventory=[]
    if len(source.slides)!=len(final.slides):
        raise ValueError("Source and candidate page counts differ before chart matching.")
    for page,(first,last) in enumerate(zip(source.slides,final.slides),1):
        sc=list(FID["chart_shapes"](first.shapes));fc=list(FID["chart_shapes"](last.shapes))
        used=set()
        for ordinal,(src,grouped) in enumerate(sc,1):
            key=chart_key(src)
            matches=[(i,d) for i,(d,_) in enumerate(fc) if i not in used and chart_key(d)==key]
            if len(matches)>1:
                matches=[(i,d) for i,d in matches if d.shape_id==src.shape_id]
            if len(matches)!=1:
                issues.append({"page":page,"shape_id":src.shape_id,"reason":"Match the original chart, series names, categories and numeric values before changing its labels."})
                continue
            index,dest=matches[0];used.add(index)
            approved=apply_authorizations(src,page,ordinal,auth)
            before,expected=visible(dest),visible(src)
            got={k:len(v) for k,v in before.items()};need={k:len(v) for k,v in expected.items()}
            if before!=expected:
                for sg in groups(src):
                    dg,=[g for g in groups(dest) if group_key(g)==group_key(sg)]
                    sync_owner(sg,dg)
                    for ss in sg.xpath("c:ser"):
                        ds,=[s for s in dg.xpath("c:ser") if identity(s)==identity(ss)]
                        sync_owner(ss,ds)
                if visible(dest)!=expected:raise ValueError("Could not reproduce all source point-label exceptions.")
                changed[str(dest.chart.part.partname).lstrip("/")]=dest.chart.part.blob
            records.append({"page":page,"chart_index":index,"source_shape_id":src.shape_id,"shape_id":dest.shape_id,
                            "before":got,"required":need,"changed":before!=expected,"named_overrides":approved})
            if include_inventory:
                inventory.append({"page":page,"source_shape_id":src.shape_id,"series":FID["label_contract"](src)["series"]})
    return {"charts":records,"issues":issues,"expected_series":inventory},changed


def write_copy(source,output,parts):
    if output.exists():raise ValueError("Use a new output path for the repaired PowerPoint.")
    output.parent.mkdir(parents=True,exist_ok=True)
    with NamedTemporaryFile(dir=output.parent,delete=False) as t:path=Path(t.name)
    try:
        with ZipFile(source) as src,ZipFile(path,"w") as dst:
            for obj in src.infolist():dst.writestr(obj,parts.get(obj.filename,src.read(obj)))
        os.link(path,output)
    finally:path.unlink(missing_ok=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=["audit","repair"])
    for key in ("source","final"):parser.add_argument(key,type=Path)
    parser.add_argument("output",nargs="?",type=Path);parser.add_argument("--work",type=Path)
    a=parser.parse_args()
    if (a.action=="repair")!=(a.output is not None):parser.error("Repair needs a fresh output path.")
    report,parts=reconcile(a.source,a.final,authorizations(a.work,a.source),include_inventory=True)
    if a.output and not report["issues"]:write_copy(a.final,a.output,parts)
    print(json.dumps(report,ensure_ascii=False))
    raise SystemExit(2 if report["issues"] or a.action=="audit" and parts else 0)
