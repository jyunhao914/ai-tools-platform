# 精緻型裝飾圖件交付驗收

交付前執行 `scripts/check-refined-cutout-delivery.py`。以完整定稿配置 `pages[].objects` 辨識所有精緻頁圖件。全域 `settings.editable_profile` 或 `editable_profile` 為 `refined`，逐頁可用 `page_profiles` 或 `page.editable_profile` 覆寫。一般照片、沿用的截圖與數據圖表保留既有驗收方式。標為 `protected:true` 或 `action:"keep"` 的物件保留原貌。

- 裝飾圖件的 `kind` 或 `role` 採用 `icon`、`small_illustration`、`subject_cutout` 或 `cutout`。亦可在具名物件上指定 `transparent_cutout:true`。
- 對應 PowerPoint 的既有獨立物件名稱寫入 `name`。圖片攜帶審過之原始 PNG 的 `visual_review.cutout_check.sha256` 或 `approved_sha256`。產圖與組裝必須沿用同一組已接受位元。精緻原生向量 icon 可標為 `kind:"icon_group"`、`native_icon:true` 或 `kind:"vector",role:"icon"`。若群組有多個子物件，替整組取穩定名稱。
- 在成品真正完成且原生媒體可讀時取得證據。PowerPoint PDF 使用此次交付的 PPTX 渲染。Google Slides 讀回同一簡報的 `presentationId`、`revisionId`、`pageSize`、`slides[].pageElements`，保留子物件、樣式與圖片 `contentUrl`。在相同修訂匯出完整 PDF。若匯出前後有變更，重新讀取。
- Google 原生物件識別碼可由建立操作回傳並寫入 `slides_object_id`。轉檔後才取得映射時，保留已核准 PLAN 位元，另以 `--slides-bindings` 提供 `{"presentation_id":"…","slides_revision":"…","objects":[{"page":1,"name":"…","object_id":"…"}]}`。以實際原生物件的標題、內容及位置對照，缺失或有歧義時重新定位。
- 白底或背景難以判讀時，從實際原生物件目前的 `image.contentUrl` 讀取原始媒體，傳入 `--slides-media`。格式為 `{"原生物件ID":{"content_url":"本次讀回的同一URL","file":"下載的PNG相對路徑"}}`。保護帶時效的存取網址。對外報告只保留物件 ID、雜湊與取樣結果。
- 背景紋理或附近物件讓自動比對有歧義時，可在該物件的 `transparency_probes.pptx` 或 `.slides` 提供至少三組樣本。每組 `{"clear":[u,v],"backdrop":[x,y]}` 中，前者是物件內已知透空位置，後者是鄰近且應該連續的真實頁面底色，分別採用物件與整頁的 0–1 相對座標。旋轉、未解群組或解析度不足的輸出需調整組裝再驗，保留其 `needs_review` 記錄。

```sh
python -B scripts/check-refined-cutout-delivery.py plan.json final.pptx \
  --pptx-pdf final-rendered.pdf --slides-json slides-readback.json \
  --slides-pdf slides-export.pdf --slides-bindings real-object-map.json \
  > refined-cutout-delivery.json
```

只要求單一輸出的工作可使用 `--surface pptx` 或 `--surface slides`。Google 單一輸出仍傳入此次組裝的中繼 PPTX，以核對已批准的 PNG 和主體像素。Google 比對基於最終原生頁面及原生簡報匯出。Python 需要 python-pptx、Pillow、numpy 與 PyMuPDF，並與 `check-cutout.py` 同目錄。

報告 schema 是 `presentation-studio/cutout-delivery/v1`。交付 gate 從原定稿配置獨立列舉預期具名物件，逐一比對 `checked_targets`、實際要求的 `surfaces`、PLAN 與交付檔雜湊，雲端另比對簡報 ID 和本次修訂。物件的每個要求輸出必須顯示 `pass`。只有定稿內確實沒有適用物件時才適用 `not_applicable`。檢查失敗或待覆核時留存具名物件及原因，修正該圖件、重新匯出，再驗同一組交付檔。

檢查會解開 PPTX 並讀取實際媒體、裁切、白底背板及原生群組，然後在每個最終 PDF 閱讀圖件內部、周邊底色與主體像素。Google 會另核對真實頁面物件和所在頁。配色和文字相近的複雜背景可能需要人工標示取樣。報告記錄 PPTX、各 PDF 與原生 JSON 的 SHA-256 及 Google 修訂。
