# 第一份公開給使用者的檔案就檢查畫面

可更新原生資料圖表以圖表自身的資料標籤為準。先讀 references/linked-chart-run.md 的原生 XLSX 匯入方式。使用者指定可更新時，調整資料來源、匯入規格、圖表大小與數列原生標籤位置，下方另加可編輯文字圖層的舊手法僅適用於使用者明確選用靜態註解的輸出。

對話中任何可開啟的工作稿、部分成品與定稿都要先在私人工作區完成同一版的畫面檢查。用實際要附上的 PowerPoint 二進位渲染全部頁面，用實際要分享的原生 Google 簡報逐頁取畫面或重新匯出 PDF。先查明原文、已採用的版面或來源是否刻意留白。原稿隱藏頁仍要核對內容及播放狀態。連結圖表或可見物件數不能證明頁面能正常繪出。工作稿若缺美術可註明；原本應有內容的整頁空白不能當作草稿交出去。

在可執行 Python 的宿主，對每一種格式獨立使用 scripts/check-visible-pages.py PLAN.json ACTUAL-OUTPUT.pdf。PLAN 包含 artifact_id、output_revision 與逐頁 pages（page_number、expected_content 為 body 或 intentionally_blank）；可針對當頁構圖傳 body_regions，例如資料圖表所在的正規化矩形。看 render_sha256 對應的影像，確認文字和受保護的圖表等主要內容在正確位置。全白、單色背景或有標頭邊線卻沒有預期正文時，先修問題頁並重新匯出後再驗。微弱或稀疏內容標為需複核，目視確認後記錄針對該頁、該次 PDF 的觀察。缺檢、權限失效或真的無法修復時，保存私有進度和具體頁次，同輪繼續其他工作。只有實際通過這個檢查的檔案才交付。取得修復前的舊附件、上次截圖或檔名相同的檔案，應核對檔案內容版本再使用。

JS 宿主藉 verify 回傳 visible_reports（以 pptx、slides 區分），或提供 inspectVisible(job,candidate,formats) 即時讀回兩份渲染報告。artifact_id 分別綁 candidate.pptx_ref、candidate.native_id，output_revision 綁 candidate.output_revisions[format] 或 candidate.output_revision（建議 PPTX SHA256 與實際原生 revisionId）。報告含 pdf_sha256、page_count、status、pages、errors。刻意留白從採用來源計畫傳 job.intentionally_blank_pages。對 needs_review 目視後可在該列附 visual_review：page、同一 pdf_sha256、pass 與 observation。repairVisible(base,job,candidate,issues) 可從原有物件修復遮蓋、位置、字色或匯入問題，保留內容與資料的可編輯性。每次修完重新讀取兩份成品並重驗；發布前鎖定核過的版次，publishDraft(base,job,preview) 僅發布該份 preview 且回傳相同 output_revision 和檔案引用。


## 轉檔後的實際字級

適用於將可編輯 PowerPoint 轉成原生 Google 簡報的雙格式交付。取本次定稿 PPTX 的實際 PDF 渲染作設計基準，從本次原生 Google 簡報的同一修訂匯出第二份 PDF。採原稿重新排版時，以本次重新設計後的字體層級為準。比對兩份渲染的相同頁序、畫布與文字，涵蓋標題、正文、圖說、表格及群組。若有隱藏頁，補齊同頁序的渲染再比對。全頁沒有原生字的情況由畫面覆核其用途。

1. 執行 `python3 scripts/compare-rendered-type.py PPTX.pdf NATIVE.pdf > TYPE.json`（PyMuPDF）。程式按相同畫布寬度正規化單位，依相同文字比對實際繪製字級，適用換行、不同文字 run 與替代字型。比基準小超過 8% 且超過 1 pt 時，逐項記下頁次、字串、兩份字級及區域。退出碼 0 表示已比到的全數通過，1 表示需要修復，2 表示需覆核無法配對或缺乏可量測文字的區域。未配對、抽字次序變化或圖表轉為點陣的區域，用兩份本版渲染對照實際字級、文字完整性與可讀性。PDF 工具不可用時，以兩份等寬的實際畫面量同段字高，比對比例並留下原始畫面、頁次和量測結果。兩份檔案的物件樣式或總字數相同，仍須做畫面比對。
2. 有縮字時讀回同一原生簡報的 presentationId、revisionId、pageSize、目標頁物件與 rich text。將本次完整 get_presentation 結果存為 NATIVE.json，比對 PDF 取得當時的同一 revision，執行 `python3 scripts/slides-font-repair.py TYPE.json NATIVE.json --revision REVISION`。工具就可定位且有明確字級的普通文字框產生精確的 batch_update，每個 updateTextStyle 只修改該物件、該 UTF-16 FIXED_RANGE 的 fontSize，保留混合字級、字體、顏色、粗體和段落。用實際 Google Slides 寫入工具對回傳的 presentation_id 執行相同請求及 writeControl。若工具的輸入欄位分開，依實際契約傳入；遇到版本衝突或回覆不明，先確認同一簡報實際狀態，重新渲染、重新讀回物件後才產生下一批。
3. inspect 或 unmatched 項由宿主對照畫面及實際文字框、群組、表格 cell、各文字 run 與自動縮放狀態處理。放大框、挪用附近留白、調行距或還原該段實際設計字級時，保留原物件文字、樣式及相鄰圖像。若是 TEXT_AUTOFIT 造成縮小，先給文字足夠空間，依需要在該文字框設 autofitType=NONE，並調整相關區段的字級；fontScale 與 lineSpacingReduction 為唯讀。若已是 NONE 而文字 run 本身寫小，須局部改回字級。表格在對應儲存格修復；圖表標籤到實際連結的試算表圖表處理，再更新投影片圖表。
4. 從修好的同一原生簡報再次匯出 PDF 和讀回新修訂。所有曾失敗的區域逐段重量，其餘各頁也重跑，實看裁切、越界、遮擋、重疊、斷行和文字完整性。取得新版實測報告後再交付；若該檔仍有可量測縮字，接著修框並重排。若確有宿主權限或輸出限制，說明具體頁面、文字與兩份有效字級，依部分交付規則標記。兩份成品的內容、可編輯性、圖片與圖表仍依原有驗收。

## 可攜的圖表資料與可見標籤

新工作的圖表驗收設定為 `job.chart_fidelity_version=1`。從定稿列入每頁要保留的原生圖表數量與交付格式（`job.editable_charts`）。可沿用同一工作的既有圖表與試算表 ID。由本地製作端或網頁 Work 逐步製作時，也執行以下步驟。

**PowerPoint。** 對要交付的實體檔案執行 `python3 scripts/prepare-editable-delivery.py INPUT.pptx NEW.pptx`，用修復後的 NEW 取代工作輸出及附件來源，再從 Drive 下載將要交件的那份，對它執行 `python3 scripts/prepare-editable-delivery.py --audit DOWNLOAD.pptx`。確認內部的 chart.xml 仍含原生圖表，c:externalData 的 r:id 指向封裝內的工作簿，圖表引用的各儲存格可從內嵌 .xlsx 讀出且與原數列相符。外部路徑、孤立的 embeddings 檔案或快取值不算通過。若來源為缺少快取的複雜圖表，取得獲授權的實際工作簿後重建或修復對應的內部關聯。修復之後須再開啟、渲染新檔、檢查同份雲端附件雜湊。將最後一次檢查結果存入 `verified.pptx_chart_audit`，將獨立讀回的最終交付檔 SHA256 存入 `verified.pptx_sha256`。

**Google 圖表及各點標籤。** 對定稿 PowerPoint 及其實際渲染執行 `python3 scripts/chart-fidelity.py plan FINAL.pptx FINAL.pdf PAGE --chart-index 0`。從同頁各原生圖表建立各自的參照；群組圖表以實際全頁座標傳 `--region x0 y0 x1 y1`（0–1）。結果含數列名稱、資料點序號、顯示值、基準字級及圖例／刻度方向。遇到自訂數字格式、重複值或圖表點陣化，逐一在原渲染中定位再完成參照；保留每項量測與原圖，不把覆核清單直接清空。資料表有數值與投影片有對應的可見標籤須分別核對。

- 讀回本次 Sheet 的完整 EmbeddedChart.spec 與來源儲存格，把實際各數列範圍對應回參照。標籤文字由工作儲存格的 numberFormat 決定；保留整數、百分比小數位數及原圖僅在部分數列或點顯示標籤的設定。工具可讀夠完整時，`python3 scripts/chart-fidelity.py sheets CHART.json PLAN.json NAMES.json` 會保留完整圖表規格，依 NAMES（來源儲存格驗證過、以該 Sheet 排序的數列名稱陣列）產生 updateChartSpec。先在 Sheets 以實際 chartId 寫入，只有需要顯示標籤的數列設 dataLabel.type=DATA、textFormat.fontSize 及合法 placement。部分點顯示或自訂格式可用對應命名且有公式的輔助欄與 CUSTOM，保留資料連結。工具若只回傳部分 spec，先補足已驗證的原圖表規格，以免 updateChartSpec 用不完整內容覆蓋組合圖、軸或資料範圍。
- 在同一原生 Slides 用該圖表原物件 objectId 寫入 refreshSheetsChart，讀回後匯出新 PDF 或取實際投影片畫面。以同等頁寬量測每個資料標籤、圖例、日期及左右軸刻度，再調整。若整張圖放縮造成字小，可擴展投影片上原圖表的版位、等比例調整來源圖表以提高畫中字高、騰出旁邊空間。必要時用該工作可用的原生 Sheets 圖表編輯能力調整圖例與刻度。size、活頁簿格式與整頁文字計數本身無法證明畫面字級。
下段的投影片文字註解只適用於明確指定靜態標註。可更新圖表在原生試算表中調整數列與 DATA 或 CUSTOM 儲存格標籤。
- `verified.chart_visual_audit` 存入最終 Google 簡報 PDF 的 `slides_pdf_sha256`、基準 `reference_pdf_sha256`、上面的圖表參照陣列 `references` 及逐圖 `rows`。各列存 page、來源 shape_id、native_object_id、axes_legend_reviewed、type_samples（實際文字、role、reference_pt、actual_pt）及 labels（series、point、text、actual_pt、在該點量出的全頁 rect、at_data_point）。字級均以相同頁寬換算；須能從該版 PDF 或圖像定位。逐一讀回已修的成品及裡面的工作簿後才交件。同一個資料點出現兩個標籤也要修復。

### 連結柱線組合圖實際縮字時直接修復

若原生圖表自動略掉刻度、縮小圖例、同組資料只有部分標籤符合 PowerPoint 字級，使用 `scripts/linked-chart-text.py` 在現有工作檔修復整張圖。保留可更新的 SheetsChart 與原始資料，將受渲染器限制的文字做成同一張投影片上的可編輯圖層。此校準適用含一組直條、具名折線、雙側數值軸及至少三個不同共享分類的非堆疊組合圖。其他圖型沿用前述原生圖表修復及逐項驗讀。

1. 保留本次可編輯 PPTX 及其實際 PDF。從本次 Google 試算表讀取完整 EmbeddedChart 存為 CHART.json（chartId、spec、position），以其來源範圍讀回完整表頭與儲存格。建立 NAMES.json，內容是 Sheet 圖表每個**實際資料數列依序對應的 PowerPoint 數列名稱**，不得猜來源。將本輪原生 Slides 的完整 presentationId、revisionId、pageSize、各頁 objectId 與 pageElements（含 objectId、size、transform、sheetsChart、shape.shapeType）存為 NATIVE.json。
2. 在本工作的 Sheet 圖表上執行 `python3 scripts/linked-chart-text.py prepare CHART.json --width 530 --bounds BOUNDS.json`，將回傳請求送入 spreadsheets.batchUpdate。寬度可依實際資料點數調整，畫布等比。工具只關閉自動圖例及自動數值標籤，保留真正的資料柱與折線。若右軸未能涵蓋原可見最大刻度，BOUNDS.json 指定該軸、已驗證的 min/max、與工作用試算表內已確認空白且不屬於他人資料的專用區（sheetId、rowIndex、columnIndex，零起算）。例如百分比數列使用小數上下限，axis 取 RIGHT_AXIS。程式按分類範圍的實際長度寫入輔助刻度資料，加入不可見的校準線；既有工作重試沿用同一專用區。不需要校準上界時可省略 --bounds。工作簿僅允許改自己的本次圖表，使用者提供的原件唯讀。
3. 在同一原生簡報對該 SheetsChart 的 objectId 呼叫 refreshSheetsChart。讀回圖表、最新 Slides metadata，從該修訂匯出最新 BARE-GOOGLE.pdf；若另有之前的單一輔助標籤，傳其已核實屬於本工作的 text box ID 給 `--legacy-label`。執行 `python3 scripts/linked-chart-text.py project FINAL.pptx FINAL-PPTX.pdf BARE-GOOGLE.pdf NATIVE.json CHART.json NAMES.json --page PAGE --element LINKED_OBJECT_ID`。若頁上有多個原生 PowerPoint 圖表，以 --chart-index 指定。這支程式以原 PDF 的實際字級、數列、逐點可見性，與本輪 Google PDF 裡圖的原始像素和長條／折線座標，計算真正的幾何投影。出現範圍不足、數列／圖色／座標不明時需修正這次的資料與刻度，再刷新重跑。
4. 把整批 requests、presentation_id 與 write_control 透過正式 Slides batchUpdate 套用到同一修訂。維持原真實圖表物件及其資料連結，僅遮掉原生圖表在繪圖區外的細字。工具依同一圖表物件的穩定名稱重用輸出，已存在的圖層就地重建。重試或資料更新需重新取得該檔實際 PDF、revisionId 與圖表資料再執行。最後重新匯出整份 Google PDF 量測；應能直接從最終 PDF 文字層讀到所有資料標籤、分類、刻度與圖例，各自與 PowerPoint 實際字級相符。等頁寬檢視整幅圖，確認圖例符號與文字分開，軸上數字完整、資料標籤靠正確數列點，沒有重疊並且後方仍是連結圖表。

此路徑需要 python-pptx、PyMuPDF、NumPy 與隨附的 chart-fidelity.py；僅依當前檔案和本次圖表校準，可在已認領工作的 Work 檔案執行環境使用。
