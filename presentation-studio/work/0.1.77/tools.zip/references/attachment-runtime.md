# 原始附件取得

部分讀稿、原稿已在 Drive 核實引用的可編輯精緻型，保留已讀回的檔案 ID／修訂，交由 Work 核實位元組。Chat 產生可複製的指令時沿用 studio-settings 的固定開頭與正式工作入口，和原稿及選項放在同一個可複製區。read_partial 不改變啟動語句或最終圖表驗收。

本文件處理有附件、但只有文字抽取結果或原件下載失敗的情況。文字能讀取不代表原件已取得；某一執行工具下載失敗也不代表所有正式執行入口都不可用。

1. 依當回合Library指引區分來源。由search/list找到檔案時，保留完整原樣結果，使用當次最新版library_download.py與所需伴隨檔案，不能另外prepare_materialize或切換到transfer helper。可在正式Node入口呼叫本技能腳本的downloadLibrarySearch({helperPath,workspace,result,selection,destination})；result為完整搜尋結果，selection為官方三位數索引如000，destination為工作空間下相對目錄。逐項檢查回傳files及partial/warnings，失敗或部分完成不可冒稱全數成功。
   直接附件已提供確切引用、不是由search/list取得時，才依指引呼叫prepare_materialize。若回傳workspace_path，依指引核對檔案與屬性，直接使用。若回傳download_url，保留完整transfer物件，不把網址當路徑、不顯示短效網址。以下transfer步驟只適用此路徑。
2. 從目前Library技能來源取得該次最新library_file_transfer.py與library_hosted_apps.py，原樣保存於同一個私人暫存目錄。依官方指引完成傳輸，不能自行改寫下載或驗證邏輯。
3. 當本回合提供node_repl等可執行Node的正式工具時，可直接在該入口呼叫本技能scripts/materialize-library.mjs的materializeLibrary({helperPath,destination,transfer})。helperPath為本次取得的官方helper絕對路徑；destination為當前工作空間路徑；transfer為完整實際回傳物件。必要時依正式資源讀取工具取得本套件腳本原件，不能假設雲端技能已掛載或硬編作者電腦路徑。
4. 該腳本只透過stdin把transfer交給官方helper，保留TLS驗證與Library屬性。Python缺省憑證設定不完整時，使用已安裝certifi的可信CA；不安裝新套件、不停用驗證、不更動全域設定。傳輸使用獨立暫存位置；若該目的地已有其他內容，另選該工作的來源檔名重試。執行結果必須ok=true且實際檔案存在；核對位元組大小及SHA256後才標為原件已取得。
5. 若先前只在exec_command發生一般下載/DNS/傳輸錯誤，查找當回合另一個正式檔案處理入口是否可用，再以相同官方helper嘗試一次。只有該入口實際測試結果才能作為依據，不能把單一工具的網路失敗說成整個平台沒有能力。明確權限拒絕、政策禁止或授權失敗不可用其他入口繞過；短效傳輸過期才重新準備傳輸。
6. 取得PPTX後按ppt/presentation.xml及其關係檔讀取真實頁序，讀各頁XML、原生文字/物件及媒體引用；核對ZIP完整性、頁數與引用檔存在。圖片頁需開啟其真實圖像，不只使用文字抽取。遇到WDP/JPEG XR等附加高解析素材時，先檢查a:blip指向的可讀PNG/JPEG主圖；不可僅因附加格式解碼失敗就判定整份原稿不可讀，也不可將背景當完整頁。
7. 讀完原件與全部必要頁面才進入模式③設定。保留原始檔案與分享權限。若已在 Work 接手確認過的工作，讀不到檔案時接下方「Work 取回交接原稿」。

若search/list下載回傳LIBRARY_BRIDGE_UNAVAILABLE，代表該執行入口無法呼叫Library服務，不是沒有附件，也不是使用者尚未授權。不要重複同一路徑、另建MCP或把搜尋ID偽裝成直接附件引用繞路。保留原本附件直接提供的有效引用與已取得的本次原檔；若已有原檔就繼續解析。沒有時保留此次錯誤，按當前階段繼續下方流程。

## Chat 交接前留存可核對的私人原稿

模式③與其他需要在 Work 重讀原件的工作，在 Chat 讀到實際原檔後，記下當次選取的來源 ID、修訂與檔案位元組的 SHA-256（`source_sha256`）。來源 ID 即使可在兩端辨認，也可能無法在 Work 下載。

先完成原件準備。使用者同意這次的原始二進位檔存放在特定私人工作資料夾，才用 `source_storage={"mode":"private_folder","folder_id":"實際資料夾 ID"}`；在原設定中選「只用附件」或未選擇授權，使用 `{"mode":"attachment_only"}`。只就「私人設定文件／純文字設定指令」作選擇，對原件暫存授權沒有增減效果。若原稿本身就是可跨端讀回的 Drive 原件，或僅需完整定稿大綱，無需建立另一份來源或這欄。

在設定腳本目錄執行 `python3 web-confirmation.py prepare-source PLAN.json`。回 `read_original` 就按本文件取得已確認的原件；把真正讀得的路徑與取得它的原引用用 `--source-file ORIGINAL --source-id SOURCE_REF` 傳入，計算實際雜湊。回 `verify_private_source_copy` 就依下方以實際授權的目的資料夾做儲存及讀回：再次執行同一命令，另帶 `--drive-meta DRIVE_META.json`，若需要可加 `--downloaded-file DRIVE_COPY` 及目前帳號的 `--account-email`。讀回來源準備工具的 plan，再用它顯示原本選定的交接形式。執行入口不提供工具時，依相同分支執行能使用的正式工具；不假設一個特定服務或檔案已經存在。

若現有正式工具實測失敗，將真實「讀原檔」或「備份讀回」失敗分別記入 `--read-error` 或 `--copy-error`。例如 dns、access_denied、not_materialized、tool_unavailable、copy_not_verified，保存實際發生的步驟供 Work 接續。工具允許在這個前提下用附件交接；有實算 SHA 仍保留。沒有嘗試的操作不可填失敗。

- 使用者允許將原稿留在本人私人 Drive 時，在**顯示最後確認卡或可複製指令以前**，確認帳號與指定工作資料夾屬本人、權限為私人，將本次已讀的原始二進位檔存入該處。若本次來源已位於該私人資料夾，或本工作已有同一來源的私人副本，先按實際 ID 查回並核對，相同即可沿用。上傳中斷時先查同一次操作的結果，避免另存多份。
- 重新讀取該 Drive 檔案的中繼資料，核對檔案 ID、父資料夾、檔案類型、本人持有、完整檔案權限只有本人，以及原件內容。缺少權限欄位時，以該檔案 ID 讀取完整權限清單。單一來源可綁一份副本；工作使用多個獨立來源時逐一記錄原引用，不能將其中一份副本套給整個工作。從本技能目錄執行 `python3 scripts/verify-source-copy.py ORIGINAL DRIVE_META.json --folder-id PRIVATE_FOLDER_ID --expected-sha256 SHA`。如連接器省略 ownedByMe 和 owners.me，以目前 Drive 帳號的 get_profile 取回 email，查該檔完整 permissions(type,role,emailAddress)，另傳 `--account-email` 加上此帳號的 email 核對唯一的 owner。若 Drive 沒有提供原檔 SHA-256，再以該 ID 下載原始二進位並加 `--downloaded-file DRIVE_COPY`。原稿、Drive 檔和父資料夾核對成功，才將工具回傳的 `source_sha256` 與 `source_mirror: {file_id, sha256}` 一同放入 plan，保留原來的 `source_ref` 和 `source_revision`。檔名、資料夾名稱、卡片、檔案大小或「下載已開始」都不能代替這項核對。
- 沒有授權存放原稿、未能確認資料夾私密性、工具不足或備份讀回失敗時，略過該副本並省略 `source_mirror`。已取得的原始 SHA 仍應帶入，沿用普通 Chat 可複製的純文字交接。不得更動分享權限或向其他服務上傳。

## Work 取回交接原稿

1. 保留同一 job、設定及使用者指定的來源。檢查原 Work 這則**使用者送出的訊息**的附件與宿主回傳的檔案對應。助理回覆內的來源引用、右側預覽、交接文字提到的 ID 都不能證明這則訊息已附檔。
   - 有卡時，先讀該次附件在 Work 執行環境已掛入的實檔。用宿主為這個附件實際提供的 path、file ID、大小等資料；若以先前已驗證的 SHA 綁定，也可核對這次實檔的 SHA。不得搜尋整台電腦，亦不得把同名暫存檔或交接文字中的路徑當作宿主回傳。Node 環境可用 `scripts/materialize-library.mjs` 的 `readWorkAttachment({attachment,expectedFileId,expectedSha256})`，其中 attachment 用當次宿主資料的 file_id、workspace_path、size_bytes（若已知）。直接附件另有正式下載 transfer 時，可向原本的 materializeLibrary 一起傳入 attachment、expectedFileId、expectedSha256；它會先實讀已掛入的附件，只有未掛入時才走正式傳輸。原生 Python 環境可直接用檔案工具驗同一關聯和實檔。對相同 ID 或已驗 SHA 的可讀附件，直接開啟原稿 ZIP 驗頁面與物件，再受理、製作；不要繞道重新下載。
   - 若卡片只有可攜引用、沒有掛入可讀檔，才按正式 Library 指引取得這次附件。若已在同一 Work 測過兩個入口同樣遭 DNS 失敗，保留其結果，先查已掛入的檔案或已驗證的私人 Drive 副本，避免重複同一路徑。Work 未附檔時，用交接的原引用實際讀取當次附件或確切 Drive 版本。遇到 DNS、服務暫時不可用或傳輸逾時，先分辨實際取檔端點。短效傳輸過期才重新取得。當官方 helper 回報 `DNS_RESOLUTION_FAILED`，只記錄本回傳的 `endpoint_key`（同一執行環境本輪嘗試的來源與路徑雜湊），不保存短效 URL。下一個正式 transfer 呼叫 `materializeLibrary` 時傳 `failedEndpointKeys`；只有宿主真正指出失敗的 DNS 主機時，才能同傳 `failedDnsHosts`。若新的附件卡／Drive 檔案引用仍到同一端點，或同一已確認無法解析的主機，工具回 `DNS_ENDPOINT_ALREADY_FAILED`；更換檔名、短效簽章、連接器或重新發同張卡都不是另一條取檔路。若另一個已授權正式工具可直接交回位元組、回傳已掛載可讀的實檔，或確定走不同可讀端點，先用它並比對 SHA（不用再請人選檔）。權限拒絕與 DNS 分開記錄，不能繞過明確拒絕。若工具不揭露失敗的主機，不臆測兩個端點相同。下載回報完成後，檢查該環境確有可開啟的原件並計算 SHA。辨認工具的 DNS_RESOLUTION_FAILED、SOURCE_BYTES_NOT_MATERIALIZED（目的地缺檔或零位元組）、PARTIAL_DOWNLOAD 及 ACCESS_DENIED。部分成功先核對 files/warnings 中對應這件原稿的實檔；一般傳輸或缺檔，繼續下一條可用取檔路徑。
   同一帳號的 Library 若能透過正式搜尋、檔案資訊或原始附件開啟這次的項目，先核對它與設定 Chat **同一張上傳卡／同一不可變附件 ID** 的關聯。記下可重開的私人 Library 連結並嘗試正式取檔；若是搜尋結果，仍用該結果的正式 download helper。只靠同名、頁數或縮圖不得認定同一件。只有取得實檔才繼續。已獨立查證這個連結對應原上傳卡時，可憑該關聯與實讀位元組認領原附件；不可把 libfile ID 填成 upload ID。
2. 如 plan 有 `source_mirror`，而原方法因傳輸、遺失或檔案不可用而失敗，以本人已授權的 Drive 讀取**該 ID** 的原始二進位，再核對其檔案 SHA 與 plan 內已驗證的 SHA。符合才自動接著做。禁止尋找過往工作的原稿、使用同名副本、用文字摘要還原原件，或用附件引用充當下載證明。權限拒絕與 DNS／檔案不存在分開記錄；遇到明確拒絕，不得換入口存取被拒資料，須由使用者恢復所需權限或另行指定有權使用的輸入；若明確拒絕本項資料移轉，立即尊重。
3. 用完可用且獲准的途徑後，以同一個 Work、一個回復處理現況，沿用設定：
   - 此次使用者訊息**沒有原稿卡**：在既有 Work 點輸入框「＋ → 從檔案庫加入」，選這次的確切版本，按「新增至對話」。看到附件後，與「用這份原稿」一併送出。新開 Work 頁的同等操作是「檔案 → 搜尋空間中的檔案」。用本次完整檔名說明；已貼好的設定指令不必複製第二遍。
   - **已附同一張檔案庫卡**，但 Work 仍取不到原始位元組：告知已辨識的檔名與停點，請直接以「＋ → 上傳檔案」選取裝置上的原始檔，或提供該帳號能讀取的私人 Drive 原件連結。資料來源仍是使用者指定的檔案。不要要求把同一張檔案庫卡再加一次，也不要索取裝置上的本機路徑。若使用者剛才已直接上傳且取檔同樣失敗，優先用獲准的 Drive 原件。已取得其中一份可讀實檔即在同個工作接續，無需另一句「繼續」。
4. 新附件或使用者指定的 Drive 檔案抵達後，先取回實檔並算 SHA。已知舊原稿 SHA 且符合，記錄這次實際取得的引用，在原工作直接接續。與已知 SHA 不符時明說版本不同，保留原工作及設定；使用者明確選用這份不同版本才記為新來源。若舊交接只有不可變附件 ID，讀到舊 ID 的實檔即可核實。舊 ID 不可讀且舊 SHA 從未取得時，由使用者在上一步明確指定的附件／連結建立本件的新來源修訂，記錄新引用、實算 SHA 及來源變更原因；只表示「已採用你這次指定的檔案」，不得宣稱已驗證與舊版一致。沿用同一 `job_id` 及所有已確認設定，依交接規則建立新修訂，重新檢查受來源變動影響的對應、逐頁內容與保護物件。不要開新工作或要求重新填表。

## 當二進位取檔失敗，評估同源的 Google 簡報

這是可選的原稿閱讀／可編輯工作來源。Work 能開啟 Google 原生頁面不代表已取得原始 PowerPoint 位元組。若使用者要求 **Work 自己**以原始 PPTX 重算 SHA，或限制原件只用附件，仍走前述原檔路徑。

- **從可驗的原件建立。** 只有原設定 Chat 已實讀這次 PPTX、保存不可變來源引用及實算 SHA，且有本次將它存入私人 Google 工作區和建立原生簡報的授權時，才可從該二進位檔匯入。讀回本人資料夾、原檔與產生的 Google 簡報 ID、MIME、匯入結果和修訂。以 `source_native` 記錄原生檔 ID、真正的服務修訂、私人來源／驗收紀錄引用及原始 PPTX 的 ID 和 SHA；保持 `source_mirror` 專指逐位元組相同的二進位副本。對沒有轉換來源證據或未能檢查的同名原生連結，不能用作同源工作稿。
- **驗每頁、每個受保護物件。** 按原始頁序與原生簡報正式 get 回傳核對尺寸、可見／隱藏、正文與備註、表格的文字、合併與資料、可編輯圖表及數據、截圖和照片的內容、裁切與顯示比例。另以能正確顯示原字形的來源畫面，與真正從 Google 原生簡報匯出的渲染逐頁對照。有字的獨立向量圖、嵌入圖、截圖及公文逐一看其中文字和符號，放大受影響圖區檢查缺字、方框、錯字、破碎筆畫或遮字。物件數、圖片尺寸、正文抽取、檔案指紋或 OCR 成功都不能替代實圖對照。
- **先修匯入損失。** 優先從已核對 SHA 的 PPTX 擷取該獨立原圖及其必要字型，以能正確顯示原字形的渲染器繪製高解析、無損 PNG。確認 PNG 全部字樣且清楚可讀，再在原位置替換原生簡報中的問題物件，保留原裁切、顯示長寬比與圖層；適合透明背景時保留透明。來源圖本來就是截圖或嵌入向量物件才適用；不得將原本可編輯的表格、圖表、文字框轉成圖片以躲過核對。只能取得正確的原頁渲染時，先驗裁切區只含單一原物件，包括重疊、透明、群組與前後圖層；混入其他元素或原字形仍失真即換路徑。不得將整頁扁平化。修補後重新讀取原生檔的新修訂，並重新匯出核對實畫。
- **核對後才作工作來源。** 可讀取的中繼簡報可供定位、檢查及修補；未通過的頁保留具體缺項。全數通過後，將本件紀錄中的原生檔、真正修訂及對照證據一同帶入同一工作。Work 再用正式工具讀回該 ID、修訂與證據。既有 Drive 原件入口可由同一 job 記錄新的「製作來源」修訂，將 `source_ref` 設為核對的原生簡報、`source_revision` 為其服務修訂、`source_mime_type` 為 Google presentation，並保存此前的原始 PPTX ID/SHA、原設定、目的地與來源準備結果。此時 `source_sha256` 不得填入原始 PPTX 的 SHA 冒稱原生檔的雜湊；原件暫存設定留在原件紀錄，不要拿它當原生檔的二進位副本。使用者的明確原稿核對要求優先，不以更改修訂的方式取消要求。
- **從副本完成真正的成品。** 在私人工作位置複製出不同於中繼來源的成品 ID，按原來選的形式／風格完成實際重新設計；從這份完成後的原生簡報匯出可編輯 PPTX。分別開啟真正的 Google 簡報和該次匯出的 PowerPoint，逐頁核對原文、備註、隱藏頁、原生表格／圖表及所有受保護圖片，放大查看上述含字圖區在兩種成品均呈現正確字形。僅在成功後交付該成品的實際兩個連結。舊來源、副本未修改、局部修圖樣張或單一格式渲染都不是重新設計的兩項交付。

**使用同源原生版的工作紀錄。** 僅在完成上述查核、決定採用這個實際修訂時，將以下資訊寫入本工作；之前的待修候選放在工作區即可。

1. 助手從本次真實逐頁結構與視覺檢查結果讀取每頁的 source_page、native_page_id、structure_verified、protected_visuals_verified、unresolved。以本次已讀的原檔、兩份 PDF、native ID 和 revision 綁定這份工作內部檢查結果。在製作腳本目錄可用 `python3 native-source-report.py ORIGINAL.pptx SOURCE.pdf NATIVE.pdf GET_PRESENTATION.json COMPLETED_REVIEW.json CHECKS.json --original-ref SOURCE_REF --import-source-id DRIVE_BINARY_ID` 自動從真實檔案計算頁數、尺寸、各頁渲染與檔案雜湊；它以原檔 SHA、來源與原生 PDF 的 SHA、真正的 native_file_id 和 native_revision 驗證已完成的檢查。不要叫使用者填表、產檔或手算雜湊。對讀稿沒有影響的渲染字距差、字型替代或原有空白頁碼預留位置，只在需要時以實畫判定並在工作紀錄中消除誤報；真正文字、表格、資料或視覺的缺失要修。以私人 JSON 保存本次比較結果，包括 `original_ref`、`original_sha256`、`import_source_id`（實際提供給 Google 匯入的原始 Drive 二進位檔 ID）、`native_file_id`、`native_revision`、`source_page_count` 和依原頁序的 `pages`。每頁包含 `source_page`、`native_page_id`、實際檢視之來源與原生頁面渲染的 `source_render_sha256` 和 `native_render_sha256`、`structure_verified`、`protected_visuals_verified` 以及 `unresolved`。記錄私有證據的位置與露出錯字／缺字的圖區、所作修復，供人工查閱。僅能在實際比較成功時設為 true 且 unresolved 為空；即使計數和結構都對，圖內字形未通過就須停在查修，不得認證原生來源。
2. 原生來源須取回 PDF 或 PPTX 做比對時，可使用 ../../studio-production/references/web-production-tools.md 的「Google 原生簡報匯出原始檔案」，處理工具實際回傳的結構化位元組。以 canonical JSON（UTF-8、依鍵名排序、保留 Unicode、無額外空白）計算完整紀錄的 SHA-256；將其可讀取的私人檔案引用及雜湊填入 `plan.source_native.verification_ref`、`verification_sha256`。該欄也帶相同的 original_ref、original_sha256、import_source_id、native_file_id、native_revision、實讀的 original_page_count，及對本件已成立的 private_native_source_allowed。頂層 source_ref 是核對過的原生簡報標準編輯網址，source_revision 與服務讀回相同；若要求 Work 實算原始位元組，記 `requirements.verify_original_bytes_in_work=true`，此備援不適用。
3. 在 Work 用真正 get_presentation 的 ID 與修訂執行。若有權隨純文字指令帶入核對摘要，可將只含頁次、識別、校驗碼和結果的完整 compact JSON 放在 source_native.verification，此時不需另存 verification_ref 或另外下載。勿將投影片文字、原圖、私密連結參數或原檔塞入封包。若摘要存於私人 Drive 的小檔，用正式工具直接讀到 JSON 文字或 inline bytes；存於本人私人 Google 文件時可正式讀回完整正文，解析 JSON 後在 Work 儲存。以 canonical digest 核對，排版空白不影響。用已內嵌的紀錄，或從已核對引用讀回、實際寫入 Work 的 JSON 檔，執行 `open-portable` 和 `claim`，兩者都帶 `--source-id ACTUAL_NATIVE_ID --source-version ACTUAL_NATIVE_REVISION`；紀錄另存檔時加 `--native-verification CHECKS.json`。有 source_native 而欠缺這些讀回證據、任一頁未通過或修訂不同時，請完成或重新執行比較。具備這些核對後，照前述規則建立不同成品 ID、重新設計，再驗兩種正式交付。一般使用者直接以既有 Google 簡報為原稿仍走原本的原生來源入口。
