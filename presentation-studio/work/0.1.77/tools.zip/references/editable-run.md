# 正式製作端受理可編輯式製作

依 ../../studio-flow/references/chat-to-work.md 分流，Work 取得已確認工作後才執行下列製作步驟。普通 Chat 或宿主身分不明時，以可選取文字或已驗證的原設定卡提供本件完整 Work 指令及貼上步驟，到此結束 Chat 的交接。明確獨立的 Codex 任務沿用其原有入口。

連第一份工作稿在對話出現之前，就依 visible-delivery.md 核對兩個實際輸出的每一頁。任一應有內容的頁面空白，須在私人工作檔中修復、重新渲染，再交出本版。

正式製作端的可編輯工作以文件製作為主。在本次工作檔內使用當下提供的 ChatGPT Images 工具產生已授權的素材。原生生圖工具可以與文件工具同時存在；圖片在回覆中顯示為圖集，只說明畫面已顯示。依實際回傳的圖檔或操作記錄決定下一個工具動作。只有已知會結束回合的獨立圖片介面才需要已受理這份工作的接續服務。 依本次設定選擇媒材。允許概念示意時可製作原生圖解；選寫實照片或超擬真重繪時須實際使用相應的生圖工具。已選原圖重繪就傳入該圖的真實參照。

網頁 Work 讀回並認領使用者親自貼送的工作後，或明確獨立的 Codex 任務取得既有授權後，立即讀取原稿與本次設定，使用該宿主已有的簡報、檔案和 Google Drive 工具。在查找或等待圖片能力之前，先實際寫入所有頁面能獨立完成的版面、精確原文、保護圖片、表格、資料圖與隱藏狀態。鎖定原稿版本（可取 SHA256 則取）、版面與逐圖需求。原稿的另一份完全相同的複本、只有空白頁或頁面數的清單，都不算完成排版。資料密度需要使用者決定的頁按已授權範圍先保全並處理其他頁。

**本工作要求每張重新生成時**，採用新工作 ID 並保存 `settings.fresh_images_only=true`。比對、派工、補做、接續及成品驗收都以當次請求為邊界。略過舊素材包、先前成品及 Library 舊圖，後續可取回本工作已派出的同一次正式生成結果。對 `findGenerated` 只查待處理的 request.key，回傳的 request_key、asset_key 皆須吻合；另用 generation_ref 和解碼檔案核實。此限制只管需要新增或重繪的圖位，原稿指定沿用的截圖、資料圖、識別影像及原文照常保留。

**明確要求測單頁失敗時**，在 `job.retry_test={page,name}` 填入本次計畫中的一個圖位。首次到此圖位時，佇列在呼叫服務之前只注入一次 not_started，記成 injected_not_started。接著實際完成其餘可製作頁面並保存每張新圖檔，首輪結束再對該圖位真正派工，沿用同一工作及確認。每次記錄頁、圖位、次數、事件、實際結果引用；用最後成品對照每張圖已置入。單步 Python 可將相同的 retry_test 傳給 editable-image-queue.py，其 STATE 的 image_events 按實際順序保存注入與完成事件。製作端只有逐次工具時，執行同一順序並以真實工作檔／工具回傳留證。日常任務省略 retry_test。製作報告分別說明受控未派送、實際服務錯誤與成功生成；只有觀察到後頁真的先完成、本頁真正補回並交付時，才報告該情境通過。介面沒有可接續的生成路徑時仍完成其他工作，列明未通過的步驟。

**先確保轉檔途徑。** 能直接寫 Slides 時，將完成的這一層配置寫到同一份私人原生簡報並讀回每頁；採 PPTX 路徑則先組裝、讀回各頁及保護物件，再使用既有的 Drive 匯入備援。保留可更新的原生 ID 或可重開的工作檔。資料圖、組織圖、截圖核對原件與數字；原文和資料不能進入生圖提示詞請它重製。生圖只收獨立的非敏感素材。儲存本次生成物與工作紀錄；途中收到工具錯誤仍接著做。原稿和成品目標分開。

表單的逐圖例外在任何生圖、快取比對之前套用。JavaScript 入口接受 job.image_adjustments={source_key,revision,catalogue,edits}。catalogue 每筆含 page（目標頁）、name（穩定圖位）、kind（original 或 empty_page），原件含 reference、sha256、protected；edits 只列修改的 page、name、action 與適用的 brief。original 支援 inherit／keep／redraw／replace；empty_page 支援 inherit／skip／add。來源端計畫先按全份預設建立；用實際提交的多行 brief，保留其他頁與同頁各圖的原決定。替換沿用原物件圖位；被指定維持無圖的頁不派送自動新增的圖片。只有逐次工具的環境也以這些實際欄值製作。

**文件工作的原生單圖回圈。** 在本次文件工作目錄建立實際 plan.json 和 state.json。每次用 `editable-image-queue.py next` 取得真正待辦，點擊只需一次。執行對應 prepare-asset-call.py，把它產生的該件場景或單獨參照交給目前可用的 ChatGPT Images。圖像回傳是預覽卡且主體明顯錯誤時，本機仍可記錄該次原生卡與拒用原因，下一步從佇列重新取得，不能把整個服務登記為已失敗。可取得原檔的成功和可確認的失敗都要逐次寫回。當目前圖位暫時沒有支援的參照輸入，繼續其他圖位並列出該圖位真正受阻的原因。確認規格與來源從本工作紀錄讀回，無須使用者再傳描述。

在 Python 文件宿主上，共用目前對話的生圖工具將 settings.image_input_scope 設為 conversation。程式逐件輸出 generate_asset 操作。當前原生工具實際支援的參照欄傳入 prepare-asset-call.py 的 --reference-key，可出現多個宣告過的欄。工具僅從目前回覆接收圖片時，顯示唯一的本圖位參照後立即呼叫它；不得在參數中假造 file ID。已目視整張輸出卡但拿不到正式圖檔時，使用 `editable-image-queue.py reject-preview PLAN STATE EVENT`。EVENT 帶上 page_number、name、當次 request_id 和實際 generation_ref，preview_review 內同時帶該 request_id、generation_ref、preview_ref、whole_output=true、content 和觀察到的理由 observation。實際可用的本次工具收據、同次工作已儲存的該圖卡或其媒體引用，皆可作拒用綁定。只有「生成中」或沒有對應的實際結果時保留待查。只有資料夾中可打開的原始圖片和該圖位的成功驗收可成為組裝輸入。
   
**同次呼叫派工。** 若宿主有可連續呼叫連接器的 JavaScript 工具，載入 scripts/run-editable.mjs 的 runEditable(job, host)，立即 await 其結果。只有實際製作端可呼叫此入口。不可在只負責提交對話的 HTML 表單裡模擬工具。job 的 id、revision、source_key、pages、settings、assets 綁定本次任務。assets 只含已授權的獨立素材，每項含 page、name、action、brief，redraw 再含 reference。鎖定媒材、重繪對象、無圖頁授權與保護例外。不要將暫效簽名網址寫入進度。

| 宿主提供的函式 | 實際工作 |
| --- | --- |
| load(id)、save(id,state,expectedVersion) | 讀本工作的私有 JSON，以修訂比對後才寫入；新紀錄版本為 0。發生競爭則重新讀回，避免重複派工。 |
| prepare(job,base) | 組裝或讀回已完成獨立排版的所有頁，回傳 ref 與按原順序的 page_refs。接續時驗證並沿用同一底稿。 |
| generate(asset,request)、lookup(asset,request) | 用正式生圖工具實際派工。實際未啟動回 not_started，明確失敗回 failed；可驗證的真圖回 ready、file、generation_ref。未取得結果或可能仍在執行回 unknown 及可用的 operation_ref；lookup 依操作收據或同一請求查回。不能證明服務未啟動時勿重送。 |
| apply(base,ready) | 在原先保留的版位加入或替換所有可用真圖。以頁及穩定物件名稱識別，重做也只會有一個物件。部分缺圖仍要完成其餘物件。 |
| verify(base,job,ready) | 必要時按既有直接匯入／Drive 接續轉檔，讀回同一原生 Slides。回傳 native_id、url、pages、content_ok、differences。依實際檔案核對文字、受保護原件、數據、圖片、頁序、顯示與無新增頁碼。 |

**精緻型宿主驗收。** 依 refined-review.md 實際渲染並看過所有精緻型頁面。verify 除原有欄位外回 output_revision（本次正式成品的版本，如 PPTX SHA256 與原生 Slides revisionId 的組合）及 design_review；可改由 host.reviewDesign(base,job,verified) 取得。design_review 包含 profile="refined"、source_key、revision、native_id、output_revision 與 pages。每頁含 page、render_ref（實際開啟的該頁渲染物引用或雜湊）、focal_point、observation、status="pass" 或 "revise"、editable_ok；需改時附 reason。來源有原生圖表時提供 job.editable_charts，每項含 page、count、formats（依交付要求為 pptx、slides 或兩者），row.chart_counts 各記從對應交付檔實際讀回且可編輯的數目。PPTX 驗查資料活頁簿與數列；Slides 驗查圖表物件與對應 Sheets 數據。
**連結資料圖表。** 快速型和精緻型均從已確認的原生圖表需求與實際 Slides 物件查核。job.work_folder_id 或 prepare 的 base.folder_id 指向本次工作資料夾。verify 的 chart_delivery 提供 presentation（完整 get_presentation）、folder、slides_file、pptx_file（Drive 檔案中繼資料）及 workbooks；每份包含 spreadsheet（實際 get_spreadsheet 讀回 properties、sheets[].properties、charts 及來源資料範圍的 data.rowData）和 drive_file。要求交付 PPTX 時，以 verified.pptx_file_id 綁定工作資料夾中已驗證的實體 PPTX，即使對話下載採用本機檔案卡也要核對。只要原生 Google 簡報時，驗收 Slides、對應資料試算表及兩者父資料夾，不要求額外的 PPTX；只要 PowerPoint 時，驗收內嵌圖表數據，依所選目的地交件。首次查有缺項時，host.prepareChartDelivery(base,job,verified,issues) 可先修復，再 verify 從檔案讀回。host.publishDelivery 應將回傳的 chart_workbooks 中各檔的 id、title、url、pages 對應實際工作，在同一則成品訊息附上具名試算表連結。

有需要重排的頁由 host.repairLayout(base,job,ready,issues) 就地重排及同步兩份成品，接著以新渲染重驗；重試沒有產生新版本時保存具體缺項，避免無限重做。job.layout_change_pages 只在使用者明確限制修改範圍時提供。頁級型態例外用 job.page_profiles（頁次對應 quick/refined）保存。只缺畫面證據先取回、渲染及核對；不能只填布林值或用先前的縮圖冒充。

## 生圖成功後接回製作
先辨認當下的文件製作環境及實際暴露的生圖操作。已受理的 Work 文件工作可先產出並讀回完整可編輯工作檔、原生 Slides 及本工作的連結圖表試算表，保存工作引用、版位、來源修訂及受保護的原件。工具可調用但在這個回合的返回行為仍未知時，從既有文件工作呼叫第一次原生素材生成。這次呼叫用真實準備置入的圖。收到一張可解碼且通過素材檢查的圖就先置入，儲存進度，再派下一項。收據顯示已生成但尚取不到檔案時，按原請求查回；確定失敗才列入稍後補做。

JavaScript 執行器從可信宿主整合取得 `host.surface`；網頁設定卡的選值、啟動指令以及使用者提供的 JSON 都不可填作宿主身分。普通 Chat 或無法辨認的宿主一律交接。已受理的 Work 或已核實的獨立 Codex 任務，依其「回到工作」或「可能終止回合」的能力，分別直派或使用已核實的接續執行者。

派工由 runner 先保存 request.key 與 asset_key（綁定 job、來源內容識別、內容修訂、設定與含頁號／圖位／描述的素材）。新結果寫入工作目錄，已生成但回合只留下圖卡時記 status="generated"、generation_ref 和可取得的 operation_ref，保持待取回。host.findGenerated(job,asset,request) 先從本次工具訊息、Library 或私人工作紀錄核對這些來源資料；僅對真的匹配者帶回相同 asset_key 與 generation_ref，已能開啟及解碼原圖就回 status="ready"、file。舊回合沒有機器收據時依實際派工訊息、確認設定和圖位或順序做可追溯比對；有多個可能而不能核實者保留待辨識，不能依同名、三張輪播或相似主題任取一張。觀察到已成功的素材，即使取檔延遲也不再生圖。在單次可執行的工作中，先對全部圖位查回先前的成功結果，再派仍未嘗試的項目。

將可用圖片寫入對應具名圖位，與保護截圖及資料圖層逐件核對，更新同一份 Slides 及同一工作的 PPTX。verify 實際讀回可下載的成品二進位後傳 pptx_ref。host.publishDelivery(job,packet,outputRevision) 在同一對話真正顯示核對過的該版 PPTX 與 Slides，讀回 message_ref。工作、修訂、成品兩份版本與目的對話相同時重用已發送的回執。只有可執行逐次工具的環境，以實際工具及當下可顯示的最終訊息完成相同行為。若發布前已中斷，接手時優先補交已驗證的兩份檔案。

**只有逐次工具呼叫的製作端** 也依上表次序直接執行各項實際工具，不把腳本支援當作前置條件。可用 Python 時依 editable-image-queue.py 的 next、record、defer 保存並取得下一項。若一次未派工就顯示「圖像生成未啟動」，以該素材記錄 not_started，同一回合派送其餘素材；首輪完成自動回頭補，每項最多三次。工具傳輸結果不明先查回，其他工作仍推進。所有已確認符合素材要求的真圖都要寫入，包括有某一素材耗盡重試時。Google 原生讀回成功且各頁保護項核對完成才交付，尚缺素材必須列明。若宿主在工具回應前終止對話且沒有可繼續的執行器，保留實際已寫入的工作；只有實際仍在執行的工作可以告知正在背景製作。

## 精緻型的逐件配圖與錯圖回補

以本頁的圖文關係決定每一件授權素材的用途。獨立點陣 icon 用 role=icon，小插圖用 small_illustration，去背人物或器物用 subject_cutout；組裝時寫入 kind=cutout。簡單圖示可直接由原生透明底圖形組成。場景照與保護原件依各自用途記錄。局部改提示詞、重試和接續時帶回這些圖位設定。提供透明輸出參數的原生生圖工具，首次和補圖都傳實際的透明參數。按 scripts/check-cutout.py 對下載的完整圖做檢查。退件先做後頁，再由原佇列回補。

把完整成品物件計畫保存為 job.visual_plan，各頁沿用 page_number 及 objects；跨格式用穩定名稱對回實際物件。原生小圖示記 kind=icon_group 或 native_icon=true，獨立去背圖片保留 role、transparent_cutout=true 與核准素材的 SHA256。PPTX 與原生 Slides 的輸出用 references/refined-cutout-delivery.md 的命令直接驗收。JavaScript 製作端將原始報告放入 design_review.cutout_delivery，或從 host.inspectCutouts(base,job,verified) 回傳。verify 從實際定稿計畫檔計算 visual_plan_sha256，讀回本次可交付檔案的 pptx_sha256、原生 slides_revision、visible_reports 的各 PDF 雜湊。遇到轉檔白底、錯素材或少列一件，對應圖位須補驗或修復再交付。只要求一種格式時核對該格式。

每個新生或重繪圖位只向圖像工具傳**獨立素材的視覺描述**（request.prompt 或 Python 佇列返回的 prompt）。例如「單張寫實攝影，戴淺藍手術衣的護理師在無人洗手台上以肥皂洗手，側面近景，自然光」。重繪另外傳入該圖的實際原始參照。工作識別、檔案、頁數、驗收表、故障測試、三份交付說明及對話歷史屬組裝端紀錄，請留在外層；不要複製到圖片提示。每次呼叫前重新建立該圖位的短描述。補做只根據上次錯圖原因收窄鏡頭、主體、材質與背景。

從本次生成操作取回**整張原始檔**、計算 SHA256，開圖實看其主體、媒材、畫面是否符合當頁要求，並按最終投影片渲染尺寸量圖位可見寬高（像素）。照片中合理出現儀表板或招牌要依用途判讀。整張錯生為流程說明、交付資訊圖、拼貼聯絡表或驗收報告，標記 wrong_composition 並淘汰整張。取其局部、加大插值、重新壓縮或同一圖片冒充不同新圖位，均無法補救此失敗。合格獨立原圖可在 PowerPoint／Slides 原生圖位內等比裁切；按比例檢查實際可見區的像素夠用。原有截圖、數據圖及已指定的原圖照其既有規則保護。

已受理此工作的製作端可用 Python 時，先逐張看原圖，從剛開啟的檔案和原始工具結果取得真正的雜湊，填寫 EVIDENCE.json，包含 generation_ref、source_sha256（工具原始輸出）、viewed_sha256（實看檔案）、observation（具體看見的內容）、content（matched／wrong_subject／wrong_medium／wrong_composition／unusable）及 placement_px={width,height}。執行 `python3 scripts/check-generated-asset.py IMAGE EVIDENCE.json`。腳本會解碼並量測檔案，檢查雜湊、像素與人工／模型的實圖觀察。JS 宿主將其 visual_review 連同原工具的 file 與 generation_ref 交給 runner，或以 host.reviewGenerated(asset,receipt,request) 讀回同格式證據，file 應為本次同一份可查回的檔案引用。用 Python 佇列時將其 visual_review、file、generation_ref 放入 record 事件。不要用布林勾選、圖名、OCR 關鍵字或沒有打開原圖的推測代替實看。

明確錯圖記 rejected，保存圖位、生成引用、雜湊及實際不符原因；先跑所有尚未派工的圖位，再自動回補受拒圖位，每次要取得該圖位另一個獨立生成原檔。不得回收同一被淘汰的圖。只缺證據時保留原請求為待查狀態，繼續其他頁；可取回原操作時先查回，避免無謂重送。三次真實嘗試均失敗才標明缺圖，保留其餘已完成的內容。有舊工作已把淘汰圖片嵌入時，host.apply 的 restore_slots 僅恢復具名圖位的原始狀態。以上也適用於只有逐次工具呼叫的 Chat。交圖前從成品讀回圖片，核對與本次驗收的原始圖檔對得上。

## 生圖服務未啟動時接回同一工作的真圖

每次實際取得一張生成素材就保存該素材、原件內容雜湊、採用修訂、完整設定、頁別與物件例外、實際提示和生成收據。使用自己 Drive 的工作資料夾，無須開啟公開連結。可用 scripts/saved-media.py 的 pack SOURCE JOB.json ARCHIVE.zip 保存。JOB 含 revision、settings、assets；每個素材含 page、name、action、brief、可選的逐物件設定、file、generation_ref，redraw 另帶原件雜湊或穩定參照 reference。建議檔名「PS-media-原稿SHA256-修訂.zip」。排版底稿、已完成簡報不放入此素材包。

同工作接續或「同一份、同樣設定」的新一輪，有已失敗或根本未啟動的素材時，用目前已連接的 Drive 在工作或原稿資料夾尋找相符素材包。確認卡建立時若已核對過包的真實引用，可把該引用隨提交帶入。現有照片素材也可以來自該工作已實際生成並核對的私人紀錄。使用者明確要求全新圖時跳過既有素材。只有檔名或語意相似均不足以採用。recovery 的條件是來源內容雜湊、採用修訂、完整設定及例外、該頁該物件的動作、參照、已採用畫法與提示都相同。重跑同一設定時沿用已保存的逐物件計畫；另有指定要更換主體或媒材則使用新修訂。

執行 recover SOURCE JOB.json ARCHIVE.zip OUTPUT_DIR 核對以上條件、每一張圖片的實際解碼與 SHA256，只回傳完全符合的個別素材。當次流程可以直接讀到資料時，也依同樣契約逐一核對。將這個讀取接到 runEditable 的 host.recover(job,asset)。有真實命中就把它寫入相應圖層、標註「沿用本份原稿先前生成」，不宣稱本次重新生成。不符或取不到就處理其他頁、執行有限重試，不任選庫存照或整份舊簡報替代。Google Slides 接受本回合檔案時可直接以 batch_update_presentation 的工具契約將私有圖片置入，或將圖片放進同一 PPTX 再經由 Drive 轉檔。先前若只累積了圖片，這次仍需從本次原稿組裝與核對所有頁及圖表。

非終止式產圖適配器提供 host.generateReturning(asset,request)，回傳已解碼的圖檔或可查回的收據。優先使用此適配器。只有能持久監看本作業並主動呼叫組裝與交付的宿主，才實作 host.ensureContinuation(job,base,oldReceipt)。先確認其實際執行、來源、修訂、目的對話與存取權，驗證後回傳 active、job_id、revision、worker_ref；同一工作重用訂閱。宿主不提供此能力時勿自行填造。

**連接器只傳回圖表 ID 時的唯讀驗收。** Drive 提供的 mime_type 和 parent_ids 可直接讀取。若 Sheets 無法用唯讀工具取得完整 chart.spec，先以原生試算表 ID 讀取 sheets[].properties、charts_only 的 chartId 及標題，再從同一個 ID 匯出 XLSX，保留匯出回執的 file_id、mime_type、size。將同次查回的 spreadsheetId 與各工作表的 properties／charts 合併為 META.json。執行 scripts/read-exported-chart-ranges.py META.json EXPORT_RECEIPT.json EXPORT.xlsx，將輸出放入該工作簿紀錄的 exported_ranges。它從工作表繪圖與圖表關聯讀取各數列的實際儲存格公式，單張圖對單張圖或唯一、完全相同的圖名才能配對。若無法對應便保留未驗收。用實際分頁名稱讀取這些範圍的 CellData，再依 sheetId 合併到同一本試算表的 sheets[].data，以 cell.effectiveValue 或實際已輸入的值核對。不要用試算表寫入操作來取得圖表定義。直接讀回完整 chart.spec 和儲存格時可以省略匯出。

### 可編輯 PowerPoint 轉檔的字級驗收

製作流程知道 Google 簡報由此次可編輯 PowerPoint 轉檔時，將 `slides_from_pptx: true` 寫入當次 verify 結果及轉檔工具的進度；獨立設計或只有整頁圖片的簡報不套用逐字比對。以實際交付的 PowerPoint PDF 和本次原生 Slides 匯出的 PDF 執行 `scripts/compare-rendered-type.py`，保存輸出的 JSON。將前者的 SHA256 填入原生簡報驗收 PLAN 的 `pptx_pdf_sha256`，執行 `python3 scripts/check-visible-pages.py PLAN.json NATIVE.pdf --type-report TYPE.json`。以該結果作為 `visible_reports.slides`。同一個字級報告必須對得上兩份最新渲染。可量測的縮字會回傳頁次、文字與尺寸給既有的 repairVisible；無法自動配對的標籤則對照兩份畫面逐項複核。先修復該頁原生文字再讀回，以新版本重新比對。資料圖表的文字若由圖表引擎繪製，要調整相應的圖表設定或依實際渲染覆核，維持已連結試算表的圖表。

### 錯圖改用一個實際參照的單圖編輯請求

精緻型某圖位若生成整頁簡報、圖集或其他錯圖，記錄這次操作為 rejected。先跑所有待做頁，再用該圖位新的 request_id。加圖的回補實際改用帶參照的編輯呼叫。重繪直接使用已授權原件的獨立圖片。只有服務真能在不帶舊對話的獨立上下文生成時，才可改以該獨立單圖工具進行文字生圖。兩種作法都由正式製作端在文件工作內實際派送。

生圖期間，先將整份底稿、逐頁 PDF／PNG、圖表及修復樣張存到工作目錄。用程式讀取文字、像素統計和圖表數值，這些私下的實際檢查可以持續進行，工具回覆只顯示數字、文字及引用。不要在對話內顯示整份簡報的縮圖表、任何完整投影片或 chart 截圖。要察看生成原圖時只顯示那一個圖位的獨立原圖；所有圖片派工結束後才展示或打開完整簡報的畫面進行最終視覺驗收。

1. 在檔案工具中以本次 `editable-image-queue.py next` 的單一 ACTION.json 執行 `python3 scripts/prepare-asset-call.py ACTION.json WORKDIR --reference-key referenced_image_paths`。動作會有 prompt、request_id 及 reference_kind。首次新增素材為 none，原圖重繪為 original，新增圖位的錯圖回補為 guide。guide 會依這張圖的主體、實際版位長寬比生成一張無文字的獨立 PNG 構圖稿。可以在該圖位的 composition_guide 提供 preset（object、person、people、environment、detail）或 primitives（單一主體的輪廓，格式形如 `[["ellipse",[0.3,0.15,0.65,0.5],"foreground"],["line",[0.6,0.46,0.85,0.84],"subject"]]`）。顏色可用 background、subject、foreground，座標值為 0–1；另支援 rectangle 和 polygon。把主體的可辨識特徵畫出來，避免只放一個抽象色塊。original 可用 `--original-file` 帶實際解碼的原始物件。參照只用指定的單一原件或這次生成的構圖稿。
2. 若當前原生生圖工具只接受圖片引用，將參數改成 `--reference-key referenced_image_ids`。收到 register_reference 就用本回合可用的檔案／圖片功能實際註冊這張 PNG，再以 `--registered-ref ACTUAL_ID` 執行同一動作。不以路徑冒充檔案 ID。將輸出中的 **provider_input 本身**逐欄傳給當前真正的生圖工具。不要另外串入 JSON 的其餘欄位或工作說明。本次操作的一個新請求收據及回傳的原始圖檔在生圖服務之外登記。使用具備真正獨立上下文的文字生圖時，可對 guide 動作用 `--isolated-text`。缺少參照時記錄實際無法註冊的操作，再做其他圖位。
   若原生編輯工具的真實契約只接受最近圖片，選用 `--reference-key num_last_images_to_include`。工具回傳 show_single_reference 時，在本回合實際單獨顯示 reference_file，確認畫面只有該張參照且它是最新的一張，使用剛顯示檔案的真實雜湊傳 `--last-shown-sha HASH`，立即對同一圖位發出編輯呼叫。provider_input 會限制最近影像為 1。不要在兩個動作間開啟簡報、資訊圖或縮圖表。宿主不支援這個參數時，只用它已支援並可核對的圖片引用。

3. 純 JS 宿主可提供 `host.singleImage.generate(provider_input,operation)`，把 operation.key 留在本地追查，將第一參數直接用於單素材生成。參照欄採用已暴露工具的真實契約 `host.singleImage.referenceKey`。有需要時由 `host.resolveImageReference(source,key,kind)` 實際下載／註冊；Node 宿主會執行同一 Python 工具製作導引。底稿階段的 prepare、verify、inspectVisible、apply 均收到 render=private_files、display=none；可用檔案與數值核對。最近圖片介面須以 showSingleImage 的實際顯示回執核對 sole_image、latest 及 sha256。沙箱也可實作 `host.makeSceneGuide(action)`，回傳實際無字 PNG 的 file 和 sha256。舊宿主的 generate 僅將 request.provider_input 送入生圖工具；如實際工具要求不同的參照欄，將該次唯一 reference 轉為它的正式參數。宣告 isolated=true 的宿主必須真正開啟獨立的當次運算；圖片命名或提示詞無法保證隔離。
4. 在原始生成檔實看後才組裝。將 prepare 回傳的 reference_sha256 作為本次結果事件的 input_reference_sha256，排除直接回傳原圖或無字構圖稿。仍生錯圖就繼續佇列；某圖位已耗盡三次時，做完所有其他符合條件的圖位。已通過的圖照常組裝，剩下哪個圖位是真的缺件要列明。

### 已看到整張錯圖，但工具尚未把原檔交回

錯圖的原生生成卡若已完整顯示、能連回本圖位這一次請求，直接記拒用，隨即繼續佇列。Python 使用 `editable-image-queue.py reject-preview PLAN STATE EVENT`，事件帶 page_number、name、原 request_id、實際 generation_ref；preview_review 內帶相同 request_id 與 generation_ref、實際可回查的 preview_ref、whole_output=true、具體觀察 observation，以及 wrong_subject、wrong_medium、wrong_composition 或 unusable。JS 回傳 status=rejected_preview，附本請求的 request_key、asset_key、generation_ref 與同一份 preview_review。畫面只見局部、串錯頁或缺乏可以查證的作業引用時，維持待查；接受素材仍一律需要解碼並審核原始圖檔。同一操作重入不重複計數。一般工具錯誤用 defer，已看見完整拼貼的情形用 reject-preview，才能啟動錯圖的參照回補。

每個圖位仍有未試次數時，用相應的原件／無字構圖稿單獨再派，不因第一個圖位重生失敗就放棄後面所有圖位。在 `prepare-asset-call.py` 重複帶 `--reference-key`，列出目前原生工具確有的欄位；某欄位實際註冊失敗可用 `--unavailable-reference-key` 略過該欄並沿用同一請求。JS 可用 host.singleImage.referenceKeys 列出同一個原生工具確已宣告的欄位。先嘗試已可用的方法，沒有才回傳 register_reference／show_single_reference。所有已宣告方法皆被拒時，Python 以 `hold-reference` 事件記錄這次 request_id 與具體 reason，繼續其他圖位。這不是生成嘗試；同一次工作的工具取得新方法後，用 `release-reference` 並帶原 request_id 與已可用欄 available_field，就能繼續原待補圖位。JS 當輪也會停用無法派工的圖位、繼續其餘項目，重入時再次查核可用方法。只將當前原生 ChatGPT／OpenAI 生圖工具綁入這個製作流程。即使原生工具無法派圖，也不會改用 Canva 或其他外部生圖服務。

確知原生圖片工具帶入整段對話上下文時，將 settings.image_input_scope 設為 conversation。對精緻型新增素材，第一次就採用獨立單圖引導。Python 會標示 guide_if_supported；把從當前工具實際讀到的參照欄交給 prepare-asset-call.py，它再決定製作構圖稿、註冊或使用該圖。JS 明確回報 singleImage.isolated=false 且提供真實參照欄時同樣執行。可確證隔離的單圖服務可直接送獨立文字；未提供參照欄就不捏造參數、圖片 ID 或曾完成的編輯動作。
