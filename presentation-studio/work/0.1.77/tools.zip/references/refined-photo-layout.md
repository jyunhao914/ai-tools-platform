# 精緻型的照片取景與圖層

先在原稿或工作底稿上圈定要完整保留的截圖、正文、表格、數據圖與註腳。再看已授權使用的獨立圖片，指出觀眾需要看清的主體，例如正在接合的兩個零件、正在示範的雙手或一人看向另一人的視線。讓原生文字、照片和色塊可以分別選取。

## 從主體決定框與層次

- 解釋環境時可讓大照片跨過兩欄、越過頁邊，或把主體放在版面一側，為相鄰原句留出空間。例如用跨欄的操作情境照保留兩人與器材的關係。橫幅和直幅要分別計算主體範圍，勿直接置中裁成同樣的方塊。
- 解釋物件外形時，可把獨立透明主體跨放在兩個純色區域或情境照邊緣。圖示可用數個可改色的原生形狀組合。同頁的小插畫可與主圖錯開對齊，讓視線從正文走向相關部件。配圖數量、輪廓和層數取決於這頁的資訊；純文字和證據頁可只調整字級、排列與間距。
- 圖層跨色塊或靠近文字時，在最終雙色底與正式頁面看輪廓、文字對比和閱讀順序。要沿用的截圖、圖表、標誌與其他證據保有完整畫面和長寬比。受保護資料的頁面位置可在計畫中預留。

## 直接使用正式配圖計畫

以下為已授權新增照片的一頁。假設投影片 13.33 × 7.5 英吋，照片裡操作雙手位於右半部。讀取獨立生成檔後才量焦點及主體邊界，實際工作需換成該頁數值和檔名。

```json
{
  "editable_profile": "refined",
  "pages": [{
    "page_number": 1,
    "protected_objects": ["操作說明"],
    "layers": [{
      "name": "雙手組裝零件",
      "kind": "picture",
      "action": "add",
      "file": "assets/assembly.png",
      "box": [5.2, -0.15, 8.4, 7.9],
      "fit": "cover",
      "photo_layout": {
        "focus": [0.73, 0.50],
        "subject": [0.61, 0.26, 0.24, 0.46],
        "anchor": [0.57, 0.51],
        "safe_zones": [{"name": "左欄圖說", "box": [0.50, 2.1, 4.4, 2.25]}]
      }
    }]
  }]
}
```

`box` 和安全區均為當頁左、上、寬、高（英吋）。`focus` 是原圖上的關鍵點，`subject` 是應完整保留的原圖範圍，`anchor` 是希望焦點落在擬定圖片框的位置。三者以各自寬高的 0–1 表示。超出畫布的框會收至實際頁面邊界；主體仍須完整可見。安全區預設 `avoid:"image"` 完整排除圖片。刻意用照片作為文字底圖時，只在該文字範圍使用 `avoid:"subject"`，同時供應 `subject`；這會留出主體以外的區域，底色對比仍以實際渲染檢查。

把要沿用的具名原件加入當頁 `protected_objects`。PowerPoint 製作工具自動加入原生頂層表格與圖表的範圍，其他證據應填入該名稱。群組可取整個具名外框，或在 `safe_zones` 提供換算至頁面的真實外框。若要用原生文字疊於攝影留白，該文字框只用主體避讓區；其餘截圖、刻度與註解維持完整排除。當主體無法容納或侵入保護區，製作工具先組裝其他物件和後頁，再自動回來試放完整原圖，必要時移入最近且足夠大的可用區域。同一頁毫無可用區域時，回傳 `status:"needs_layout"` 與 `pending_layout`，保存原件及已組裝的工作稿。依該清單自動重排授權變動的物件並重跑待修頁，已完成的頁可沿用。若重排需要拆頁或變更使用者鎖定的原件，依原有密度流程處理。

對應 `VISUALS.json` 的 `kind:"cutout"` 或 `role:"icon" | "small_illustration" | "subject_cutout"` 應以同一頁碼、物件名稱與角色填入生成佇列。精緻型已核准新增／重繪的點陣小圖即使標為 `kind:"picture"` 也用透明 PNG 檢查。向量圖示仍用 `kind:"vector"`，可在簡報內更改各部件。一般情境照片保留 `kind:"picture"`。物件用途本身不授權新增或重繪。

## PowerPoint 與 Google 簡報

1. `python3 scripts/editable_visuals.py INPUT.pptx VISUALS.json OUTPUT.pptx` 會把原始單圖嵌入 PPTX，將可見幾何寫入原生圖片裁切。可個別選圖重新取景。舊工作省略 `photo_layout` 時沿用原來的置中 cover／contain。需單獨計算時執行 `python3 scripts/refined-photo-layout.py SPEC.json`；輸入鍵為 `image_size`（像素寬、高）、`frame`、`canvas`（頁面寬、高）、`options`（上述 photo_layout）和可選的 `fit`。
2. 新製作的 Google 簡報優先匯入該 PPTX。從該頁讀回原生圖片、cropProperties、實際框與層序，再與 PowerPoint 畫面並排看主體及證據。同一圖表的資料連結仍按 editable-layout.md 的流程驗收。
3. 直接在既有 Google 簡報新增圖片時，將原始單圖保存在本工作私人素材中。`slides_visuals.prepare_focal_image(layer, asset_root, output_dir, canvas, editable_profile="refined", protected=zones, occupied=other_objects)` 以同一幾何輸出該圖片的展示用 PNG、原件路徑與雜湊、可見框。zones 要帶入這頁各原生表格、圖表和指定原件的實際框，other_objects 帶入需要避免在局部換位時遮住的現有文字、圖片與群組。用 `focal_add_requests(layer, prepared, page_id, new_object_id, units_per_inch=...)` 把 PNG 作為獨立原生圖片加入。傳入實際頁尺寸換算的單位、最新修訂及工作內圖檔，透過 Slides 連接器的 image_uris 交付位元組。若計畫以前後具名物件為錨，依頁上真實順序另排層並回讀。需要更新已核准的原圖時，比對原件識別後只替換其圖片，核對實際位置、圖層及畫面。Google 的 cropProperties 供讀回使用；直製的展示圖要重新取景時，由保留的完整原件再產生該單圖。

## 使用者明確指定大圖構圖變化

將已確認的要求存入 `settings.photo_layout_variety:true`。既有交接可沿用 requirements 或 settings.layout_instruction 的原句，例如「大圖依版面錯落裁切」。只選精緻型或自動版面時，依每頁內容決定。明確鎖定圖片框的物件以 `layout_locked:true` 或 `fixed_frame:true` 留在原位。截圖、數據、裝飾小圖與透明主體沿用各自的保護或去背驗收。

先按頁面用途決定取景。跨欄場景需要能看清人物或器材關係的橫構圖，短操作示範可留一張局部靠邊的完整手勢照片，資料密集頁先保正文與證據。生成前把該頁的構圖和主體寫入其獨立配圖 brief。若現成原圖的焦點放不進選定圖框，先試不裁主體的其他可用留白。重繪需沿用前一步已授權的原圖範圍。需要重新生成才可解決時，先做其他頁，再回到該圖位。

對有三個以上可調整主圖的精緻頁，`work-pptx` 直接量成品的可見框形與畫布比例。相同滿高側欄的左右交換屬同一種構圖。尺寸、長寬比例和頁緣關係要有看得見的不同，例如一張全高側照配一張橫幅或局部靠邊相片。可用以下工作命令處理。
   
- `python3 scripts/photo-layout-variety.py check RUN_DIR CANDIDATE.pptx` 讀定稿中的具名圖片，回傳逐頁實際圖框、原生裁切及 pass、repair_layout 或 not_applicable。
- `python3 scripts/photo-layout-variety.py repair RUN_DIR CANDIDATE.pptx --out FIXED.pptx [--focus FOCUS.json]` 在既有安全空間內挑一個主圖框調整，另存本工作的修正版。FOCUS 為陣列，如 `[{"page":4,"name":"監測小組","focus":[0.64,0.41],"subject":[0.34,0.18,0.46,0.59],"anchor":[0.55,0.44]}]`；依該頁實照量取，座標格式與前段相同。省略完整主體範圍時只嘗試容納整張圖。實在沒有可用空間時，工具保留原稿，由製作端優先改排允許移動的版面區域或改生該頁適合的獨立比例。對沒有改動授權的證據原件保留其位置、顯示比例及裁切。
- 再跑 `work-pptx`、實際逐頁渲染與雲端核對。Google 簡報使用正式檔的 `presentations.get` 完整讀回，如 `check RUN_DIR FIXED.pptx --slides-json NATIVE.json --slides-id ID --slides-revision REV`。交付證據使用 `files.slides_json` 指向同一正式修訂。檢查可到達的原生物件、可見框與裁切，確認對應的兩份實際畫面均保留焦點與全部正文。
