# 圖像式逐頁製作與交付

ChatGPT 的三種製作模式（含單頁）只有實際 Work 受理後才可啟動本流程。App、網頁普通 Chat 或宿主不明時直接回 ../../studio-flow/references/chat-to-work.md，留下可複製的 Work 啟動指令。已辨認的獨立 Codex 任務可照原有入口執行。每張重新設計的投影片都由正式 ChatGPT Images 依本頁定稿直接生成整頁。使用正式可用的素材、組裝與 Drive 工具，依 ../../studio-flow/references/chat-to-work.md 確認正式製作端，受理後依 studio-production 保存並讀回原生 Google 簡報。腳本在 ../scripts/；雲端可透過正式技能資源取得這些實檔後放在同一資料夾。以下命令都由外掛執行。使用者只需回答內容與設計問題。

## 頁面任務

建立 v2 JOB，③每頁都要完成密度試排，記錄 fits、needs_decision 或已授權方案。①②文字取自已採用大綱，③取自原稿、已採用改句或已授權拆頁的新計畫。每頁即使只有一張圖或沒有文字，也要保存其真實內容。例：

```json
{"schema_version":2,"mode":3,"content_revision":"r1","expected_pages":1,
 "pages":[{"page_number":1,"title":"操作流程","text":"操作流程\n先洗手。","hidden":false,"density_status":"fits",
 "design":{"palette":["#FFFFFF","#182D40"],"layout":"左對齊","typography":"清晰黑體"},
 "visuals":[]}]}
```

圖像式工作若有逐頁／逐圖調整，先依 studio-settings/references/image-review.md 將表單值實際寫入頁面的 visuals。可用 scripts/image-adjustments.mjs 的 applyImageAdjustments(job) 套用同一份編輯紀錄，再用這份已解析的計畫啟動整頁佇列；重繪要用正確原件、沿用要帶原件雜湊。

每頁預設 source_kind=generated_full_page。visuals 列本頁要出現的物件。keep 和 redraw 均需 id、action、可用的原始區域 reference 與實際來源 sha256；redraw 還要描述被授權重繪的主體與用途（brief）。add 需要 id、action 及其授權；讀稿後將正文支持的具體選材及用途寫入 brief 或 subject。整份、頁與物件的 media_style 由窄到廣查找，寫實照片、插畫與自訂畫法只套用 add／redraw。使用者交由內容自動決定時，為各圖填 resolved_subject 與 resolved_media_style；keep 區域直接使用原物件。省略的裝飾不列入。visuals=[] 表示本頁不加配圖，仍須實際生成整頁。已核准保留的圖中若含內文，逐區記錄屬於該圖的文字，在生圖提示中標明原圖會帶入這些字，避免頁面出現兩份。

依本頁內容選擇視覺主次、對齊、層級、圖文位置及留白。例如組織頁按原隸屬關係安排層級與留白，儀表板頁依閱讀順序為原始儀表板保留可讀的最大面積。避免所有內頁都複製深色標題條、縮小內容塞入格子。不得為了變化創造病人、設備、組織關係、圖表或數值。「自動風格」只解決設計選擇，不能改變正文或擴大配圖授權。

③某頁已明確授權整頁原樣保留時，才填 source_kind=approved_original_page、authorization、真實 reference 及對應的 sha256。取得保留比例、不裁切內容的 16:9 原頁影像；原尺寸不符時先以等比例補邊取得該頁影像，記錄轉換及來源，再核對這張影像的雜湊。一般選「沿用原圖」限於頁內指定物件。①②新建頁預設 hidden=false；③逐頁複製已讀取的來源狀態。已採用拆頁依密度規則記錄 source_page、source_range。

## 派送與記錄

執行 image-page-queue.py init JOB STATE，再用 next JOB STATE。依下列步驟處理每個派送結果，並以同一狀態接續。每次只送本頁的完整正文、共用風格、本頁構圖及真正需要的來源素材。保存當次提示、來源物件用途、工具實際回傳的結果與引用。生成多頁總覽、拼貼再分切，不能充作逐頁生圖。

1. generate_full_page：對目前頁實際呼叫正式 ChatGPT Images。核對 prompt 包含全部定稿並將其標明為畫面要呈現的文字；重繪物件要把真實參考檔一同送入。由模型直接產出單張、滿版 16:9 的完整投影片，完成標題、正文、承載資訊的層次與已授權視覺。指定 keep 的資產只於指定位置預留正確比例及空白，不讓模型重造其中的文字或數據。若無需嵌回原區域，該生成結果即是最終頁。避免把模型限縮成只提供照片或背景後再用程式加正文。
2. 生成頁的 RECEIPT 記錄當次工具結果 generation_ref、保存下來的完整 generated_path 與 asset_evidence（無物件時為 []）。keep、redraw 各一筆 {id,action,reference,sha256,path}，path 指該項已核對的來源素材實檔；add 填 {id,action:"add"}。所有列項依 JOB 原決定填入。keep 另附像素位置 box=[x,y,w,h]。只有 keep 需要合成時，使用 compose-page.py JOB 頁碼 RECEIPT OUT.png 將指定來源區域等比例嵌回正式生成頁，其他像素保持原樣。不使用合成補正文、建立圖表、繪製模板或重做整頁。沒有 keep 時用原始生成檔當 image_path。保留原始生成檔、圖像工具引用與最終實檔，逐頁都可對回實際工具結果。
3. reuse_original_page：取用該頁已授權的原頁檔，image_path 必須符合來源雜湊，不填生成引用。檢視每張最終頁及整份縮圖：核對與原頁的對應、層級、閱讀順序、可讀性、保護區域、配圖動作及是否新增頁碼。先看整頁呈現，再放大資料與文字區。檢查原稿／授權與可見成品之間的實際差異。若生成輸出只有背景、純局部插圖、套版截圖、錯誤來源或缺了整個資訊區，依第 6 步處理。

4. 對最終畫面或原生物件及其渲染畫面獨立讀回文字。原稿只用作比對，不能把 expected 複製到 observed_text 充作讀回。固定依原稿的區域閱讀順序，包含標題、正文、表格單位、圖表數字、註腳、來源與署名。必要時放大該區；標誌、已沿用圖片中的原文字不應漏讀或重複。OCR 讀錯而畫面實際正確，採畫面文字。無法可靠辨認時標明「待辨識」，不猜字、不阻塞其他頁。
5. 在上述 RECEIPT 補齊 page_number、此次 request_id、實檔 image_path、layout="single_slide"、review。review 包含實際 PNG/JPEG 的 artifact_sha256、method（visual、ocr_confirmed、ocr_uncertain 或 native_and_visual）及獨立實讀的 observed_text。另在 review 填 added_page_number=false，代表已核對畫面沒有新增頁碼；若為 true，需先局部移除額外頁碼，再核對該頁，不把它當一般錯字交付。若整頁確實無法讀回，才用 method=unreadable 加具體 reason；此頁列入交付的未核對說明。執行 image-page-queue.py record JOB STATE RECEIPT。頁面有錯字也會回 page_recorded，直接 next。已保存的頁若晚些才發現錯字，用 review JOB STATE EVENT 更新同一圖的閱讀結果；EVENT 含 page_number、原 request_id、review。錯字既不重繪也不要求採用。若同一張已保存圖片後來發現多了頁碼，review 回 page_reopened；用新 request_id 只修該頁。使用者要求後才開局部修訂。
6. 工具未啟動、明示失敗、逾時查明失敗、缺有效整頁生圖或生成證據、錯頁、錯用素材、版面截斷或工具只回縮圖總覽時，執行 defer JOB STATE EVENT，EVENT 含 page_number、次序相符的 request_id、具體 reason。defer 的回傳含 next，直接執行其中的下一個操作，無須使用者點重試或傳送接續訊息。工具回傳遺失時以 next JOB STATE 取回同一個待辦。先跑完還沒有試過的頁面，再分輪修待補頁。每頁最多原嘗試加兩次自動修復；needs_attention 只會在其他可前進頁面都處理後回報。整個服務不可用時保存進度，不針對每頁消耗額度。重送相同事件是冪等的，晚到的舊嘗試不會覆蓋新結果。
7. assemble 時執行 export JOB STATE MANIFEST，使用佇列產生的新版 manifest（schema_version=3）；讀回所有生成引用、來源區域、實檔、SHA256 及原頁序。檔案完整性與引用互異可由腳本檢查，正式生圖工具呼叫的真實性與畫面是否符合用途仍須對照實際回傳與成品，不能以手填引用、輸出頁數或每頁一張圖代替。逐頁放入對應的完整頁面圖並設定該頁 hidden。使用 PPTX 路徑時，用 slide-output.py assemble MANIFEST DECK.pptx（python-pptx）或同等工具組裝；validate-image-deck.py MANIFEST DECK.pptx 退出碼 0 且 passed=true 才按 studio-production 匯入。若直接建立原生 Slides，從 manifest 取回已驗證的真實圖檔，以本回合能力置入並讀回頁序、尺寸、圖片數量／位置、播放狀態及實際渲染，逐頁比對相應來源。結構檢查與文字清單獨立，已知錯字不會令此檢查失敗。

## 可交付畫面的驗收

三種來源模式都在首次工作稿、正式交件、變更格式或重交下載前看實際將交出去的版本。單頁生圖若只回傳整張透明、白色、其他單色，record 會將該頁排入補做，直接執行回傳的 next。hidden 只控制播放順序，隱藏頁仍要用本身的完整畫面驗收。如果原稿本來就刻意留白或使用者已指明，先在採用的 JOB 中設 expected_content="intentionally_blank"、blank_authority=該原稿位置或實際授權，並確認該頁沒有要保留的正文或圖片。封面、純圖頁及無配圖頁預設仍有正文或視覺主體；如主體刻意置於非預設位置可在 JOB 填實際版面的 body_regions。

validate-image-deck.py MANIFEST DECK.pptx 的 passed 只證明結構及來源，可進行匯入。若交付的是 PPTX（含首次可下載工作稿、替換附件或重新取得的下載），從該附件的確切位元組直接匯出 PDF 並包含隱藏頁。將 artifact_id、output_revision（該 PPTX 的 SHA256）、pdf_path、pdf_sha256 寫進 RENDER_RECEIPT.json，同一工具操作保存輸入及輸出對應。用 validate-image-deck.py MANIFEST DECK.pptx RENDER_RECEIPT.json 執行實際像素檢查，release_ready=true 才提供使用者。只有 needs_review 的頁可補入 visual_reviews，每筆以 page、pdf_sha256、pass 和實際所見 observation 記錄。整頁應有內容卻空白時，先重新寫入該頁並重渲染。原生 Slides 另從準備顯示連結的目標檔取當下 revisionId，匯出逐頁畫面驗收；備援轉檔造成的空白就修復同一檔。若一般 PDF 省略隱藏頁，逐頁取隱藏頁實際縮圖、或在不動交付檔的驗收副本暫顯後渲染，依原序校對回實際投影片。已清楚註明工作稿也不能跳過畫面檢查。

## 文字差異清單

report JOB STATE 可隨時讀回已完成頁發現的差異。依成品頁碼排序，列「第 N 頁〈頁標題〉｜畫面：…｜定稿：…」。字太短則附前後文，漏字或多字寫清楚。拆頁後同列原第幾頁。OCR 仍不確定的項目另標「待辨識」；確有未檢查區域要具體說明。清單與簡報連結一起交付，不另加投影片，不擅改原稿本來的字。完全一致時無須多列一張空表。可編輯式對實際輸出可使用 page-text-review.py EXPECTED.txt EVIDENCE.json RENDERED_FILE 對讀回結果做相同比對，彙整到同一份交付訊息。Google 匯入若改變可見文字，更新為實際交付版本的讀回結果。

## 舊版與接續

保留舊 JOB、STATE、原始結果及來源授權。舊 v1 或 v2 manifest 可用於稽核當時成品。舊版已有真實整頁生成並能核對該次引用、生成檔、文字修訂、素材及逐物件決定的頁，才可沿用到新版製作。舊版以程式排字合成的 composed_page 缺少整頁生圖，不得改名、補寫引用或直接搬到新版完成清單；保留舊檔，按原稿及已確認設定只補製未達條件的頁。舊原頁保留紀錄需將既有授權與實際原頁 SHA256 對應後再沿用。遷移時先按逐頁已決定的動作與來源備齊 hashes，重新 init 新版工作狀態，不覆蓋舊進度。已知錯字不構成舊生成頁重做的原因。

新版 v2 JOB/STATE 跨環境接續時保留工作、狀態、原始生成、來源區域及最終圖片的相對路徑；從保存的檔案重算 SHA256。內容／風格確有修改時建立新修訂，先 init 新狀態，再用 image-page-queue.py carry OLD_JOB OLD_STATE NEW_JOB NEW_STATE。它只沿用新舊均可驗證、文字範圍與物件處理相同的頁及其紀錄。其餘各頁按新任務處理。錯字清單更新使用 review，不另開修訂。
