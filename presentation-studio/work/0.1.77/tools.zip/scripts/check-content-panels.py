"""Check redundant enclosures across a statement, sequence and comparison in actual editable output."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn

HERE=Path(__file__).resolve().parent
ROLES={"statement-spread","sequence","parallel-comparison"}
ROLE_NAMES={"statement":"statement-spread","thesis":"statement-spread","procedure":"sequence",
            "steps":"sequence","comparison":"parallel-comparison"}
AUTO=(None,"","auto","automatic","自動","自動風格","依內容設計")


def box(shape,deck):
    return (shape.left/deck.slide_width, shape.top/deck.slide_height,
            shape.width/deck.slide_width, shape.height/deck.slide_height)


def rect_fill(shape):
    xml=shape._element
    if not xml.xpath('./p:spPr/a:prstGeom[@prst="rect" or @prst="roundRect"]'):
        return None
    colors=xml.xpath("./p:spPr/a:solidFill/a:srgbClr/@val|./p:spPr/a:solidFill/a:schemeClr/@val")
    return colors[0] if colors else None


def contains(frame,content):
    x,y,w,h=frame
    a,b,c,d=content
    slack=.013
    return x-slack<=a and y-slack<=b and x+w+slack>=a+c and y+h+slack>=b+d


def capped(frame,rule):
    x,y,w,h=frame
    a,b,c,d=rule
    return ((d<=.034 and abs(x-a)<.015 and abs(c-w)<.025 and min(abs(y-b),abs(y+h-b-d))<.014) or
            (c<=.027 and abs(y-b)<.015 and abs(d-h)<.025 and min(abs(x-a),abs(x+w-a-c))<.014))


def panels(page,deck):
    shapes=list(page.shapes)
    if any(s.has_table or s.has_chart or s._element.tag in (qn("p:pic"),qn("p:graphicFrame"),qn("p:grpSp"))
           or s._element.xpath("./p:spPr/a:blipFill") for s in shapes):
        return []
    text=[s for s in shapes if s.has_text_frame and s.text.strip()]
    empty=[(s,box(s,deck),rect_fill(s)) for s in shapes if s.has_text_frame and not s.text.strip() and rect_fill(s)]
    result=[]
    for s,frame,color in empty:
        x,y,w,h=frame
        if not (.12<w<.83 and .10<h<.73 and y>.12):
            continue
        members=[t for t in text if contains(frame,box(t,deck))]
        if not members:
            continue
        caps=[k for k,r,accent in empty if k.shape_id!=s.shape_id and accent!=color and capped(frame,r)]
        effect=s._element.xpath("./p:spPr/a:effectLst/a:outerShdw")
        # Free-standing dividers, colored title bands and rectangles without text are not cards.
        if caps or effect:
            result.append((s,frame,color,members,caps))
    # Require repeated, separate shells actually enclosing different groups of text.
    if len(result)<2 or any(set(t.shape_id for t in a[3])&set(t.shape_id for t in b[3])
                               for i,a in enumerate(result) for b in result[i+1:]):
        return []
    dominant=max({r[2] for r in result},key=lambda c:sum(t[2]==c for t in result))
    repeated=[r for r in result if r[2]==dominant]
    return repeated if len(repeated)>=2 else []


def options(plan):
    rows={}
    values=[plan.get("pages"),plan.get("visual_plan")]
    for val in values:
        if isinstance(val,dict):
            val=val.get("pages")
        if isinstance(val,list):
            for p in val:
                if isinstance(p,dict):
                    n=p.get("page") or p.get("page_number")
                    rows.setdefault(n,{}).update(p)
    return rows


def related_roles(source,plan,model=None):
    settings=plan.get("settings",{})
    if settings.get("layout_style") not in AUTO or (settings.get("editable_profile")!="refined"
            and "refined" not in (plan.get("page_profiles") or {}).values()) or settings.get("template_ref"):
        return {}
    if model is None:
        compose=runpy.run_path(str(HERE/"compose-refined.py"))["compose"]
        with TemporaryDirectory() as tmp:
            model=compose(source,Path(tmp)/"designed.pptx",plan)
    rows=options(plan)
    source_deck=Presentation(source)
    result={}
    for item in model["pages"]:
        i=item["page"]
        cfg=rows.get(i,{})
        if ((plan.get("layout_change_pages") is not None and i not in plan["layout_change_pages"]) or
            (plan.get("page_profiles") or {}).get(str(i),settings.get("editable_profile"))!="refined" or
            cfg.get("layout_locked") or cfg.get("approved_original_page") or
            source_deck.slides[i-1]._element.get("show") in ("0","false")):
            continue
        if item["composition"] in ("respect-explicit-layout","quick-or-other-profile") or cfg.get("comparison_group") or cfg.get("template_id") or cfg.get("allow_content_panels"):
            continue
        explicit=str(cfg.get("purpose") or cfg.get("intent") or "").casefold()
        role=ROLE_NAMES.get(explicit,explicit) if explicit else item["composition"]
        # A named but unrecognized activity, layout or set of parallel cards has no applicable claim.
        if role in ROLES and not panels(source_deck.slides[i-1],source_deck):
            result[i]=role
    return result


def windows(roles):
    return [[i,i+1,i+2] for i in sorted(roles) if {roles.get(i),roles.get(i+1),roles.get(i+2)}==ROLES]


def sentence_stream(page):
    return "".join("".join(s.text.split()) for s in page.shapes if s.has_text_frame and s.text.strip())


def text_matches(source,target):
    # A format's slide index alone cannot bind a role to different or reordered material.
    return sentence_stream(source)==sentence_stream(target)


def check(source,candidate,roles):
    original=Presentation(source)
    deck=Presentation(candidate)
    if len(original.slides)!=len(deck.slides):
        raise ValueError("Input and output slide counts differ.")
    found={}
    for page in sorted({p for triple in windows(roles) for p in triple}):
        a,b=original.slides[page-1],deck.slides[page-1]
        if text_matches(a,b):
            rows=panels(b,deck)
            if rows:
                found[page]=rows
    hits=[g for g in windows(roles) if all(i in found for i in g)]
    return deck,found,hits


def repair(deck,found,pages,roles,target,original_file):
    for page in pages:
        slide=deck.slides[page-1]
        rows=found[page]
        # Some exporters keep the background on the master; only remove bright panels if text
        # contrast can be kept. Native text may inherit its fill from an unknown theme.
        shade=slide._element.xpath("./p:cSld/p:bg/p:bgPr/a:solidFill/a:srgbClr/@val")
        if not shade or min(bytes.fromhex(shade[0]))<195:
            raise ValueError("Use the private composed source or reflow the native page manually; background contrast cannot be verified.")
        if any(r[2] not in ("lt1","bg1") and (len(r[2])!=6 or min(bytes.fromhex(r[2]))<190) for r in rows):
            raise ValueError("Recompose these source roles without changing light text contrast.")
        for panel,_,_,_,borders in rows:
            for s in [panel,*borders]:
                if s._element.getparent() is not None:
                    s._element.getparent().remove(s._element)
        if roles[page]=="parallel-comparison":
            frames=sorted((r[1] for r in rows),key=lambda f:f[0])
            if len(frames)==2:
                left,right=frames
                gap=right[0]-left[0]-left[2]
                if .008<gap<.18 and abs(right[1]-left[1])<.018:
                    line=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,int((right[0]-gap/2)*deck.slide_width),
                                int(left[1]*deck.slide_height),max(1,int(.0013*deck.slide_width)),int(min(left[3],right[3])*deck.slide_height))
                    line.name="Comparison column divider"
                    line.fill.solid();line.fill.fore_color.rgb=RGBColor.from_string("A3B6B1")
                    line.line.fill.background()
    with TemporaryDirectory(dir=target.parent) as tmp:
        updated=Path(tmp)/"updated.pptx"
        copy=Path(tmp)/"private.pptx"
        deck.save(updated)
        changed={str(deck.slides[n-1].part.partname).lstrip("/") for n in pages}
        # Only these slide XML parts changed. Keep original notes, media, charts, master
        # artwork, package relationships and every unrelated slide byte-for-byte.
        with ZipFile(original_file) as before, ZipFile(updated) as after, ZipFile(copy,"w") as out:
            for info in before.infolist():
                src=after if info.filename in changed else before
                out.writestr(info,src.read(info.filename))
        os.link(copy,target)


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("source",type=Path)
    cli.add_argument("pptx",type=Path)
    cli.add_argument("--plan",required=True)
    cli.add_argument("--roles",type=Path)
    cli.add_argument("--roles-sha256")
    cli.add_argument("--slides",type=Path)
    cli.add_argument("--require-slides",action="store_true")
    cli.add_argument("--repair-out",type=Path)
    a=cli.parse_args()
    plan=json.load(sys.stdin) if a.plan=="-" else json.loads(Path(a.plan).read_bytes())
    model=None
    if a.roles:
        raw=a.roles.read_bytes()
        if sha256(raw).hexdigest()!=a.roles_sha256:
            raise ValueError("The source role report does not match its accepted Work checkpoint.")
        model=json.loads(raw)
    roles=related_roles(a.source,plan,model)
    selected=windows(roles)
    issues=[]
    if selected:
        inputs={"pptx":a.pptx}
        if a.slides:
            inputs["slides"]=a.slides
        elif a.require_slides:
            issues.append({"format":"slides","reason":"Read the final native Slides PowerPoint export to compare the three content relations."})
        for fmt,file in inputs.items():
            deck,found,hits=check(a.source,file,roles)
            pages=sorted({n for group in hits for n in group})
            if pages and a.repair_out and fmt=="pptx":
                repair(deck,found,pages,roles,a.repair_out,file)
                if check(a.source,a.repair_out,roles)[2]:
                    raise ValueError("Repeated text enclosures remain after repair.")
            if pages:
                issues.append({"format":fmt,"pages":pages,"roles":[roles[n] for n in pages],
                    "reason":"不同閱讀關係的連續三頁，把各段原文重複包進帶有相同邊飾或陰影的獨立框。保留對照與步驟，移除多餘外框後再看三頁。",
                    "repair":"check-content-panels.py SOURCE OUTPUT --plan PLAN.json --repair-out FRESH.pptx; apply the corresponding native object changes to Slides and read back both outputs."})
    print(json.dumps({"issues":issues,"eligible_windows":selected},ensure_ascii=False))


if __name__=="__main__":
    main()
