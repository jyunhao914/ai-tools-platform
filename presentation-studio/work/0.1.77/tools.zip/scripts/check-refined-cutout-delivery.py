"""Read the real PPTX objects and verify nominated decorations on the delivered surfaces."""
import argparse
import hashlib
import importlib.util
import json
import math
import re
from io import BytesIO
from pathlib import Path

import fitz
import numpy as np
from PIL import Image
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE as ST
from pptx.oxml.ns import qn
from pptx.exc import PackageNotFoundError

SCHEMA = "presentation-studio/cutout-delivery/v1"
NATIVE = {ST.AUTO_SHAPE, ST.FREEFORM, ST.LINE, ST.CALLOUT}
UNIT = {"PT": 1, "EMU": 1/12700}
BOX_KINDS = {"rect","roundRect","RECTANGLE","ROUND_RECTANGLE"}


spec = importlib.util.spec_from_file_location("cutout_check", Path(__file__).with_name("check-cutout.py"))
cutout_check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cutout_check)


class Review(ValueError):
    """Evidence is incomplete; the absence of evidence is not an acceptance."""


def sha(data):
    return hashlib.sha256(data).hexdigest()


def document(path):
    return json.loads(path.read_text(encoding="utf-8"))


def targets(plan):
    """The source is the complete approved layout, not a list supplied by the final report."""
    found = []
    keys = set()
    default = (plan.get("settings") or {}).get("editable_profile") or plan.get("editable_profile")
    profiles = plan.get("page_profiles") or {}
    for i, page in enumerate(plan["pages"],1):
        n = page.get("page_number",i)
        if not isinstance(n,int) or n < 1:
            raise ValueError("Invalid page number")
        profile = page.get("editable_profile") or profiles.get(str(n)) or default
        if profile != "refined":
            continue
        for obj in page.get("objects",[]):
            kind = obj.get("kind")
            if obj.get("protected") is True or obj.get("action") == "keep":
                continue
            cutout = cutout_check.requires_cutout(obj)
            icon = (obj.get("native_icon") is True or kind in {"icon_group", "native_icon"}
                    or (cutout and kind in {"vector", "shape", "auto_shape", "freeform", "group"}))
            if not (cutout or icon):
                continue
            name = obj.get("name")
            if not isinstance(name,str) or not name.strip() or (n,name) in keys:
                raise ValueError("Ambiguous, duplicated or unnamed planned decoration")
            keys.add((n,name))
            found.append((n,name,"native_icon" if icon else "picture",obj))
    return found


def require(ok, message):
    if not ok:
        raise ValueError(message)


def status(call):
    try:
        return {"status":"pass",**call()}
    except Review as e:
        return {"status":"needs_review","reason":str(e)}
    except (ValueError,KeyError,IndexError,TypeError,OSError) as e:
        return {"status":"fail","reason":str(e)}


def pts(m):
    return float(m["magnitude"])*UNIT[m.get("unit","EMU")]


def bounds(coords):
    x,y = zip(*coords)
    return (min(x),min(y),max(x),max(y))


def area(b):
    return max(0,b[2]-b[0])*max(0,b[3]-b[1])


def nearly_same(b, target):
    overlap = (max(b[0],target[0]),max(b[1],target[1]),min(b[2],target[2]),min(b[3],target[3]))
    return area(target)>0 and area(overlap)/area(target)>=.82 and area(b)<=area(target)*1.55


def ppt_bounds(s):
    return (s.left,s.top,s.left+s.width,s.top+s.height)


def normalized(box, w, h):
    return tuple(v/(h if i%2 else w) for i,v in enumerate(box))


def leaves(s):
    if s.shape_type != ST.GROUP:
        yield s
    else:
        for c in s.shapes:
            yield from leaves(c)


def solid_white_powerpoint(s):
    geom = s._element.xpath("./p:spPr/a:prstGeom")
    if not geom or geom[0].get("prst") not in BOX_KINDS:
        return False
    fill = s._element.xpath("./p:spPr/a:solidFill")
    if not fill:
        return False
    v = list(fill[0])
    if not v:
        return False
    colour=v[0]
    if colour.xpath("./a:alpha") and int(colour.xpath("./a:alpha")[0].get("val","100000")) < 90000:
        return False
    token=colour.get("val","")
    return (colour.tag==qn("a:srgbClr") and bool(re.fullmatch("[0-9a-fA-F]{6}",token))
            and min(bytes.fromhex(token))>=236) or (colour.tag==qn("a:schemeClr") and token in {"bg1","lt1"})


def native_ppt(s):
    parts=list(leaves(s))
    require(parts and all(p.shape_type in NATIVE and not p._element.xpath(".//a:blip") and
            not (p.has_text_frame and p.text.strip()) for p in parts),"Icon contains non-native artwork or text")
    if s.shape_type==ST.GROUP:
        if any(p.shape_type==ST.GROUP for p in s.shapes):
            raise Review("Inspect nested icon transforms against the underlying design")
        children=list(s.shapes)
        overall=bounds([(x,y) for p in children for x,y in (ppt_bounds(p)[:2],ppt_bounds(p)[2:])])
        if any(solid_white_powerpoint(p) and nearly_same(ppt_bounds(p),overall) for p in children):
            raise ValueError("White rectangular backplate inside PowerPoint icon group")
    elif solid_white_powerpoint(s):
        raise ValueError("A white rectangular shape cannot prove an unbacked native icon")
    return len(parts)


def approved_pixels(blob, fractions=(0,0,0,0)):
    check = cutout_check.inspect_bytes(blob)
    require(check["status"] == "ready", "Ineligible delivered cutout: " + ", ".join(check["reasons"]))
    with Image.open(BytesIO(blob)) as img:
        require(img.format=="PNG" and ("A" in img.getbands() or "transparency" in img.info),
                "Final image is not an alpha-bearing PNG")
        image=img.convert("RGBA")
        w,h=image.size
        l,t,r,b=fractions
        if min(fractions)<0 or not (l+r<1 and t+b<1):
            raise Review("Unresolved extended or empty image crop")
        image=image.crop((round(l*w),round(t*h),round((1-r)*w),round((1-b)*h)))
        data=np.asarray(image.getchannel("A"))
        require(data.size and np.mean(data<=16)>=.01 and np.mean(data>=max(20, .42*int(data.max())))>=.01,
                "Crop has no meaningful transparent surround or visible subject")
        if any(fractions):
            visible=image.copy()
            visible.thumbnail((640,640),Image.Resampling.NEAREST)
            alpha=np.asarray(visible.getchannel("A"))
            core=alpha>=max(120,round(int(alpha.max())*.75))
            for side in (core[0],core[-1],core[:,0],core[:,-1]):
                require(cutout_check.longest_run(side)<max(3,round(len(side)*.025)),
                        "Slide crop cuts into the delivered cutout silhouette")
        return np.asarray(image.resize((96,96),Image.Resampling.NEAREST))


def ppt_object(deck, n, name, kind, item):
    slide=deck.slides[n-1]
    items=[s for s in slide.shapes if s.name==name]
    if not items:
        if any(p.name==name for s in slide.shapes for p in leaves(s)):
            raise Review("Target nested in a transformed group; supply a named top-level delivery object")
        raise ValueError("Planned object missing from final PPTX: "+name)
    require(len(items)==1,"Ambiguous final PowerPoint object: "+name)
    s=items[0];box=ppt_bounds(s)
    require(area(box)>0,"Decoration has no visible extent")
    if s.rotation:
        raise Review("Rotated decoration needs a transformed appearance check")
    for other in slide.shapes:
        if other.shape_id!=s.shape_id and solid_white_powerpoint(other) and nearly_same(ppt_bounds(other),box):
            raise ValueError("Separate opaque white backplate at the PowerPoint decoration")
    audit={"pptx_shape_id":s.shape_id}
    mask=None
    if kind=="picture":
        require(s.shape_type==ST.PICTURE,"Expected a separate picture object")
        source=s.image.blob
        digest=sha(source)
        reviewed=item.get("visual_review",{}).get("cutout_check",{})
        approved = [v for v in (item.get("approved_sha256"), item.get("source_sha256"), reviewed.get("sha256")) if v]
        if approved:
            require(all(v == digest for v in approved),"Final picture differs from the approved original asset")
        else:
            raise Review("Bind the verified cutout asset SHA-256 to this planned picture")
        mask=approved_pixels(source,(s.crop_left,s.crop_top,s.crop_right,s.crop_bottom))
        xfrm=s._element.xpath("./p:spPr/a:xfrm")
        if xfrm:
            if xfrm[0].get("flipH") in {"1","true"}: mask=np.fliplr(mask)
            if xfrm[0].get("flipV") in {"1","true"}: mask=np.flipud(mask)
        audit.update(embedded_sha256=digest,clear_fraction=round(float(np.mean(mask[:,:,3]<=16)),4))
    else:
        audit["native_parts"]=native_ppt(s)
    return normalized(box,deck.slide_width,deck.slide_height),mask,audit


def xform(t):
    factor=UNIT[t.get("unit","EMU")]
    return np.array([[t.get("scaleX",1),t.get("shearX",0),t.get("translateX",0)*factor],
                     [t.get("shearY",0),t.get("scaleY",1),t.get("translateY",0)*factor],[0,0,1]])


def google_nodes(elements, parent=None):
    parent=np.eye(3) if parent is None else parent
    nodes=[]
    for e in elements:
        m=parent@xform(e.get("transform",{}));children=e.get("elementGroup",{}).get("children",[])
        cid=e.get("objectId")
        if children:
            group=google_nodes(children,m)
            childboxes=[v[1] for v in group if v[1]]
            box=bounds([p for b in childboxes for p in (b[:2],b[2:])]) if childboxes else None
        else:
            group=[];size=e.get("size",{})
            if not size.get("width") or not size.get("height"):
                box=None
            else:
                w,h=pts(size["width"]),pts(size["height"])
                box=bounds([tuple((m@np.array([x,y,1]))[:2]) for x,y in [(0,0),(w,0),(0,h),(w,h)]])
        nodes.append((e,box,group,m))
    return nodes


def flatten(nodes):
    for n in nodes:
        yield n
        yield from flatten(n[2])


def white_google(e):
    s=e.get("shape",{})
    if s.get("shapeType") not in BOX_KINDS:return False
    fill=s.get("shapeProperties",{}).get("shapeBackgroundFill",{})
    if fill.get("propertyState")=="NOT_RENDERED":return False
    solid=fill.get("solidFill",{});colour=solid.get("color",{})
    rgb=colour.get("rgbColor")
    return solid.get("alpha",1)>=.9 and (colour.get("themeColor") in {"LIGHT1","BACKGROUND1"} or
             (rgb is not None and min(rgb.get(k,0) for k in ("red","green","blue"))>=.925))


def google_object(native,n,item,kind,media,base):
    if native.get("presentationId") is None or not native.get("revisionId"):
        raise Review("A native Google presentation ID and revision are required")
    oid=item.get("slides_object_id")
    if not oid:raise Review("Bind the actual Google Slides objectId after assembly")
    nodes=list(flatten(google_nodes(native["slides"][n-1]["pageElements"])))
    found=[row for row in nodes if row[0].get("objectId")==oid]
    require(len(found)==1,"Google objectId missing or ambiguous on this page")
    e,b,children,m=found[0]
    if b is None or not area(b):raise Review("Insufficient Google geometry")
    if not children and (abs(m[0,1])>1e-7 or abs(m[1,0])>1e-7):
        raise Review("Rotated or skewed Google image needs a transformed appearance check")
    for other,rb,_,_ in nodes:
        if rb and white_google(other) and nearly_same(rb,b):
            raise ValueError("Opaque white rectangular backplate in the Google presentation")
    verified_media=False;proof={"slides_object_id":oid}
    if kind=="native_icon":
        leaves_=[z[0] for z in flatten(children) if not z[2]] if children else [e]
        require(leaves_ and all(("line" in c or ("shape" in c and
                not any(t.get("textRun",{}).get("content","").strip() for t in c["shape"].get("text",{}).get("textElements",[]))))
                for c in leaves_),"Google icon flattened to an image, or contains text")
        proof["native_parts"]=len(leaves_)
    else:
        require("image" in e,"Google decoration is not a separate image")
        if oid in media:
            record=media[oid]
            require(e["image"].get("contentUrl") and record.get("content_url")==e["image"]["contentUrl"],
                    "Media was not bound to the current Google object contentUrl")
            blob=(base/record["file"]).read_bytes();crop=e["image"].get("imageProperties",{}).get("cropProperties",{})
            approved_pixels(blob,tuple(crop.get(k,0) for k in ("leftOffset","topOffset","rightOffset","bottomOffset")))
            verified_media=True;proof["cloud_media_sha256"]=sha(blob)
    page=native["pageSize"]
    return normalized(b,pts(page["width"]),pts(page["height"])),verified_media,proof


def render(pdf,n):
    page=pdf[n-1]
    scale=min(3,1800/max(page.rect.width,page.rect.height))
    pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),colorspace=fitz.csRGB,alpha=False)
    return np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,3)


def probe_render(im,box,pixels,structural_alpha,manual):
    """Compare nearby inside/outside colors in an actual rendered slide, never the source thumbnail."""
    mask = pixels[:,:,3] if pixels is not None else None
    x0,y0,x1,y1=box;h,w=im.shape[:2]
    if not (0<=x0<x1<=1.001 and 0<=y0<y1<=1.001):
        raise Review("Clipped or off-canvas decoration requires reviewed interior samples")
    def rgb(x,y):
        if not (0<x<1 and 0<y<1):return None
        i,j=round(y*(h-1)),round(x*(w-1))
        return np.median(im[max(0,i-1):i+2,max(0,j-1):j+2],axis=(0,1))
    def xy(u,v):return x0+(x1-x0)*u,y0+(y1-y0)*v
    def clear(u,v):return mask is None or mask[min(95,int(v*96)),min(95,int(u*96))]<=16
    def dist(a,b):return float(np.max(np.abs(a-b)))
    if (x1-x0)*w<10 or (y1-y0)*h<10:raise Review("Too few final pixels to verify this icon at delivery resolution")
    tests=[]
    if manual:
        for pair in manual:
            u,v=pair["clear"];x,y=pair["backdrop"]
            require(0<u<1 and 0<v<1 and clear(u,v) and not (x0<x<x1 and y0<y<y1),"Invalid clear/background sample")
            a,b=rgb(*xy(u,v)),rgb(x,y)
            require(a is not None and b is not None,"Invalid background probe location")
            tests.append((a,b))
        require(len({tuple(v["clear"]) for v in manual})>=3,"Need three distinct transparent sample locations")
    else:
        dx,dy=max(3/w,(x1-x0)*.035),max(3/h,(y1-y0)*.035)
        positions = (.035,.08,.15,.85,.92,.965) if mask is None else (.08,.20,.35,.5,.65,.80,.92)
        for v in positions:
            for u,z,bx,by in [(.045,v,x0-dx,y0+v*(y1-y0)),(.955,v,x1+dx,y0+v*(y1-y0)),
                              (v,.045,x0+v*(x1-x0),y0-dy),(v,.955,x0+v*(x1-x0),y1+dy)]:
                a,b=rgb(*xy(u,z)),rgb(bx,by)
                if clear(u,z) and a is not None and b is not None:tests.append((a,b))
    if len(tests)<3:raise Review("Insufficient visible clear pixels; supply reviewed clear/background samples")
    agree=[dist(a,b)<=18 for a,b in tests]
    colored=[(a,b) for a,b in tests if min(b)<220]
    verified_color=bool(colored) and sum(dist(a,b)<=18 for a,b in colored)>=max(2,math.ceil(len(colored)*.60))
    clear_edges = sum(agree) >= max(2, math.ceil(len(tests)*(.85 if manual else .65)))
    if not clear_edges and mask is None and structural_alpha and not manual:
        # Native line/group bounds end at the stroke center. A round cap can
        # occupy the nearest "outside" sample. Measure a second ring beyond the
        # stroke and use it only if it corroborates the dominant near backdrop.
        margin=max(6.,.14*min((x1-x0)*w,(y1-y0)*h))
        ring=[rgb(x,y) for v in positions for x,y in
              [(x0-margin/w,y0+v*(y1-y0)),(x1+margin/w,y0+v*(y1-y0)),
               (x0+v*(x1-x0),y0-margin/h),(x0+v*(x1-x0),y1+margin/h)]]
        ring=[sample for sample in ring if sample is not None]
        outside=np.median([b for _,b in tests],axis=0)
        if (len(ring)>=12 and sum(dist(b,outside)<=8 for b in ring)>=.95*len(ring)
                and sum(dist(b,outside)<=8 for _,b in tests)>=.65*len(tests)):
            hits = []
            for left, top in ((.03,.03),(.51,.03),(.03,.51),(.51,.51)):
                samples = [rgb(*xy(left+u, top+v)) for u in np.linspace(0,.45,8)
                           for v in np.linspace(0,.45,8)]
                hits.append(sum(a is not None and dist(a,outside)<=12 for a in samples))
            clear_edges = sum(hits) >= 96 and sum(count>=14 for count in hits) >= 3
            if clear_edges and min(outside)<220:
                verified_color=True
    if not clear_edges:
        if colored and sum(min(a)>=236 and dist(a,b)>26 for a,b in colored)>=max(2,len(colored)*.6):
            raise ValueError("White rectangle on the final rendered backdrop")
        raise Review("Complex background or inconsistent registration; supply reviewed clear/background samples")
    if not structural_alpha and not verified_color:
        raise Review("White/ambiguous backdrop cannot prove cloud alpha; read actual Google object media")
    outer=np.median(np.array([b for a,b in tests]),axis=0)
    ink=0
    colour_samples = []
    visible_cutoff = max(20, .42*int(mask.max())) if mask is not None else 0
    for u in np.linspace(.05,.95,17):
        for v in np.linspace(.05,.95,17):
            if mask is not None and mask[int(v*96),int(u*96)]<visible_cutoff:continue
            sample=rgb(*xy(u,v))
            if sample is not None and mask is not None and mask[int(v*96),int(u*96)] >= 245:
                colour_samples.append(dist(sample,pixels[int(v*96),int(u*96),:3]))
            if sample is not None and dist(sample,outer)>24:ink+=1
    if not ink:raise Review("No distinguishable subject in the delivered decoration")
    proof = {"clear_samples":len(tests),"clear_matches":sum(agree),"colored_backdrop_verified":bool(verified_color),
             "subject_samples":ink}
    if mask is not None:
        if len(colour_samples) < 3:
            # A soft-edged drawing may have no opaque pixels. On a measured flat
            # background compare the actual composite using its PNG alpha values.
            if max(dist(b,outer) for _,b in tests) > 12:
                raise Review("Semi-transparent subject on a varying backdrop needs reviewed pixels")
            for u in np.linspace(.04,.96,23):
                for v in np.linspace(.04,.96,23):
                    color = pixels[int(v*96),int(u*96)]
                    if color[3] < 32:
                        continue
                    sample = rgb(*xy(u,v))
                    blended = color[:3] * (color[3]/255.) + outer * (1-color[3]/255.)
                    if sample is not None:
                        colour_samples.append(dist(sample,blended))
            if len(colour_samples) < 3:
                raise Review("Too few visible subject pixels to bind the image")
        proof["source_color_samples"] = len(colour_samples)
        proof["source_color_matches"] = sum(d <= 30 for d in colour_samples)
        require(proof["source_color_matches"] >= math.ceil(len(colour_samples)*.65),
                "Rendered subject pixels disagree with the approved image at the planned object")
    return proof


def slides_bindings(path, native, wanted):
    if not path:
        return {}
    data = document(path)
    require(data.get("presentation_id") == native.get("presentationId") and
            data.get("slides_revision") == native.get("revisionId"), "Object map belongs to a different Slides revision")
    names = {(n,name) for n,name,_,_ in wanted}
    mapping = {}
    for item in data["objects"]:
        key = (item["page"], item["name"])
        oid = item["object_id"]
        require(key in names and key not in mapping and isinstance(oid,str) and oid.strip(),
                "Unknown, duplicated or empty native object binding")
        mapping[key] = oid
    return mapping


def include_composed_art(plan, layout):
    """Add artwork chosen during composition to the originally approved verification targets."""
    plan = dict(plan)
    adopted = plan.get("pages")
    by_page = {}
    if isinstance(adopted, list):
        for i, page in enumerate(adopted, 1):
            if isinstance(page, dict):
                by_page[page.get("page_number", page.get("page", i))] = dict(page)
    for row in layout["pages"]:
        n = row["page"]
        page = by_page.setdefault(n, {})
        page["page_number"] = n
        original = page.get("objects", [])
        objects = list(original)
        names = {obj.get("name") for obj in original}
        for item in row.get("native_art", []):
            name = item.get("object_name")
            if name and name not in names:
                objects.append({"name": name, "kind": "icon_group", "native_icon": True})
                names.add(name)
        for item in row.get("art_slots", []):
            name = item.get("name")
            if name and name not in names and item.get("placed") and item.get("role") == "subject_cutout":
                objects.append({"name": name, "role": "subject_cutout", "transparent_cutout": True,
                                "approved_sha256": item["sha256"]})
                names.add(name)
        page["objects"] = objects
    plan["pages"] = [dict(by_page[n], page_number=n) for n in sorted(by_page)]
    return plan


def run(args):
    data=args.plan.read_bytes();plan=json.loads(data)
    composition=getattr(args,"composition",None)
    layout_bytes=composition.read_bytes() if composition is not None else None
    if layout_bytes is not None:
        plan=include_composed_art(plan,json.loads(layout_bytes))
    wanted=targets(plan)
    modes=["pptx","slides"] if args.surface=="both" else [args.surface]
    artifacts={"pptx_sha256":sha(args.pptx.read_bytes())}
    if layout_bytes is not None:
        artifacts["composition_sha256"]=sha(layout_bytes)
    deck=Presentation(str(args.pptx))
    pdfs={};native={};media={};rows=[]
    bindings = {}
    claimed = set()
    try:
        for mode in modes:
            path=getattr(args, mode+"_pdf")
            if path:
                pdfs[mode]=fitz.open(path);artifacts[mode+"_pdf_sha256"]=sha(path.read_bytes())
                require(len(pdfs[mode])==len(deck.slides),mode+" PDF does not contain the same complete slide sequence")
        if "slides" in modes and args.slides_json:
            native=document(args.slides_json);artifacts.update(presentation_id=native.get("presentationId"),slides_revision=native.get("revisionId"),
                                                             slides_json_sha256=sha(args.slides_json.read_bytes()))
            require(len(native.get("slides",[]))==len(deck.slides),"Native presentation page count differs")
            bindings = slides_bindings(args.slides_bindings, native, wanted)
            if args.slides_bindings:
                artifacts["slides_bindings_sha256"] = sha(args.slides_bindings.read_bytes())
        if "slides" in modes and args.slides_media:
            media = document(args.slides_media)
            artifacts["slides_media_receipt_sha256"] = sha(args.slides_media.read_bytes())
        cached_page = None
        page_renders = {}
        for n,name,kind,item in wanted:
            if n != cached_page:
                page_renders.clear()
                cached_page = n
            result={"page":n,"name":name,"kind":kind,"surfaces":{}}
            def verify(mode):
                if mode not in pdfs:raise Review("Missing final "+mode+" PDF rendering")
                box,mask,proof=ppt_object(deck,n,name,kind,item)
                if mode=="slides":
                    if not native:raise Review("Missing actual native Google Slides object metadata")
                    target = dict(item)
                    supplied = bindings.get((n,name))
                    if supplied:
                        require(not item.get("slides_object_id") or item.get("slides_object_id") == supplied,
                                "Plan and revision-specific object map disagree")
                        target["slides_object_id"] = supplied
                    oid = target.get("slides_object_id")
                    if oid:
                        require(oid not in claimed, "One cloud object cannot verify two distinct decorations")
                        claimed.add(oid)
                    box,verified,proof=google_object(native,n,target,kind,media,args.slides_media.parent if args.slides_media else Path("."))
                else:verified=True
                probes=item.get("transparency_probes",{}).get(mode,[])
                if mode not in page_renders:
                    page_renders[mode] = render(pdfs[mode],n)
                return {**proof,"render_check":probe_render(page_renders[mode],box,mask,
                              kind=="native_icon" or verified,probes)}
            for mode in modes:result["surfaces"][mode]=status(lambda:verify(mode))
            rows.append(result)
    finally:
        for pdf in pdfs.values():pdf.close()
    states={v["status"] for r in rows for v in r["surfaces"].values()}
    overall="not_applicable" if not rows else "fail" if "fail" in states else "needs_review" if "needs_review" in states else "pass"
    return {"schema":SCHEMA,"status":overall,"plan_sha256":sha(data),"artifacts":artifacts,"surfaces":modes,"checked_targets":rows}


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("plan",type=Path);cli.add_argument("pptx",type=Path)
    cli.add_argument("--composition",type=Path,help="Bound composition report produced before final export")
    cli.add_argument("--surface",choices=["pptx","slides","both"],default="both")
    for flag in ("pptx-pdf","slides-json","slides-pdf","slides-media","slides-bindings"):
        cli.add_argument("--"+flag,type=Path)
    args=cli.parse_args()
    try:r=run(args)
    except (ValueError,OSError,KeyError,TypeError,IndexError,PackageNotFoundError) as e:
        r={"schema":SCHEMA,"status":"fail","reason":str(e),"checked_targets":[]}
    print(json.dumps(r,ensure_ascii=False))
    raise SystemExit({"pass":0,"not_applicable":0,"needs_review":2,"fail":1}[r["status"]])
