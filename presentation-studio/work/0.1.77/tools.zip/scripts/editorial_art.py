"""Keep an approved, real image editable while composing its crop with editable text."""
from hashlib import sha256
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageOps
from pptx.oxml.ns import qn
from semantic_icons import forbids_new
from image_provenance import annot, DEFAULT_LABEL


AUTO={"auto","auto_add","auto_illustrate","automatic","content_auto","依內容自動配圖","自動配圖"}
CUTOUT={"subject_cutout","transparent_cutout","cutout","transparent_subject"}
PHOTO={"editorial_photo","hero_photo","scene","background_photo","hero","photo","main_photo","main_scene","supporting_photo"}
REDRAW={"redraw","replace","hyperrealistic_redraw","photorealistic_redraw","超擬真重繪"}


def observed_activity(text):
    """A working scene can illustrate people performing an action already named in the copy."""
    import re
    people=r"人員|同仁|學員|讀者|志工|師生|居民|團隊|旅客|技師|工作者|\b(?:staff|workers?|technicians?|readers?|students?|volunteers?|visitors?|team)\b"
    action=r"監測|檢查|巡查|維修|領取|測量|取樣|整理|安裝|觀測|核對|記錄|清理|演練|操作|\b(?:check|inspect|measure|monitor|collect|sort|repair|install|record|practice)(?:s|ing|ed)?\b"
    return bool(re.search(people,text,re.I) and re.search(action,text,re.I))


def assets_in(plan):
    result=[]
    for owner in (plan,plan.get("settings",{})):
        for key in ("assets","image_assets","image_plan"):
            rows=owner.get(key,[])
            result.extend(rows.get("assets",[]) if isinstance(rows,dict) else rows or [])
    for page in (plan.get("pages") if isinstance(plan.get("pages"),list) else []):
        if isinstance(page,dict):
            for row in (page.get("assets") or page.get("images") or []):
                result.append({**row,"page_number":page.get("page_number",page.get("page"))})
    return result


def permitted_assets(plan,ready):
    settings=plan.get("settings",{})
    approved={(a.get("page_number",a.get("page")),a.get("name")):a for a in assets_in(plan) if isinstance(a,dict)}
    out={}
    for asset in ready or []:
        p=asset.get("page_number",asset.get("page"))
        name=asset.get("name")
        matched=approved.get((p,name),{})
        if not isinstance(p,int) or not name:
            continue
        if matched.get("protected") or matched.get("action") in ("keep","preserve","none") or asset.get("protected"):
            continue
        row={**asset,**matched}
        action=row.get("action","add")
        if action in REDRAW:
            if not (row.get("source_shape_id") and (matched.get("action") in REDRAW or settings.get("original_images") in REDRAW)):
                continue
        elif action=="add":
            if forbids_new(plan,p,empty=True,slot=name,explicit=matched.get("action")=="add"):
                continue
            if matched.get("action")!="add" and settings.get("imageless_pages",settings.get("empty_page_images")) not in AUTO:
                continue
        else:
            continue
        role=row.get("role") or row.get("kind") or "editorial_photo"
        if role in CUTOUT or row.get("transparent_cutout") is True:
            role="subject_cutout"
        elif role in PHOTO or (not row.get("role") and role in ("picture","image","photograph")):
            role="editorial_photo"
        else:
            continue
        file=asset.get("file")
        if not file:
            continue
        data=Path(file).read_bytes()
        digest=sha256(data).hexdigest()
        if asset.get("sha256") and digest!=asset["sha256"]:
            raise ValueError(f"The reviewed bytes changed for {name}.")
        with Image.open(BytesIO(data)) as im:
            if ImageOps.exif_transpose(im).size!=im.size:
                raise ValueError(f"Normalize and review the rotation before using {name}.")
            dimensions=im.size
            if role=="subject_cutout":
                alpha=im.convert("RGBA").getchannel("A").histogram()
                if sum(alpha[:20])<.015*sum(alpha) or sum(alpha[200:])<.05*sum(alpha):
                    continue
        out.setdefault(p,[]).append({**row,"role":role,"bytes":data,"size":dimensions,"sha256":digest})
    return out


def place_art(c,index,box,background_field=None):
    if index>=len(c.photos):
        return False
    row=c.photos[index]
    x,y,w,h=box
    ratio=row["size"][0]/row["size"][1]
    target=w*c.w/(h*c.h)
    if row["role"]=="subject_cutout":
        rw,rh=(w,w*c.w/ratio/c.h) if ratio>=target else (h*c.h*ratio/c.w,h)
        x,y,w,h=x+(w-rw)/2, y+h-rh, rw,rh
    shape=c.slide.shapes.add_picture(BytesIO(row["bytes"]),int(x*c.w),int(y*c.h),int(w*c.w),int(h*c.h))
    shape.name=row["name"]
    if row.get("generation_ref") or (row.get("visual_review") or {}).get("generation_ref"):
        annot(shape,DEFAULT_LABEL)
    if row["role"]=="editorial_photo":
        fx,fy=row.get("focus",(.5,.5))
        if not all(isinstance(v,(float,int)) and 0<=v<=1 for v in (fx,fy)):
            raise ValueError("Photo focus is an x,y pair between zero and one.")
        if ratio>target:
            v=target/ratio
            shape.crop_left=max(0,min(1-v,fx-v/2))
            shape.crop_right=1-v-shape.crop_left
        else:
            v=ratio/target
            shape.crop_top=max(0,min(1-v,fy-v/2))
            shape.crop_bottom=1-v-shape.crop_top
    # Earlier native text and original evidence stay above the placed picture. A selected
    # background color field may sit behind a transparent silhouette that crosses its edge.
    tree=c.slide.shapes._spTree
    tree.remove(shape._element)
    tree.insert(tree.index(background_field._element)+1 if background_field is not None else 2,shape._element)
    if row.get("source_shape_id"):
        old=next(s for s in c.pics if s.shape_id==row["source_shape_id"])
        old._element.getparent().remove(old._element)
    c.art_slots.append({"name":shape.name,"role":row["role"],"box":[x,y,w,h],"sha256":row["sha256"],"placed":True,
                        "source_shape_id":row.get("source_shape_id")})
    return True


def icon_slot(c,name,box,anchor):
    c.art_slots.append({"name":name,"role":"native_icon","page_number":c.page_number,"box":list(box),"anchor_text":anchor})


def can_use_art(c,rows):
    if not rows:
        return []
    if c.pics:
        ids={p.shape_id for p in c.pics}
        replacement=[r for r in rows if r.get("source_shape_id") in ids and r.get("action") in REDRAW]
        # Mixed protected exhibits or diagrams require a local per-object design.
        if len(ids)!=1 or len(replacement)!=1:
            return []
        return replacement
    return [r for r in rows if not r.get("source_shape_id") and r.get("action","add")=="add"]


def photo_tones(photo):
    """Use real scene colors when a generic source supplies no brand palette."""
    import colorsys
    from collections import Counter
    with Image.open(BytesIO(photo["bytes"])) as im:
        sample=im.convert("RGB").resize((56,40))
    bins=Counter()
    for r,g,b in (sample.get_flattened_data() if hasattr(sample,"get_flattened_data") else sample.getdata()):
        h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
        if s>.22 and .16<v<.9:
            bins[int(h*18)]+=s*(1-min(1,abs(v-.52)))
    if not bins:
        return None
    h=(bins.most_common(1)[0][0]+.5)/18
    def grade(light,sat):
        return "".join(f"{round(channel*255):02X}" for channel in colorsys.hls_to_rgb(h,light,sat))
    return grade(.215,.34), grade(.90,.22), grade(.56,.36)


def white_text_on_photo(photo,c):
    """Check contrast where the actual full-bleed crop would sit behind native type."""
    if photo["role"]!="editorial_photo":
        return False
    import math
    from PIL import ImageFilter, ImageStat
    if (photo.get("focus") or (.5,.5))[0] < .63:
        return False
    with Image.open(BytesIO(photo["bytes"])) as im:
        image=ImageOps.fit(im.convert("RGB"),(240,round(240*c.h/c.w)),centering=tuple(photo.get("focus",(.5,.5))))
        region=image.crop((int(.035*image.width),int(.12*image.height),int(.50*image.width),int(.86*image.height)))
        # Test the bright tail as well as the mean; a lamp or white sign can break contrast.
        def linear(v):
            v=v/255
            return v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
        lum=sorted(sum(linear(v)*k for v,k in zip(px,(.2126,.7152,.0722))) for px in (region.get_flattened_data() if hasattr(region,"get_flattened_data") else region.getdata()))
        return lum[min(len(lum)-1,math.floor(.96*len(lum)))]<.175 and ImageStat.Stat(region.convert("L").filter(ImageFilter.FIND_EDGES)).mean[0]<30


def low_key(photo):
    if not photo or photo["role"]!="editorial_photo":
        return False
    with Image.open(BytesIO(photo["bytes"])) as im:
        small=im.convert("L").resize((48,34))
        vals=sorted(small.get_flattened_data() if hasattr(small,"get_flattened_data") else small.getdata())
    return vals[len(vals)//2]<80 and vals[int(len(vals)*.88)]<150


def contrast_veil(c,photo_name,ink):
    """Editable left-to-right native transparency: hold white type, reveal the subject."""
    from pptx.oxml.xmlchemy import OxmlElement
    from pptx.enum.shapes import MSO_SHAPE
    veil=c.slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,0,0,c.w,c.h)
    veil.name="Light falloff behind cover title"
    veil.line.fill.background()
    sp=veil._element.spPr
    for x in list(sp):
        if x.tag in [qn("a:"+t) for t in ("solidFill","gradFill","noFill")]:
            sp.remove(x)
    grad=OxmlElement("a:gradFill")
    grad.set("rotWithShape","1")
    stops=OxmlElement("a:gsLst")
    for pos,alpha in ((0,82000),(34000,63000),(66000,6000),(84000,0),(100000,0)):
        gs=OxmlElement("a:gs");gs.set("pos",str(pos))
        col=OxmlElement("a:srgbClr");col.set("val",ink)
        a=OxmlElement("a:alpha");a.set("val",str(alpha))
        col.append(a);gs.append(col);stops.append(gs)
    grad.append(stops)
    lin=OxmlElement("a:lin");lin.set("ang","0");lin.set("scaled","0");grad.append(lin)
    sp.insert_element_before(grad,"a:ln","a:effectLst","a:extLst")
    photo=next(s for s in c.slide.shapes if s.name==photo_name)
    photo._element.addnext(veil._element)
    return veil
