#!/usr/bin/env python3
"""Verify single-token editable labels on actual PDF renders and repair their PPTX text boxes."""
import argparse
import json
from pathlib import Path
import re

import fitz
import numpy as np
from pptx import Presentation
from pptx.enum.text import MSO_AUTO_SIZE, PP_ALIGN


def compact_label(s):
    # Acronyms, codes and value–unit pairs are intended to stay on a single line.
    # Natural-language headings can intentionally wrap and need separate layout review.
    return 2 <= len(s) <= 12 and bool(re.fullmatch(
        r"(?:[A-Za-z][A-Za-z0-9./·+−%-]*|[+-]?\d+(?:[.,]\d+)?[A-Za-z%°µμ年月日秒次人件]+)", s))


def label_shapes(deck):
    def visit(shapes, sx, sy, tx, ty, supported):
        for shape in shapes:
            if not all(getattr(shape, k) is not None for k in ("left", "top", "width", "height")):
                continue
            x, y = tx + shape.left * sx, ty + shape.top * sy
            w, h = shape.width * sx, shape.height * sy
            aligned = supported and not shape.rotation
            if hasattr(shape, "shapes"):
                xf = shape._element.grpSpPr.xfrm
                if xf is None or xf.chExt is None or not xf.chExt.cx or not xf.chExt.cy:
                    continue
                ax, ay = w / xf.chExt.cx, h / xf.chExt.cy
                yield from visit(shape.shapes, ax, ay, x - xf.chOff.x * ax, y - xf.chOff.y * ay,
                                 aligned and not xf.flipH and not xf.flipV)
            elif shape.has_text_frame and compact_label(shape.text.strip()):
                bounds = (x, y, x + w, y + h)
                yield shape, bounds, aligned

    for n, slide in enumerate(deck.slides, 1):
        for shape, r, aligned in visit(slide.shapes, 1, 1, 0, 0, True):
            box = tuple(v / d for v, d in zip(r, (deck.slide_width, deck.slide_height) * 2))
            yield n, shape, box, aligned


def nearby_line(page, label, box):
    target = fitz.Rect(box) * fitz.Matrix(page.rect.width, page.rect.height)
    # Allow ascenders and text-box insets to extend just beyond the nominal shape.
    area = target + (-8, -8, 8, 8)
    found = []
    raw = page.get_text("rawdict", flags=fitz.TEXTFLAGS_RAWDICT & ~fitz.TEXT_PRESERVE_IMAGES)
    for block in raw["blocks"]:
        for line in block.get("lines", []):
            chars = [{**c, "font_pt":span["size"]} for span in line["spans"] for c in span["chars"] if not c["c"].isspace()]
            if "".join(c["c"] for c in chars) != label:
                continue
            rect = fitz.Rect(line["bbox"])
            if area.intersects(rect):
                found.append(chars)
    return found


def pixels(page, clip):
    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), clip=clip, colorspace=fitz.csRGB, alpha=False)
    return np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, 3)


def opaque_overlap(page, chars):
    """Detect later, opaque rectangular paint over a substantial part of a glyph."""
    rects = [(d["seqno"], item[1]) for d in page.get_drawings()
             if d.get("fill_opacity") == 1 and len(d["items"]) == 1
             for item in d["items"] if item[0] == "re"]
    glyphs = {}
    for run in page.get_texttrace():
        for value, _, origin, bounds in run["chars"]:
            key = value, round(origin[0], 1), round(origin[1], 1)
            glyphs[key] = run["seqno"], fitz.Rect(bounds)
    covered = set()
    for i, char in enumerate(chars):
        if len(char["c"]) != 1:
            continue
        x, y = char["origin"]
        info = glyphs.get((ord(char["c"]), round(x, 1), round(y, 1)))
        if info is None:
            continue
        seqno, bounds = info
        if not bounds.is_empty and any(z > seqno and (bounds & rect).get_area() > .23 * bounds.get_area()
                                       for z, rect in rects):
            covered.add(i)
    return covered


def visible_chars(doc, n, chars):
    # Remove just the matching glyphs in a scratch PDF. If the final image does not
    # change for a glyph, another object, clipping or the background has hidden it.
    scratch = fitz.open()
    try:
        scratch.insert_pdf(doc, from_page=n - 1, to_page=n - 1)
        page = scratch[0]
        for char in chars:
            r = fitz.Rect(char["bbox"])
            cx, cy = (r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2
            page.add_redact_annot((cx - .1, cy - .1, cx + .1, cy + .1), fill=False, cross_out=False)
        page.apply_redactions(images=0, graphics=0, text=0)
        missing = []
        covered = opaque_overlap(doc[n - 1], chars)
        for i, char in enumerate(chars):
            r = fitz.Rect(char["bbox"])
            clip = r & page.rect
            if clip.is_empty or r.get_area() <= 0 or clip.get_area() < .97 * r.get_area():
                missing.append(char["c"])
                continue
            actual = pixels(doc[n - 1], clip)
            removed = pixels(page, clip)
            changed = np.abs(actual.astype(np.int16) - removed).max(axis=2) > 22
            if i in covered or changed.sum() < max(2, changed.size * .014):
                missing.append(char["c"])
        return missing
    finally:
        scratch.close()


def review(deck, doc):
    if len(deck.slides) != len(doc):
        raise ValueError("Slide count and PDF page count differ")
    rows = []
    for n, shape, box, aligned in label_shapes(deck):
        label = shape.text.strip()
        row = {"page":n, "shape_id":shape.shape_id, "label":label, "box":box}
        lines = nearby_line(doc[n - 1], label, box) if aligned else []
        if not aligned:
            row["status"] = "review_rotated_group"
        elif len(lines) != 1:
            row["status"] = "ambiguous" if lines else "missing_or_wrapped"
        else:
            missing = visible_chars(doc, n, lines[0])
            row["status"] = "occluded_or_clipped" if missing else "pass"
            width, height = doc[n-1].rect.width, doc[n-1].rect.height
            ink = fitz.Rect(lines[0][0]["bbox"])
            for char in lines[0][1:]:
                ink |= fitz.Rect(char["bbox"])
            row["ink_box"] = [v/d for v,d in zip(ink,(width,height)*2)]
            row["font_pt"] = sorted({round(c["font_pt"] * (deck.slide_width / 12700) / width, 3) for c in lines[0]})
            if missing:
                row["glyphs"] = missing
        rows.append(row)
    return rows


def native_labels(slide):
    def visit(elements, origin=(0,0), scale=(1,1)):
        for e in elements:
            tf=e.get("transform",{})
            unit=tf.get("unit","EMU")
            if unit not in ("EMU","PT") or tf.get("shearX") or tf.get("shearY"):
                continue
            dx,dy=scale
            x=origin[0]+dx*tf.get("translateX",0)/(12700 if unit=="EMU" else 1)
            y=origin[1]+dy*tf.get("translateY",0)/(12700 if unit=="EMU" else 1)
            sx,sy=dx*tf.get("scaleX",1),dy*tf.get("scaleY",1)
            if min(sx,sy)<=0:
                continue
            if e.get("elementGroup"):
                yield from visit(e["elementGroup"]["children"],(x,y),(sx,sy))
                continue
            shape=e.get("shape",{})
            if shape.get("shapeType","TEXT_BOX")!="TEXT_BOX":
                continue
            props=shape.get("shapeProperties",{})
            if any(props.get(k,{}).get("propertyState")=="RENDERED"
                   for k in ("shapeBackgroundFill","outline")):
                continue
            parts=shape.get("text",{}).get("textElements",[])
            runs=[part["textRun"] for part in parts if "textRun" in part]
            label="".join(run.get("content","") for run in runs).strip()
            if not compact_label(label) or not e.get("size"):
                continue
            size=[points(e["size"][k]) for k in ("width","height")]
            rect=fitz.Rect(x,y,x+sx*size[0],y+sy*size[1])
            align=next((p["paragraphMarker"].get("style",{}).get("alignment","START")
                        for p in parts if "paragraphMarker" in p),"START")
            fonts={points(run["style"]["fontSize"]) for run in runs if run.get("style",{}).get("fontSize")}
            yield label,e["objectId"],rect,size,align,fonts
    return list(visit(slide.get("pageElements",[])))


def points(value):
    if value["unit"] not in ("EMU","PT"):
        raise ValueError("Unsupported Slides measurement unit")
    return value["magnitude"]/(12700 if value["unit"]=="EMU" else 1)


def native_packet(deck, result, native):
    slides=native["slides"]
    if len(slides)!=len(deck.slides) or not native.get("presentationId") or not native.get("revisionId"):
        raise ValueError("Read the full current Slides revision and its nested native page elements.")
    width,height=[points(native["pageSize"][k]) for k in ("width","height")]
    source_width,source_height=deck.slide_width/12700,deck.slide_height/12700
    if abs(width/source_width-height/source_height)>.001:
        raise ValueError("The Slides and PowerPoint page aspect ratios differ.")
    requests,changes,review=[],[],[]
    for a,b in zip(result["pptx"],result["slides"],strict=True):
        if b["status"]=="pass" or a["status"]!="pass":
            continue
        key={"page":a["page"],"label":a["label"],"source_shape_id":a["shape_id"]}
        if b["status"] not in ("missing_or_wrapped","font_size_differs") or len(a["font_pt"])!=1:
            review.append({**key,"reason":"Inspect occlusion, mixed typography or ambiguous source geometry."})
            continue
        target=fitz.Rect([v*d for v,d in zip(a["box"],(width,height)*2)])
        found=[z for z in native_labels(slides[a["page"]-1]) if z[0]==a["label"] and (z[2]&target).get_area()>.35*min(z[2].get_area(),target.get_area())]
        if len(found)!=1:
            review.append({**key,"reason":"Need exactly one native label with matching text and location."})
            continue
        _,oid,rect,size,align,native_fonts=found[0]
        font=a["font_pt"][0]*width/source_width
        ink_width=(a["ink_box"][2]-a["ink_box"][0])*width
        # Leave horizontal breathing room for the actual Google glyphs and both box insets.
        want=max(rect.width,ink_width*1.12+max(15,font))
        anchor={"CENTER":.5,"END":1,"RIGHT":1}.get(align,0)
        left=rect.x0-anchor*(want-rect.width)
        if left<0 or left+want>width or rect.height<=0 or min(size)<=0:
            review.append({**key,"reason":"Choose a nearby open area within the slide."})
            continue
        fixes=[]
        if want>rect.width+.1:
            fixes.append({"updatePageElementTransform":{"objectId":oid,"applyMode":"ABSOLUTE","transform":{
                "scaleX":want/size[0],"scaleY":rect.height/size[1],"translateX":left,"translateY":rect.y0,"unit":"PT"}}})
        if b["status"]=="font_size_differs" or native_fonts and any(abs(v-font)>.5 for v in native_fonts):
            fixes.append({"updateTextStyle":{"objectId":oid,"textRange":{"type":"ALL"},
                          "style":{"fontSize":{"magnitude":font,"unit":"PT"}},"fields":"fontSize"}})
        if not fixes:
            review.append({**key,"reason":"Box and font already meet source measurements. Inspect clipping or occlusion."})
            continue
        requests.extend(fixes)
        changes.append({**key,"object_id":oid,"reference_font_pt":font,"current_box_pt":list(rect),
                        "planned_box_pt":[left,rect.y0,left+want,rect.y1]})
    return {"presentation_id":native["presentationId"],"write_control":{"requiredRevisionId":native["revisionId"]},
            "requests":requests,"changes":changes,"review":review}


def load_positions(path):
    if path is None:
        return {}
    positions = {}
    for row in json.loads(path.read_text()):
        l, t, r, b = row["box"]
        if not (0 <= l < r <= 1 and 0 <= t < b <= 1):
            raise ValueError("Position must be an on-slide normalized [left,top,right,bottom] box")
        key = row["page"], row["shape_id"], row["label"]
        if key in positions:
            raise ValueError("Duplicate label position")
        positions[key] = l, t, r, b
    return positions


def repair(deck, failures, positions):
    changed = []
    for n, shape, box, aligned in label_shapes(deck):
        key = n, shape.shape_id, shape.text.strip()
        if key not in failures or not aligned or box[2] <= box[0] or box[3] <= box[1]:
            continue
        if key in positions:
            # A reviewed nearby gap can keep an overlapping label with its subject.
            l, t, r, b = positions[key]
            kx, ky = shape.width / (box[2] - box[0]), shape.height / (box[3] - box[1])
            shape.left += round((l - box[0]) * kx)
            shape.top += round((t - box[1]) * ky)
            shape.width, shape.height = round((r - l) * kx), round((b - t) * ky)
        else:
            # Preserve the visual centre, group, siblings and original font size.
            old_width = shape.width
            room = 2 * min((box[0] + box[2]) / 2, 1 - (box[0] + box[2]) / 2) / (box[2] - box[0])
            width = round(old_width * min(1.65, room))
            if width < old_width:
                continue
            shape.left -= (width - old_width) // 2
            shape.width = width
        tf = shape.text_frame
        tf.margin_left = tf.margin_right = 0
        tf.word_wrap = False
        tf.auto_size = MSO_AUTO_SIZE.NONE
        for paragraph in tf.paragraphs:
            paragraph.alignment = PP_ALIGN.CENTER
        changed.append({"page":n, "shape_id":shape.shape_id, "label":key[2]})
    return changed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx", type=Path)
    parser.add_argument("pptx_pdf", type=Path)
    parser.add_argument("--slides-pdf", type=Path)
    parser.add_argument("--repair-to", type=Path, help="Write repaired copy. Generate new renders and run again.")
    parser.add_argument("--positions", type=Path, help="Optional reviewed placement overrides for failed labels")
    parser.add_argument("--slides-native", type=Path, help="Current presentations.get JSON including nested group children, text styles and transforms")
    args = parser.parse_args()
    deck = Presentation(args.pptx)
    result = {}
    for name, path in (("pptx", args.pptx_pdf), ("slides", args.slides_pdf)):
        if path is not None:
            with fitz.open(path) as doc:
                result[name] = review(deck, doc)
    if "slides" in result:
        for a,b in zip(result["pptx"],result["slides"],strict=True):
            if a["status"]==b["status"]=="pass" and (len(a["font_pt"])!=len(b["font_pt"]) or
                    any(abs(x-y)>max(.5,.04*x) for x,y in zip(a["font_pt"],b["font_pt"]))):
                b["status"]="font_size_differs"
    failures = {(r["page"], r["shape_id"], r["label"]) for r in result["pptx"]
                if r["status"] in ("missing_or_wrapped", "occluded_or_clipped")}
    unverified = any(r["status"] != "pass" for rows in result.values() for r in rows)
    if args.slides_native:
        if "slides" not in result:
            parser.error("--slides-native requires the matching current --slides-pdf")
        native=json.loads(args.slides_native.read_bytes())
        native=native.get("presentation",native)
        result["slides_repair"]=native_packet(deck,result,native)
    if args.repair_to:
        if args.repair_to.resolve() == args.pptx.resolve():
            raise ValueError("Choose a separate working copy for repair")
        result["repairs"] = repair(deck, failures, load_positions(args.positions))
        deck.save(args.repair_to)
    print(json.dumps(result, ensure_ascii=False))
    return int(unverified)


if __name__ == "__main__":
    raise SystemExit(main())
