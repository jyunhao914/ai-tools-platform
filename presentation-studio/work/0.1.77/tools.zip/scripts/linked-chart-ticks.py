"""Verify both rendered quantitative scales for a calibrated editable combo chart."""
import argparse
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import runpy
import sys
import fitz

HERE = Path(__file__).resolve().parent
reference = runpy.run_path(str(HERE/"linked-chart-text.py"))["chart_reference"]
verify_export = runpy.run_path(str(HERE/"chart-fidelity.py"))["verify_export"]


def number(text):
    value = str(text).strip().replace("−","-").replace(",","")
    try:
        parsed = Decimal(value.rstrip("%"))
    except InvalidOperation:
        return None
    return (parsed, value.endswith("%")) if parsed.is_finite() else None


def aligned(expected, candidates):
    """An ordered column of ticks at the same x coordinate, with legible type."""
    direction = 1 if expected[-1]["y"] > expected[0]["y"] else -1
    for seed in candidates:
        if seed["value"] != number(expected[0]["text"]):
            continue
        prior = -2
        matched=[]
        for tick in expected:
            choices = [item for item in candidates if item["value"] == number(tick["text"]) and abs(item["x"]-seed["x"]) < .065 and
                       item["y"]*direction > prior+.004 and item["font"]+.75 >= tick["font"]*.9]
            if not choices:
                break
            point=min(choices,key=lambda item:item["y"]*direction)
            matched.append(point)
            prior=point["y"]*direction
        else:
            def extra_tick(first, second):
                v, percent=first["value"]
                interval=float(second["value"][0]-v)
                if not interval:
                    return False
                for point in candidates:
                    if point["value"][1]!=percent or abs(point["x"]-seed["x"])>=.045:
                        continue
                    steps=float(point["value"][0]-v)/interval
                    if steps<=-.8 and abs(point["y"]-(first["y"]+steps*(second["y"]-first["y"])))<.025:
                        return True
                return False
            if not extra_tick(matched[0],matched[1]) and not extra_tick(matched[-1],matched[-2]):
                return True
    return False


def read_ticks(pptx, source_pdf, google_pdf, page_num, chart_index, audit):
    chart, _, _, axes, ws, hs = reference(pptx, source_pdf, page_num, chart_index)
    with fitz.open(google_pdf) as doc:
        page = doc[page_num-1]
        w,h = page.rect.width,page.rect.height
        region = fitz.Rect(chart.x0/ws*w,chart.y0/hs*h,chart.x1/ws*w,chart.y1/hs*h)
        candidates=[]
        for block in page.get_text("dict", clip=region, flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    value=number(span["text"])
                    if value is not None:
                        rect=fitz.Rect(span["bbox"])
                        candidates.append(dict(value=value,x=((rect.x0+rect.x1)/2-region.x0)/region.width,
                                               y=((rect.y0+rect.y1)/2-region.y0)/region.height,font=span["size"]*ws/w))
    issues=[]
    for side, role, lower, upper in [("LEFT_AXIS","axis_l",-.01,.27),("RIGHT_AXIS","axis_r",.73,1.01)]:
        expected=sorted(axes[side],key=lambda row: row["y"])
        observed=[row for row in candidates if lower<=row["x"]<=upper]
        if aligned(expected, observed):
            continue
        samples=[]
        for sample in audit.get("type_samples",[]):
            rect=sample.get("rect")
            if sample.get("role")!=role or not isinstance(rect,list) or len(rect)!=4 or not all(isinstance(v,(int,float)) and 0<=v<=1 for v in rect):
                continue
            x=((rect[0]+rect[2])/2*w-region.x0)/region.width
            y=((rect[1]+rect[3])/2*h-region.y0)/region.height
            if lower<=x<=upper and 0<=y<=1 and number(sample.get("text")) is not None:
                samples.append((sample,dict(value=number(sample["text"]),x=x,y=y,font=sample.get("actual_pt") or 0)))
        if samples and aligned(expected,observed+[point for _,point in samples]):
            proof={"slides_pdf_sha256":hashlib.sha256(google_pdf.read_bytes()).hexdigest(),
                   "rows":[{"page":page_num,"labels":[dict(sample,series=role,point=i) for i,(sample,_) in enumerate(samples)]}]}
            if not verify_export(google_pdf,proof)["issues"]:
                continue
        issues.append({"page":page_num,"axis":role,"expected":[e["text"] for e in expected],
                       "issue":"Validate this complete axis on the latest native export, including its endpoints and legible ticks."})
    return {"issues":issues}


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    for name in ("pptx","source_pdf","google_pdf"):
        cli.add_argument(name,type=Path)
    cli.add_argument("--page",required=True,type=int)
    cli.add_argument("--chart-index",required=True,type=int)
    args=cli.parse_args()
    try:
        report=read_ticks(args.pptx,args.source_pdf,args.google_pdf,args.page,args.chart_index,json.load(sys.stdin))
    except (KeyError, ValueError, OSError, IndexError) as exc:
        report={"issues":[{"page":args.page,"issue":str(exc)}]}
    print(json.dumps(report,ensure_ascii=False))
