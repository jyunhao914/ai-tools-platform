import { spawn } from 'node:child_process';
import { isAbsolute, dirname, join, basename, resolve as resolvePath, relative, sep } from 'node:path';
import { stat, mkdir, mkdtemp, link, rm, realpath } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';

const pythonLauncher = [
  'import os,sys,runpy',
  'try:',
  ' import certifi',
  ' if not os.environ.get("SSL_CERT_FILE"): os.environ["SSL_CERT_FILE"]=certifi.where()',
  'except ImportError: pass',
  'sys.argv=sys.argv[1:]',
  'sys.path.insert(0,os.path.dirname(sys.argv[0]))',
  'runpy.run_path(sys.argv[0],run_name="__main__")',
].join('\n');

async function runOfficial({ helperPath, args, input, pythonExecutable, cwd }) {
  return new Promise((resolve) => {
    const child = spawn(pythonExecutable, ['-c', pythonLauncher, helperPath, ...args], { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', chunk => { stdout += chunk.toString(); });
    child.stderr.on('data', chunk => { stderr = (stderr + chunk.toString()).slice(-4000); });
    child.on('error', error => resolve({ ok: false, stage: 'spawn', code: error.code || 'SPAWN_FAILED' }));
    child.stdin.on('error', () => {});
    child.on('close', exitCode => {
      const http = stderr.match(/\bHTTP(?: status| Error)?\s+(\d{3})\b/i);
      let code;
      if (http && ['401', '403'].includes(http[1])) code = 'ACCESS_DENIED';
      else if (/Library prepare_materialize is not available/.test(stderr)) code = 'LIBRARY_BRIDGE_UNAVAILABLE';
      else if (/download failed:\s*DNS\b|\b(?:ENOTFOUND|EAI_AGAIN|EAI_NONAME)\b|name or service not known|nodename nor servname provided|temporary failure in name resolution|getaddrinfo failed/i.test(stderr)) code = 'DNS_RESOLUTION_FAILED';
      else if (/certificate verify failed|CERTIFICATE_VERIFY_FAILED/i.test(stderr)) code = 'CERTIFICATE_VERIFICATION_FAILED';
      else if (/download failed/i.test(stderr)) code = 'DOWNLOAD_FAILED';
      resolve({ ok: exitCode === 0, stage: 'transfer', exitCode, stdout, ...(code ? { code } : {}), ...(http ? { httpStatus: Number(http[1]) } : {}) });
    });
    child.stdin.end(JSON.stringify(input));
  });
}

// Search/list results must use the official download helper's complete-result route.
export async function downloadLibrarySearch({ helperPath, workspace, result, selection, destination, pythonExecutable = 'python3' }) {
  if (!isAbsolute(helperPath) || !isAbsolute(workspace)) throw new Error('Absolute helper and workspace paths required');
  if (typeof destination !== 'string' || isAbsolute(destination) || destination.split(/[\\/]/).includes('..')) throw new Error('Contained relative destination required');
  if (!/^(ALL|(?:\d{3})+)$/.test(selection)) throw new Error('Official selection format required');
  await stat(helperPath);
  const run = await runOfficial({ helperPath, args: [], input: { result, selection, destination }, pythonExecutable, cwd: workspace });
  if (!run.ok) { delete run.stdout; return run; }
  let report;
  try { report = JSON.parse(run.stdout); }
  catch { return { ok: false, stage: 'result', code: 'INVALID_HELPER_RESULT' }; }
  if (!report || !Array.isArray(report.files) || report.error || report.ok === false) {
    return { ok: false, stage: 'result', code: 'INVALID_HELPER_RESULT' };
  }
  if (report.files.length === 0) return { ok: false, stage: 'result', code: 'SOURCE_BYTES_NOT_MATERIALIZED', result: report };
  const root = resolvePath(await realpath(workspace), destination);
  for (const entry of report.files) {
    if (typeof entry !== 'string' || !entry) return { ok: false, stage: 'result', code: 'INVALID_HELPER_RESULT' };
    const path = resolvePath(workspace, entry);
    if (!(await nonemptyFile(path))) {
      return { ok: false, stage: 'result', code: 'SOURCE_BYTES_NOT_MATERIALIZED', result: report };
    }
    const local = relative(root, await realpath(path));
    if (!local || local === '..' || local.startsWith('..' + sep) || isAbsolute(local)) {
      return { ok: false, stage: 'result', code: 'INVALID_HELPER_RESULT' };
    }
  }
  if (report.partial) return { ok: false, stage: 'result', code: 'PARTIAL_DOWNLOAD', result: report };
  return { ok: true, result: report };
}

async function nonemptyFile(path) {
  try {
    const info = await stat(path);
    return info.isFile() && info.size > 0 ? info : null;
  } catch (error) {
    if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return null;
    throw error;
  }
}

async function fingerprint(path) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}

// Pass only the file record returned for an attachment on this Work message.
// Workspace paths never come from a pasted packet, a filename search or a prior chat.
export async function readWorkAttachment({ attachment, expectedFileId, expectedSha256 }) {
  const stage = 'work_attachment';
  if (!attachment) return { ok: false, stage, code: 'SOURCE_NOT_ATTACHED' };
  const { file_id: fileId, workspace_path: path, size_bytes: byteCount } = attachment;
  const sameId = typeof fileId === 'string' && fileId.length > 0 && fileId === expectedFileId;
  if (expectedSha256 != null && !/^[0-9a-f]{64}$/.test(expectedSha256)) {
    return { ok: false, stage, code: 'INVALID_SOURCE_DIGEST' };
  }
  if (!sameId && !expectedSha256) return { ok: false, stage, code: 'SOURCE_ID_NOT_CONFIRMED' };
  if (typeof path !== 'string' || !isAbsolute(path)) {
    return { ok: false, stage, code: 'ATTACHED_SOURCE_NOT_MOUNTED' };
  }
  try {
    const info = await nonemptyFile(path);
    if (!info) return { ok: false, stage, code: 'ATTACHED_SOURCE_NOT_MOUNTED' };
    if (byteCount != null && (!Number.isSafeInteger(byteCount) || info.size !== byteCount)) {
      return { ok: false, stage, code: 'SOURCE_SIZE_MISMATCH' };
    }
    const sha256 = await fingerprint(path);
    if ((expectedSha256 && expectedSha256 !== sha256) || (attachment.sha256 && attachment.sha256 !== sha256)) {
      return { ok: false, stage, code: 'SOURCE_HASH_MISMATCH' };
    }
    return { ok: true, stage, path, file_id: fileId ?? null, sha256, sizeBytes: info.size };
  } catch (error) {
    if (error.code === 'EACCES' || error.code === 'EPERM') return { ok: false, stage, code: 'ACCESS_DENIED' };
    if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return { ok: false, stage, code: 'ATTACHED_SOURCE_NOT_MOUNTED' };
    throw error;
  }
}

// The helper writes to private staging. Only a complete, verified transfer is published.
export async function materializeLibrary({ helperPath, destination, transfer, attachment, expectedFileId, expectedSha256, failedDnsHosts = [], failedEndpointKeys = [], pythonExecutable = 'python3' }) {
  if (attachment) {
    const mounted = await readWorkAttachment({ attachment, expectedFileId, expectedSha256 });
    if (mounted.ok || mounted.code !== 'ATTACHED_SOURCE_NOT_MOUNTED' || !transfer?.download_url) return mounted;
  }
  if (!transfer || typeof transfer !== 'object' || typeof transfer.download_url !== 'string') throw new Error('Complete official signed-URL transfer required');
  const url = new URL(transfer.download_url);
  const host = url.hostname.toLowerCase();
  // A helper may report DNS without revealing whether a proxy or redirect failed.
  // Record the attempted origin/path without retaining tokens; a hostname-wide
  // skip is used only when the host runtime actually identified that DNS failure.
  const endpointKey = host ? createHash('sha256').update(url.origin + url.pathname).digest('hex') : null;
  if (host && (failedDnsHosts.includes(host) || failedEndpointKeys.includes(endpointKey))) {
    return { ok: false, stage: 'transfer', code: 'DNS_ENDPOINT_ALREADY_FAILED', endpoint_key: endpointKey };
  }
  if (!isAbsolute(helperPath) || !isAbsolute(destination)) throw new Error('Absolute helper and destination paths required');
  await stat(helperPath);
  await mkdir(dirname(destination), { recursive: true });
  const staging = await mkdtemp(join(dirname(destination), '.studio-transfer-'));
  const staged = join(staging, basename(destination));
  try {
    const result = await runOfficial({ helperPath, args: ['materialize', staged], input: transfer, pythonExecutable });
    delete result.stdout;
    if (!result.ok) {
      if (result.code === 'DNS_RESOLUTION_FAILED' && endpointKey) result.endpoint_key = endpointKey;
      return result;
    }
    const info = await nonemptyFile(staged);
    if (!info) return { ok: false, stage: 'result', code: 'SOURCE_BYTES_NOT_MATERIALIZED' };
    if (typeof transfer.size_bytes === 'number' && info.size !== transfer.size_bytes) {
      return { ok: false, stage: 'size', expected: transfer.size_bytes, actual: info.size };
    }
    const sha256 = await fingerprint(staged);
    if ((transfer.sha256 != null && String(transfer.sha256).toLowerCase() !== sha256) ||
        (expectedSha256 != null && expectedSha256 !== sha256)) {
      return { ok: false, stage: 'verify', code: 'SOURCE_HASH_MISMATCH' };
    }
    try {
      await link(staged, destination);
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      if (await fingerprint(destination) !== sha256) {
        return { ok: false, stage: 'publish', code: 'DESTINATION_HAS_DIFFERENT_SOURCE' };
      }
    }
    return { ok: true, path: destination, sizeBytes: info.size, sha256 };
  } finally {
    await rm(staging, { recursive: true, force: true });
  }
}
