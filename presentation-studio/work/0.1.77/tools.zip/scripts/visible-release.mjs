// A successful object/content check does not prove that the exported pages are visible.
const valid = value => typeof value === "string" && Boolean(value.trim());
const sha = value => typeof value === "string" && /^[a-f\d]{64}$/i.test(value);

export function visibilityIssues(job, candidate, formats, reports = candidate.visible_reports) {
  const issues = [];
  for (const format of formats) {
    const report = reports?.[format];
    const id = format === "slides" ? candidate.native_id : candidate.pptx_ref;
    const revision = candidate.output_revisions?.[format] ?? candidate.output_revision;
    if (!valid(id) || !valid(revision) || report?.artifact_id !== id || report.output_revision !== revision ||
        !["pass","needs_review","fail"].includes(report.status) || !sha(report.pdf_sha256) || report.page_count !== job.pages ||
        !Array.isArray(report.pages) || report.pages.length !== job.pages) {
      issues.push({format, reason:"缺少待交付這個版本的完整逐頁渲染。", refresh:true});
      continue;
    }
    if (format === "slides" && formats.includes("pptx") && candidate.slides_from_pptx === true &&
        (!sha(reports.pptx?.pdf_sha256) || report.pptx_pdf_sha256 !== reports.pptx.pdf_sha256)) {
      issues.push({format, reason:"依本次 PowerPoint 與 Google 簡報的實際渲染重新比對字級。", refresh:true});
      continue;
    }
    for (const [index, row] of report.pages.entries()) {
      const page = index + 1;
      const intentional = job.intentionally_blank_pages?.includes(page) === true;
      const decision = row?.visual_review;
      const seen = row?.status === "needs_review" && decision?.page === page &&
        decision.pdf_sha256 === report.pdf_sha256 && decision.pass === true && valid(decision.observation);
      if (!row || !sha(row.render_sha256) || row.page_number !== page || row.expected_content !== (intentional ? "intentionally_blank" : "body") ||
          (row.status !== "pass" && !seen)) {
        const issue = {format,page,reason:row?.reason || "當頁的最終畫面尚未核實。",refresh:!row || row.status==="needs_review"};
        if (row?.type_measurements) issue.type_measurements = row.type_measurements;
        issues.push(issue);
      }
    }
    if (report.errors?.length || report.status === "fail" && !issues.some(issue=>issue.format===format)) {
      issues.push({format,reason:"該檔的逐頁渲染檢查失敗。",refresh:true});
    }
  }
  return issues;
}

export async function inspectVisible(job, host, candidate, formats, renderOptions) {
  let reports = candidate.visible_reports;
  if (visibilityIssues(job,candidate,formats,reports).length && typeof host.inspectVisible === "function") {
    try { reports = await host.inspectVisible(job, candidate, formats, renderOptions); } catch { /* Missing renders block publication. */ }
  }
  return visibilityIssues(job,candidate,formats,reports);
}
