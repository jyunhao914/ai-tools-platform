"""Place and edit real vector groups in authorized illustration slots. No image service is used."""
import json
import math
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE as S, MSO_CONNECTOR
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Pt

AUTO = {"auto","auto_add","auto_illustrate","automatic","content_auto","依內容自動配圖","自動配圖","全自動配圖"}
NONE = {"none","no","never","off","no_new_images","no_images","no_icons","keep_empty","original_only","preserve_only",
        "text_only","no_new","不配圖","不加圖","不要配圖","不加新圖","維持無圖","沿用原稿","僅沿用原圖"}
ICON_KINDS = {"native_icon","icon_group","native_illustration"}
MEDIA_FIELDS = ("imageless_pages","empty_page_images","image_policy","new_image_policy","new_images","add_images","images")


@lru_cache(maxsize=1)
def catalog():
    return json.loads(Path(__file__).with_name("semantic-icons.json").read_text(encoding="utf-8"))["icons"]


def normalized(value):
    return unicodedata.normalize("NFKC",str(value)).strip().casefold()


def matches(text, term):
    if re.fullmatch(r"[a-z0-9 -]+",term):
        return bool(re.search(r"(?<![a-z0-9])"+re.escape(term)+r"(?![a-z0-9])",text))
    return term in text


def choose_icon(text, chosen=None):
    """Exact semantic or explicitly chosen catalog key; unrelated or tied terms need a human/editor choice."""
    library=catalog()
    if chosen is not None:
        return chosen if isinstance(chosen,str) and chosen in library else None
    text=normalized(text)
    lead=re.split(r"[：:｜|]",text,maxsplit=1)[0]
    for phrase in dict.fromkeys((lead,text)):
        def score(definition):
            return max((len(term.replace(" ","")) for term in definition["terms"] if matches(phrase,term)),default=0)
        ranked=sorted(((score(v),key) for key,v in library.items()),reverse=True)
        if ranked[0][0]:
            return ranked[0][1] if ranked[0][0]>ranked[1][0] else None
    return None


def page_options(plan, n):
    result={}
    for group in (plan.get("pages"),plan.get("visual_plan"),plan.get("page_overrides"),
                  (plan.get("settings") or {}).get("individual_adjustments")):
        if isinstance(group,dict) and "pages" in group:
            group=group["pages"]
        entry=None
        if isinstance(group,dict):
            entry=group.get(str(n),group.get(n))
        elif isinstance(group,list):
            entry=next((row for row in group if isinstance(row,dict) and
                        row.get("page_number",row.get("page",row.get("source_page")))==n),None)
        if isinstance(entry,dict):
            result.update(entry)
    return result


def refined_page(plan,n):
    settings=plan.get("settings") or {}
    profile=page_options(plan,n).get("editable_profile") or (plan.get("page_profiles") or {}).get(str(n),settings.get("editable_profile"))
    return settings.get("format") in (None,"editable") and profile=="refined"


def forbids_new(plan,n,*,icon=False,empty=True,slot=None,explicit=False):
    cfg=page_options(plan,n)
    review=plan.get("image_adjustments") or (plan.get("settings") or {}).get("image_adjustments") or {}
    catalogue={row.get("name"):row for row in review.get("catalogue",[]) if row.get("page")==n}
    for edit in review.get("edits",[]):
        if edit.get("page")!=n or edit.get("action")!="skip":
            continue
        row=catalogue.get(edit.get("name"),{})
        if row.get("scope")=="page" or (row.get("kind")=="empty_page" and row.get("scope")!="object" and len(catalogue)==1) or edit.get("name")==slot:
            return True
    for owner in (plan,plan.get("settings") or {},plan.get("requirements") or {},cfg):
        if not isinstance(owner,dict):
            continue
        if owner.get("no_new_images") is True or owner.get("original_only") is True or owner.get("text_only") is True:
            return True
        # An explicitly authorized new object can override the default for otherwise
        # unillustrated pages. A specific prohibition or a protected page still wins.
        fields=MEDIA_FIELDS if empty and not explicit else MEDIA_FIELDS[2:]
        if any((isinstance(owner.get(k),str) and normalized(owner[k]) in NONE) or owner.get(k) is False for k in fields):
            return True
        if icon and (owner.get("no_icons") is True or owner.get("allow_icons") is False or owner.get("native_icon") is False
                     or owner.get("icons") is False or normalized(owner.get("icons","")) in NONE
                     or normalized(owner.get("icon_policy","")) in NONE):
            return True
    return any(cfg.get(k) is True for k in ("layout_locked","approved_original_page","preserve_layout","protected"))


def authorized(plan,n,*,empty,explicit=False,icon=False,slot=None):
    if forbids_new(plan,n,icon=icon,empty=empty,slot=slot,explicit=explicit):
        return False
    cfg=page_options(plan,n)
    if explicit:
        return True
    if any(owner.get("only_listed_assets") is True or owner.get("image_policy")=="per_object"
           for owner in (plan,plan.get("settings") or {},cfg)):
        return False
    for owner in (cfg,plan.get("settings") or {},plan):
        for key in MEDIA_FIELDS:
            policy=owner.get(key)
            if key in ("imageless_pages","empty_page_images") and not empty:
                continue
            if normalized(policy) in AUTO or policy is True:
                return True
    return False


SCENES={
    "sun":"低角度取景的一列光伏模組，日光掠過玻璃表面，前景可見金屬支架",
    "wind":"開闊地形中順風轉動的一座風力發電機，葉片和塔身完整，遠處可見地平線",
    "battery-charging":"一座公用儲能設施的電池模組與維護走道，利用重複的模組呈現儲能規模",
    "droplets":"水庫岸邊的取水設施和水面，側光映出水位及岸線",
    "train-front":"列車緩緩駛入月台，取景顯示車頭、月台與軌道之間的空間關係",
    "plane":"民航客機停靠航廈空橋，透過候機區窗戶看向停機坪",
    "book-open":"圖書館書架旁的一位讀者取下一本書，以手和書脊帶出閱讀活動",
    "presentation":"小型工作坊中講者與學員在桌邊共同示範操作，視線集中於桌面的材料",
    "microscope":"實驗室工作桌上的光學顯微鏡與玻片，近距離看見調焦輪和物鏡結構",
    "recycle":"分類回收工作台上整理完畢的紙材、金屬和塑料，從側上方取景",
}


def scene_brief(slot,text):
    if slot.get("candidate") and slot.get("role") in ("cutout","subject_cutout"):
        anchor=normalized(slot.get("anchor_text") or text)
        subjects=("澆水壺","浇水壶","麥克風","麦克风","錄音機","录音机","觀察手冊","顯微鏡","显微镜",
                  "太陽能板","太阳能板","指南針","指南针","溫度計","温度计","取樣瓶","采样瓶","扳手","量杯",
                  "watering can","microphone","recorder","microscope","solar panel","compass","thermometer",
                  "sample bottle","wrench","battery module","boarding pass")
        chosen=next((term for term in subjects if matches(anchor,term)),None)
        return "獨立單件「"+chosen+"」，完整外形、透明背景和自然光；無字、無底板。" if chosen else None
    for field in ("brief","subject","description"):
        value=slot.get(field)
        if not slot.get("candidate") and isinstance(value,str) and value.strip():
            return value.strip()
    anchor=slot.get("anchor_text") or text
    for terms,view in (
            (("屋頂花園","屋顶花园","rooftop garden"),"屋頂花園的種植床與走道，近處可見葉面，遠處保留屋頂環境"),
            (("海岸","海岸線","coastal","coastline"),"沿海步道朝向海岸線的視角，前景步道、岸邊浪區與海面清晰分層"),
            (("水庫","水库","reservoir"),"水庫岸邊的取水設施和水面，側光呈現岸線與水位"),
            (("水質","水质","water quality"),"工作桌上的水樣採集瓶與檢測器材，以取樣動作呈現水質檢測")):
        if any(matches(normalized(anchor),term) for term in terms):
            return view+"。單一場景，無文字或版面。"
    key=choose_icon(anchor)
    brief=SCENES.get(key)
    if not brief and slot and not slot.get("candidate") and isinstance(anchor,str) and anchor.strip() and anchor!=text:
        brief=anchor.strip()
    if not brief and slot.get("candidate") and slot.get("role") in ("hero_photo","editorial_photo"):
        brief=slot.get("brief")
    if not isinstance(brief,str) or not brief.strip():
        return None
    return (brief.strip()+"。單一獨立場景。若無當地實拍授權參照，以匿名工作情境、器物或材料示意；"
            "不可虛構成具名機構的院舍、地標、商標或人物肖像。畫面無字，避開可辨識個資、數據螢幕、拼貼及投影片外框。")


def plan_icons(plan,page):
    """Return a bounded slot-name -> explicit choice map, even when the final choice has no known glyph."""
    out={}
    cfg=page_options(plan,page)
    for owner in (plan,plan.get("settings") or {},cfg):
        for key in ("assets","image_assets","image_plan","objects","layers","art_slots"):
            rows=owner.get(key)
            if isinstance(rows,dict):
                rows=rows.get("assets")
            for row in rows if isinstance(rows,list) else []:
                if not isinstance(row,dict) or row.get("page_number",row.get("page",page if owner is cfg else None))!=page:
                    continue
                if row.get("role",row.get("kind")) not in ICON_KINDS or row.get("action","add") not in ("add","auto","include"):
                    continue
                slot=row.get("slot") or row.get("name")
                if slot and not row.get("protected"):
                    out[slot]=row
    return out


def art_style(canvas, box, slot):
    # Check original objects and live foreground text, then determine the backdrop
    # from the actual slide or its generated solid field. Never cover original evidence.
    x,y,w,h=box
    originals={s.shape_id for s in canvas.items}
    bg="FFFFFF"
    def solid(fill):
        try:
            return str(fill.fore_color.rgb)
        except (ValueError,AttributeError,TypeError):
            return None
    bg=solid(canvas.slide.background.fill) or bg
    for shape in canvas.slide.shapes:
        if shape.width<=0 or shape.height<=0:
            continue
        X,Y,W,H=canvas.geometry(shape)
        area=max(0,min(x+w,X+W)-max(x,X))*max(0,min(y+h,Y+H)-max(y,Y))
        if area<=w*h*.004:
            continue
        text=shape.has_text_frame and shape.text.strip()
        fill=solid(shape.fill) if hasattr(shape,"fill") else None
        if not text and shape.shape_id not in originals and fill and area>=w*h*.997:
            bg=fill
            continue
        return None
    accent=slot.get("color") or canvas.palette.get("14574F","14574F")
    if not isinstance(accent,str) or not re.fullmatch(r"[0-9a-fA-F]{6}",accent):
        accent="14574F"
    def luminance(c):
        v=[int(c[i:i+2],16)/255 for i in (0,2,4)]
        v=[i/12.92 if i<=.04045 else ((i+.055)/1.055)**2.4 for i in v]
        return sum(a*b for a,b in zip(v,(.2126,.7152,.0722)))
    a,b=sorted((luminance(accent),luminance(bg)))
    if (b+.05)/(a+.05)<3:
        accent="FFFFFF" if luminance(bg)<.24 else "172F2D"
    return accent,bg


def symbol_color(shape,color,weight):
    shape.line.color.rgb=RGBColor.from_string(color)
    shape.line.width=Pt(weight)
    shape._element.spPr.get_or_add_ln().set("cap","rnd")


def clear_effects(shape):
    for ref in shape._element.xpath("./p:style/a:effectRef"):
        ref.set("idx","0")
    props=shape._element.xpath("./p:spPr | ./p:grpSpPr")[0]
    for effects in props.xpath("./a:effectLst | ./a:effectDag"):
        props.remove(effects)
    props.append(OxmlElement("a:effectLst"))


def draw_parts(group,parts,view,box,color,background,weight_factor=1):
    x,y,w,h=box
    u=min(w/view[0],h/view[1]); ox=x+(w-view[0]*u)/2;oy=y+(h-view[1]*u)/2
    pos=lambda X,Y:(round(ox+X*u),round(oy+Y*u))
    weight=max(.65,u/12700*1.72*weight_factor)
    for kind,data,*paint in parts:
        if kind=="line":
            for p,q in zip(data,data[1:]):
                if math.dist(p,q)<.16:
                    radius=.86*weight_factor
                    X,Y=pos(p[0]-radius,p[1]-radius)
                    element=group.shapes.add_shape(S.OVAL,X,Y,max(1,round(radius*2*u)),max(1,round(radius*2*u)))
                    element.fill.solid();element.fill.fore_color.rgb=RGBColor.from_string(color);element.line.fill.background()
                else:
                    element=group.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,*pos(*p),*pos(*q))
                    symbol_color(element,color,weight)
            continue
        X,Y,W,H,*extra=data
        shape_kind={"oval":S.OVAL,"rect":S.ROUNDED_RECTANGLE if extra and extra[0] else S.RECTANGLE,
                    "panel":S.PARALLELOGRAM,"triangle":S.ISOSCELES_TRIANGLE}[kind]
        element=group.shapes.add_shape(shape_kind,*pos(X,Y),max(1,round(W*u)),max(1,round(H*u)))
        if kind=="rect" and extra and extra[0] and element.adjustments:
            element.adjustments[0]=min(.5,extra[0]/min(W,H))
        element.fill.background()
        if paint:
            # A material surface may be filled. The icon's surrounding area stays transparent.
            tint=RGBColor(*(round(.16*a+.84*b) for a,b in zip(bytes.fromhex(color),bytes.fromhex(background))))
            element.fill.solid();element.fill.fore_color.rgb=tint
        symbol_color(element,color,weight)


def scene_art(key):
    if key=="sun":
        return (["oval",[4,3,7,7]],["panel",[11,10,21,10],"E3EFDF"],["line",[[15,15],[30,15]]],
                ["line",[[22,10],[19,20]]],["line",[[27,10],[24,20]]],["line",[[21,21],[21,25],[28,25]]],
                ["line",[[4,24],[10,24]]],["line",[[7.5,0],[7.5,1]]],["line",[[.2,6.5],[2,6.5]]])
    if key=="wind":
        parts=[]
        for x,y,r,bottom in [(12,8,7,25),(27,13,5,25)]:
            parts.extend([["line",[[x,y+1.4],[x-.7,bottom],[x+.8,bottom],[x+.3,y+1.3]]],
                          ["line",[[x,y],[x-.5,y-r],[x+.7,y-r*.61],[x+.6,y-.6]]],
                          ["line",[[x,y],[x+r*.92,y+r*.37],[x+r*.5,y+r*.38],[x,y+.7]]],
                          ["line",[[x,y],[x-r*.69,y+r*.60],[x-r*.3,y+r*.08],[x-.7,y-.3]]],
                          ["oval",[x-.85,y-.85,1.7,1.7],"E3EFDF"]])
        return parts+[["line",[[2,26],[34,26]]]]
    if key in ("map-pin","route","compass"):
        return (["line",[[2,6],[10,3],[20,6],[31,2],[31,19],[22,23],[12,20],[2,24],[2,6]]],
                ["line",[[10,3],[12,20]]],["line",[[20,6],[22,23]]],["oval",[24,6.5,3.5,3.5]],
                ["line",[[6,17],[13,12],[16,14],[24,9]]])
    if key in ("presentation","messages-square","notebook-pen","lightbulb","users-round"):
        return (["rect",[3,3,26,16,1.2],"EDF4EF"],["line",[[16,19],[16,23]]],
                ["line",[[16,23],[9,26]]],["line",[[16,23],[23,26]]],["line",[[7,14],[12,10],[16,12],[23,6]]],
                ["oval",[28,13,5,5]],["line",[[34,25],[33,19],[30,19],[26,17],[22,13]]])
    return None


def apply_semantic_icons(canvas,plan,page_number,composition):
    """Fill the layout's reserved slots with independent editable native groups; return chosen objects."""
    if not refined_page(plan,page_number) or composition in (None,"custom-composition-needed","respect-explicit-layout","quick-or-other-profile"):
        return []
    explicit=plan_icons(plan,page_number)
    empty=not any(s._element.xpath(".//a:blip") or s.has_chart or s.has_table for s in canvas.items)
    output=[]
    for slot in getattr(canvas,"art_slots",[]):
        if slot.get("role") not in ICON_KINDS:
            continue
        name=slot.get("name")
        selected=explicit.get(name,{})
        if not name or not authorized(plan,page_number,empty=empty,icon=True,explicit=bool(selected),slot=name):
            continue
        role=selected.get("role") or selected.get("kind") or slot["role"]
        subject=slot.get("anchor_text","")
        key=choose_icon(subject, selected.get("icon_key",slot.get("icon_key")))
        if not key:
            continue
        normalized_box=slot.get("box")
        if not isinstance(normalized_box,(list,tuple)) or len(normalized_box)!=4:
            continue
        x,y,w,h=normalized_box
        if not (0<=x<x+w<=1.000001 and 0<=y<y+h<=1.000001 and min(w*canvas.w,h*canvas.h)>=13*12700):
            continue
        style_colors=art_style(canvas,normalized_box,slot)
        if style_colors is None:
            continue
        style=normalized((plan.get("settings") or {}).get("media_style",""))
        illustrated=style in ("illustration","插圖","插畫","插图","插画")
        large_enough=min(w*canvas.w,h*canvas.h)>=32*12700
        drawing=scene_art(key) if role=="native_illustration" or illustrated and large_enough and not selected else None
        if role=="native_illustration" and drawing is None:
            continue
        if drawing:
            role="native_illustration"
        bounds=(x*canvas.w,y*canvas.h,w*canvas.w,h*canvas.h)
        group=canvas.slide.shapes.add_group_shape()
        group.name=f"PS art {page_number} {name} {key}"
        draw_parts(group,drawing or catalog()[key]["parts"],(36,28) if drawing else (24,24),bounds,*style_colors,.77 if drawing else 1)
        for part in (group,*group.shapes):
            clear_effects(part)
        group._element.nvGrpSpPr.cNvPr.set("descr",str(subject)[:180])
        output.append({"name":name,"object_name":group.name,"role":role,"icon_key":key,
                       "anchor_text":subject,"box":list(normalized_box),"native_parts":len(group.shapes)})
    return output


if __name__=="__main__":
    import argparse
    cli=argparse.ArgumentParser(description="Read the bundled editable icon choices for an approved layout slot.")
    cli.add_argument("--text",help="Suggest an icon only for an identifiable action or subject")
    args=cli.parse_args()
    result=({"icon_key":choose_icon(args.text)} if args.text is not None else
            {key:value["terms"] for key,value in catalog().items()})
    print(json.dumps(result,ensure_ascii=False,indent=2))
