#!/usr/bin/env python3
"""Decode the original generation and bind its pixel size, digest and visual review to a slot."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

from PIL import Image, ImageOps

spec = importlib.util.spec_from_file_location("studio_cutout", Path(__file__).with_name("check-cutout.py"))
cutouts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cutouts)
requires_cutout = cutouts.requires_cutout

DECISIONS = {"matched", "wrong_subject", "wrong_medium", "wrong_composition", "unusable"}


def inspect(file, evidence, require_cutout=False):
    evidence = dict(evidence)
    if require_cutout:
        result = cutouts.inspect(file)
        evidence["cutout_check"] = result
        if result["status"] != "ready":
            return {"status": result["status"], "reason": ", ".join(result["reasons"]), "visual_review": evidence}
    with Image.open(file) as image:
        image.load()
        width, height = ImageOps.exif_transpose(image).size
    digest = hashlib.sha256(Path(file).read_bytes()).hexdigest()
    reviewed = {**evidence, "file": str(file), "width": width, "height": height, "sha256": digest}
    if require_cutout and reviewed["cutout_check"]["sha256"] != digest:
        return {"status": "unverified", "reason": "Original file changed during inspection.", "visual_review": reviewed}
    decision = reviewed.get("content")
    raw = reviewed.get("source_sha256", "")
    if (not reviewed.get("generation_ref") or not reviewed.get("observation", "").strip()
            or reviewed.get("viewed_sha256") != digest or len(raw) != 64
            or any(ch not in "0123456789abcdef" for ch in raw) or decision not in DECISIONS):
        return {"status": "unverified", "reason": "Read the original tool result and inspect its complete image.", "visual_review": reviewed}
    if raw != digest:
        return {"status": "rejected", "reason": "This file differs from the original generation.", "visual_review": reviewed}
    if decision != "matched":
        return {"status": "rejected", "reason": decision + ": " + reviewed["observation"], "visual_review": reviewed}
    target = reviewed.get("placement_px") or {}
    if any(type(target.get(key)) is not int or target[key] <= 0 for key in ("width", "height")):
        return {"status": "unverified", "reason": "Measure the visible artwork box in the intended slide render.", "visual_review": reviewed}
    if width < target["width"] or height < target["height"]:
        return {"status": "rejected", "reason": "Insufficient native pixels for this artwork box.", "visual_review": reviewed}
    return {"status": "ready", "visual_review": reviewed}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file", type=Path)
    parser.add_argument("evidence", type=Path)
    parser.add_argument("--cutout", action="store_true", help="Require original PNG with exterior transparency.")
    args = parser.parse_args()
    print(json.dumps(inspect(args.file, json.loads(args.evidence.read_text()), args.cutout), ensure_ascii=False))
