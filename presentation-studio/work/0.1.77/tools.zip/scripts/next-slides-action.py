#!/usr/bin/env python3
"""Select the next Google Slides delivery operation from one revision's real receipts."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from visible_page_receipt import digest, release_state


def next_action(state):
    capabilities = set(state["available"])
    attempts = state.get("attempts", {})
    native_id = state.get("native_id")
    pending = state.get("pending_write")
    if pending:
        if state.get("unresolved_write") == pending:
            return {"action": "blocked", "reason": "unresolved_write", "operation": pending}
        return {"action": "reconcile_write", "operation": pending}
    if native_id:
        if state.get("native_readback") == "mismatch":
            if "repair_existing" not in capabilities or attempts.get("repair_existing"):
                return {"action": "blocked", "reason": "native_content_mismatch", "native_id": native_id}
            return {"action": "repair_existing", "native_id": native_id}
        if state.get("native_readback") == "unreadable":
            return {"action": "blocked", "reason": "readback_unavailable", "native_id": native_id}
        if state.get("verified_native_id") == native_id:
            revision = state.get("native_revision")
            if not revision:
                return {"action":"read_native_revision", "native_id":native_id}
            verdict, pages = release_state((state.get("visible_reports") or {}).get("slides"), native_id,
                                          revision, state.get("expected_pages"), state.get("intentionally_blank_pages", []))
            if verdict == "deliver":
                if state.get("slides_from_pptx") and "pptx" in state.get("deliverables", ["pptx","slides"]):
                    reports = state["visible_reports"]
                    baseline = (reports.get("pptx") or {}).get("pdf_sha256")
                    if not digest(baseline) or reports["slides"].get("pptx_pdf_sha256") != baseline:
                        action = "compare_rendered_type"
                        if attempts.get(action) == [baseline, revision]:
                            return {"action":"blocked", "reason":"unverified_type_comparison", "native_id":native_id}
                        return {"action":action, "native_id":native_id, "revision":revision, "pptx_pdf_sha256":baseline}
                return {"action":"deliver", "native_id":native_id}
            if verdict == "repair":
                action = "repair_existing" if "repair_existing" in capabilities and not attempts.get("repair_existing") else "blocked"
                details = [r for r in state["visible_reports"]["slides"]["pages"]
                           if r.get("type_measurements") and r["page_number"] in pages]
                result = {"action":action,"reason":"native_pages_not_visible","pages":pages,"native_id":native_id}
                if details:
                    result["reason"] = "native_render_mismatch"
                    result["type_measurements"] = [r["type_measurements"] for r in details]
                return result
            action = "review_rendered_pages" if verdict == "review" else "render_native"
            if attempts.get(action) == revision:
                return {"action":"blocked","reason":"unverified_render","native_id":native_id,"pages":pages}
            return {"action":action,"native_id":native_id,"revision":revision,"pages":pages}
        return {"action": "read_native", "native_id": native_id}

    def available(action):
        return action in capabilities and not attempts.get(action)

    if not state.get("raw_id") and available("import_original"):
        return {"action": "import_original"}
    # Upload once; all conversion routes use the same source bytes.
    raw_id = state.get("raw_id")
    bridge = "import_fetched" in capabilities and "fetch_raw" in capabilities
    if not raw_id and available("upload_raw") and (bridge or "convert_drive" in capabilities):
        return {"action": "upload_raw"}
    if raw_id and bridge:
        if not state.get("fetched_reference") and available("fetch_raw"):
            return {"action": "fetch_raw", "raw_id": raw_id}
        if state.get("fetched_reference") and available("import_fetched"):
            return {"action": "import_fetched"}
    if raw_id and available("convert_drive"):
        return {"action": "convert_drive", "raw_id": raw_id}
    if available("build_native"):
        return {"action": "build_native"}
    return {"action": "blocked", "attempted": list(attempts)}


if __name__ == "__main__":
    print(json.dumps(next_action(json.load(sys.stdin)), ensure_ascii=False))
