#!/usr/bin/env python3
"""Prepare targeted Google Slides fontSize edits from a measured PDF comparison. No network writes."""
import argparse
import json
from pathlib import Path
import unicodedata


def as_pt(value):
    return value["magnitude"] * {"EMU": 1 / 12700, "PT": 1}[value["unit"]]


def shape_contains(element, box, canvas):
    """Use native position as a second independent check on a content match."""
    t = element.get("transform", {})
    if t.get("shearX") or t.get("shearY") or min(t.get("scaleX", 1), t.get("scaleY", 1)) <= 0:
        return False
    size = element.get("size", {})
    if not all(size.get(axis, {}).get("unit") in ("PT", "EMU") and
               size[axis].get("magnitude", 0) > 0 for axis in ("width", "height")):
        return False
    unit = t.get("unit", "EMU")
    if unit not in ("PT", "EMU"):
        return False
    x = as_pt({"magnitude": t.get("translateX", 0), "unit": unit})
    y = as_pt({"magnitude": t.get("translateY", 0), "unit": unit})
    w = as_pt(size["width"]) * t.get("scaleX", 1)
    h = as_pt(size["height"]) * t.get("scaleY", 1)
    cx = (box[0] + box[2]) / 2 * as_pt(canvas["width"])
    cy = (box[1] + box[3]) / 2 * as_pt(canvas["height"])
    return x - 1 <= cx <= x + w + 1 and y - 1 <= cy <= y + h + 1


def indexed_runs(shape):
    """Map normalized rendered characters to UTF-16 indexes in native rich-text runs."""
    text, index = [], []
    for run_no, element in enumerate(shape.get("text", {}).get("textElements", [])):
        run = element.get("textRun")
        if not run:
            continue
        offset = element.get("startIndex", 0)
        size = run.get("style", {}).get("fontSize")
        for ch in run["content"]:
            end = offset + len(ch.encode("utf-16-le")) // 2
            for c in unicodedata.normalize("NFKC", ch):
                if not c.isspace() and c not in ("\u00ad", "\u200b"):
                    text.append(c)
                    index.append((run_no, offset, end, size))
            offset = end
    return "".join(text), index


def locate(slide, issue, canvas):
    choices = []
    for element in slide.get("pageElements", []):
        shape = element.get("shape")
        if not shape or not shape_contains(element, issue["slides_bbox"], canvas):
            continue
        text, positions = indexed_runs(shape)
        needle = issue["text"]
        if not needle:
            continue
        start = text.find(needle)
        while start >= 0:
            choices.append((element, positions[start:start + len(needle)]))
            start = text.find(needle, start + 1)
    return choices


def targeted_ranges(element, selected, issue):
    shape = element["shape"]
    autofit = shape.get("shapeProperties", {}).get("autofit", {})
    if autofit.get("autofitType") not in (None, "NONE") or autofit.get("fontScale", 1) != 1:
        return None
    spans = []
    for run, start, end, size in selected:
        if not size or size.get("unit") != "PT" or size.get("magnitude", 0) <= 0:
            return None
        # Don't cross paragraph/soft-break markers or apply a style from an adjacent run.
        if spans and run == spans[-1][0] and start <= spans[-1][2]:
            spans[-1][2] = max(spans[-1][2], end)
        else:
            spans.append([run, start, end, size["magnitude"]])
    return [{"updateTextStyle": {"objectId": element["objectId"],
              "textRange": {"type": "FIXED_RANGE", "startIndex": start, "endIndex": end},
              "style": {"fontSize": {"magnitude": round(size * issue["expected_pt"] / issue["actual_pt"], 1),
                                    "unit": "PT"}}, "fields": "fontSize"}} for _, start, end, size in spans]


def plan(report, deck, expected_revision):
    if not expected_revision or deck.get("revisionId") != expected_revision:
        raise ValueError("Fetch the same native revision that produced the compared PDF.")
    if not deck.get("presentationId") or report["page_count"] != len(deck["slides"]):
        raise ValueError("The native presentation and PDF page sequences must match.")
    requests, manual = [], []
    for row in report["pages"]:
        slide = deck["slides"][row["page"] - 1]
        for issue in row["issues"]:
            choices = locate(slide, issue, deck["pageSize"])
            edits = targeted_ranges(*choices[0], issue) if len(choices) == 1 else None
            if edits:
                requests.extend(edits)
            else:
                manual.append({"page": row["page"], **issue, "reason": "inspect_shape_range_size_or_autofit"})
    return {"presentation_id": deck["presentationId"], "slides_pdf_sha256": report["slides_pdf_sha256"],
            "batch_update": {"writeControl": {"requiredRevisionId": expected_revision}, "requests": requests},
            "inspect": manual}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("comparison", type=Path)
    parser.add_argument("native_json", type=Path)
    parser.add_argument("--revision", required=True, help="Revision recorded at native PDF export.")
    args = parser.parse_args()
    print(json.dumps(plan(json.loads(args.comparison.read_text()), json.loads(args.native_json.read_text()),
                          args.revision), ensure_ascii=False))
