#!/usr/bin/env python3
"""Compare independently read slide text to the fixed manuscript. Preserve actual characters."""
import difflib
import hashlib
import json
import sys
from pathlib import Path


def continuous(text):
    # Only layout line breaks are disregarded. Spaces, signs, units, and punctuation matter.
    return text.replace("\r\n", "").replace("\r", "").replace("\n", "")


def text_sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def differences(expected, observed):
    expected, observed = continuous(expected), continuous(observed)
    if expected == observed:
        return []
    # A single typo in a long repeated table should not require a quadratic
    # alignment of all the surrounding identical cells.
    limit = min(len(expected), len(observed))
    prefix = 0
    while prefix < limit and expected[prefix] == observed[prefix]:
        prefix += 1
    suffix = 0
    while suffix < limit - prefix and expected[-suffix-1] == observed[-suffix-1]:
        suffix += 1
    matcher = difflib.SequenceMatcher(None, expected[prefix:len(expected)-suffix],
                                      observed[prefix:len(observed)-suffix], autojunk=False)
    result = []
    for tag, i, j, k, l in matcher.get_opcodes():
        if tag != "equal":
            i, j, k, l = i+prefix, j+prefix, k+prefix, l+prefix
            result.append({"kind": tag, "expected": expected[i:j], "actual": observed[k:l],
                           "expected_context": expected[max(0, i-6):min(len(expected), j+6)],
                           "actual_context": observed[max(0, k-6):min(len(observed), l+6)],
                           "expected_offset": i, "actual_offset": k})
    return result


def review_text(expected, review, artifact_sha):
    if not isinstance(review, dict) or review.get("artifact_sha256") != artifact_sha:
        raise ValueError("Review must identify the exact artifact that was read.")
    if review.get("added_page_number") is not False:
        raise ValueError("Check for added visible page numbers. Remove any unintended folio before delivery.")
    method = review.get("method")
    if method not in ("visual", "ocr_confirmed", "ocr_uncertain", "native_and_visual", "unreadable"):
        raise ValueError("Unknown readback method.")
    result = {"added_page_number": False, "method": method, "artifact_sha256": artifact_sha, "expected_sha256": text_sha(expected)}
    if method == "unreadable":
        if not isinstance(review.get("reason"), str) or not review["reason"].strip():
            raise ValueError("Describe the actual readback limitation.")
        return dict(result, status="unchecked", reason=review["reason"], differences=[])
    actual = review.get("observed_text")
    if not isinstance(actual, str):
        raise ValueError("Read the output independently, then supply observed_text.")
    diffs = differences(expected, actual)
    status = "uncertain" if method == "ocr_uncertain" else "differences" if diffs else "match"
    return dict(result, status=status, observed_sha256=text_sha(actual), differences=diffs)


if __name__ == "__main__":
    # For editable output use the actual final rendered page or verified native page snapshot.
    try:
        expected = Path(sys.argv[1]).read_text(encoding="utf-8")
        evidence = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
        artifact = hashlib.sha256(Path(sys.argv[3]).read_bytes()).hexdigest()
        print(json.dumps(review_text(expected, evidence, artifact), ensure_ascii=False))
    except (OSError, ValueError, IndexError) as error:
        sys.exit(str(error))
