"""Bind a private Drive file to the exact original bytes read for this job.

Before uploading, the caller verifies the user's consent and private destination
folder. Read back id, parents, ownedByMe (or owners.me), permissions(type,role),
mimeType, trashed, size and sha256Checksum from Drive. If a connector omits
permissions, fetch the complete ACL on that same ID before invoking this check.
If owner-self fields are absent, use --account-email with the email returned by
the authenticated Drive profile for the same connection.
When Drive omits SHA256, supply the bytes downloaded from that exact file ID.
This command performs no writes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re


def fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
            size += len(chunk)
    if size == 0:
        raise ValueError("The source copy is empty.")
    return digest.hexdigest(), size


def verify(original, metadata, folder_id, expected_sha256, downloaded_file=None, account_email=None):
    if not re.fullmatch("[0-9a-f]{64}", expected_sha256):
        raise ValueError("Supply the SHA-256 of the selected original when it was read.")
    original_hash, original_size = fingerprint(original)
    if original_hash != expected_sha256:
        raise ValueError("The original changed after it was selected.")
    if not isinstance(metadata, dict):
        raise ValueError("Read the source file's metadata from Drive.")
    file_id = metadata.get("id")
    if (not isinstance(file_id, str) or not re.fullmatch(r"[\w-]+", file_id, re.ASCII)
            or re.fullmatch(r"file_[0-9a-f]{32}", file_id) or file_id.startswith("libfile_")):
        raise ValueError("Expected the Drive file ID returned by metadata readback.")
    parents = metadata.get("parents", metadata.get("parent_ids"))
    if not folder_id or not isinstance(parents, list) or folder_id not in parents:
        raise ValueError("The copy is outside the verified private source folder.")
    mime = metadata.get("mimeType") or metadata.get("mime_type") or ""
    if not isinstance(mime, str) or not mime or metadata.get("trashed") or mime.startswith("application/vnd.google-apps."):
        raise ValueError("Expected an unconverted, non-trashed binary source file.")
    permissions = metadata.get("permissions")
    if not isinstance(permissions, list) or not permissions:
        raise ValueError("Read the complete permissions for this Drive file before binding it.")
    if (len(permissions) != 1 or not isinstance(permissions[0], dict)
            or permissions[0].get("type") != "user" or permissions[0].get("role") != "owner"):
        raise ValueError("The source copy must be accessible only by its owner.")
    if "ownedByMe" in metadata or "owned_by_me" in metadata:
        owned = metadata.get("ownedByMe", metadata.get("owned_by_me")) is True
    else:
        owners = metadata.get("owners") or []
        owner_flags = [owner["me"] for owner in owners if isinstance(owner, dict) and "me" in owner]
        if owner_flags:
            owned = any(value is True for value in owner_flags)
        else:
            owner_email = permissions[0].get("emailAddress") or permissions[0].get("email_address")
            owned = (isinstance(account_email, str)
                     and re.fullmatch(r"[^\s@]+@[^\s@]+", account_email) is not None
                     and isinstance(owner_email, str) and owner_email.casefold() == account_email.casefold())
    if not owned:
        raise ValueError("Verify file ownership using Drive owner flags or the authenticated Drive profile email.")
    if metadata.get("size") is not None and int(metadata["size"]) != original_size:
        raise ValueError("The original and Drive file sizes differ.")
    checksum = metadata.get("sha256Checksum") or metadata.get("sha256_checksum")
    if checksum and checksum.lower() != original_hash:
        raise ValueError("The Drive checksum differs from the selected original.")
    if downloaded_file is not None:
        # Read the output of the connector download, never the pre-upload input.
        if original.samefile(downloaded_file) or fingerprint(downloaded_file) != (original_hash, original_size):
            raise ValueError("Read back a separate, byte-identical copy from Drive.")
    elif not checksum:
        raise ValueError("Download this exact Drive file and verify its bytes.")
    return {"source_sha256": original_hash, "source_mirror": {"file_id": file_id, "sha256": original_hash}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", type=Path)
    parser.add_argument("drive_metadata", type=Path)
    parser.add_argument("--folder-id", required=True)
    parser.add_argument("--expected-sha256", required=True)
    parser.add_argument("--downloaded-file", type=Path)
    parser.add_argument("--account-email", help="Email read from the authenticated profile of this same Drive connection.")
    args = parser.parse_args()
    try:
        data = verify(args.original, json.loads(args.drive_metadata.read_bytes()), args.folder_id,
                      args.expected_sha256, args.downloaded_file, args.account_email)
    except (ValueError, OSError) as exc:
        parser.exit(2, str(exc) + "\n")
    print(json.dumps(data))
