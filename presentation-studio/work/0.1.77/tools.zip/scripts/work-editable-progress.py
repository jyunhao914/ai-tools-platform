"""Bind a claimed Work packet and an editable source to the existing native-image queue."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
import runpy
import subprocess
from urllib.parse import urlparse, parse_qs
import sys

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.oxml.ns import qn
import semantic_icons as media
import image_provenance

HERE = Path(__file__).resolve().parent
DECORATIONS = runpy.run_path(str(HERE/"source-decoration.py"))
VERSION = "presentation-studio/work-progress/v1"
AUTO_IMAGES = {"auto", "auto_add", "auto_illustrate", "automatic", "content_auto", "依內容自動配圖", "自動配圖"}
REDRAW = {"redraw", "photorealistic_redraw", "hyperrealistic_redraw", "超擬真重繪", "重新配圖"}


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_bytes())


def save_once(path, value, queue):
    if path.exists():
        require(read_json(path) == value, "Another Work request already owns " + path.name)
    else:
        queue.write(path, value)


def walk(shapes):
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from walk(shape.shapes)
        else:
            yield shape


def inventory(source, root):
    deck = Presentation(source)
    pages = {}
    for n, slide in enumerate(deck.slides, 1):
        titles = []
        items = []
        top_frames={el._element for el in slide.shapes}
        for shape in walk(slide.shapes):
            if shape.has_text_frame and shape.text.strip():
                titles.extend(line.strip() for line in shape.text.splitlines() if line.strip())
            for blip in shape._element.xpath(".//a:blip"):
                rid = blip.get(qn("r:embed"))
                if not rid:
                    continue
                part = slide.part.related_part(rid)
                digest = sha256(part.blob).hexdigest()
                path = root / "references" / (digest + Path(str(part.partname)).suffix.lower())
                path.parent.mkdir(exist_ok=True)
                if path.exists():
                    require(sha(path) == digest, "Original image checkpoint was modified")
                else:
                    path.write_bytes(part.blob)
                items.append({"page_number":n,"shape_id":shape.shape_id,"name":shape.name,
                              "sha256":digest,"reference":str(path),
                              "source_visual":DECORATIONS["source_facts"](shape,deck,part.blob) if shape._element in top_frames else {}})
        pages[n] = {"title":titles[0] if titles else "", "pictures":items,
                    "native_data":any(s.has_chart or s.has_table for s in walk(slide.shapes))}
    return pages


def bounded_scene(title):
    # Delimit source text as a topic. Do not pass slide bodies, source media or operational notes to a new scene.
    title = re.sub(r"[\s。；;]+", " ", str(title)).strip()[:100]
    require(title, "Supply an approved scene brief for an untitled page")
    return "用與此頁主題相符的一個具體場景呈現「" + title + "」，單一自然取景，畫面不含字或簡報版面"


def explicit_assets(plan):
    for owner in (plan, plan.get("settings", {})):
        for key in ("assets", "image_assets", "image_plan"):
            if key in owner:
                value = owner[key]
                if isinstance(value,dict):
                    value = value.get("assets")
                require(isinstance(value,list),"Use an array for confirmed image slots")
                return value
    rows=[]
    seen=False
    for i,page in enumerate(plan.get("pages",[]),1):
        for key in ("assets","images"):
            if key in page:
                seen=True
                require(isinstance(page[key],list),"Invalid per-page image list")
                rows.extend({"page_number":page.get("page_number",page.get("source_page",i)),**item} for item in page[key])
    return rows if seen else None


def original(asset, page):
    candidates = page["pictures"]
    if asset.get("source_shape_id") is not None:
        candidates=[p for p in candidates if p["shape_id"]==asset["source_shape_id"]]
    elif asset.get("source_name") or asset.get("name"):
        label=asset.get("source_name") or asset.get("name")
        candidates=[p for p in candidates if p["name"]==label]
    if asset.get("source_sha256"):
        candidates=[p for p in candidates if p["sha256"]==asset["source_sha256"]]
    require(len(candidates)==1,"Identify the exact original picture by page and shape for this redraw")
    return candidates[0]


def fallback_cutout(assets):
    # Only a page for which the current plan already permits automatic new art.
    for row in assets:
        n=row["page_number"]
        if (row.get("name")==f"scene-{n}" and row.get("action")=="add" and not row.get("protected")
                and not row.get("replaces_source") and row.get("transparent_cutout") is not False):
            return {"page_number":n,"name":f"cutout-{n}-auto","action":"add","kind":"cutout","transparent_cutout":True,
                    "brief":"一個與這個場景主題相關的獨立小物件，無字、完整外形、透明背景："+row["brief"]}
    return None


def refined_scenes(page,layout):
    """Schedule concrete, useful photo subjects only in a composition's intended image slots."""
    if any(s.get("placed") for s in layout.get("art_slots",[])):
        return []
    rows=[]
    for slot in layout.get("art_slots",[]):
        role=slot.get("role")
        if role not in ("photo","scene","hero_photo","cutout","editorial_photo","subject_cutout"):
            continue
        subject=media.scene_brief(slot,page["title"])
        if not subject:
            continue
        cutout=role in ("cutout","subject_cutout")
        row={"page_number":layout["page"],"name":slot["name"],"kind":"cutout" if cutout else "picture",
             "action":"add","brief":subject,"role":role}
        if cutout:
            row["transparent_cutout"]=True
        for field in ("box","focus","anchor_text"):
            if slot.get(field) is not None:
                row[field]=slot[field]
        rows.append(row)
    return rows


def convert(plan, pages, composition=None):
    settings = dict(plan["settings"])
    if runpy.run_path(str(HERE/"photo-layout-variety.py"))["requested"](plan):
        settings["photo_layout_variety"] = True
    if settings.get("new_images_only"):
        settings["fresh_images_only"] = True
    approved = explicit_assets(plan)
    assets=[]
    native_replacements=[]
    unresolved=[]
    if approved is not None:
        for item in approved:
            require(isinstance(item,dict),"Invalid approved image slot")
            n=item.get("page_number",item.get("page",item.get("source_page")))
            require(n in pages,"Image slot identifies an unknown source page")
            if DECORATIONS["protected"](item) or item.get("action")=="none":
                continue
            if item.get("kind") in DECORATIONS["VECTOR"]:
                if item.get("action") in ("redraw","replace") and media.refined_page(plan,n):
                    source=original(item,pages[n])
                    if DECORATIONS["preserves"](plan,source):continue
                    native_replacements.append({**item,"name":item.get("name") or source["name"],"page_number":n,
                        "source_shape_id":source["shape_id"],"source_sha256":source["sha256"],"replaces_source":True})
                continue
            row = dict(item,page_number=n)
            row.setdefault("action","add")
            require(row["action"] in ("add","redraw","replace"),"Unsupported image operation in confirmed settings")
            if row["action"]=="add" and media.forbids_new(plan,n,empty=not pages[n]["pictures"],slot=row.get("name"),explicit=True):
                continue
            row["name"]=row.get("name") or row.get("object_name") or f"page-{n}-asset-{len(assets)+1}"
            row["brief"]=row.get("brief") or row.get("subject") or row.get("description") or bounded_scene(pages[n]["title"])
            if row["action"] in ("redraw","replace"):
                source=original(row,pages[n])
                if DECORATIONS["preserves"](plan,source):continue
                DECORATIONS["bind_redraw"](plan,row,source)
                row.update(source_sha256=source["sha256"],source_shape_id=source["shape_id"],replaces_source=True)
                if row["action"]=="redraw":
                    row.update(reference=source["reference"],sha256=source["sha256"])
                else:
                    row["action"]="add"
            assets.append(row)
    else:
        empty_policy = settings.get("imageless_pages",settings.get("empty_page_images"))
        layouts={r["page"]:r for r in (composition or {}).get("pages",[])}
        for n,p in pages.items():
            if p["pictures"] or p["native_data"] or not p["title"] or not media.authorized(plan,n,empty=True):
                continue
            if media.refined_page(plan,n) and composition is not None:
                assets.extend(refined_scenes(p,layouts.get(n,{})))
            elif empty_policy in AUTO_IMAGES:
                assets.append({"page_number":n,"name":f"scene-{n}","kind":"picture",
                               "action":"add","brief":bounded_scene(p["title"])})
        required=settings.get("transparent_png")
        if isinstance(required,dict) and type(required.get("required")) is int:
            count=required["required"]
            require(0<=count<=len(pages),"Invalid requested number of transparent illustrations")
            for i in range(count):
                n=required.get("page_number",list(pages)[-(i+1)])
                require(n in pages,"Transparent slot points to an unknown page")
                if media.forbids_new(plan,n,empty=not pages[n]["pictures"]):
                    continue
                assets.append({"page_number":n,"name":f"cutout-{n}-{i+1}","action":"add","kind":"cutout",
                               "transparent_cutout":True,"brief":required.get("brief") or
                               "一件清楚可辨的獨立器物，可代表「"+pages[n]["title"][:70]+"」，完整外形、無字、透明背景"})
        if settings.get("original_images") in REDRAW | {"replace"}:
            unresolved=[p for page in pages.values() for p in page["pictures"] if not DECORATIONS["preserves"](plan,p)]
        if not assets and not unresolved and (settings.get("original_images") not in ({None,"keep","preserve","original","per_object","沿用原圖","replace"}|REDRAW|media.NONE)
                                              or empty_policy not in ({None,"keep","suggest"}|AUTO_IMAGES|media.NONE)):
            raise ValueError("Parse the confirmed media policy into explicit per-page image slots before production")
    review=plan.get("image_adjustments") or settings.get("image_adjustments")
    if review:
        program="import{applyImageAdjustments as f}from "+json.dumps((HERE/"image-adjustments.mjs").as_uri())+";let b='';for await(const c of process.stdin)b+=c;process.stdout.write(JSON.stringify(f(JSON.parse(b)).assets));"
        job={"source_key":plan.get("source_key") or plan["source_revision"],"revision":plan["revision"],
             "assets":[{**x,"page":x["page_number"]} for x in assets],"pages":len(pages),"image_adjustments":review}
        changed=subprocess.run(["node","--input-type=module","-e",program],input=json.dumps(job),text=True,capture_output=True)
        require(changed.returncode==0,"Could not bind the per-object edits to this source/revision: "+changed.stderr[-450:])
        catalogue={(r["page"],r["name"]):r for r in review["catalogue"]}
        overrides={(e["page"],e["name"]):e for e in review["edits"]}
        omit=set()
        for key,row in catalogue.items():
            edit=overrides.get(key,{})
            if row.get("kind")=="original" and (row.get("protected") or edit.get("action","inherit")!="inherit"):
                src=original({"name":key[1],"source_sha256":row.get("sha256")},pages[key[0]])
                omit.add((key[0],src["shape_id"],src["sha256"]))
        unresolved=[u for u in unresolved if (u["page_number"],u["shape_id"],u["sha256"]) not in omit]
        assets=[]
        for row in json.loads(changed.stdout):
            n=row["page"];row["page_number"]=n
            if row["action"]=="add" and not row.get("replace_original") and media.forbids_new(
                    plan,n,empty=not pages[n]["pictures"],slot=row.get("name"),
                    explicit=overrides.get((n,row.get("name")),{}).get("action")=="add"):
                continue
            if row.get("replace_original") or row["action"]=="redraw":
                src=original({"name":row["name"],"source_sha256":row.get("sha256")},pages[n])
                if DECORATIONS["preserves"](plan,src):continue
                DECORATIONS["bind_redraw"](plan,row,src)
                row.update(replaces_source=True,source_shape_id=src["shape_id"],source_sha256=src["sha256"])
                if row["action"]=="redraw":row.update(reference=src["reference"],sha256=src["sha256"])
            assets.append(row)
    queue_plan={"job_id":plan["job_id"],"content_revision":str(plan["revision"]),"settings":settings,"assets":assets}
    if native_replacements:queue_plan["native_source_replacements"]=native_replacements
    if approved is None and settings.get("transparent_png") is True:
        is_cutout=runpy.run_path(str(HERE/"check-cutout.py"))["requires_cutout"]
        if not any(is_cutout(r) for r in assets):
            if unresolved:
                queue_plan["classify_for_cutout"]=True
                if review:queue_plan["cutout_page_overrides"]=True
            elif not review:
                slot=fallback_cutout(assets)
                if slot:assets.append(slot)
    for k in ("page_profiles","retry_test"):
        if k in plan:queue_plan[k]=plan[k]
    return queue_plan,unresolved


def drive_id(ref):
    if isinstance(ref,dict):
        return ref.get("id") or ref.get("file_id") or ref.get("source_file_id") or drive_id(ref.get("url") or ref.get("source_url"))
    if not isinstance(ref,str) or not ref.strip():return None
    if "/" not in ref and ":" not in ref:return ref
    url=urlparse(ref)
    if url.hostname not in ("docs.google.com","drive.google.com"):return None
    parts=url.path.strip("/").split("/")
    if "d" in parts and len(parts)>parts.index("d")+1:return parts[parts.index("d")+1]
    return parse_qs(url.query).get("id",[None])[0]


def source_binding(plan, downloaded, proof_path):
    revision=plan["source_revision"]
    identity=drive_id(plan.get("source_ref")) or drive_id(plan.get("source_url"))
    sources=[item for item in plan.get("sources",[]) if isinstance(item,dict)]
    if not identity and len(sources)==1:identity=drive_id(sources[0])
    matching=[s for s in sources if identity and drive_id(s)==identity]
    candidates=[plan.get("source_sha256"),revision if re.fullmatch(r"[a-fA-F0-9]{64}",revision) else None]
    candidates.extend(s.get("sha256") for s in matching)
    hashes={str(h).lower() for h in candidates if h}
    actual=sha(downloaded)
    if hashes:
        require(hashes=={actual},"Source bytes differ from the confirmed source SHA-256")
        return actual
    require(proof_path and identity, "Provide --source-readback from the authenticated download of the confirmed source ID and revision")
    proof=read_json(proof_path)
    require((proof.get("file_id") or proof.get("id"))==identity and proof.get("revision")==revision and
            str(proof.get("sha256","")).lower()==actual,"Wrong source identity, revision or downloaded bytes")
    if "size" in proof:require(int(proof["size"])==downloaded.stat().st_size,"Downloaded source size differs")
    return actual


def start(args,ctx):
    queue=ctx["queue"]
    root=args.run_dir.resolve()
    root.mkdir(parents=True,exist_ok=True)
    receipt=read_json(args.received)
    require(receipt.get("action")=="resume","Read back this Work owner's accepted claim before starting")
    plan=receipt["plan"]
    own=receipt["receipt"]
    require(own.get("state")=="accepted" and own.get("work_ref") and own.get("job_id")==plan.get("job_id") and
            own.get("revision")==plan.get("revision") and re.fullmatch(r"[0-9a-f]{64}",own.get("packet_sha256","")),
            "Claim does not bind this job, revision and owning Work run")
    form=plan.get("settings",{}).get("format")
    editable=form=="editable" or (form is None and plan.get("settings",{}).get("editable_profile") in ("quick","refined"))
    require(plan.get("mode") in (3,"3") and editable,
            "This entry accepts mode 3 editable PPTX work")
    source=args.source.resolve()
    expect=source_binding(plan,source,args.source_readback)
    base=root/"base.pptx"
    require(source!=base and not (base.exists() and base.samefile(source)),"Original must remain separate from the private draft")
    with queue.locked(root/"work-checkpoint"):
        cp=root/"work.json"
        owner={"job_id":own["job_id"],"revision":own["revision"],"packet_sha256":own["packet_sha256"],
               "work_ref":own["work_ref"],"source_sha256":expect,"input_base_sha256":sha(args.base.resolve()) if args.base else expect}
        owner_file=root/"work-owner.json"
        if owner_file.is_file() and args.base is None:
            owner["input_base_sha256"]=read_json(owner_file).get("input_base_sha256")
        if not owner_file.exists():
            require(not any(x.exists() for x in (base,cp,root/"assets.json",root/"attempts.json")),
                    "The destination contains an unowned production file")
        save_once(owner_file,owner,queue)
        if cp.exists():
            old=read_json(cp)
            require(all(old["receipt"].get(k)==own.get(k) for k in ("job_id","revision","packet_sha256","work_ref")) and old["source_sha256"]==expect,"Directory belongs to another accepted Work run")
            require(base.is_file() and sha(base)==old["baseline_sha256"],"Restore the owned baseline before resuming")
        else:
            draft_source=(args.base or source).resolve()
            if not base.exists():
                require(sha(draft_source)==owner["input_base_sha256"],"Provide the previously bound baseline again after interruption")
            require(draft_source!=base and len(Presentation(draft_source).slides)==len(Presentation(source).slides),
                    "Use a private baseline matching the original page sequence")
            if not base.exists():
                profiles=plan.get("page_profiles",{}).values()
                if args.base is None and ("refined" in profiles or plan["settings"].get("editable_profile")=="refined"):
                    layout=runpy.run_path(str(HERE/"compose-refined.py"))["compose"](draft_source,base,plan)
                    queue.write(root/"refined-composition.json",layout)
                else:
                    runpy.run_path(str(HERE/"remove-slide-numbers.py"))["write_copy"](draft_source,base)
            else:
                require(len(Presentation(base).slides)==len(Presentation(draft_source).slides),
                        "Damaged unfinished baseline in this owned directory")
            pages=inventory(source,root)
            confirmed_count=plan.get("settings",{}).get("page_count")
            if confirmed_count is not None:
                require(type(confirmed_count) is int and confirmed_count==len(pages),"Source page count differs from confirmed plan")
            composition_file=root/"refined-composition.json"
            queue_plan,unresolved=convert(plan,pages,read_json(composition_file) if composition_file.is_file() else None)
            save_once(root/"assets.json",queue_plan,queue)
            save_once(cp,{"schema":VERSION,"receipt":own,"source_sha256":expect,
                          "baseline_sha256":sha(base),"source_file":str(source),"pages":len(pages),"source_objects_for_review":unresolved,
                          "delivery":plan.get("delivery",{}),"editable_charts":plan.get("editable_charts",[]),
                          "settings":queue_plan["settings"], "page_profiles":plan.get("page_profiles",{}),
                          "layout_change_pages":plan.get("layout_change_pages"),
                          "composition_sha256":sha(root/"refined-composition.json") if (root/"refined-composition.json").exists() else None,
                          "supplied_base":bool(args.base), "art_requirements":plan.get("requirements",{}),
                          "media_scope":{k:plan[k] for k in ("assets","image_assets","image_plan","page_overrides","image_adjustments","image_policy","no_new_images","only_listed_assets") if k in plan},
                          "design_constraints":plan.get("pages",[]),"visual_plan":plan.get("visual_plan"),"source_key":plan.get("source_revision") or expect},queue)
    return next_work(root,args,ctx)


def paths(root):
    return dict(run_dir=str(root),base=str(root/"base.pptx"),plan=str(root/"assets.json"),state=str(root/"attempts.json"))


def classifications(args,ctx):
    root=args.run_dir.resolve(); cp=read_json(root/"work.json");rows=read_json(args.decisions)
    base=read_json(root/"assets.json")
    require(isinstance(rows,list),"Supply one source review per identified picture")
    known={(r["page_number"],r["shape_id"],r["sha256"]):r for r in cp["source_objects_for_review"]}
    observed=set();new=[];legacy=None
    for r in rows:
        ident=(r.get("page_number"),r.get("shape_id"),r.get("sha256"))
        require(ident in known and ident not in observed and r.get("action") in ("keep","redraw","replace"),"Unexpected or duplicate source review")
        require(isinstance(r.get("observation"),str) and r["observation"].strip(),"Review the actual source picture")
        if DECORATIONS["protected"](r):
            r["action"]="keep"
        observed.add(ident)
        if r["action"] in ("redraw","replace"):
            require(r.get("brief"),"Supply a concrete independent scene for an approved redraw")
            p=known[ident]
            policy=read_json(root/"assets.json")["settings"].get("original_images")
            require((policy in REDRAW and r["action"]=="redraw") or (policy=="replace" and r["action"]=="replace"),
                    "Source classification cannot widen the confirmed picture operation")
            row={"page_number":p["page_number"],"name":p["name"]+"-"+str(p["shape_id"]),"brief":r["brief"],
                 "source_sha256":p["sha256"],"source_shape_id":p["shape_id"],"replaces_source":True}
            if r["action"]=="redraw":row.update(action="redraw",reference=p["reference"],sha256=p["sha256"])
            else:row["action"]="add"
            for key in ("role","kind","source_use","transparent_cutout"):
                if key in r:row[key]=r[key]
            visual=p
            if "source_visual" not in p and media.refined_page(base,p["page_number"]):
                if legacy is None:legacy=inventory(Path(cp["source_file"]),root)
                visual=original({"source_shape_id":p["shape_id"],"source_sha256":p["sha256"]},legacy[p["page_number"]])
            DECORATIONS["bind_redraw"](base,row,visual)
            new.append(row)
    require(set(known)==observed,"Inspect every ambiguous original evidence or decoration explicitly")
    if base.get("classify_for_cutout"):
        is_cutout=runpy.run_path(str(HERE/"check-cutout.py"))["requires_cutout"]
        for item in new:
            if is_cutout(item):
                item["transparent_cutout"]=True
        if not any(is_cutout(item) for item in [*new,*base["assets"]]):
            if not base.get("cutout_page_overrides"):
                slot=fallback_cutout(base["assets"])
                if slot:new.append(slot)
    with ctx["queue"].locked(root/"work-checkpoint"):
        save_once(root/"source-decisions.json",rows,ctx["queue"])
        save_once(root/"redraws.json",{**base,"assets":new,"retry_test":None},ctx["queue"])
    return next_work(root,args,ctx)


def native_action(action,root,opts):
    original=action["asset"].get("reference")
    fields=opts.get("reference_key") or []
    prepared=runpy.run_path(str(HERE/"prepare-asset-call.py"))["prepare_native"](
        action,root,fields,registered=opts.get("registered_ref"),original=Path(original) if original else None,
        last_shown=opts.get("last_shown_sha"),supports_transparency=opts.get("supports_transparent_background",False))
    if prepared.get("action")=="generate":
        return {**prepared,"action":"call_native_image","asset":action["asset"],"attempt":action["attempt"],
                "request_id":action["request_id"],"dispatch_recorded":False}
    return {**action,**prepared}


def prepared_art(root, cp, files, ready, ctx):
    """Recompose once, from the bound private source and vetted native image receipts."""
    if not ready or cp.get("supplied_base") or not (root/"refined-composition.json").exists():
        return {}
    rows=[]
    for name in ("assets.json","redraws.json"):
        if (root/name).exists():
            rows.extend(read_json(root/name)["assets"])
    source=Path(cp["source_file"])
    require(sha(source)==cp["source_sha256"],"The source bytes have changed since confirmation.")
    key=sha256(json.dumps([cp["baseline_sha256"],ready,rows],sort_keys=True).encode()).hexdigest()[:20]
    out=root/f"editorial-{key}.pptx"
    report=root/f"editorial-{key}.json"
    plan={"settings":cp["settings"],"page_profiles":cp.get("page_profiles"),"pages":cp.get("design_constraints"),
          "visual_plan":cp.get("visual_plan"),"layout_change_pages":cp.get("layout_change_pages"),
          "requirements":cp.get("art_requirements",{}),"assets":rows, **cp.get("media_scope",{})}
    provider=ctx["queue"]
    with provider.locked(root/("editorial-"+key)):
        if report.exists() and out.exists():
            received=read_json(report)
            require(received.get("pptx_sha256")==sha(out),"The private composed artwork file changed.")
        else:
            import tempfile
            with tempfile.TemporaryDirectory(dir=root) as workspace:
                staged=Path(workspace)/"staged.pptx"
                verified=[{**a,"file":str((root/a["file"]).resolve())} for a in ready]
                received=runpy.run_path(str(HERE/"compose-refined.py"))["compose"](source,staged,plan,verified)
                received["pptx_sha256"]=sha(staged)
                # The same queue lock owns both files, making a retry after interruption safe.
                staged.replace(out)
                provider.write(report,received)
    placed=[(r["page"],s["name"]) for r in received["pages"] for s in r.get("art_slots",[]) if s.get("placed")]
    if not placed:
        return {}
    files["baseline_without_new_art"]=files["base"]
    files["base"]=str(out)
    return {"composition":received,"preplaced_assets":[{"page_number":n,"name":s} for n,s in placed],
            "remaining_assets":[a for a in ready if (a["page_number"],a["name"]) not in placed],
            "instruction":"Use files.base, which already contains the listed pictures and editable text. Place only remaining_assets and verify all approved assets."}


def next_work(root,args,ctx):
    cp=read_json(root/"work.json")
    require(sha(root/"base.pptx")==cp["baseline_sha256"],"Use the owned baseline bytes")
    base_paths=paths(root)
    all_ready=[]
    inflight = read_json(root/"native-requests.json") if (root/"native-requests.json").exists() else {}
    waiting = []
    for source, state in (("assets.json","attempts.json"),("redraws.json","redraw-attempts.json")):
        if not (root/source).exists():
            if source=="redraws.json" and cp["source_objects_for_review"] and not waiting:
                result={"action":"classify_source_objects","objects":cp["source_objects_for_review"],"files":base_paths}
                result["source_review_instruction"]=("對照原圖與它在頁面的用途。證據、截圖、圖表、識別標誌及指定保護內容使用 keep。"+
                    "精緻型把獨立物件、圖示或小插畫註記 source_use=decoration；連續場景與紀實照片用 source_use=continuous_photo。"+
                    "確認可重繪的裝飾以完整主體、透明外圍產生並查驗。未明時先沿用並完成其他頁。")
                if read_json(root/"assets.json").get("classify_for_cutout"):
                    result["transparent_instruction"]=result["source_review_instruction"]
                return result
            continue
        action=ctx["run"](["next",str(root/source),str(root/state)])
        if action["action"]=="generate_asset" and action["request_id"] in inflight:
            plan,slots=ctx["load_plan"](root/source)
            current=read_json(root/state)
            for slot in list(slots):
                request=ctx["attempt_id"](current,slot)
                if request not in inflight or slot in current.get("results",{}):
                    continue
                waiting.append(inflight[request])
                del slots[slot]
                for table in ("failures","reference_holds","awaiting_review"):
                    current.get(table,{}).pop(slot,None)
            if not slots:
                continue
            action=ctx["next_task"](plan,slots,current,root)
        if action["action"]=="assemble":
            all_ready.extend(action["assets"])
            continue
        body = native_action(action,root,vars(args)) if action["action"]=="generate_asset" else action
        return {**body,"files":{**base_paths,"active_plan":str(root/source),"active_state":str(root/state)}}
    if waiting:
        return {"action":"reconcile_native_image","requests":waiting,"files":base_paths,
                "reason":"Read the actual operation or files before reuse or re-dispatch."}
    layout_hint = ({"photo_layout": {"check":"photo-layout-variety.py check RUN_DIR CANDIDATE.pptx",
        "repair":"photo-layout-variety.py repair RUN_DIR CANDIDATE.pptx --out NEW.pptx [--focus FOCUS.json]",
        "instruction":"Choose the frame using the photographed subject and real text/evidence before placing each main image. For three eligible pages, keep at least two visibly different frame shapes."}}
        if cp.get("settings",{}).get("photo_layout_variety") is True else {})
    if (root/"refined-composition.json").is_file():
        layout_hint["composition"]=read_json(root/"refined-composition.json")
    layout_hint.update(prepared_art(root,cp,base_paths,all_ready,ctx))
    return {"action":"assemble",**layout_hint,"files":base_paths,
            "image_provenance_instruction":"When preserving the source text, put new AI picture credits in picture alt text or the delivery message. Keep visible credits already in the source or explicitly requested by the user.",
            "assets":all_ready,"job_id":cp["receipt"]["job_id"],
            "delivery":cp["delivery"],"editable_charts":cp["editable_charts"],"verified_complete":False}


def valid_spreadsheet(file, root):
    from openpyxl import load_workbook
    book=load_workbook(file,read_only=True,data_only=True)
    try:
        import math
        cp=read_json(root/"work.json")
        source=Path(cp["source_file"])
        require(sha(source)==cp["source_sha256"],"Source changed since production acceptance")
        source_deck=Presentation(source)
        expected=[]
        for slide in source_deck.slides:
            for shape in walk(slide.shapes):
                if not shape.has_chart:continue
                for series in shape.chart._chartSpace.xpath(".//c:ser"):
                    labels=series.xpath("./c:tx//c:v/text()")
                    vals=series.xpath("./c:val//c:pt/c:v/text()")
                    if labels and vals:expected.append((labels[0],list(map(float,vals))))
        rows=0;matched=set()
        for tab in book:
            data=list(tab.values)
            rows+=sum(any(v is not None for v in row) for row in data)
            for i,row in enumerate(data):
                for j,value in enumerate(row):
                    if not isinstance(value,str):continue
                    for h,(label,numbers) in enumerate(expected):
                        if "".join(value.split())!="".join(label.split()):continue
                        col=[r[j] if len(r)>j else None for r in data[i+1:i+1+len(numbers)]]
                        if len(col)==len(numbers) and all(isinstance(c,(int,float)) and not isinstance(c,bool)
                                and math.isclose(c,x,rel_tol=1e-11,abs_tol=1e-13) for c,x in zip(col,numbers)):
                            matched.add(h)
        require(rows>0,"The actual spreadsheet export is empty")
        require(len(matched)==len(expected),"The standalone workbook does not contain all original chart series")
        return {"sha256":sha(file),"nonempty_rows":rows,"matched_source_series":len(matched)}
    finally:
        book.close()


def probe_deck(root, candidate, ctx, opts):
    cp=read_json(root/"work.json")
    pending=next_work(root,opts,ctx)
    require(pending["action"]=="assemble","Image production or original-image review is still incomplete")
    produced=Presentation(candidate)
    source=Path(cp["source_file"])
    require(sha(source)==cp["source_sha256"],"The original source revision changed")
    original_deck=Presentation(source)
    require(len(produced.slides)==cp["pages"],"Incomplete final PowerPoint page count")
    def records(slide):
        text=[];art=[]
        for shape in walk(slide.shapes):
            if shape._element.xpath('.//a:fld[@type="slidenum"]|.//p:ph[@type="sldNum"]'):
                continue
            if shape.has_text_frame and shape.text.strip():
                text.append("".join(shape.text.split()))
            if shape.has_table:
                text.extend("".join(c.text.split()) for c in shape.table.iter_cells() if not c.is_spanned and c.text.strip())
            for b in shape._element.xpath(".//a:blip"):
                rid=b.get(qn("r:embed"))
                if not rid:continue
                crop=b.getparent().find(qn("a:srcRect"))
                off=tuple(int(crop.get(k,0)) if crop is not None else 0 for k in "ltrb")
                art.append((shape.name,sha256(slide.part.related_part(rid).blob).hexdigest(),off))
        return text,art
    base_plan=read_json(root/"assets.json")
    slots=[*base_plan["assets"],*base_plan.get("native_source_replacements",[])]
    if (root/"redraws.json").exists():slots.extend(read_json(root/"redraws.json")["assets"])
    plan={"settings":cp["settings"],"page_profiles":cp.get("page_profiles"),"pages":cp.get("design_constraints"),
          "visual_plan":cp.get("visual_plan"),"requirements":cp.get("art_requirements",{}),**cp.get("media_scope",{})}
    provenance=image_provenance.scan(original_deck,produced,dict(plan,mode=3),pending["assets"])
    if provenance["issues"]:
        return {"action":"repair_provenance","verified_complete":False,"provenance":provenance,
                "repair":"Use image_provenance.py repair SOURCE CANDIDATE --plan CONFIRMED_PLAN --out NEW.pptx, then assemble the cloud outputs from the corrected copy. Report any page attribution without a unique image in the delivery message."}
    source_reviews=read_json(root/"source-decisions.json") if (root/"source-decisions.json").exists() else []
    design_check=runpy.run_path(str(HERE/"refined-design.py"))["inspect"](
        source,candidate,{**plan,"layout_change_pages":cp.get("layout_change_pages")},[*source_reviews,*slots])
    decoration=design_check["decorations"]
    if decoration["issues"]:
        return {"action":"repair_decorations","decoration_redraws":decoration,"verified_complete":False,
                "refined_design":design_check,
                "repair":"Run refined-design.py repair SOURCE CANDIDATE --plan PLAN --run-dir RUN_DIR --out NEW.pptx. For an incomplete silhouette or complex backdrop, defer only its slot and regenerate the complete native transparent asset."}
    if design_check["layout"]["status"]=="repair":
        return {"action":"repair_layout","verified_complete":False,"refined_design":design_check,
                "repair":"Run refined-design.py repair SOURCE CANDIDATE --plan PLAN --run-dir RUN_DIR --out NEW.pptx. Use the corrected local copy to prepare Google Slides and recheck its actual export."}
    geometry=runpy.run_path(str(HERE/"protected-image-geometry.py"))["assessment"](source,candidate,slots)[0]
    require(geometry["status"]=="pass","Protected evidence geometry needs correction: "+
            json.dumps(geometry["issues"],ensure_ascii=False)+
            ". Run protected-image-geometry.py repair SOURCE.pptx CANDIDATE.pptx --out FIXED.pptx --run-dir RUN_DIR, then work-pptx again.")
    def appearance(slide):
        # Private baseline normalization may only remove page-number fields. That alone is not redesign.
        from lxml import etree
        parts=[]
        for shape in walk(slide.shapes):
            if shape._element.xpath('.//a:fld[@type="slidenum"]|.//p:ph[@type="sldNum"]'):continue
            visible=shape._element.xpath('./p:spPr|./p:style|./p:txBody|./p:blipFill|./p:graphicFrame|./a:graphic')
            parts.append((shape.shape_type,shape.left,shape.top,shape.width,shape.height,
                          tuple(etree.tostring(node,method="c14n",exclusive=True) for node in visible)))
        backs=slide._element.xpath('./p:cSld/p:bg')
        return (parts,[etree.tostring(node,method="c14n",exclusive=True) for node in backs])
    changed=False
    for n,(a,b) in enumerate(zip(original_deck.slides,produced.slides),1):
        if b._element.xpath('.//a:fld[@type="slidenum"]|.//p:ph[@type="sldNum"]'):
            raise ValueError(f"Final page {n} still has a slide-number field")
        require(a._element.get("show","1")==b._element.get("show","1"),f"Hidden-state change on page {n}")
        changed|=appearance(a)!=appearance(b)
        words,originals=records(a);written,images=records(b)
        if cp["settings"].get("text_policy","preserve") in ("preserve","verbatim","keep"):
            stream="".join(written)
            require(not (Counter("".join(words))-Counter(stream)) and all(t in stream for t in words),
                    f"Missing source text on final page {n}")
        redrawn=Counter(x["source_sha256"] for x in slots if x["page_number"]==n and (x["action"]=="redraw" or x.get("replaces_source")))
        actual=Counter((digest,off) for _,digest,off in images)
        for _,digest,off in originals:
            if redrawn[digest]:
                redrawn[digest]-=1
            else:
                require(actual[digest,off]>0,f"Missing or differently cropped source evidence on final page {n}")
                actual[digest,off]-=1
        for item in pending["assets"]:
            if item["page_number"]==n:
                require(any(name==item["name"] and dg==item["sha256"] for name,dg,_ in images),
                        f"Missing independent approved picture on final page {n}: {item['name']}")
    require(changed,"The source copy contains no evidence of editable layout work")
    variety=runpy.run_path(str(HERE/"photo-layout-variety.py"))["check"](produced,cp,slots)
    if variety["status"]=="repair_layout":
        return {"action":"repair_layout","photo_layout_variety":variety,"verified_complete":False,
                "repair":"Run photo-layout-variety.py repair using this run directory, then inspect both renders."}
    return {"action":"verified_local_pptx","pages":len(produced.slides),"pptx_sha256":sha(candidate),
            "assets":pending["assets"],"refined_design":design_check,"photo_layout_variety":variety,"protected_image_geometry":geometry,"decoration_redraws":decoration,"verified_complete":False}


def run(argv,ctx):
    cli=argparse.ArgumentParser()
    commands=cli.add_subparsers(dest="command",required=True)
    start_cmd=commands.add_parser("start-work")
    start_cmd.add_argument("received",type=Path);start_cmd.add_argument("source",type=Path)
    start_cmd.add_argument("run_dir",type=Path);start_cmd.add_argument("--base",type=Path);start_cmd.add_argument("--source-readback",type=Path)
    for key in ("work-next","work-event","work-classify","work-dispatch","work-pptx","work-xlsx"):
        cmd=commands.add_parser(key);cmd.add_argument("run_dir",type=Path)
        if key=="work-event":
            cmd.add_argument("event_type",choices=("record","defer","reject-preview","hold-reference","release-reference"))
            cmd.add_argument("event",type=Path)
        if key=="work-xlsx":cmd.add_argument("xlsx",type=Path)
        if key=="work-pptx":cmd.add_argument("pptx",type=Path)
        if key=="work-dispatch":cmd.add_argument("request_id")
        if key=="work-classify":cmd.add_argument("decisions",type=Path)
    for cmd in commands.choices.values():
        cmd.add_argument("--reference-key",choices=("referenced_image_paths","referenced_image_ids","num_last_images_to_include"),action="append")
        cmd.add_argument("--supports-transparent-background",action="store_true")
        cmd.add_argument("--registered-ref");cmd.add_argument("--last-shown-sha")
    args=cli.parse_args(argv)
    if args.command=="start-work":return start(args,ctx)
    if args.command=="work-classify":return classifications(args,ctx)
    root=args.run_dir.resolve()
    if args.command=="work-xlsx":return valid_spreadsheet(args.xlsx,root)
    if args.command=="work-pptx":return probe_deck(root,args.pptx,ctx,args)
    if args.command=="work-dispatch":
        with ctx["queue"].locked(root/"dispatch-lock"):
            act=next_work(root,args,ctx)
            if act["action"]!="call_native_image" or act["request_id"]!=args.request_id:
                return act
            path=root/"native-requests.json"
            prior=read_json(path) if path.exists() else {}
            prior[args.request_id]={"request_id":args.request_id,"page_number":act["asset"]["page_number"],
                                    "name":act["asset"]["name"],"state":"dispatch_intent"}
            ctx["queue"].write(path,prior,replace=path.exists())
            return {**act,"action":"invoke_native_image","dispatch_recorded":False}
    if args.command=="work-event":
        event=read_json(args.event)
        # Apply only to the originating slot. Duplicate operation results are handled by the durable queue.
        for pl,st in (("assets.json","attempts.json"),("redraws.json","redraw-attempts.json")):
            if not (root/pl).exists():continue
            _,slots=ctx["load_plan"](root/pl)
            key=ctx["queue"].digest([event.get("page_number"),event.get("name")])
            if key in slots:
                if args.event_type=="record" and read_json(root/pl).get("settings",{}).get("fresh_images_only"):
                    original=(args.event.resolve().parent/event["file"]).resolve()
                    digest=sha(original)
                    saved=read_json(root/st) if (root/st).exists() else {}
                    other_records=[value for other,value in saved.get("results",{}).items() if other!=key]
                    other_stage=root/("redraw-attempts.json" if st=="attempts.json" else "attempts.json")
                    if other_stage.exists():other_records.extend(read_json(other_stage).get("results",{}).values())
                    if any(v.get("sha256")==digest or v.get("generation_ref")==event.get("generation_ref") for v in other_records):
                        bad=dict(event,reason="A different independent slot already owns this image or operation")
                        tmp=root/("duplicate-"+event["request_id"]+".json")
                        save_once(tmp,bad,ctx["queue"])
                        ctx["run"](["defer",str(root/pl),str(root/st),str(tmp)])
                        break
                ctx["run"]([args.event_type,str(root/pl),str(root/st),str(args.event)])
                break
        else:raise ValueError("Event does not match a generated slot in this job")
    return next_work(root,args,ctx)
