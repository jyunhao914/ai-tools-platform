#!/usr/bin/env python3
"""Persist approved image-generation attempts for editable slides; return the next action."""
import hashlib
import importlib.util
import json
import os
import re
import sys
from pathlib import Path

from PIL import Image

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("studio_page_queue", Path(__file__).with_name("image-page-queue.py"))
queue = importlib.util.module_from_spec(spec)
spec.loader.exec_module(queue)
check_spec = importlib.util.spec_from_file_location("studio_generated_asset", Path(__file__).with_name("check-generated-asset.py"))
checker = importlib.util.module_from_spec(check_spec)
check_spec.loader.exec_module(checker)
require = queue.require
MAX_ATTEMPTS = 3


def load_plan(path):
    plan = queue.read(path)
    require(queue.nonblank(plan.get("job_id")) and queue.nonblank(plan.get("content_revision")),
            "Supply job_id and the approved content revision.")
    require(isinstance(plan.get("assets"), list), "List the approved assets still requiring generation.")
    tasks = {}
    for asset in plan["assets"]:
        n, name = asset["page_number"], asset["name"]
        require(type(n) is int and n > 0 and queue.nonblank(name) and queue.nonblank(asset.get("brief")),
                "Each generated asset needs a page number, stable layer name and approved brief.")
        require(asset["action"] in ("add", "redraw") and
                (asset["action"] != "redraw" or queue.nonblank(asset.get("reference"))),
                "Specify an approved add or redraw with its source reference.")
        key = queue.digest([n, name])
        require(key not in tasks, "Layer names must be unique within a page.")
        tasks[key] = asset
    test = plan.get("retry_test")
    if test is not None:
        require(isinstance(test, dict) and queue.digest([test.get("page"), test.get("name")]) in tasks,
                "Select an approved image slot for the requested retry test.")
    return plan, tasks


def image_digest(path):
    with Image.open(path) as image:
        require(image.format in ("PNG", "JPEG", "WEBP"), "Unsupported generated image format.")
        image.load()
    return hashlib.sha256(path.read_bytes()).hexdigest()


def attempt_id(state, key):
    return queue.digest([state["plan_sha256"], key, len(state["failures"].get(key, [])) + 1])

def trace(state, asset, status, attempt, reference):
    if "image_events" in state:
        state["image_events"].append({"page": asset["page_number"], "name": asset["name"],
                                      "attempt": attempt, "status": status, "reference": reference})


def refined(plan, asset):
    profile = plan.get("settings", {}).get("editable_profile") or plan.get("editable_profile")
    return plan.get("page_profiles", {}).get(str(asset["page_number"]), profile) == "refined"


def cutout_slot(plan, asset):
    return (refined(plan, asset) or asset.get("transparent_cutout") is True) and checker.requires_cutout(asset)


def generator_prompt(asset, settings, cutout=False):
    operational = re.compile(r"驗收|回補|重試|佇列|工作資料夾|Google (Slides|Drive|Sheets)|PowerPoint|PPTX|request[_ -]?id|job[_ -]?id|acceptance test|retry queue", re.I)
    parts = []
    for key in ("subject", "resolved_subject", "brief"):
        for part in re.split(r"[。；;\n]+", asset.get(key, "")):
            part = part.strip()
            if part and not operational.search(part) and part not in parts:
                parts.append(part)
    style = asset.get("resolved_media_style") or asset.get("media_style") or settings.get("media_style", "auto")
    medium = {"photorealistic": "單張寫實攝影。自然光影，真實材質。", "illustration": "獨立插畫。", "auto": ""}.get(style, style + "。")
    ending = "。只呈現這一個獨立畫面。"
    if cutout:
        ending += "輸出真正透明背景的 PNG；完整單一主體四周留透明空間，不要白底、外框、棋盤格或場景底板。"
    return medium + "。".join(parts) + ending if parts else None


def apply_event(command, event, event_dir, folder, plan, tasks, state):
    key = queue.digest([event["page_number"], event["name"]])
    require(key in tasks, "Unknown page or visual layer.")
    prior = state["failures"].get(key, [])
    request_id = event["request_id"]
    if command in ("record","reject-preview","defer"):
        for rejected in prior:
            if rejected["request_id"] == request_id and rejected.get("generation_ref") == event.get("generation_ref") and rejected.get("rejected"):
                return
    if command == "release-reference":
        held=state.get("reference_holds",{}).get(key)
        require(held and held["request_id"]==request_id and queue.nonblank(event.get("available_field")),
                "Resolve the original blocked request with a newly usable native reference method.")
        del state["reference_holds"][key]
        return
    if command == "hold-reference":
        require(request_id==attempt_id(state,key) and key not in state["results"] and
                queue.nonblank(event.get("reason")), "Identify this unsent attempt and its actual reference error.")
        state.setdefault("reference_holds",{})[key]={"request_id":request_id,"reason":event["reason"]}
        return
    preview = event.get("preview_review")
    if command=="reject-preview" or preview is not None:
        require(refined(plan,tasks[key]) and request_id==attempt_id(state,key) and len(prior)<MAX_ATTEMPTS
                and key not in state["results"] and isinstance(preview,dict)
                and queue.nonblank(event.get("generation_ref")) and preview.get("generation_ref")==event["generation_ref"]
                and preview.get("request_id")==request_id and queue.nonblank(preview.get("preview_ref"))
                and preview.get("whole_output") is True and queue.nonblank(preview.get("observation"))
                and preview.get("content") in ("wrong_subject","wrong_medium","wrong_composition","unusable"),
                "Rejection requires this exact request and an observed mismatch in its complete image card.")
        pending=state.get("awaiting_review",{}).get(key)
        require(not pending or pending["generation_ref"]==event["generation_ref"],"The card belongs to another image result.")
        state.get("awaiting_review",{}).pop(key,None)
        state.get("reference_holds",{}).pop(key,None)
        reason=preview["content"]+": "+preview["observation"]
        state["failures"].setdefault(key,[]).append({"request_id":request_id,"generation_ref":event["generation_ref"],
            "preview_ref":preview["preview_ref"],"rejected":True,"reason":reason})
        trace(state,tasks[key],"rejected",len(state["failures"][key]),event["generation_ref"])
        return
    if command == "defer":
        require(queue.nonblank(event.get("reason")), "State the generation error.")
        for failure in prior:
            if failure["request_id"] == request_id:
                require(failure["reason"] == event["reason"], "Conflicting repeated error.")
                return
    require(request_id == attempt_id(state, key) and len(prior) < MAX_ATTEMPTS, "Stale or exhausted attempt.")
    saved = state["results"].get(key)
    if command == "defer":
        require(saved is None, "This visual already has a verified image.")
        state.get("awaiting_review", {}).pop(key, None)
        trace(state, tasks[key], "failed", len(prior) + 1, request_id)
        state["failures"].setdefault(key, []).append({"request_id": request_id, "reason": event["reason"]})
        return
    require(queue.nonblank(event.get("generation_ref")) and queue.nonblank(event.get("file")),
            "A generation result requires its real tool reference and file.")
    file = (event_dir / event["file"]).resolve()
    cutout = cutout_slot(plan, tasks[key])
    record = {"request_id": request_id, "file": os.path.relpath(file, folder),
              "sha256": hashlib.sha256(file.read_bytes()).hexdigest() if cutout else image_digest(file), "generation_ref": event["generation_ref"]}
    if refined(plan, tasks[key]) or cutout:
        prior_candidate = state.get("awaiting_review", {}).get(key)
        if prior_candidate and (prior_candidate["generation_ref"] != record["generation_ref"] or prior_candidate["sha256"] != record["sha256"]):
            raise ValueError("Inspect the pending original image for this request.")
        evidence = dict(event.get("visual_review") or {})
        if tasks[key].get("placement_px"):
            evidence["placement_px"] = tasks[key]["placement_px"]
        review = checker.inspect(file, evidence, require_cutout=cutout)
        require(not evidence.get("generation_ref") or evidence["generation_ref"] == record["generation_ref"], "Review belongs to a different generator result.")
        if review["status"] == "unverified":
            require(saved is None, "This slot already has a verified result.")
            state.setdefault("awaiting_review", {})[key] = record
            return
        repeated = any(row.get("generation_ref") == record["generation_ref"] or row.get("sha256") == record["sha256"] for row in prior)
        reused = plan.get("settings", {}).get("fresh_images_only") and any(
            other != key and row["sha256"] == record["sha256"] for other, row in state["results"].items())
        input_copy = record["sha256"] in [h for h in (event.get("input_reference_sha256"), tasks[key].get("sha256")) if h]
        if review["status"] == "rejected" or repeated or reused or input_copy:
            require(saved is None, "This slot already has a verified result.")
            state.get("awaiting_review", {}).pop(key, None)
            failure = {**record, "rejected": True, "reason": review.get("reason", "Repeated artwork or unchanged input reference.")}
            state["failures"].setdefault(key, []).append(failure)
            trace(state, tasks[key], "rejected", len(state["failures"][key]), record["generation_ref"])
            return
        record["visual_review"] = review["visual_review"]
        state.get("awaiting_review", {}).pop(key, None)
    require(saved is None or saved == record, "Conflicting repeated success.")
    if saved is None:
        trace(state, tasks[key], "ready", len(prior) + 1, record["generation_ref"])
    state["results"][key] = record


def next_task(plan, tasks, state, root):
    for key, record in list(state["results"].items()):
        review = record.get("visual_review") or {}
        proof = review.get("cutout_check") or {}
        missing_cutout = cutout_slot(plan, tasks[key]) and not (proof.get("checker") == checker.cutouts.CHECKER
            and proof.get("status") == "ready" and proof.get("sha256") == record["sha256"])
        if missing_cutout or (refined(plan, tasks[key]) and not review):
            state.setdefault("awaiting_review", {})[key] = state["results"].pop(key)
    if len(state["results"]) == len(tasks):
        for key, record in list(state["results"].items()):
            try:
                if image_digest(root / record["file"]) == record["sha256"]:
                    continue
                reason = "Saved generated image has changed."
            except (OSError, ValueError) as exc:
                reason = str(exc)
            del state["results"][key]
            state["failures"].setdefault(key, []).append({"request_id": record["request_id"], "reason": reason})

    unfinished = [key for key in tasks if key not in state["results"]]
    if not unfinished:
        return {"action": "assemble", "assets": [
            {"page_number": a["page_number"], "name": a["name"], **state["results"][key]} for key, a in tasks.items()]}
    def order(key):
        return len(state["failures"].get(key, [])), tasks[key]["page_number"]
    pending = state.get("awaiting_review", {})
    held = state.get("reference_holds", {})
    eligible = [k for k in unfinished if k not in pending and k not in held and len(state["failures"].get(k, [])) < MAX_ATTEMPTS]
    if not eligible and pending:
        key = next(iter(pending))
        return {"action": "review_asset", "asset": tasks[key], **pending[key]}
    if not eligible:
        return {"action": "needs_attention", "assets":[
            {"page_number":tasks[k]["page_number"], "name":tasks[k]["name"], **r} for k,r in state["results"].items()],
            "missing": [
            {"page_number": tasks[k]["page_number"], "name": tasks[k]["name"], "reason": held[k]["reason"] if k in held else state["failures"][k][-1]["reason"]}
            for k in unfinished]}
    key = min(eligible,key=order)
    failures = state["failures"].get(key, [])
    task = {"action": "generate_asset", "asset": tasks[key], "request_id": attempt_id(state, key), "attempt": len(failures) + 1}
    cutout = cutout_slot(plan, tasks[key])
    if cutout:
        task["transparent_background"] = True
    task["prompt"] = generator_prompt(tasks[key], plan.get("settings", {}), cutout)
    if not task["prompt"]:
        return {"action":"needs_scene", "asset":tasks[key], "request_id":task["request_id"]}
    if tasks[key]["action"] == "redraw":
        task["reference_kind"] = "original"
    elif refined(plan,tasks[key]) and any(row.get("rejected") for row in failures):
        task["reference_kind"] = "guide"
    elif refined(plan,tasks[key]) and plan.get("settings",{}).get("image_input_scope")=="conversation":
        # The preparation helper receives the actual native reference fields, if any.
        task["reference_kind"] = "guide_if_supported"
    else:
        task["reference_kind"] = "none"
    if failures:
        task["last_failure"] = failures[-1]["reason"]
    return task


def run(args):
    require(len(args) in (3, 4), "Use next PLAN STATE or supply a slot event with its matching request_id.")
    command, plan_path, state_path = args[0], Path(args[1]).resolve(), Path(args[2]).resolve()
    require((command == "next" and len(args) == 3) or (command in ("record","defer","reject-preview","hold-reference","release-reference") and len(args) == 4), "Invalid command.")
    require(plan_path != state_path, "Plan and state need distinct paths.")
    plan, tasks = load_plan(plan_path)
    signature = queue.digest(plan)
    with queue.locked(state_path):
        fresh = not state_path.exists()
        state = {"plan_sha256": signature, "failures": {}, "results": {}} if fresh else queue.read(state_path)
        require(state.get("plan_sha256") == signature, "State belongs to another job, revision or asset plan.")
        test = plan.get("retry_test")
        if test:
            state.setdefault("image_events", [])
        if command != "next":
            event_path = Path(args[3]).resolve()
            require(event_path not in (plan_path, state_path), "Use a separate event path.")
            apply_event(command, queue.read(event_path), event_path.parent, state_path.parent, plan, tasks, state)
        action = next_task(plan, tasks, state, state_path.parent)
        if test and action["action"] == "generate_asset" and action["attempt"] == 1:
            asset = action["asset"]
            if (asset["page_number"], asset["name"]) == (test["page"], test["name"]):
                key = queue.digest([test["page"], test["name"]])
                request_id = action["request_id"]
                state["failures"][key] = [{"request_id": request_id,
                    "reason": "Controlled retry test: skipped provider dispatch once."}]
                trace(state, asset, "injected_not_started", 1, request_id)
                action = next_task(plan, tasks, state, state_path.parent)
        queue.write(state_path, state, replace=not fresh)
        return action


if __name__ == "__main__":
    try:
        args = sys.argv[1:]
        if args and args[0] in ("start-work","work-next","work-event","work-classify","work-dispatch","work-pptx","work-xlsx"):
            import runpy
            module = runpy.run_path(str(Path(__file__).with_name("work-editable-progress.py")))
            result = module["run"](args, globals())
        else:
            result = run(args)
        print(json.dumps(result, ensure_ascii=False))
    except (OSError, ValueError, TypeError, KeyError, queue.gate.GateError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False))
        sys.exit(1)
