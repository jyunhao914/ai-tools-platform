#!/usr/bin/env python3
"""Apply approved visual layers to a PPTX. See references/editable-layout.md.

Usage: python3 editable_visuals.py INPUT.pptx VISUALS.json OUTPUT.pptx
The request's pages contain page_number (1-based) and layers in drawing order.
Slide boxes use inches. Native vector parts use a local 0–100 grid.
"""
import argparse
from copy import deepcopy
from functools import lru_cache
import hashlib
import importlib.util
from io import BytesIO
import json
from math import isfinite
import os
from pathlib import Path
import re
import tempfile

from PIL import Image, ImageOps
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE_TYPE, MSO_SHAPE
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt


@lru_cache(maxsize=1)
def _cutout_check():
    path = Path(__file__).with_name("check-editable-deck.py")
    spec = importlib.util.spec_from_file_location("studio_editable_check", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.cutout_alpha


@lru_cache(maxsize=1)
def _focal_module():
    path = Path(__file__).with_name("refined-photo-layout.py")
    spec = importlib.util.spec_from_file_location("studio_refined_photo_layout", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@lru_cache(maxsize=1)
def _cutout_rules():
    path = Path(__file__).with_name("check-cutout.py")
    spec = importlib.util.spec_from_file_location("studio_cutout_bytes", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_clean_cutout(data):
    result = _cutout_rules().inspect_bytes(data)
    if result["status"] != "ready":
        raise ValueError("Cutout is not ready: " + ", ".join(result["reasons"]))


def _keys(spec, allowed):
    if not isinstance(spec, dict) or spec.keys() - set(allowed):
        raise ValueError(f"Expected an object with only these fields: {', '.join(sorted(allowed))}")


def _profile(value):
    if value is not None and value not in ("quick", "refined"):
        raise ValueError("editable_profile must be quick or refined.")
    return value


def select_visual_layers(layers, editable_profile=None, *, auto_visuals=False, report=None):
    """Select authorized candidates before making assets or creating objects.

    The planner supplies actual user exceptions and identifies which approved text
    needs explanation. Merely choosing a profile never authorizes an add/redraw.
    Refined raster icons and subject illustrations use the cutout validation path.
    """
    _profile(editable_profile)
    if type(auto_visuals) is not bool:
        raise ValueError("auto_visuals must be a boolean page-level authorization.")
    if not isinstance(layers, list):
        raise ValueError("layers must be a list.")
    if editable_profile == "refined":
        return [dict(layer, kind="cutout") if layer.get("kind") == "picture"
                and layer.get("action") in ("add","redraw") and _cutout_rules().requires_cutout(layer) else layer
                for layer in layers]
    if editable_profile != "quick":
        return list(layers)

    selected = []
    omitted_positions = {}
    for layer in layers:
        name = layer.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("Each layer requires a nonempty name.")
        kind, action = layer.get("kind"), layer.get("action")
        if kind not in ("background", "picture", "cutout", "vector") or action not in ("add", "redraw"):
            raise ValueError("Profiles apply only to approved visual add/redraw actions.")

        # A named omitted redraw leaves the original picture available as an anchor.
        # For a never-created addition, its former insertion point can anchor a
        # surviving layer. Resolve in creation order, as with regular named positions.
        position = layer.get("position")
        if isinstance(position, dict) and len(position) == 1:
            side, anchor = next(iter(position.items()))
            if side in ("before", "after") and isinstance(anchor, str) and anchor in omitted_positions:
                source_name, fallback = omitted_positions[anchor]
                position = {side: source_name} if source_name else fallback
                layer = dict(layer, position=position)

        explicit = layer.get("explicit_request")
        explanation = layer.get("explanation_for")
        flat_color = (action == "add" and kind == "background" and "file" not in layer
                      and "color" in layer and layer.get("position", "back") == "back")
        necessary = (auto_visuals and action == "add" and kind in ("picture", "cutout", "vector")
                     and isinstance(explanation, str) and bool(explanation.strip()))
        if flat_color or necessary or (isinstance(explicit, str) and explicit.strip()):
            selected.append(layer)
            continue

        source = layer.get("replace") if action == "redraw" else None
        source_name = source.get("name") if isinstance(source, dict) else None
        omitted_positions[name] = (source_name, position or ("back" if kind == "background" else "front"))
        if report is not None:
            report.append({"name": name, "reason": "quick_profile_omits_unspecified_visual"})
    return selected


def _number(value):
    if type(value) not in (int, float) or not isfinite(value):
        raise ValueError("Coordinates and stroke widths must be finite numbers.")
    return value


def _box(values, local=False):
    if not isinstance(values, (list, tuple)) or len(values) != 4:
        raise ValueError("A box requires [x, y, width, height].")
    x, y, width, height = map(_number, values)
    if width <= 0 or height <= 0:
        raise ValueError("A box must have positive width and height.")
    if local and (min(x, y) < 0 or max(x + width, y + height) > 100):
        raise ValueError("Vector primitive must fit within the 0–100 grid.")
    return x, y, width, height


def _color(value):
    if not isinstance(value, str) or not re.fullmatch("[a-fA-F0-9]{6}", value):
        raise ValueError("Use six hexadecimal digits for a color.")
    return RGBColor.from_string(value.upper())


def _node(tag, **attrs):
    node = OxmlElement("a:" + tag)
    for key, value in attrs.items():
        node.set(key, str(value))
    return node


def _path(commands):
    if not isinstance(commands, list) or not commands or not commands[0] or commands[0][0] != "M":
        raise ValueError("A vector path must begin with M.")
    ops = {"M": ("moveTo", 2), "L": ("lnTo", 2), "Q": ("quadBezTo", 4),
           "C": ("cubicBezTo", 6), "Z": ("close", 0)}
    geometry = _node("custGeom")
    for tag in ("avLst", "gdLst", "ahLst", "cxnLst"):
        geometry.append(_node(tag))
    geometry.append(_node("rect", l="l", t="t", r="r", b="b"))
    paths = _node("pathLst")
    path = _node("path", w=100000, h=100000)
    geometry.append(paths)
    paths.append(path)
    drew = False
    for command in commands:
        if not isinstance(command, list) or not command or command[0] not in ops:
            raise ValueError("Use M, L, Q, C or Z for vector paths.")
        tag, count = ops[command[0]]
        if len(command) != count + 1:
            raise ValueError(f"{command[0]} expects {count} coordinates.")
        points = [_number(v) for v in command[1:]]
        if any(v < 0 or v > 100 for v in points):
            raise ValueError("Vector path coordinates must be in the 0–100 grid.")
        element = _node(tag)
        for x, y in zip(points[::2], points[1::2]):
            element.append(_node("pt", x=round(x * 1000), y=round(y * 1000)))
        path.append(element)
        drew |= command[0] in ("L", "Q", "C")
    if not drew:
        raise ValueError("A path requires a line or curve.")
    return geometry


def _part(shapes, part, frame):
    kind = part["type"]
    style = {"type", "fill", "stroke", "width_pt"}
    presets = {"rect": MSO_SHAPE.RECTANGLE, "roundRect": MSO_SHAPE.ROUNDED_RECTANGLE,
               "ellipse": MSO_SHAPE.OVAL}
    x, y, width, height = frame
    if kind == "path":
        _keys(part, style | {"commands"})
        geometry = _path(part["commands"])
        shape = shapes.add_shape(MSO_SHAPE.RECTANGLE, *map(Inches, frame))
        props = shape._element.spPr
        props.replace(props.find(qn("a:prstGeom")), geometry)
    elif kind in presets:
        _keys(part, style | {"box"})
        px, py, pw, ph = _box(part["box"], local=True)
        shape = shapes.add_shape(presets[kind], Inches(x + px * width / 100),
                                 Inches(y + py * height / 100),
                                 Inches(pw * width / 100), Inches(ph * height / 100))
    else:
        raise ValueError(f"Unsupported native vector primitive: {kind!r}.")
    fill = part.get("fill")
    stroke = part.get("stroke", None if fill else "24343A")
    if not fill and not stroke:
        raise ValueError("Vector parts require a visible fill or stroke.")
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = _color(fill)
    else:
        shape.fill.background()
    if stroke:
        width_pt = _number(part.get("width_pt", 1.5))
        if width_pt <= 0:
            raise ValueError("width_pt must be positive.")
        shape.line.color.rgb = _color(stroke)
        shape.line.width = Pt(width_pt)
        shape._element.spPr.get_or_add_ln().set("cap", "rnd")
    else:
        shape.line.fill.background()
    shape.shadow.inherit = False
    for effect in shape._element.xpath("./p:style/a:effectRef"):
        effect.set("idx", "0")
    return shape


def image_asset(layer, root, orient):
    relative = Path(layer["file"])
    filename = (root / relative).resolve()
    if relative.is_absolute() or not filename.is_relative_to(root):
        raise ValueError("Image files must be inside the plan's asset directory.")
    data = filename.read_bytes()
    source_sha = hashlib.sha256(data).hexdigest()
    with Image.open(BytesIO(data)) as image:
        if orient and image.getexif().get(274, 1) != 1:
            with ImageOps.exif_transpose(image) as upright:
                output = BytesIO()
                upright.save(output,format="PNG")
                return output.getvalue(), upright.size, source_sha
        return data, image.size, source_sha


def photo_geometry(layer, frame, size, profile, canvas, protected=(), *, data=None, recover=True, occupied=()):
    fit = layer.get("fit","cover" if layer["kind"]=="background" else "contain")
    check_edges = layer["kind"] == "cutout" and data is not None
    if profile != "refined" or ("photo_layout" not in layer and not (check_edges and fit=="cover")):
        return None
    if layer.get("role") in {"evidence","screenshot","data_chart","protected"}:
        raise ValueError("A protected source object must keep its original framing.")
    planner = _focal_module()
    options = layer.get("photo_layout", {})
    try:
        geometry = planner.layout_photo(size, frame, canvas, options, fit=fit, extra_zones=protected)
        if check_edges and any(geometry["crop"].values()):
            check = _cutout_rules().inspect_bytes(cropped_png(data, geometry["crop"]))
            if check["status"] != "ready":
                raise planner.NoPhotoFit("The proposed frame clips the original transparent silhouette.")
        return geometry
    except planner.NoPhotoFit:
        if not recover:
            raise
        return planner.recover_photo(size, frame, canvas, options,
                                     extra_zones=protected, occupied=occupied)


def cropped_png(data, crop):
    """Keep the full source separately; this is a single independent display layer."""
    with Image.open(BytesIO(data)) as original:
        if not any(crop.values()) and original.format=="PNG":
            return data
        image=original.convert("RGBA" if "A" in original.getbands() or "transparency" in original.info else "RGB")
        w,h=image.size
        box=(crop["left"]*w,crop["top"]*h,(1-crop["right"])*w,(1-crop["bottom"])*h)
        size=(max(1,round(box[2]-box[0])),max(1,round(box[3]-box[1])))
        output=BytesIO()
        image.resize(size,Image.Resampling.LANCZOS,box=box).save(output,format="PNG")
        return output.getvalue()


def _image(shapes, layer, frame, root, profile, canvas, protected, recover, occupied):
    data, size, _ = image_asset(layer, root, profile=="refined" and "photo_layout" in layer)
    if profile=="refined" and layer["kind"]=="cutout":
        require_clean_cutout(data)
    fit = layer.get("fit", "cover" if layer["kind"] == "background" else "contain")
    x, y, w, h = frame
    iw, ih = size
    placement = photo_geometry(layer, frame, size, profile, canvas, protected, data=data, recover=recover, occupied=occupied)
    if placement:
        x,y,w,h = placement["box"]
    elif fit == "contain":
        ratio = min(w / iw, h / ih)
        nw, nh = ratio * iw, ratio * ih
        x, y, w, h = x + (w - nw) / 2, y + (h - nh) / 2, nw, nh
    elif fit != "cover":
        raise ValueError("fit must be contain or cover.")
    picture = shapes.add_picture(BytesIO(data), *map(Inches, (x, y, w, h)))
    if placement:
        for side, offset in placement["crop"].items():
            setattr(picture,"crop_"+side,offset)
    elif fit == "cover":
        if iw * h > ih * w:
            picture.crop_left = picture.crop_right = (1 - w * ih / (h * iw)) / 2
        else:
            picture.crop_top = picture.crop_bottom = (1 - h * iw / (w * ih)) / 2
    if layer["kind"] == "cutout" and _cutout_check()(picture) is None:
        raise ValueError(f"{layer['name']}: cutout needs a PNG with visible content and real transparency after cropping.")
    return picture


def _make(shapes, layer, root, occupied, profile, canvas, protected, recover, fallback_zones):
    kind = layer["kind"]
    frame = _box(layer["box"])
    base = {"name", "action", "kind", "box", "position", "replace", "explicit_request", "explanation_for",
            "role", "transparent_cutout"}
    if kind == "background" and "color" in layer:
        _keys(layer, base | {"color"})
        shape = _part(shapes, {"type": "rect", "box": [0, 0, 100, 100], "fill": layer["color"]}, frame)
    elif kind in ("picture", "background", "cutout"):
        _keys(layer, base | {"file", "fit","photo_layout"})
        shape = _image(shapes, layer, frame, root, profile, canvas, protected, recover, fallback_zones)
    elif kind == "vector":
        _keys(layer, base | {"parts"})
        parts = layer["parts"]
        if not isinstance(parts, list) or not parts:
            raise ValueError("A vector needs at least one native part.")
        if len(parts) == 1:
            shape = _part(shapes, parts[0], frame)
        else:
            shape = shapes.add_group_shape()
            for index, part in enumerate(parts, 1):
                name = f"{layer['name']}/{index}"
                if name in occupied:
                    raise ValueError(f"Vector part name already exists: {name!r}.")
                _part(shape.shapes, part, frame).name = name
    else:
        raise ValueError(f"Unsupported visual kind: {kind!r}.")
    shape.name = layer["name"]
    return shape


def _unique(collection, name):
    hits = [s for s in collection if s.name == name]
    if len(hits) != 1:
        raise ValueError(f"Expected one top-level object named {name!r}; found {len(hits)}.")
    return hits[0]


def _target(layer, original, tree):
    if layer.get("action") == "add" and "replace" not in layer:
        return None
    if layer.get("action") != "redraw" or not isinstance(layer.get("replace"), dict):
        raise ValueError("Use action add or authorize redraw with the original picture name and SHA-256.")
    expected = layer["replace"]
    _keys(expected, {"name", "source_sha256"})
    source = _unique(original, expected["name"])
    if (source.shape_type != MSO_SHAPE_TYPE.PICTURE or source._element.getparent() is not tree
            or source.is_placeholder):
        raise ValueError("Only a current, independent original picture can be replaced.")
    if hashlib.sha256(source.image.blob).hexdigest() != expected["source_sha256"].lower():
        raise ValueError("Redraw source does not match the approved embedded picture.")
    return source


def _place(shapes, shape, position, source, backmost):
    element = shape._element
    if position is None and source is not None:
        source._element.addprevious(element)
    elif position == "back":
        if backmost is not None and backmost.getparent() is shapes._spTree:
            backmost.addnext(element)
        else:
            first = next((s for s in shapes if s._element is not element), None)
            if first is not None:
                first._element.addprevious(element)
        return element
    elif isinstance(position, dict) and list(position) in (["before"], ["after"]):
        side, name = next(iter(position.items()))
        anchor = _unique((s for s in shapes if s._element is not element), name)
        if side == "before":
            anchor._element.addprevious(element)
        else:
            anchor._element.addnext(element)
    elif position != "front":
        raise ValueError("position must be back, front, or an object containing before or after.")
    return backmost


def apply_visuals(slide, layers, asset_root, *, editable_profile=None, auto_visuals=False, report=None,
                  protected_objects=(), recover=True, deferred=None):
    """Apply resolved add/redraw decisions together. Return the added top-level shapes.

    If a layer fails, the original shape tree and its existing relationships survive.
    A repeated request with conflicting existing object names raises ValueError.
    """
    skipped = []
    layers = select_visual_layers(layers, editable_profile, auto_visuals=auto_visuals, report=skipped)
    root = Path(asset_root).resolve()
    shapes = slide.shapes
    tree = shapes._spTree
    originals = list(shapes)
    if not isinstance(protected_objects,(list,tuple)) or any(not isinstance(n,str) for n in protected_objects):
        raise ValueError("protected_objects must list existing top-level object names.")
    reserved_names = set(protected_objects)
    for name in reserved_names:
        _unique(originals,name)
    def planned_photo(layer):
        return "photo_layout" in layer or layer.get("kind")=="cutout" and layer.get("fit")=="cover"
    needs_geometry = editable_profile=="refined" and any(planned_photo(layer) for layer in layers)
    reserved = [{"name":s.name,"box":[n/914400 for n in (s.left,s.top,s.width,s.height)]}
                for s in originals if needs_geometry and (s.name in reserved_names or s.has_chart or s.has_table)]
    deck = slide.part.package.presentation_part.presentation
    canvas = (deck.slide_width/914400,deck.slide_height/914400)
    children = list(tree)
    original_rels = set(slide.part.rels)
    # Own a consistent allocator during group construction, also for turbo-mode callers.
    turbo = shapes.turbo_add_enabled
    shapes.turbo_add_enabled = False
    obsolete_images = set()
    added = []
    backmost = None
    delayed_names = set()
    try:
        for layer in layers:
            name = layer["name"]
            if not isinstance(name, str) or not name.strip():
                raise ValueError("Each layer requires a nonempty name.")
            source = _target(layer, originals, tree)
            if source is not None and source.name in reserved_names:
                raise ValueError("A protected object cannot be redrawn: "+source.name)
            # cNvPr also includes the names of nested objects.
            occupied = [n.get("name") for n in tree.xpath(".//p:cNvPr")]
            if source is not None:
                occupied.remove(source.name)
            if name in occupied:
                raise ValueError(f"An object with this name already exists: {name!r}.")
            position = layer.get("position", None if source is not None else
                                 ("back" if layer["kind"] == "background" else "front"))
            # After an infeasible crop, continue other objects and pages first. Keep
            # named dependent drawings with their anchor for the same retry.
            if isinstance(position,dict) and any(anchor in delayed_names for anchor in position.values()):
                deferred.append((layer, "Awaiting the planned drawing anchor."))
                delayed_names.add(name)
                continue
            fallback_zones = []
            if recover and needs_geometry and planned_photo(layer):
                for existing in shapes:
                    if source is not None and source._element is existing._element:
                        continue
                    if (existing.shape_type in (MSO_SHAPE_TYPE.PICTURE, MSO_SHAPE_TYPE.GROUP)
                            or (existing.has_text_frame and existing.text.strip())):
                        fallback_zones.append({"name":existing.name, "box":[n/914400 for n in
                            (existing.left,existing.top,existing.width,existing.height)]})
            try:
                shape = _make(shapes, layer, root, set(occupied), editable_profile, canvas, reserved,
                              recover, fallback_zones)
            except _focal_module().NoPhotoFit as error:
                if deferred is None:
                    raise
                deferred.append((layer, str(error)))
                delayed_names.add(name)
                continue
            backmost = _place(shapes, shape, position, source, backmost)
            if source is not None:
                # Keep the source shape id (animation/connector target) and nonvisual metadata.
                old_meta = source._element.xpath("./*/p:cNvPr")[0]
                new_meta = shape._element.xpath("./*/p:cNvPr")[0]
                retained = deepcopy(old_meta)
                retained.set("name", name)
                new_meta.getparent().replace(new_meta, retained)
                obsolete_images.update(source._element.xpath(".//a:blip/@r:embed"))
                tree.remove(source._element)
            added.append(shape)
    except Exception:
        for child in list(tree):
            tree.remove(child)
        for child in children:
            tree.append(child)
        for rid in set(slide.part.rels) - original_rels:
            slide.part.drop_rel(rid)
        raise
    finally:
        shapes.turbo_add_enabled = turbo
    # python-pptx reference counting only checks r:id; pictures use r:embed.
    live_refs = set(slide._element.xpath(".//@r:embed | .//@r:link | .//@r:id"))
    for rid in obsolete_images - live_refs:
        slide.part.drop_rel(rid)
    if report is not None:
        report.extend(skipped)
    return added


def compose(source, request, destination):
    """Write a complete package to a sibling temporary file, then replace the destination."""
    source, request, destination = map(Path, (source, request, destination))
    for protected in (source, request):
        if destination.resolve() == protected.resolve() or (destination.exists() and destination.samefile(protected)):
            raise ValueError("The output path must be distinct from the input deck and plan.")
    plan = json.loads(request.read_text(encoding="utf-8"))
    _keys(plan, {"pages", "editable_profile"})
    profile = _profile(plan.get("editable_profile"))
    skipped = []
    if not isinstance(plan["pages"], list):
        raise ValueError("pages must be a list.")
    deck = Presentation(source)
    seen = set()
    revisit = []
    for page in plan["pages"]:
        _keys(page, {"page_number", "layers", "editable_profile", "auto_visuals","protected_objects"})
        number = page["page_number"]
        if type(number) != int or not 1 <= number <= len(deck.slides) or number in seen:
            raise ValueError(f"Invalid or duplicate page_number: {number!r}.")
        seen.add(number)
        page_report = []
        deferred = []
        apply_visuals(deck.slides[number - 1], page["layers"], request.parent,
                      editable_profile=_profile(page.get("editable_profile")) or profile,
                      auto_visuals=page.get("auto_visuals", False), report=page_report,
                      protected_objects=page.get("protected_objects",[]), recover=False, deferred=deferred)
        skipped.extend(dict(item, page_number=number) for item in page_report)
        if deferred:
            revisit.append((number,page,deferred))
    pending = []
    for number, page, deferred in revisit:
        remaining = []
        apply_visuals(deck.slides[number-1], [layer for layer, _ in deferred], request.parent,
                      editable_profile=_profile(page.get("editable_profile")) or profile,
                      auto_visuals=page.get("auto_visuals",False), protected_objects=page.get("protected_objects",[]),
                      recover=True, deferred=remaining)
        pending.extend({"page_number":number, "name":layer["name"], "reason":reason} for layer,reason in remaining)
    with tempfile.NamedTemporaryFile(dir=destination.parent, suffix=".pptx", delete=False) as handle:
        tmp = Path(handle.name)
    try:
        deck.save(tmp)
        os.replace(tmp, destination)
    finally:
        tmp.unlink(missing_ok=True)
    report = {"skipped": skipped}
    if pending:
        report.update(status="needs_layout", pending_layout=pending)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("plan")
    parser.add_argument("output")
    args = parser.parse_args()
    try:
        print(json.dumps(compose(args.source, args.plan, args.output), ensure_ascii=False))
    except Exception as exc:
        parser.exit(1, f"editable_visuals: {exc}\n")
