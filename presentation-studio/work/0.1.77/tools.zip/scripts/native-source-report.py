"""Bind the completed slide-by-slide checks to the actual original, renders and native revision.

The host supplies completed structural and visual reviews, including any unresolved
issues. Users do not enter checks or hashes. No image or slide text goes in the packet.
"""
import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile
import fitz

P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def emu(size):
    factor = {"PT": 12700, "EMU": 1}.get(size["unit"])
    if factor is None:
        raise ValueError("Read the native slide dimensions including their units.")
    return round(factor * float(size["magnitude"]))


def build(original, original_pdf, native_pdf, native, review, original_ref, import_source_id):
    with zipfile.ZipFile(original) as package:
        presentation = ET.fromstring(package.read("ppt/presentation.xml"))
        original_count = len(presentation.findall(P+"sldIdLst/"+P+"sldId"))
        s = presentation.find(P+"sldSz")
        original_size = tuple(int(s.attrib[k]) for k in ("cx","cy"))
    slides = native["slides"]
    file_id, revision = native["presentationId"], native["revisionId"]
    if not file_id or not revision or not original_ref or not import_source_id or not original_count:
        raise ValueError("The native readback, source identity or import input is missing.")
    source_sha = file_digest(original)
    expected = {"original_sha256":source_sha, "native_file_id":file_id, "native_revision":revision,
                "source_pdf_sha256":file_digest(original_pdf), "native_pdf_sha256":file_digest(native_pdf)}
    if any(review.get(k)!=v for k,v in expected.items()):
        raise ValueError("Use the review made against this exact source, native revision and pair of renders.")
    size = tuple(emu(native["pageSize"][k]) for k in ("width","height"))
    if any(abs(a-b)>127 for a,b in zip(size,original_size)):
        raise ValueError("Native slide dimensions differ from the source.")
    if len(slides)!=original_count or len(review.get("pages",[]))!=original_count:
        raise ValueError("Original, native slide count or review coverage differs.")
    out = {**expected,"original_ref":original_ref,"import_source_id":import_source_id,
           "source_page_count":original_count,"pages":[]}
    with fitz.open(original_pdf) as src, fitz.open(native_pdf) as dest:
        if len(src)!=original_count or len(dest)!=original_count:
            raise ValueError("Render every page for this comparison, including hidden slides.")
        for i,(a,b,page,checked) in enumerate(zip(src,dest,slides,review["pages"]),1):
            if checked.get("source_page")!=i or checked.get("native_page_id")!=page["objectId"]:
                raise ValueError("The review does not refer to this exact page sequence.")
            if not isinstance(checked.get("unresolved"),list):
                raise ValueError("Record each page's unresolved checks.")
            # Only counts and results travel. Keep details of sensitive objects in the private review.
            problems = len(checked["unresolved"])
            out["pages"].append({"source_page":i,"native_page_id":page["objectId"],
                "structure_verified":checked.get("structure_verified") is True,
                "protected_visuals_verified":checked.get("protected_visuals_verified") is True,
                "unresolved":[] if not problems else [f"{problems} unresolved checks in the private review"],
                "source_render_sha256":digest(a.get_pixmap(alpha=False).tobytes("png")),
                "native_render_sha256":digest(b.get_pixmap(alpha=False).tobytes("png"))})
    return out


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    for arg in ("original","original_pdf","native_pdf","native_readback","completed_review","output"):
        parser.add_argument(arg,type=Path)
    parser.add_argument("--original-ref",required=True)
    parser.add_argument("--import-source-id",required=True)
    a=parser.parse_args()
    result=build(a.original,a.original_pdf,a.native_pdf,json.loads(a.native_readback.read_bytes()),
                 json.loads(a.completed_review.read_bytes()),a.original_ref,a.import_source_id)
    data=json.dumps(result,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
    a.output.write_bytes(data)
    print(json.dumps({"file":str(a.output),"pages":result["source_page_count"],"verification_sha256":digest(data)}))
