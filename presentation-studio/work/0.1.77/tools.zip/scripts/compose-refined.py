"""Compose a private editable source copy. The source, notes and media parts stay intact."""
import argparse
import json
import math
import os
import re
import tempfile
import unicodedata
from copy import deepcopy
from collections import Counter
from lxml import etree
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE_TYPE as Shape, MSO_SHAPE, PP_PLACEHOLDER
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Pt

from slide_numbers import strip_slide_numbers
from editorial_art import can_use_art, icon_slot, observed_activity, permitted_assets, place_art, photo_tones, white_text_on_photo, low_key, contrast_veil

INK = "172F2D"
GREEN = "14574F"
PAPER = "F7F5EE"
WHITE = "FFFFFF"
MUTED = "45645F"
LINE = "B6C8BF"
PALE = "D5E8C7"
ACCENT = "B35E36"
TINT = "EEE4D4"


def wide_length(text):
    return sum(1 if unicodedata.east_asian_width(c) in ("W", "F") else
               .32 if c.isspace() else .63 if c.isupper() else .55 for c in text)


def rgb(color):
    return RGBColor.from_string(color)


def blend(base, target, proportion):
    rgb1=bytes.fromhex(base)
    rgb2=bytes.fromhex(target)
    return "".join(f"{round(a*(1-proportion)+b*proportion):02X}" for a,b in zip(rgb1,rgb2))


def theme_for(slide,scene_colors=None):
    master=slide.slide_layout.slide_master
    theme=etree.fromstring(master.part.part_related_by(RT.THEME).blob)
    accent=theme.find(".//"+qn("a:accent1"))
    key=accent[0].get("val") if accent is not None and len(accent) else None
    if not key or not re.fullmatch("[0-9A-Fa-f]{6}",key):
        key=GREEN
    # Prefer a recurring authored ink over the stock Office palette, including when a deck
    # uses its institution's colors directly on shapes rather than editing the master.
    explicit=Counter()
    for e in slide.part.package.presentation_part.presentation.slides:
        for item in e.shapes:
            if item.has_text_frame and item.text.strip():
                for node in item._element.xpath("./p:spPr/a:solidFill/a:srgbClr|./p:txBody/a:p/a:r/a:rPr/a:solidFill/a:srgbClr"):
                    col=node.get("val","")
                    if re.fullmatch("[0-9a-fA-F]{6}",col):
                        vs=bytes.fromhex(col)
                        if max(vs)-min(vs)>45 and sum(vs)/3<195:
                            explicit[col.upper()]+=1
    if explicit and explicit.most_common(1)[0][1]>=3 and key in ("5B9BD5","4F81BD","156082","4472C4"):
        key=explicit.most_common(1)[0][0]
    # Keep source hue in a readable editorial ink even for saturated legacy hyperlink-like blues.
    channels=bytes.fromhex(key)
    strength=(max(channels)-min(channels))/255
    dark=blend(key,"213139",.60 if strength>.75 else .26)
    def luminance(color):
        v=[c/255 for c in bytes.fromhex(color)]
        v=[c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in v]
        return sum(a*b for a,b in zip(v,(.2126,.7152,.0722)))
    while luminance(dark)>.13:
        dark=blend(dark,"111816",.12)
    palette={GREEN:dark,INK:blend(dark,"18201E",.62),MUTED:blend(dark,"414648",.46),
             LINE:blend(dark,WHITE,.70),PAPER:blend(key,"FBFAF6",.965),PALE:blend(key,WHITE,.86),
             "7CA59A":blend(dark,WHITE,.52),WHITE:WHITE}
    secondary=theme.find(".//"+qn("a:accent2"))
    alt=secondary[0].get("val") if secondary is not None and len(secondary) else None
    alt=alt if alt and re.fullmatch("[0-9A-Fa-f]{6}",alt) else ACCENT
    palette[ACCENT]=blend(alt,"543C28",.33)
    palette[TINT]=blend(alt,"F5F0E6",.85)
    # Stock Office themes carry no bespoke brand signal. Use their secondary as a
    # small print accent and warm paper for editorial spreads; retain branded palettes.
    if not explicit and key in ("5B9BD5","4F81BD","156082","4472C4"):
        primary,soft,highlight=scene_colors or ("30483E","DEE6D9","9D7549")
        palette.update({PAPER:"F7F3E9",INK:blend(primary,"21221D",.57),GREEN:primary,
                        MUTED:blend(primary,"4D554C",.55),PALE:soft,LINE:blend(primary,WHITE,.68),ACCENT:highlight})
    fonts={}
    for group in ("majorFont","minorFont"):
        parent=theme.find(".//"+qn("a:"+group))
        if parent is None:
            fonts[group]=(None,None)
            continue
        latin=parent.find(qn("a:latin"))
        default_east=parent.find(qn("a:ea"))
        east=(default_east.get("typeface") if default_east is not None else None) or ("+mj-ea" if group=="majorFont" else "+mn-ea")
        fonts[group]=(latin.get("typeface") if latin is not None else None,east)
    return palette, fonts


class DensityNeeded(Exception):
    """This source needs custom grouping or a user-approved split before delivery."""


def rect(s):
    return s.left, s.top, s.width, s.height


def rich_lines(shape):
    """Split only original author-supplied paragraph and soft breaks; keep all inline runs."""
    lines = []
    for para in shape.text_frame.paragraphs:
        element = para._p
        template = deepcopy(element)
        for node in list(template):
            if node.tag != qn("a:pPr"):
                template.remove(node)
        fragment = deepcopy(template)
        for node in element:
            if node.tag == qn("a:br"):
                if fragment.xpath(".//a:t[text()]"):
                    lines.append(fragment)
                fragment = deepcopy(template)
            elif node.tag != qn("a:pPr"):
                fragment.append(deepcopy(node))
        if fragment.xpath(".//a:t[text()]"):
            lines.append(fragment)
    return lines


def text_of(lines):
    return ["".join(x.itertext()) if x.tag == qn("a:t") else
            "".join(t.text or "" for t in x.xpath(".//a:t")) for x in lines]


def is_picture(shape):
    return shape._element.tag==qn("p:pic")


def ordinary_text(shape):
    # Unknown inline structures (Office Math, embedded equations, AlternateContent) must
    # retain their original XML. A missing plain-text projection is not an empty paragraph.
    return all(child.tag in (qn("a:pPr"),qn("a:r"),qn("a:br"),qn("a:endParaRPr")) and
               (child.tag!=qn("a:r") or all(leaf.tag in (qn("a:rPr"),qn("a:t")) for leaf in child))
               for para in shape.text_frame.paragraphs for child in para._p)


def heading(shape):
    if not shape.is_placeholder:
        return False
    return shape.placeholder_format.type in (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE)


def plain_split_ok(shape):
    # Preserve automatic numbering, timings, links and unsupported inline features in place.
    return not shape._element.xpath(".//a:buAutoNum|.//a:fld|.//a:hlinkClick|.//a:hlinkMouseOver|.//a:blip")


class Canvas:
    def __init__(self, deck, slide, theme):
        self.palette, self.fonts = theme
        self.slide = slide
        self.w, self.h = deck.slide_width, deck.slide_height
        self.items = list(slide.shapes)
        self.texts = [s for s in self.items if s.has_text_frame and s.text.strip()]
        self.source_copy={s.shape_id:s.text.splitlines() for s in self.texts}
        self.pics = [s for s in self.items if is_picture(s)]
        self.groups = [s for s in self.items if s.shape_type == Shape.GROUP]
        self.charts = [s for s in self.items if s.has_chart]
        self.tables = [s for s in self.items if s.has_table]
        self.original = {s.shape_id: self.geometry(s) for s in self.items}
        self.title = next((s for s in self.texts if heading(s)), None)
        if self.title is None and self.texts:
            self.title = min(self.texts, key=lambda s: (s.top, s.left))

    def geometry(self, shape):
        x, y, w, h = rect(shape)
        return (x/self.w, y/self.h, w/self.w, h/self.h)

    def place(self, shape, box, contain=False):
        x, y, w, h = box
        if contain:
            orig = self.original[shape.shape_id]
            scale = min(w/orig[2], h/orig[3])
            width, height = orig[2]*scale, orig[3]*scale
            x += (w-width)/2
            y += (h-height)/2
            w, h = width, height
        shape.left, shape.top = int(x*self.w), int(y*self.h)
        shape.width, shape.height = int(w*self.w), int(h*self.h)

    def background(self, color):
        fill = self.slide.background.fill
        fill.solid()
        fill.fore_color.rgb = rgb(self.palette.get(color,color))

    def panel(self, box, color, name):
        shape = self.slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, self.w, self.h)
        shape.name = name
        shape.fill.solid()
        shape.fill.fore_color.rgb = rgb(self.palette.get(color,color))
        shape.line.fill.background()
        self.place(shape, box)
        tree = self.slide.shapes._spTree
        tree.remove(shape._element)
        tree.insert(2, shape._element)
        return shape

    def block(self, shape, lines, box, nominal, color=INK, bold=False, keep_emphasis=False):
        if shape is None:
            shape = self.slide.shapes.add_textbox(0, 0, self.w, self.h)
        self.place(shape, box)
        frame = shape.text_frame
        if lines is not None:
            for para in list(frame._txBody.xpath("./a:p")):
                frame._txBody.remove(para)
            for line in lines:
                frame._txBody.append(deepcopy(line))
        if shape.shape_type in (Shape.PLACEHOLDER, Shape.AUTO_SHAPE, Shape.TEXT_BOX):
            shape.fill.background()
            shape.line.fill.background()
        frame.vertical_anchor = MSO_ANCHOR.TOP
        frame.word_wrap = True
        frame.auto_size = MSO_AUTO_SIZE.NONE
        frame.margin_left = frame.margin_right = Pt(0)
        frame.margin_top = frame.margin_bottom = Pt(0)
        pts_w = box[2]*self.w / 12700
        pts_h = box[3]*self.h / 12700
        # Size scales with physical page dimensions and respects wrapped Latin words and CJK.
        size = nominal * min(self.w/(13.333*914400), self.h/(7.5*914400))
        source_lines = [s for p in frame.paragraphs for s in p.text.split("\v")]
        if nominal>=28 and len(source_lines)==1:
            natural=wide_length(source_lines[0])*size
            if pts_w*.91 < natural < pts_w*1.30:
                size=min(size,pts_w*.90/max(1,wide_length(source_lines[0])))
        def height_at(size):
            capacity = max(1, pts_w / size * .93)
            count = 0
            for line in source_lines:
                rows, width = 1, 0
                for unit in re.findall(r"[\x21-\x7e]+|[^\x21-\x7e]", line):
                    u = wide_length(unit)
                    if width and width+u>capacity:
                        rows += 1
                        width = 0
                    width += u
                    if width>capacity:
                        spill = math.ceil(width/capacity)-1
                        rows += spill
                        width -= spill*capacity
                count += rows
            return count * size * 1.24 + max(0, len(source_lines)-1)*size*.07
        while size>7 and height_at(size)>pts_h*.96:
            size -= .5
        legible=min(nominal,13)*min(self.w/(13.333*914400),self.h/(7.5*914400))
        if size<legible-.51 or height_at(size)>pts_h*.99:
            raise DensityNeeded()
        if (shape.shape_id==self.title.shape_id and nominal>=28) or nominal>=48:
            size=balance_title(frame,pts_w,pts_h,size)
        font_group="majorFont" if nominal>=30 else "minorFont"
        latin, east=self.fonts[font_group]
        for p in frame.paragraphs:
            p.alignment = PP_ALIGN.LEFT
            # Explicit values neutralize an oversized title placeholder inherited from a master.
            p.space_before = Pt(0)
            p.space_after = Pt(0)
            p.line_spacing = 1.03
            pp = p._p.get_or_add_pPr()
            for key in ("marL", "marR", "indent"):
                pp.set(key, "0")
            for r in (p, *p.runs):
                font = r.font
                if latin and (font.name is None or font.name.startswith("+")):
                    font.name = latin
                font.size = Pt(size)
                if not keep_emphasis or font.bold is None:
                    font.bold = bold
                font.color.rgb = rgb(self.palette.get(color,color))
                prop = pp.get_or_add_defRPr() if r is p else r._r.get_or_add_rPr()
                ea = prop.find(qn("a:ea"))
                if ea is None:
                    ea = OxmlElement("a:ea")
                    prop.append(ea)
                if east and not (ea.get("typeface") or "").strip("+"):
                    ea.set("typeface",east)
        return shape

    def titlebar(self, width=.90, height=.115):
        self.block(self.title, None, (.045, .047, width, height), 36, GREEN, True)


def title_breaks(text, capacity):
    """Choose actual native line breaks, preserving CJK punctuation, word and grapheme boundaries."""
    width=wide_length(text)
    cjk=sum(1 for c in text if unicodedata.east_asian_width(c) in ("W","F") and c.isalpha())
    if width<=capacity or cjk<3 or cjk*2<len(text.strip()) or len(text)>120:
        return ()
    ends=[0]
    for i in range(1,len(text)):
        a,b=text[i-1],text[i]
        if (unicodedata.combining(b) or b in "︀︁︎️‍" or a=="‍" or
            unicodedata.category(b) in ("Pe","Pf") or b in "，。、；：！？％…,.!?:;%" or
            unicodedata.category(a) in ("Ps","Pi") or
            (a.isascii() and b.isascii() and not (a.isspace() or b.isspace()))):
            continue
        ends.append(i)
    ends.append(len(text))
    prefix=[0.]
    for char in text:
        prefix.append(prefix[-1]+wide_length(char))
    # Fewest lines first. Within that count, minimize squared line lengths. This yields
    # balanced rows while favoring a natural punctuation or space boundary when close.
    best={0:(0,0.,())}
    for end in ends[1:]:
        choices=[]
        for start in ends:
            if start>=end:
                break
            used=prefix[end]-prefix[start]
            if start not in best or used>capacity or (end==len(text) and used<1.7):
                continue
            count,cost,breaks=best[start]
            lexical=0 if end==len(text) or text[end-1].isspace() or unicodedata.category(text[end-1]).startswith("P") else .3
            choices.append((count+1,cost+used*used+lexical,breaks+((end,) if end<len(text) else ())))
        if choices:
            best[end]=min(choices)
    return best.get(len(text),(0,0.,()))[2]


def balance_title(frame,width,height,size):
    segments=[]
    for paragraph in frame.paragraphs:
        current=[]
        for child in paragraph._p:
            if child.tag==qn("a:r"):
                current.append(child)
            elif child.tag==qn("a:br"):
                segments.append(current)
                current=[]
            elif child.tag not in (qn("a:pPr"),qn("a:endParaRPr")):
                return size
        segments.append(current)
    values=["".join(run.findtext(qn("a:t"),"") for run in runs) for runs in segments]
    def inspect(points):
        capacity=width*.92/points
        plans=[title_breaks(text,capacity) for text in values]
        rows=sum(len(cuts)+1 if cuts else max(1,math.ceil(wide_length(text)/capacity))
                 for text,cuts in zip(values,plans))
        return plans,rows
    plans,rows=inspect(size)
    if not any(plans):
        return size
    smaller,new_rows=inspect(size*.90)
    if new_rows<rows:
        size*=.90
        plans,rows=smaller,new_rows
    if rows*size*1.24>height*.98:
        return size
    for runs,cuts in zip(segments,plans):
        offset=0
        for run in runs:
            text=run.findtext(qn("a:t"),"")
            local=[i-offset for i in cuts if offset<i<=offset+len(text)]
            offset+=len(text)
            if not local:
                continue
            at=0
            for stop in local+[len(text)]:
                if stop>at:
                    chunk=deepcopy(run)
                    chunk.find(qn("a:t")).text=text[at:stop]
                    run.addprevious(chunk)
                if stop in local:
                    run.addprevious(OxmlElement("a:br"))
                at=stop
                if stop==len(text):
                    break
            run.getparent().remove(run)
    return size


def leading_label(text):
    # Short prefixes repeated across source paragraphs are evidence of member names / step labels.
    match=re.match(r"^(.{1,24}?)([｜|：:]|\s[–—-]\s)\s*",text)
    return match.group(0) if match and wide_length(match.group(1))<=16 else ""


def split_prefix(line, count):
    left,right=deepcopy(line),deepcopy(line)
    for target,first in ((left,True),(right,False)):
        offset=0
        for run in list(target):
            node=run.find(qn("a:t"))
            if node is None:
                continue
            value=node.text or ""
            portion=value[:max(0,count-offset)] if first else value[max(0,count-offset):]
            offset+=len(value)
            if portion:
                node.text=portion
            else:
                target.remove(run)
    return left,right


def text_composition(c, number, intent):
    title = c.title
    lines = rich_lines(title)
    if not lines or not all(plain_split_ok(t) and ordinary_text(t) for t in c.texts):
        return None
    other = [s for s in c.texts if s.shape_id != title.shape_id]
    if number==1 and len(other)<=1:
        rest=rich_lines(other[0]) if other else lines[1:]
        if len(lines)<=3 and len(rest)<=3 and sum(map(wide_length,text_of(lines+rest)))<=60:
            if not other and len(lines)>1:
                # A grouped title/byline with an original hard break keeps its reading order.
                lead=lines[1:]
                byline=lines[:1]
                primary=None
                small=title
            else:
                lead=lines
                byline=rest
                primary=title
                small=other[0] if other else None
            if c.photos:
                hero=c.photos[0]
                woven=(c.night and hero["role"]=="editorial_photo" and hero.get("focus",(.5,.5))[0]>=.57) or white_text_on_photo(hero,c)
                cut=hero["role"]=="subject_cutout"
                c.background(GREEN if woven else PAPER)
                field=c.panel((.51,0,.49,1),PALE,"Ground behind silhouette") if cut else None
                snap=(0,0,1,1) if woven else ((.375,.035,.64,.955) if cut else (.414,0,.586,1))
                place_art(c,0,snap,field)
                if woven:
                    contrast_veil(c,hero["name"],blend(c.palette[GREEN],"071016",.64))
                color=WHITE if woven else GREEN
                margin=.058
                text_width=.44 if woven else .33
                headline=text_of(lead)
                nominal=75
                if len(headline)==1 and 3<=len(headline[0])<=10 and all(
                        unicodedata.east_asian_width(char) in ("W","F") for char in headline[0]):
                    # Short proper names should read intact as one display line.
                    nominal=min(nominal,960*text_width*.88/max(1,wide_length(headline[0])))
                original_kicker=(primary is None and small is not None and len(byline)==1)
                headline_top=.413 if original_kicker else (.288 if woven else .145)
                c.block(primary,lead,(margin,headline_top,text_width,.40),nominal,color,True)
                if byline:
                    c.block(small,byline[:1],(margin,.277 if original_kicker else .672,text_width,.124),28,WHITE if woven else GREEN,True)
                    if len(byline)>1:
                        extra=c.block(None,byline[1:],(margin,.817,text_width,.12),17,WHITE if woven else MUTED)
                        if small is not None:
                            small._element.addnext(extra._element)
            else:
                c.background(PAPER)
                # Treat the original short title as display type. Its supporting lines
                # inhabit a smaller, edge-to-edge colophon field rather than a title card.
                c.panel((0,.695,1,.305),GREEN,"Cover colophon")
                c.block(primary,lead,(.049,.135,.91,.45),86,GREEN,True)
                if byline:
                    c.block(small,byline,(.061,.748,.87,.195),27,WHITE)
            return "display-title"
    if len(other)>1:
        return None
    if other:
        sub = rich_lines(other[0])
        if not sub:
            return None
    else:
        sub = lines[1:]
        if not sub:
            return None
    body = sum(map(wide_length, text_of(sub)))
    if body>270 or len(sub)>7:
        return None
    labels=[leading_label(x) for x in text_of(sub)]
    indexed=[k for k,l in enumerate(labels) if l]
    # Repeated groups (A title, A detail, B title, B detail) stay in corresponding columns.
    if len(other)==1 and len(indexed)==2 and indexed[0]==0 and indexed[1]>=2 and len(sub)>indexed[1]+1:
        c.background(PAPER)
        c.panel((.5,.255,.5,.745),PALE,"Parallel reading column")
        c.block(title,None,(.053,.055,.885,.17),43,INK,True)
        for j,(start,end) in enumerate(((0,indexed[1]),(indexed[1],len(sub)))):
            x=.055+.50*j
            label,detail=split_prefix(sub[start],len(labels[start]))
            c.block(other[0] if j==0 else None,[label],(x,.32,.395,.17),36,GREEN,True)
            c.block(None,[detail]+sub[start+1:end],(x,.552,.395,.33),23,INK)
            icon_slot(c,f"comparison-{j+1}",(x+.314,.275,.069,.12),text_of([sub[start]])[0])
        return "parallel-comparison"
    if len(other)==1 and 2<=len(sub)<=5 and (len(indexed)==len(sub) or intent in ("sequence","procedure","steps","timeline")):
        if c.night and len(sub)<=4:
            c.background(GREEN)
            c.block(title,None,(.052,.069,.90,.23),48,WHITE,True)
            gap=.035
            width=(.90-(len(sub)-1)*gap)/len(sub)
            for j,line in enumerate(sub):
                x=.052+j*(width+gap)
                anchor=text_of([line])[0]
                icon_slot(c,f"step-{j+1}",(x,.328,.074,.139),anchor)
                if labels[j]:
                    label,detail=split_prefix(line,len(labels[j]))
                    c.block(other[0] if j==0 else None,[label],(x,.518,width,.13),31,WHITE,True)
                    c.block(None,[detail],(x,.678,width,.243),21,PALE)
                else:
                    c.block(other[0] if j==0 else None,[line],(x,.537,width,.344),24,WHITE)
            return "sequence"
        c.background(PAPER)
        c.panel((0,0,.337,1),GREEN,"Process title field")
        c.block(title,None,(.047,.16,.255,.54),47,WHITE,True)
        y0=.095
        row_h=.82/len(sub)
        for j,line in enumerate(sub):
            y=y0+j*row_h
            text=text_of([line])[0]
            # The source step name and explanation occupy the same row; the row's
            # icon sits against the margin and never substitutes for either text.
            icon_slot(c,f"step-{j+1}",(.367,y+.018,.067,min(.122,row_h*.65)),text)
            if labels[j]:
                label,detail=split_prefix(line,len(labels[j]))
                c.block(other[0] if j==0 else None,[label],(.46,y+.008,.205,row_h*.40),31,GREEN,True)
                c.block(None,[detail],(.46,y+row_h*.41,.486,row_h*.51),21,INK)
            else:
                c.block(other[0] if j==0 else None,[line],(.46,y+.025,.484,row_h*.78),24,INK)
            if j<len(sub)-1:
                c.panel((.458,y+row_h-.017,.485,.0016),LINE,"Separate consecutive instructions")
        return "sequence"
    if len(sub)>=3 and len(other)==1 and max(map(wide_length,text_of(sub)))<17:
        c.background(PAPER)
        photo=next((k for k,r in enumerate(c.photos) if r["role"]=="editorial_photo"),None)
        upper=.13
        # A portrait scene cannot carry a panoramic banner without losing faces or the
        # work being shown. Let the topic list occupy the opposing column instead.
        portrait = photo is not None and c.photos[photo]["size"][0] / c.photos[photo]["size"][1] < 1.4
        if portrait:
            place_art(c,photo,(.053,.433,.365,.513))
            upper=.185
        elif photo is not None:
            place_art(c,photo,(0,0,1,.34))
            upper=.395
        else:
            c.panel((0,0,.47,1), GREEN, "Section field")
        title_color=GREEN if photo is not None else WHITE
        c.block(title, lines[:1], (.055,.044,.405,.174) if portrait else (.055,upper,.37,.25 if photo is not None else .32), 46, title_color, True)
        if len(lines)>1:
            extra=c.block(None, lines[1:], (.055,.231,.408,.163) if portrait else (.059,upper+.305,.36,.24 if photo is not None else .33), 22, INK if photo is not None else PALE)
            title._element.addnext(extra._element)
        slot=(.945-upper)/len(sub)
        from semantic_icons import choose_icon, authorized
        for idx, line in enumerate(sub):
            y=upper+idx*slot
            label=text_of([line])[0]
            key=choose_icon(label)
            name=f"section-{idx+1}"
            mark=key and authorized(c.plan,number,empty=True,icon=True,slot=name)
            if mark:
                icon_slot(c,name,(.498,y+.012,.053,min(slot-.020,.09)),label)
            if idx:
                c.panel((.501,y-.007,.436,.0014),LINE,"Separate adjacent topics")
            x=.574 if mark else .503
            c.block(other[0] if idx==0 else None,[line],(x,y+.012,.94-x,slot-.025),23,GREEN,idx==0)
        return "section-and-list"
    c.background(PAPER)
    body_shape=other[0] if other else None
    if c.photos:
        if c.photos[0]["role"]=="subject_cutout":
            if c.night:
                c.background(GREEN)
                field=c.panel((.55,.418,.45,.582),PALE,"Light ground behind the dark silhouette")
                place_art(c,0,(.502,.230,.466,.675),field)
                c.block(title,lines[:1],(.053,.105,.77,.24),52,WHITE,True)
                c.block(body_shape,sub,(.056,.465,.401,.408),26,WHITE,keep_emphasis=True)
            else:
                field=c.panel((.696,0,.304,1),PALE,"Color behind cutout")
                place_art(c,0,(.51,.095,.472,.837),field)
                c.block(title,lines[:1],(.055,.11,.45,.28),51,GREEN,True)
                c.block(body_shape,sub,(.06,.488,.405,.365),27,INK,keep_emphasis=True)
        elif c.photos[0]["size"][0] / c.photos[0]["size"][1] < 1.2:
            # Preserve the vertical action (face, hands, tool) while the headline spans
            # the page and the body reads beside the lower photograph.
            c.block(title,lines[:1],(.051,.052,.89,.204),49,GREEN,True)
            ratio=c.photos[0]["size"][0]/c.photos[0]["size"][1]
            fw=min(.412,.696*c.h/c.w*ratio/.86)
            place_art(c,0,(.05,.304,fw,.696))
            text_x=max(.44,.05+fw+.054)
            c.block(body_shape,sub,(text_x,.368,.946-text_x,.531),26,INK,keep_emphasis=True)
        else:
            place_art(c,0,(0,.446,1,.554))
            c.block(title,lines[:1],(.052,.067,.438,.314),45,GREEN,True)
            c.block(body_shape,sub,(.548,.084,.402,.30),22,INK,keep_emphasis=True)
    elif len(sub)>1:
        # Original lead and follow-through copy receive an explicit change of
        # scale and ground. Use adjacent columns only when the source has two peers.
        c.block(title,lines[:1],(.054,.064,.895,.19),47,GREEN,True)
        c.block(body_shape,sub[:1],(.115,.31,.804,.30),33,INK,keep_emphasis=True)
        c.panel((0,.681,1,.319),GREEN,"Supporting statements")
        tails=sub[1:]
        if len(tails)==2:
            for j,tail in enumerate(tails):
                c.block(None,[tail],(.06+.48*j,.739,.41,.21),22,WHITE)
        else:
            c.block(None,tails,(.079,.737,.84,.215),22,WHITE)
    else:
        c.panel((0,.725,1,.275),PALE,"Statement ground")
        c.block(title,lines[:1],(.051,.085,.89,.258),57,GREEN,True)
        c.block(body_shape,sub,(.219,.418,.705,.395),31,INK,keep_emphasis=True)
    if other and len(lines)>1:
        # Additional original title lines belong to a custom design whenever the
        # above art direction cannot guarantee their readable space.
        raise DensityNeeded()
    return "statement-spread"


def by_position(c, shapes):
    # Match original visual reading rows before sorting across their columns.
    ordered = sorted(shapes, key=lambda s: c.original[s.shape_id][1])
    rows = []
    for s in ordered:
        b = c.original[s.shape_id]
        if not rows or abs(b[1]-c.original[rows[-1][0].shape_id][1]) > min(.13,b[3]*.5):
            rows.append([])
        rows[-1].append(s)
    return [sorted(row, key=lambda s:c.original[s.shape_id][0]) for row in rows]


def gallery(c):
    if not 3<=len(c.pics)<=12 or c.groups or c.charts or c.tables or not c.title:
        return None
    rows = by_position(c,c.pics)
    columns = max(map(len,rows))
    if len(rows)>3 or not 2<=columns<=5 or min(map(len,rows))!=columns:
        return None
    others = [s for s in c.texts if s.shape_id!=c.title.shape_id]
    cells = {p.shape_id:[] for p in c.pics}
    leads = []
    for s in others:
        x,y,w,h = c.original[s.shape_id]
        if w>.42 and (s.is_placeholder or len(rows)>1 and w>.65):
            leads.append(s)
            continue
        # Match by source caption position, with above/below kept independently.
        def distance(p):
            px,py,pw,ph = c.original[p.shape_id]
            return abs((x+min(w,pw)/2)-(px+pw/2))*2 + min(abs((y+h)-py),abs(y-(py+ph)))
        p=min(c.pics,key=distance)
        cells[p.shape_id].append(s)
    if any(len(cell)>2 for cell in cells.values()) or len(leads)>2:
        return None
    c.background(WHITE)
    if len(leads)==1 and len(rows)>1:
        c.titlebar(.43,.14)
        c.block(leads[0],None,(.51,.055,.44,.10),16,MUTED)
    else:
        c.titlebar()
    start = .19
    if len(leads)==2:
        for k,s in enumerate(sorted(leads,key=lambda s:s.left)):
            c.block(s,None,(.045+.468*k,.19,.435,.145),19,GREEN,keep_emphasis=True)
        start=.365
    elif leads and len(rows)==1:
        c.block(leads[0],None,(.045,.18,.9,.10),17,MUTED)
        start=.30
    gapx=.019
    width=(.91-(columns-1)*gapx)/columns
    rowh=(.97-start)/len(rows)
    for row_index,row in enumerate(rows):
        for col,p in enumerate(row):
            x=.045+col*(width+gapx)
            y=start+row_index*rowh
            labs=sorted(cells[p.shape_id],key=lambda s:s.top)
            above=[s for s in labs if c.original[s.shape_id][1] < c.original[p.shape_id][1]]
            below=[s for s in labs if s not in above]
            upper= min(.095,rowh*.22) if above else 0
            lower= min(.069,rowh*.19) if below else 0
            for group, a, h in [(above,y,upper),(below,y+rowh-lower-.007,lower)]:
                for j,s in enumerate(group):
                    c.block(s,None,(x,a+j*h/len(group),width,h/len(group)),15,GREEN,True)
            picbox=(x,y+upper,width,rowh-upper-lower-.021)
            c.place(p,picbox,True)
    return "captioned-exhibits"


def figure_spread(c):
    if not c.title or c.charts or c.tables:
        return None
    figures = c.pics+c.groups
    if not 1<=len(figures)<=2:
        return None
    others = [s for s in c.texts if s.shape_id!=c.title.shape_id]
    if len(others)>2:
        return None
    figures.sort(key=lambda s:s.width*s.height,reverse=True)
    if len(figures)==1:
        c.background(WHITE)
        c.titlebar(.905,.14)
        if others:
            c.place(figures[0],(.042,.215,.59,.71),True)
            band=.55/len(others)
            for idx,s in enumerate(others):
                c.block(s,None,(.675,.28+idx*band,.28,band-.04),21,GREEN,idx==0)
        else:
            c.place(figures[0],(.045,.195,.909,.746),True)
        return "lead-figure"
    main, secondary=figures
    foot=[s for s in others if c.original[s.shape_id][1]>.74 and c.original[s.shape_id][2]>.5]
    labels=[s for s in others if s not in foot]
    if len(foot)>1 or len(labels)>1:
        return None
    c.background(WHITE)
    c.titlebar(.905,.14)
    bottom=.813 if foot else .95
    c.place(main,(.03,.193,.585,bottom-.193),True)
    c.panel((.632,.215,.002,bottom-.23),LINE,"Evidence divider")
    if labels:
        c.block(labels[0],None,(.661,.225,.30,.12),21,GREEN,True)
    top=.365 if labels else .19
    c.place(secondary,(.65,top,.327,bottom-top),True)
    if foot:
        c.block(foot[0],None,(.045,.839,.92,.126),18,INK,keep_emphasis=True)
    return "paired-evidence"


def fit_figure_labels(group):
    # Short captions inside an editable group often have an inherited, very narrow textbox.
    # Use the neighboring image's width without moving, reshaping or replacing its pixels.
    for child in group.shapes:
        if child.shape_type==Shape.GROUP:
            fit_figure_labels(child)
    labels=[s for s in group.shapes if s.has_text_frame and s.text.strip()]
    pictures=[s for s in group.shapes if is_picture(s) or s._element.xpath("./p:spPr/a:blipFill")]
    if len(labels)!=1 or len(pictures)!=1 or len(group.shapes)!=2:
        return
    label,pic=labels[0],pictures[0]
    if wide_length(label.text)>18 or label.top<pic.top+pic.height*.80:
        return
    label.left=pic.left
    label.width=pic.width
    frame=label.text_frame
    frame.word_wrap=False
    frame.vertical_anchor=MSO_ANCHOR.TOP
    frame.margin_left=frame.margin_right=frame.margin_top=frame.margin_bottom=Pt(0)
    for para in frame.paragraphs:
        para.alignment=PP_ALIGN.CENTER
        para.space_before=para.space_after=Pt(0)
        para.line_spacing=1.
        for part in (para,*para.runs):
            part.font.size=Pt(min(17,max(10.,label.height/12700*.79)))


def chart_spread(c):
    if len(c.charts)!=1 or c.tables or not c.title:
        return None
    chart=c.charts[0]
    supporting=[s for s in c.texts if s.shape_id!=c.title.shape_id]
    if not c.groups and not c.pics and len(supporting)<=1:
        c.background(WHITE)
        c.titlebar(.91,.14)
        if supporting:
            c.block(supporting[0],None,(.048,.188,.89,.095),18,MUTED)
        top=.30 if supporting else .205
        c.place(chart,(.052,top,.895,.934-top))
        native=chart.chart
        graph=native._chartSpace
        # A default single bar series carries no color-coded categories. Preserve
        # every explicit series/data-point treatment, chart values and label semantics.
        if (len(native.series)==1 and graph.xpath(".//c:barChart") and
            not graph.xpath(".//c:ser/c:spPr|.//c:ser/c:dPt|.//c:varyColors[@val='1' or @val='true']|.//c:style|.//c:extLst")):
            series=native.series[0]
            series.format.fill.solid()
            series.format.fill.fore_color.rgb=rgb(c.palette[GREEN])
            for axis in (native.category_axis,native.value_axis):
                if not axis._element.xpath("./c:txPr//a:solidFill|./c:txPr//a:noFill"):
                    axis.tick_labels.font.color.rgb=rgb(c.palette[INK])
        return "chart-exhibit"
    cx,cy,cw,ch=c.original[chart.shape_id]
    # A supporting chart already in the lower right of a process should retain the links
    # in its process diagram while receiving a substantially larger analytical column.
    if cx<.52 or cy<.43 or cw>.46 or not c.groups:
        return None
    cluster=[]; findings=[]; legends=[]; notes=[]
    for s in c.items:
        if s.shape_id in (chart.shape_id,c.title.shape_id):
            continue
        x,y,w,h=c.original[s.shape_id]
        if s in c.pics:
            if x<cx-.04 or y>.22:
                return None
            notes.append(s)
        elif x >= cx-.015 and s in c.texts:
            (legends if y>=cy+ch*.78 else findings).append(s)
        elif s.shape_type==Shape.GROUP or s in c.texts:
            cluster.append(s)
        elif s.shape_type!=Shape.TEXT_BOX:
            return None
    if len(findings)>1 or len(legends)>1 or len(notes)>1 or not cluster:
        return None
    def is_connector_group(s):
        return s.shape_type==Shape.GROUP and all(k.shape_type==Shape.LINE for k in s.shapes)
    notes_in_diagram=[s for s in cluster if s.has_text_frame]
    figures=[s for s in cluster if s.shape_type==Shape.GROUP and not is_connector_group(s)]
    links=sorted((s for s in cluster if is_connector_group(s)),key=lambda s:s.left)
    if len(figures)!=1 or len(links)!=2 or not 1<=len(notes_in_diagram)<=3:
        return None
    figure=figures[0]
    fx,fy,fw,fh=c.original[figure.shape_id]
    def right(s):
        x,y,w,h=c.original[s.shape_id]
        return x+w
    left=min(c.original[s.shape_id][0] for s in notes_in_diagram)
    last=max(right(s) for s in notes_in_diagram)
    link_end=right(links[-1])
    if (not fx<fx+fw<left<last<link_end or min(left-fx-fw,link_end-last)<.025 or
        max(c.original[s.shape_id][0] for s in notes_in_diagram)-left>.04 or
        not fx+fw-.055 < c.original[links[0].shape_id][0] < left or
        not last-.055 < c.original[links[-1].shape_id][0] < link_end):
        return None
    # Map source lanes monotonically. Gutter endpoints remain aligned with the same
    # source notes in the same vertical order, even when library coordinates differ.
    input_edges=[fx,fx+fw,left,last,link_end]
    target_left=.023
    target_right=min(.62,max(.535,cx*.845))
    space=target_right-target_left
    lane_weights=[b-a for a,b in zip(input_edges,input_edges[1:])]
    lane_weights[2]=max(lane_weights[2],(link_end-fx)*.333)
    target=[target_left]
    for w in lane_weights:
        target.append(target[-1]+space*w/sum(lane_weights))
    def mapped_x(x):
        k=next((i for i in range(4) if x<=input_edges[i+1]),3)
        return target[k]+(x-input_edges[k])*(target[k+1]-target[k])/(input_edges[k+1]-input_edges[k])
    top_data=.185
    y_min=min(c.original[s.shape_id][1] for s in cluster)
    y_max=max(sum(c.original[s.shape_id][i] for i in (1,3)) for s in cluster)
    y_scale=(.926-top_data)/(y_max-y_min)
    c.background(WHITE)
    c.titlebar(.74)
    if notes:
        c.place(notes[0],(.841,.016,.107,.163),True)
    for s in cluster:
        x,y,w,h=c.original[s.shape_id]
        new_y=top_data+(y-y_min)*y_scale
        if s.has_text_frame:
            c.block(s,None,(mapped_x(x),new_y,mapped_x(x+w)-mapped_x(x),min(.95-new_y,h*y_scale*1.14)),15,INK,keep_emphasis=True)
        elif is_connector_group(s):
            gutter=1 if s.shape_id==links[0].shape_id else 3
            gx=target[gutter]+.004
            c.place(s,(gx,new_y,target[gutter+1]-gx-.005,h*y_scale))
        else:
            fit_figure_labels(s)
            c.place(s,(mapped_x(x),new_y,mapped_x(x+w)-mapped_x(x),h*y_scale),True)
    right_column=target_right+.024
    if findings:
        c.block(findings[0],None,(right_column,.178,.966-right_column,.188),17,GREEN,keep_emphasis=True)
    top=.397 if findings else .22
    c.place(chart,(right_column,top,.976-right_column,.893-top))
    if legends:
        c.block(legends[0],None,(right_column,.904,.966-right_column,.058),15,GREEN,True)
    return "native-chart-analysis"


def table_layout(c):
    if len(c.tables)!=1 or c.charts or c.groups or c.pics or len(c.texts)!=1:
        return None
    c.background(WHITE)
    c.titlebar()
    s=c.tables[0]
    # Preserve column widths and row-height ratios; python-pptx recomputes the frame.
    x,y,w,h=(.046,.205,.909,.69)
    s.left=int(x*c.w)
    s.top=int(y*c.h)
    cols=list(s.table.columns)
    rows=list(s.table.rows)
    widths=[col.width/sum(v.width for v in cols) for col in cols]
    heights=[row.height/sum(v.height for v in rows) for row in rows]
    for col,ratio in zip(cols,widths):
        col.width=int(c.w*w*ratio)
    for row,ratio in zip(rows,heights):
        row.height=int(c.h*h*ratio)
    for col_index,col in enumerate(cols):
        values=[s.table.cell(j,col_index).text.strip() for j in range(1,len(rows))]
        numeric=bool(values) and all(re.fullmatch(r"[+−–(\d.,%％)\s:/-]+",v) for v in values if v)
        for row_index,row in enumerate(rows):
            cell=s.table.cell(row_index,col_index)
            if cell.is_spanned:
                continue
            width=sum(v.width for v in cols[col_index:col_index+cell.span_width])/12700
            height=sum(v.height for v in rows[row_index:row_index+cell.span_height])/12700
            mx,my=min(11,width*.065),min(8,height*.11)
            cell.margin_left=cell.margin_right=Pt(mx)
            cell.margin_top=cell.margin_bottom=Pt(my)
            cell.vertical_anchor=MSO_ANCHOR.MIDDLE
            content=cell.text.splitlines() or [""]
            size=min(29 if row_index==0 else 26, (height-2*my)/1.37)
            def required_height(size):
                return sum(max(1,math.ceil(wide_length(t)*size/max(1,width-2*mx)*1.08)) for t in content)*size*1.27
            while size>12 and required_height(size)>height-2*my:
                size-=.5
            if size<12 or required_height(size)>height-2*my:
                raise DensityNeeded()
            for para in cell.text_frame.paragraphs:
                if numeric and row_index>0 and para.alignment is None:
                    para.alignment=PP_ALIGN.RIGHT
                para.space_before=para.space_after=Pt(0)
                for item in (para,*para.runs):
                    item.font.size=Pt(size)
    return "editable-table"


def source_page_options(plan,n):
    row={}
    for key in ("pages","visual_plan"):
        group=plan.get(key)
        if isinstance(group,dict):
            group=group.get("pages",[])
        if isinstance(group,list):
            row.update(next((entry for entry in group if isinstance(entry,dict) and
                             (entry.get("page_number") or entry.get("page"))==n),{}))
    return row


def compose(source, destination, plan, art=None):
    source, destination = Path(source), Path(destination)
    if source.resolve()==destination.resolve() or destination.exists():
        raise ValueError("Use a fresh private output path.")
    deck=Presentation(source)
    strip_slide_numbers(deck)
    results=[]
    settings=plan.get("settings",{})
    scope=plan.get("layout_change_pages")
    custom=settings.get("individual_adjustments",{})
    themes={}
    ready=permitted_assets(plan,art)
    lead=next((r for n in sorted(ready) for r in ready[n] if r["role"]=="editorial_photo"),None)
    scene_colors=photo_tones(lead) if lead else None
    night=low_key(lead)
    headings=[]
    for slide in deck.slides:
        title=slide.shapes.title
        if title is not None and title.has_text_frame and title.text.strip():
            headings.append(title.text.strip().splitlines()[0][:55])
        else:
            first=next((s.text for s in slide.shapes if s.has_text_frame and s.text.strip()),"")
            headings.append(first.splitlines()[0][:55] if first else "")
    for i,slide in enumerate(deck.slides,1):
        c=None
        icons=[]
        cfg=source_page_options(plan,i)
        profile=cfg.get("editable_profile") or (plan.get("page_profiles") or {}).get(str(i),settings.get("editable_profile","refined"))
        style=settings.get("layout_style")
        if profile!="refined":
            lane="quick-or-other-profile"
        elif (cfg.get("layout_locked") or cfg.get("approved_original_page") or
              (scope is not None and i not in scope) or cfg.get("preserve_layout") or
              (style and style not in ("auto","automatic","依內容設計","自動","自動風格")) or
              any(item.get("bounds") or item.get("geometry") or item.get("layout_locked") for item in
                  [*(cfg.get("layers") or []),*(cfg.get("objects") or [])] if isinstance(item,dict)) or
              (isinstance(custom,dict) and (str(i) in custom or i in custom)) or slide._element.xpath("./p:timing")):
            lane="respect-explicit-layout"
        else:
            master=slide.slide_layout.slide_master
            if master.part.partname not in themes:
                themes[master.part.partname]=theme_for(slide,scene_colors)
            c=Canvas(deck,slide,themes[master.part.partname])
            c.photos=can_use_art(c,ready.get(i,[]))
            c.page_number=i
            c.plan=plan
            c.night=night
            c.art_slots=[]
            artwork=any(s.shape_type not in (Shape.PLACEHOLDER,Shape.TEXT_BOX,Shape.AUTO_SHAPE,
                        Shape.PICTURE,Shape.GROUP,Shape.CHART,Shape.TABLE) or
                        (s.shape_type==Shape.AUTO_SHAPE and not (s.has_text_frame and s.text.strip())) or
                        s._element.xpath("./p:spPr/a:blipFill") for s in c.items)
            # Unsupported original art/relationships require a tailored pass. Never paint over them.
            lane=None
            unsupported_inline=any(s.has_text_frame and not ordinary_text(s) for s in c.items)
            inherited_art=any(not s.is_placeholder for part in (slide.slide_layout,master) for s in part.shapes)
            if not artwork and not inherited_art and not unsupported_inline and c.title is not None:
                original_csld=deepcopy(slide._element.cSld)
                try:
                    if not (c.charts or c.groups or c.tables) and (not c.pics or c.photos):
                        lane=text_composition(c,i,str(cfg.get("purpose") or cfg.get("intent") or "").casefold())
                    else:
                        lane=chart_spread(c) or table_layout(c) or gallery(c) or figure_spread(c)
                    if lane:
                        from semantic_icons import apply_semantic_icons
                        icons=apply_semantic_icons(c,plan,i,lane)
                        if not (c.photos or c.groups or c.charts or c.pics or c.tables):
                            from semantic_icons import authorized
                            if authorized(plan,i,empty=True):
                                source_lines=[t for s in c.items if s.shape_id in c.source_copy for t in c.source_copy[s.shape_id]]
                                anchor="；".join(source_lines)
                                explicit=cfg.get("scene_brief")
                                if not isinstance(explicit,str):
                                    explicit=""
                                if lane=="display-title":
                                    context="、".join(t for t in headings[i:i+3] if t)
                                    subject=explicit.strip() or f"原稿主題「{anchor[:140]}」，內頁涵蓋「{context}」。以符合這份原稿的真實工作、工具或環境細節，構成一張可用在封面的獨立主圖。"
                                    c.art_slots.append({"role":"hero_photo","candidate":True,"name":f"opening-scene-{i}",
                                        "anchor_text":anchor,"focus":[.72,.50],
                                        "brief":subject})
                                elif lane=="section-and-list":
                                    c.art_slots.append({"role":"editorial_photo","candidate":True,"name":f"section-scene-{i}",
                                        "anchor_text":anchor,"focus":[.50,.48],"box":[0,0,1,.34],
                                        "brief":explicit.strip() or f"取材自「{anchor[:240]}」。選其中一件能直接觀察的工作，近距離拍手與工具的互動。主體集中在水平中帶，適合寬幅取景。"})
                                elif lane=="statement-spread" and len(source_lines)>1:
                                    if explicit.strip():
                                        role="subject_cutout" if cfg.get("scene_role")=="subject_cutout" else "editorial_photo"
                                        c.art_slots.append({"role":role,"name":f"subject-{i}","brief":explicit.strip(),
                                                            "anchor_text":anchor})
                                    elif observed_activity(anchor):
                                        c.art_slots.append({"role":"editorial_photo","candidate":True,"name":f"activity-{i}",
                                            "anchor_text":anchor, "focus":[.53,.50],
                                            "brief":f"依據「{anchor[:240]}」，以匿名人物執行文中工作的一個瞬間表達內容。近距離取景，保留手勢、器材或動作的關係，適合水平裁切。"})
                                    else:
                                        c.art_slots.append({"role":"cutout","candidate":True,"name":f"subject-{i}",
                                            "anchor_text":anchor,"box":[.51,.095,.472,.837]})
                except DensityNeeded:
                    c.art_slots=[]
                    slide._element.replace(slide._element.cSld,original_csld)
                    lane="custom-composition-needed"
            lane=lane or "custom-composition-needed"
        record={"page":i,"composition":lane}
        if c and c.art_slots:
            record["art_slots"]=c.art_slots
        if icons:
            record["native_art"]=icons
        results.append(record)
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=destination.parent,suffix=".pptx",delete=False) as temp:
        temp_path=Path(temp.name)
    try:
        deck.save(temp_path)
        if len(Presentation(temp_path).slides)!=len(results):
            raise ValueError("Incomplete composed deck.")
        os.link(temp_path,destination)
    finally:
        temp_path.unlink(missing_ok=True)
    return {"pages":results,"requires_custom_layout":[row["page"] for row in results if row["composition"]=="custom-composition-needed"]}


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("source",type=Path)
    cli.add_argument("--out",required=True,type=Path)
    cli.add_argument("--plan",type=Path)
    cli.add_argument("--report",type=Path)
    cli.add_argument("--art",type=Path,help="Reviewed artwork of this job, identified by page and slot name.")
    args=cli.parse_args()
    doc=json.loads(args.plan.read_text()) if args.plan else {}
    art=json.loads(args.art.read_text()) if args.art else {}
    assets=art.get("assets",[])
    if args.art:
        assets=[{**row,"file":str((args.art.parent/row["file"]).resolve())} if row.get("file") else row for row in assets]
    result=compose(args.source,args.out,doc.get("plan",doc),assets)
    output=json.dumps(result,ensure_ascii=False,indent=2)
    if args.report:
        args.report.write_text(output+"\n",encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
