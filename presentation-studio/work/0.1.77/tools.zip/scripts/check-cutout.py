#!/usr/bin/env python3
"""Measure a cutout's original PNG bytes. Print a digest-bound JSON decision."""
import argparse
import hashlib
import io
import json
import re
import unicodedata
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

CHECKER = "presentation-studio-cutout-v1"
ROLES = {"cutout", "icon", "small_illustration", "subject_cutout"}


PROTECTED_ROLES = {"protected", "evidence", "screenshot", "data_chart", "chart", "table"}


def requires_cutout(asset):
    kind, role = asset.get("kind"), asset.get("role")
    if (asset.get("protected") is True or asset.get("action") == "keep"
            or kind in PROTECTED_ROLES or role in PROTECTED_ROLES):
        return False
    requested = asset.get("transparent_cutout")
    if type(requested) is bool:
        return requested
    if kind in ROLES or role in ROLES:
        return True
    if role:
        return False
    if asset.get("action") not in ("add", "redraw") or kind not in (None, "", "image", "picture", "raster"):
        return False
    # Only legacy raster layer identifiers. Media descriptions and geometry are never examined.
    name = unicodedata.normalize("NFKC", str(asset.get("name") or "")).strip().lower()
    if not name or len(name) > 48 or len(name.split()) > 5 or not re.fullmatch(r"[\w\u3400-\u9fff -]+", name):
        return False
    if re.search(r"截圖|圖表|照片|畫面擷取|(?:^|[ _-])(?:screenshot|photo|chart|table)(?:$|[ _-])", name):
        return False
    return bool(re.search(r"(?:圖示|小插圖|(?:^|[ _\-\u3400-\u9fff])icon)(?:[ _-]?\d{1,2})?$", name))


def longest_run(line):
    positions = np.flatnonzero(np.diff(np.r_[False, line, False]))
    return int(max(positions[1::2] - positions[::2], default=0))


def printed_checker(rgb, solid):
    # A repeating two-tone neutral pattern on both axes, as seen in flattened transparency previews.
    neutral = np.ptp(rgb, axis=2) <= 5
    gray = rgb[:, :, 0]
    values = gray[neutral & solid]
    if values.size < 32:
        return False
    counts = np.bincount(values, minlength=256)
    lo, hi = sorted(np.argsort(counts)[-2:])
    if lo < 120 or hi - lo < 8 or min(counts[lo], counts[hi]) < solid.sum() * .12:
        return False
    pattern = neutral & solid & ((gray == lo) | (gray == hi))
    if pattern.sum() < solid.sum() * .58:
        return False
    def regular(rows, mask):
        for line, allowed in zip(rows[::max(1, len(rows)//16)], mask[::max(1, len(rows)//16)]):
            jumps = np.flatnonzero(allowed[1:] & allowed[:-1] & (line[1:] != line[:-1]))
            lengths = np.diff(jumps)
            if len(lengths) >= 3 and np.median(np.abs(lengths - np.median(lengths))) <= 1:
                return True
        return False
    return regular(gray, pattern) and regular(gray.T, pattern.T)


def inspect(file):
    try:
        data = Path(file).read_bytes()
    except OSError:
        return {"checker": CHECKER, "status": "unverified", "reasons": ["original_unavailable"], "metrics": {}}
    return inspect_bytes(data)


def inspect_bytes(data):
    result = {"checker": CHECKER, "status": "rejected", "reasons": [], "metrics": {}}
    result["sha256"] = hashlib.sha256(data).hexdigest()
    reasons = result["reasons"]
    try:
        with Image.open(io.BytesIO(data)) as image:
            result["width"], result["height"] = image.size
            if image.format != "PNG":
                reasons.append("not_png")
                return result
            image.load()
            pixels = image.convert("RGBA")
    except (OSError, ValueError, Image.DecompressionBombError):
        reasons.append("invalid_png")
        return result
    pixels.thumbnail((640, 640), Image.Resampling.NEAREST)
    rgba = np.array(pixels)
    rgb, alpha = rgba[:, :, :3], rgba[:, :, 3]
    h, w = alpha.shape
    solid = alpha >= 180
    peak = int(alpha.max())
    visible = alpha >= max(20, round(peak * .42))
    metrics = result["metrics"]
    # Count exterior-connected transparency, independent of the RGB stored beneath alpha.
    pad = np.pad(alpha <= 15, 1, constant_values=True)
    connected = Image.fromarray(pad.astype(np.uint8) * 255).copy()
    ImageDraw.floodfill(connected, (0, 0), 127)
    exterior = np.asarray(connected)[1:-1, 1:-1] == 127
    metrics.update(exterior_fraction=round(float(exterior.mean()), 6),
                   visible_fraction=round(float(visible.mean()), 6), peak_alpha=peak)
    if peak < 20 or visible.sum() < 4:
        reasons.append("empty_subject")
    if exterior.sum() < max(4, .015 * w*h):
        if printed_checker(rgb, solid):
            reasons.append("printed_checkerboard")
        elif np.mean((rgb.min(axis=2) > 244) & solid) > .55:
            reasons.append("opaque_white_background")
        else:
            reasons.append("missing_exterior_transparency")
    if visible.any():
        yy, xx = np.nonzero(visible)
        metrics["subject_bbox_fraction"] = [round(float(v), 5) for v in
                    (xx.min()/w, yy.min()/h, (xx.max()+1)/w, (yy.max()+1)/h)]
        # Weak contact shadows and isolated antialiased edge pixels do not indicate clipping.
        core = alpha >= max(120, round(peak * .75))
        edges = [core[0], core[-1], core[:, 0], core[:, -1]]
        clipped = [side for side, edge in zip(("top","bottom","left","right"), edges)
                   if longest_run(edge) >= max(3, round(len(edge)*.025))]
        metrics["clipped_edges"] = clipped
        if clipped and exterior.any():
            reasons.append("subject_clipped")
    if solid.any() and exterior.any():
        yy, xx = np.nonzero(solid)
        ys, xs = slice(yy.min(), yy.max()+1), slice(xx.min(), xx.max()+1)
        patch, mask = rgb[ys, xs], solid[ys, xs]
        if min(mask.shape) >= 8 and mask.mean() >= .975:
            # Reject an opaque *rectangular backing with inner artwork*. A white silhouette
            # or a simple solid white glyph over genuine alpha does not meet these conditions.
            white = (patch.min(axis=2) >= 240) & (np.ptp(patch, axis=2) <= 12)
            border = np.r_[white[0], white[-1], white[:, 0], white[:, -1]]
            if printed_checker(patch, mask):
                reasons.append("printed_checkerboard")
            elif border.mean() >= .96 and white.mean() >= .32 and ((patch.min(axis=2) < 200) & mask).mean() >= .025:
                reasons.append("rectangular_white_backing")
    if not reasons:
        result["status"] = "ready"
    return result


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("file", type=Path)
    print(json.dumps(inspect(cli.parse_args().file), ensure_ascii=False))
