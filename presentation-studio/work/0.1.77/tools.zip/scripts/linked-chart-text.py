#!/usr/bin/env python3
"""Restore the typography of a linked column/line chart using its actual image, source data and editable Slides text."""
import argparse
import hashlib
import importlib.util
import json
import re
from pathlib import Path

import fitz
import numpy as np
from pptx import Presentation
from pptx.oxml.ns import qn


def require(condition, message):
    if not condition:
        raise ValueError(message)


def measure(value):
    return value["magnitude"] / (12700 if value.get("unit") == "EMU" else 1)


def pt(v):
    return {"magnitude":float(v),"unit":"PT"}


def normalize(s):
    return re.sub(r"\s+","",s)


def chart_spec(chart):
    basic = chart["spec"]["basicChart"]
    rows = [s for s in basic["series"] if s.get("lineStyle",{}).get("type") != "INVISIBLE"]
    require(sum(s.get("type",basic["chartType"])=="COLUMN" for s in rows)==1 and
            all(s.get("type",basic["chartType"]) in ("COLUMN","LINE") for s in rows),
            "This calibrated repair supports a combo with one column series and line series.")
    require(basic.get("stackedType","NOT_STACKED") in ("NOT_STACKED","BASIC_CHART_STACKED_TYPE_UNSPECIFIED"),
            "Stacked series need a separate coordinate calibration.")
    return basic,rows


def prepare(chart, bounds, width=None):
    basic,rows=chart_spec(chart)
    basic["legendPosition"]="NO_LEGEND"
    for row in rows:
        row["dataLabel"]={"type":"NONE"}
    requests=[]
    if bounds:
        # The caller first verifies this dedicated range is empty, or already belongs to this exact chart.
        col, lo, hi = int(bounds["columnIndex"]),float(bounds["min"]),float(bounds["max"])
        sid=bounds["sheetId"]
        domains=basic.get("domains",[])
        ranges=domains[0]["domain"]["sourceRange"]["sources"] if len(domains)==1 else []
        require(len(ranges)==1 and ranges[0].get("endColumnIndex",1)-ranges[0].get("startColumnIndex",0)==1,
                "Use an auxiliary calibration range aligned to the real category range.")
        n=ranges[0]["endRowIndex"]-ranges[0].get("startRowIndex",0)
        require(n>=3 and basic.get("headerCount",1)==1,"Bound calibration needs a header and at least two values.")
        helper={"sheetId":sid,"startRowIndex":bounds["rowIndex"],"endRowIndex":bounds["rowIndex"]+n,
                "startColumnIndex":col,"endColumnIndex":col+1}
        for row in rows+[{"series":d["domain"]} for d in basic.get("domains",[])]:
            for r in row["series"].get("sourceRange",{}).get("sources",[]):
                if r.get("sheetId",0)==sid:
                    require(helper["endColumnIndex"]<=r.get("startColumnIndex",0) or helper["startColumnIndex"]>=r.get("endColumnIndex",1e9) or
                            helper["endRowIndex"]<=r.get("startRowIndex",0) or helper["startRowIndex"]>=r.get("endRowIndex",1e9),
                            "Choose an unused calibration range outside the chart's source ranges.")
        requests.append({"updateCells":{"start":{"sheetId":sid,"rowIndex":bounds["rowIndex"],"columnIndex":col},
            "rows":[{"values":[{"userEnteredValue":{"stringValue":bounds.get("label","Axis scale")}}]},
                    {"values":[{"userEnteredValue":{"numberValue":lo}}]}]+[
                    {"values":[{"userEnteredValue":{"numberValue":hi}}]} for _ in range(n-2)],
            "fields":"userEnteredValue"}})
        if not any(s.get("series",{}).get("sourceRange",{}).get("sources")==[helper] for s in basic["series"]):
            basic["series"].append({"series":{"sourceRange":{"sources":[helper]}},"targetAxis":bounds["axis"],"type":"LINE",
                "lineStyle":{"type":"INVISIBLE"},"pointStyle":{"size":0},"colorStyle":{"rgbColor":{"red":1,"green":1,"blue":1}},
                "dataLabel":{"type":"NONE"}})
    requests.append({"updateChartSpec":{"chartId":chart["chartId"],"spec":chart["spec"]}})
    if width:
        overlay=chart["position"]["overlayPosition"]
        require(width>0 and overlay.get("widthPixels",0)>0,"Read back the actual overlay dimensions.")
        target={**overlay,"widthPixels":width,"heightPixels":round(width*overlay["heightPixels"]/overlay["widthPixels"])}
        requests.append({"updateEmbeddedObjectPosition":{"objectId":chart["chartId"],
            "newPosition":{"overlayPosition":target},"fields":"widthPixels,heightPixels"}})
    return requests


def chart_reference(pptx,pdf,page,chart_index):
    helper=Path(__file__).with_name("chart-fidelity.py")
    spec=importlib.util.spec_from_file_location("chart_fidelity",helper)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    plan=mod.chart_plan(pptx,pdf,page,chart_index,None)
    require(not plan["review"],"Resolve source labels in the reference rendering before projecting them.")
    deck=Presentation(pptx)
    shapes=[s for s in deck.slides[page-1].shapes if s.has_chart]
    shape=shapes[chart_index]
    ws,hs=deck.slide_width/12700,deck.slide_height/12700
    box=fitz.Rect([v*(hs if i%2 else ws) for i,v in enumerate(plan["region"])])
    with fitz.open(pdf) as d:
        p=d[page-1];ratio=ws/p.rect.width
        require(abs(hs/p.rect.height-ratio)<.01,"Different PowerPoint canvas ratio.")
        lines=[]
        for b in p.get_text("dict",clip=box/ratio)["blocks"]:
            for line in b.get("lines",[]):
                spans=line["spans"]
                text="".join(s["text"] for s in spans).strip()
                if text:
                    bnd=fitz.Rect(line["bbox"])*ratio
                    lines.append({"text":text,"x":(bnd.x0+bnd.x1)/2,"y":(bnd.y0+bnd.y1)/2,"w":bnd.width,
                                  "font":max(s["size"] for s in spans)*ratio})
    series=shape.chart._chartSpace.xpath(".//c:plotArea/*[c:ser]/c:ser")
    datasets=[]
    for ser, row in zip(series,plan["series"]):
        datasets.append(dict(row,values=[float(e.text) for e in ser.xpath("c:val//c:pt/c:v")],
                             cats=[e.text for e in ser.xpath("c:cat//c:pt/c:v")]))
    cats=datasets[0]["cats"]
    require(len(cats)>=3 and len(cats)==len(set(cats)) and all(s["cats"]==cats for s in datasets),
            "Need at least three distinct shared categories to calibrate the chart.")
    def match(value):
        found=[r for r in lines if normalize(r["text"])==normalize(value)]
        require(len(found)==1,"Find the unique source-render text for "+str(value))
        return found[0]
    category=[match(c) for c in cats]
    for row in datasets:
        row["legend"]=match(row["name"])
    axes={"LEFT_AXIS":[],"RIGHT_AXIS":[]}
    measured_labels = []
    for dataset in datasets:
        for point in dataset["labels"]:
            x0,y0,x1,y1 = point["rect"]
            measured_labels.append((normalize(point["text"]),(x0+x1)*ws/2,(y0+y1)*hs/2))
    for line in lines:
        # The first or last data point's label may lie beyond its category center.
        # Identify that specific rendered label by its measured box, keeping a tick
        # with identical text at another location (including repeated numeric zeros).
        if any(normalize(line["text"])==token and abs(line["x"]-x)<1 and abs(line["y"]-y)<1
               for token,x,y in measured_labels):
            continue
        token=line["text"].strip().replace(",","")
        if re.fullmatch(r"-?\d+(\.\d+)?%?",token):
            side="LEFT_AXIS" if line["x"]<category[0]["x"]-6 else "RIGHT_AXIS" if line["x"]>category[-1]["x"]+6 else None
            if side:
                axes[side].append(dict(line,value=float(token.rstrip("%"))/(100 if token.endswith("%") else 1)))
    require(all(len(rows)>=2 for rows in axes.values()),"Need both source-render quantitative axes.")
    # Explicit source endpoints can fall between major ticks, e.g. 0.05–0.75.
    # Keep these real limits when the rendered labels only span 0.1–0.7.
    declared = shape.chart._chartSpace.xpath(".//c:plotArea/c:valAx[c:axPos[@val='r']]")
    if len(declared) == 1:
        for key in ("min", "max"):
            limit = declared[0].xpath("c:scaling/c:" + key + "/@val")
            if limit:
                axes["RIGHT_AXIS"][0]["window_" + key] = float(limit[0])
    return box,category,datasets,axes,ws,hs


def chart_pixels(pdf,page,box,ws):
    with fitz.open(pdf) as d:
        p=d[page-1];ratio=p.rect.width/ws
        target=box*ratio
        match=[r for r in p.get_image_info(xrefs=True) if r["xref"] and
               (fitz.Rect(r["bbox"]) & target).get_area()>=.94*target.get_area() and
               (fitz.Rect(r["bbox"]) & target).get_area()>=.94*fitz.Rect(r["bbox"]).get_area()]
        require(len(match)==1,"Need the uniquely matching linked chart image from the latest Google PDF.")
        pix=fitz.Pixmap(d,match[0]["xref"])
        if pix.colorspace.n!=3:
            pix=fitz.Pixmap(fitz.csRGB,pix)
        return np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[:,:,:3],fitz.Rect(match[0]["bbox"])/ratio


def rgb(row):
    c=row.get("colorStyle",{}).get("rgbColor",row.get("color"))
    require(c is not None,"Read the actual series color from this Sheets chart.")
    return {key:c.get(key,0) for key in ("red","green","blue")}


def pixels_for_color(pixels,color):
    arr=np.array([color[k]*255 for k in ("red","green","blue")],dtype=float)
    return np.max(np.abs(pixels.astype(np.int16)-arr),axis=2)<18


def affine(x,y,eps):
    x,y=np.asarray(x),np.asarray(y)
    require(np.ptp(x)>1e-8,"The axis needs two distinct calibration values.")
    a,b=np.polyfit(x,y,1)
    require(float(np.max(np.abs(a*x+b-y)))<eps,"Series geometry contradicts the source values or line color.")
    return float(a),float(b)


def plot_geometry(pixels, frame, rows):
    h,w=pixels.shape[:2]
    column=next(s for s in rows if s["type"]=="COLUMN")
    mask=pixels_for_color(pixels,column["color"]);counts=mask.sum(axis=0)
    cols=np.flatnonzero(counts>max(4,.025*h))
    n=len(column["values"])
    parts=[p for p in np.split(cols,np.flatnonzero(np.diff(cols)>max(2,w/(n*115)))+1) if len(p)>2]
    require(len(parts)>=n,"Too few physical columns. Resolve the series color from this sheet or its XLSX export.")
    # A JPEG-published chart can contain tall 3px replicas of a colored edge next to
    # every real 100px bar. Only discard fragments small relative to actual bar widths.
    widths=sorted((len(block) for block in parts),reverse=True)[:n]
    minimum=max(3,.20*float(np.median(widths)))
    blocks=[part for part in parts if len(part)>=minimum]
    require(len(blocks)==n and max(len(block) for block in blocks)<1.50*min(len(block) for block in blocks),
            "Physical column widths or count contradict the current sheet. Inspect the chart image and series identity.")
    cx=np.array([(b[0]+b[-1])/2 for b in blocks])
    require(np.max(abs(np.diff(cx)-np.median(np.diff(cx))))<w*.015,"Category spacing is inconsistent.")
    X=lambda px:frame.x0+px*frame.width/w
    Y=lambda px:frame.y0+px*frame.height/h
    native_x=np.array([X(a) for a in cx]);fits={}
    bar_floors=[]
    for s in rows:
        mask=pixels_for_color(pixels,s["color"])
        ys=[]
        for i,x in enumerate(cx):
            # Sample the center half of an entire column: a crossing line can cover
            # the top at a single x and bias an extrapolated zero by a full text line.
            radius=max(3,len(blocks[i])//4) if s["type"]=="COLUMN" else max(3,round(w/(n*41)))
            part=mask[:,max(0,int(round(x))-radius):int(round(x))+radius+1]
            quorum=max(2,.15*part.shape[1]) if s["type"]=="COLUMN" else 1
            loc=np.flatnonzero(part.sum(axis=1)>=quorum)
            if s["type"]=="COLUMN" and len(loc)>0:
                sections=np.split(loc,np.flatnonzero(np.diff(loc)>2)+1)
                credible=[section for section in sections if len(section)>=3]
                loc=np.concatenate(credible) if credible else np.array([])
                if len(loc):
                    bar_floors.append(Y(loc.max()+1))
            require(len(loc)>0,"Cannot locate the actual current point of "+s["name"])
            ys.append(Y(loc.min() if s["type"]=="COLUMN" else np.median(loc)))
        s["native_y"]=ys
        if np.ptp(s["values"])>1e-8:
            fits.setdefault(s["axis"],affine(s["values"],ys,frame.height*.014))
    require(all(k in fits for k in ("LEFT_AXIS","RIGHT_AXIS")),"Both real value axes need calibrating.")
    require(len(bar_floors)==n and np.ptp(bar_floors)<frame.height*.006,"No common physical baseline for these columns.")
    floor=float(np.median(bar_floors))
    if min(column["values"])>=0 and abs(fits[column["axis"]][1]-floor) < frame.height*.025:
        for axis,(slope,zero) in list(fits.items()):
            if abs(zero-floor)>frame.height*.025:
                continue
            values=np.array([v for row in rows if row["axis"]==axis for v in row["values"]])
            positions=np.array([v for row in rows if row["axis"]==axis for v in row["native_y"]])
            anchored=float(np.dot(values,positions-floor)/np.dot(values,values))
            if max(abs(anchored*values+floor-positions))<frame.height*.014:
                fits[axis]=(anchored,floor)
    neutral=(np.ptp(pixels.astype(np.int16),axis=2)<5)&(pixels[:,:,0]>135)&(pixels[:,:,0]<240)
    good=np.flatnonzero(neutral.sum(axis=1)>w*.48)
    require(len(good)>0,"Could not locate native plot grid lines.")
    runs=[]
    for yy in good:
        edges=np.flatnonzero(neutral[yy]);groups=np.split(edges,np.flatnonzero(np.diff(edges)>2)+1)
        runs.extend((g[0],g[-1]) for g in groups if len(g)>2)
    l,r=max(runs,key=lambda v:v[1]-v[0])
    require(r-l>w*.48,"A complete horizontal grid line is needed.")
    left,right=X(l),X(r)
    return native_x,fits,left,right,floor


def make_plan(pptx,pptx_pdf,google_pdf,native,chart,names,page,element_id,chart_index,old_ids):
    ref,categories,source,axes,ws,hs=chart_reference(pptx,pptx_pdf,page,chart_index)
    slide=native["slides"][page-1];by_id={e["objectId"]:e for e in slide["pageElements"]}
    el=by_id[element_id];require(el["sheetsChart"]["chartId"]==chart["chartId"],"Chart ID mismatch.")
    pw,ph=measure(native["pageSize"]["width"]),measure(native["pageSize"]["height"])
    u=pw/ws;require(abs(ph/hs-u)<.001,"Canvas aspect ratio mismatch.")
    tr=el["transform"];require(not tr.get("shearX") and not tr.get("shearY") and tr["scaleX"]>0 and tr["scaleY"]>0,
        "Use an axis-aligned linked chart.")
    def length(value):return value/(12700 if tr.get("unit","EMU")=="EMU" else 1)/u
    x0,y0=length(tr["translateX"]),length(tr["translateY"])
    gbox=fitz.Rect(x0,y0,x0+measure(el["size"]["width"])*tr["scaleX"]/u,
                   y0+measure(el["size"]["height"])*tr["scaleY"]/u)
    pixels,imgbox=chart_pixels(google_pdf,page,gbox,ws)
    basic,srows=chart_spec(chart)
    require(basic.get("legendPosition")=="NO_LEGEND" and all(s.get("dataLabel",{}).get("type")=="NONE" for s in srows),
            "First suppress the linked chart's automatic legend/labels and refresh; keep data series visible.")
    src={r["name"]:r for r in source};require(set(src)==set(names) and len(names)==len(srows),"Resolve actual source series names.")
    rows=[dict(src[n],axis=s.get("targetAxis","LEFT_AXIS"),type=s.get("type",basic["chartType"]),color=rgb(s)) for n,s in zip(names,srows)]
    nx,fits,raw_left,raw_right,raw_floor=plot_geometry(pixels,imgbox,rows)
    sx,tx=affine(nx,[c["x"] for c in categories],2)
    la=axes["LEFT_AXIS"]; a,b=affine([r["value"] for r in la],[r["y"] for r in la],2)
    a0,b0=fits["LEFT_AXIS"];sy=a/a0;ty=b-sy*b0
    require(.5<sx<2.0 and .5<sy<2.0,"Native plot calibration requires an implausible stretch.")
    X=lambda x:sx*x+tx
    Y=lambda y:sy*y+ty
    left,right=X(raw_left),X(raw_right);baseline=Y(raw_floor)
    prefix="pst52_"+hashlib.sha256(element_id.encode()).hexdigest()[:10]+"_"
    require(all(e in by_id and e!=element_id for e in old_ids),"Legacy label ID is not an existing text box in this chart.")
    req=[{"deleteObject":{"objectId":i}} for i,e in by_id.items() if i.startswith(prefix) or i in old_ids and e.get("shape",{}).get("shapeType")=="TEXT_BOX"]
    req.append({"updatePageElementTransform":{"objectId":element_id,"applyMode":"ABSOLUTE","transform":{
        "scaleX":tr["scaleX"]*sx,"scaleY":tr["scaleY"]*sy,"translateX":X(x0)*u,"translateY":Y(y0)*u,"unit":"PT"}}})
    def base(i,x,y,w,h,kind):
        require(w>0 and h>0,"Invalid label box.")
        req.append({"createShape":{"objectId":i,"shapeType":kind,"elementProperties":{"pageObjectId":slide["objectId"],
            "size":{"width":pt(w*u),"height":pt(h*u)},"transform":{"scaleX":1,"scaleY":1,"translateX":x*u,"translateY":y*u,"unit":"PT"}}}})
    def rect(key,x,y,w,h,c):
        if w<=0 or h<=0:return
        obj=prefix+key;base(obj,x,y,w,h,"RECTANGLE")
        req.append({"updateShapeProperties":{"objectId":obj,"shapeProperties":{
            "shapeBackgroundFill":{"solidFill":{"color":{"rgbColor":c},"alpha":1}},
            "outline":{"propertyState":"NOT_RENDERED"}},"fields":"shapeBackgroundFill,outline"}})
    expected=[]
    def label(key,text,x,y,font,width,color=None,bold=False):
        expected.append({"key":key,"text":text,"font_pt":float(font),"center":[float(x/ws),float(y/hs)]})
        obj=prefix+key
        width=max(width*1.12+34, font*3)
        height=font*1.45+10
        base(obj,x-width/2,y-height/2,width,height,"TEXT_BOX")
        req.extend([{"updateShapeProperties":{"objectId":obj,"shapeProperties":{"contentAlignment":"MIDDLE",
                "autofit":{"autofitType":"NONE"}},"fields":"contentAlignment,autofit.autofitType"}},
            {"insertText":{"objectId":obj,"text":text}},
            {"updateTextStyle":{"objectId":obj,"textRange":{"type":"ALL"},"style":{
                "fontFamily":"Arial","fontSize":pt(font*u),"bold":bold,
                "foregroundColor":{"opaqueColor":{"rgbColor":color or {}}}},"fields":"fontFamily,fontSize,bold,foregroundColor"}},
            {"updateParagraphStyle":{"objectId":obj,"textRange":{"type":"ALL"},"style":{
                "alignment":"CENTER","lineSpacing":100,"spaceAbove":pt(0),"spaceBelow":pt(0)},
                "fields":"alignment,lineSpacing,spaceAbove,spaceBelow"}}])
    white={"red":1,"green":1,"blue":1};xlo,xhi=X(imgbox.x0)-1,X(imgbox.x1)+1
    yt,yb=Y(imgbox.y0)-.5,Y(imgbox.y1)+.5
    rect("left_mask",xlo,yt,left-xlo-.4,yb-yt,white)
    rect("right_mask",right+.4,yt,xhi-right-.4,yb-yt,white)
    rect("bottom_mask",left,baseline+.7,right-left,yb-baseline-.7,white)
    for side, ticks in axes.items():
        ax_s,ax_t=fits[side]
        for j,t in enumerate(ticks):
            y=Y(ax_s*t["value"]+ax_t)
            require(ref.y0-1<=y<=ref.y1,"A reference tick is outside native chart bounds. Extend the desired axis with the calibration range.")
            x=left-2-t["w"]/2 if side=="LEFT_AXIS" else right+2+t["w"]/2
            label(side.lower()+str(j),t["text"],x,y,t["font"],max(t["w"],len(t["text"])*t["font"]*.61))
    for j,c in enumerate(categories):
        label("cat"+str(j),c["text"].replace(" ",""),X(nx[j]),baseline+c["font"]*.86,c["font"],c["w"]+4)
    for j,s in enumerate(rows):
        leg=s["legend"];lgx=leg["x"];lgy=leg["y"]
        label("legend"+str(j),s["name"],lgx,lgy,leg["font"],leg["w"]+9)
        rect("legend_key"+str(j),lgx-leg["w"]*.67-11,lgy-2.2,7.5,4.4,s["color"])
        for l in s["labels"]:
            i=l["point"];font=l["font_pt"];x=X(nx[i]);is_bar=s["type"]=="COLUMN"
            require(i<len(s["native_y"]),"Missing Google data point.")
            y=baseline-1.1*font if is_bar else Y(s["native_y"][i])-font*1.1
            # Keep line labels above both visible lines at this x, clear of neighbouring markers.
            if not is_bar:
                point_y=Y(s["native_y"][i])
                others=[Y(v["native_y"][i]) for v in rows if v is not s and v["type"]=="LINE"]
                above,below=point_y-font*1.08,point_y+font*1.04
                y=above
                if any(abs(above-other_y)<font*.72 for other_y in others):
                    y=below if all(abs(below-other_y)>font*.72 for other_y in others) else min([point_y]+others)-font*.90
                # A compact label backing keeps orange values legible above a filled column.
                actual_w=fitz.get_text_length(l["text"],fontname="hebo",fontsize=font)
                rect("data_bg"+str(j)+"_"+str(i),x-actual_w/2-1,y-font*.55,actual_w+2,font*1.12,white)
            label("data"+str(j)+"_"+str(i),l["text"],x,y,font,len(l["text"])*font*.75,
                  white if is_bar else s["color"],True)
    return {"presentation_id":native["presentationId"],"write_control":{"requiredRevisionId":native["revisionId"]},
            "requests":req,"expected":expected,"summary":{"chart_id":chart["chartId"],"plot":[left,Y(imgbox.y0),right,baseline],
                "ticks":{k:len(v) for k,v in axes.items()},"categories":len(categories),"legend":len(rows),
                "labels":sum(len(s["labels"]) for s in rows)}}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="action",required=True)
    prep=sub.add_parser("prepare")
    prep.add_argument("chart",type=Path);prep.add_argument("--bounds",type=Path);prep.add_argument("--width",type=int)
    p=sub.add_parser("project")
    for f in ["pptx","pptx_pdf","google_pdf","native","chart","names"]:
        p.add_argument(f,type=Path)
    p.add_argument("--page",required=True,type=int);p.add_argument("--element",required=True)
    p.add_argument("--chart-index",type=int,default=0);p.add_argument("--legacy-label",action="append",default=[])
    a=parser.parse_args()
    load=lambda p:json.loads(p.read_text())
    if a.action=="prepare":result=prepare(load(a.chart),load(a.bounds) if a.bounds else None,a.width)
    else:result=make_plan(a.pptx,a.pptx_pdf,a.google_pdf,load(a.native),load(a.chart),load(a.names),a.page,a.element,a.chart_index,a.legacy_label)
    print(json.dumps(result,ensure_ascii=False,separators=(",",":")))
