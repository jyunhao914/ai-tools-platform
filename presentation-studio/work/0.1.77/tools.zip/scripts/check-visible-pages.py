#!/usr/bin/env python3
"""Inspect final PDF pixels against the adopted page plan. Usage: PLAN.json OUTPUT.pdf.

Normalized body_regions refer to the final layout. Provide them for cover pages
or unusual compositions where meaningful content occupies the heading/footer.
"""
import argparse
import hashlib
import json
import math
import re
import sys
from io import BytesIO
from pathlib import Path

import pymupdf
from PIL import Image, ImageChops, ImageDraw


DEFAULT_BODY = [0.025, 0.18, 0.975, 0.9]
LONG_EDGE = 1200


def edge_strength(img):
    """Maximum local color-channel difference across horizontal and vertical neighbors."""
    neighbors = [ImageChops.difference(img, ImageChops.offset(img, dx, dy)) for dx, dy in ((1, 0), (0, 1))]
    band_max = Image.new('L', img.size)
    for diff in neighbors:
        for band in diff.split():
            band_max = ImageChops.lighter(band_max, band)
    # offset wraps at the edge of the crop
    draw = ImageDraw.Draw(band_max)
    draw.line((0, 0, img.width - 1, 0), fill=0)
    draw.line((0, 0, 0, img.height - 1), fill=0)
    return band_max


def without_straight_rules(mask):
    """Remove long horizontal/vertical rules and rectangular frame corners."""
    clean = mask.copy()
    draw = ImageDraw.Draw(clean)
    for vertical in (False, True):
        scan = mask.transpose(Image.Transpose.TRANSPOSE) if vertical else mask
        width, height = scan.size
        threshold = max(24, math.ceil(width * .22))
        runs = re.compile(b'\xff{' + str(threshold).encode() + b',}')
        data = scan.tobytes()
        for y in range(height):
            base = y * width
            for match in runs.finditer(data, base, base + width):
                start, end = match.start() - base - 2, match.end() - base + 1
                rect = (y-2, start, y+2, end) if vertical else (start, y-2, end, y+2)
                draw.rectangle(rect, fill=0)
    return clean


def get_region(box, size):
    if (not isinstance(box, list) or len(box) != 4 or
            not all(type(v) in (float, int) and math.isfinite(v) and 0 <= v <= 1 for v in box)
            or box[0] >= box[2] or box[1] >= box[3]):
        raise ValueError('body_regions requires nonempty normalized [left,top,right,bottom] rectangles')
    w, h = size
    rect = (math.floor(box[0]*w), math.floor(box[1]*h), math.ceil(box[2]*w), math.ceil(box[3]*h))
    if rect[2]-rect[0] < 3 or rect[3]-rect[1] < 3:
        raise ValueError('body region smaller than three rendered pixels')
    return rect


def count_nonzero(gray):
    return gray.width * gray.height - gray.histogram()[0]


def region_evidence(img, box):
    crop = img.crop(get_region(box, img.size))
    edges = edge_strength(crop)
    strong = without_straight_rules(edges.point(lambda v: 255 if v >= 12 else 0))
    strong_count = count_nonzero(strong)
    # A single small mark or low-contrast text needs actual visual review.
    if strong_count > max(180, crop.width * crop.height * .0014):
        bounds = strong.getbbox()
        if bounds and bounds[2]-bounds[0] > 18 and bounds[3]-bounds[1] > 9:
            return {'region':box, 'status':'visible', 'detail_pixels':strong_count}
    weak = without_straight_rules(edges.point(lambda v: 255 if v else 0))
    weak_count = count_nonzero(weak)
    # A ruler/frame occupies few pixels. Two large flat colors could instead be
    # an intentional diagram, so leave that decision to the visual reviewer.
    sample = crop.resize((min(96, crop.width), min(64, crop.height)), Image.Resampling.NEAREST)
    common = max(n for n, color in sample.getcolors(maxcolors=sample.width*sample.height))
    flat_panel = common < sample.width * sample.height * .95
    return {'region':box, 'status':'uncertain' if weak_count or flat_panel else 'empty_or_rules',
            'detail_pixels':strong_count, 'weak_detail_pixels':weak_count}


def inspect_page(img, expected):
    intention = expected.get('expected_content')
    if intention not in ('body', 'intentionally_blank'):
        raise ValueError('each source page needs an adopted body/intentionally_blank expectation')
    regions = expected.get('body_regions', [DEFAULT_BODY])
    if not isinstance(regions, list) or not regions:
        raise ValueError('body_regions must be a nonempty array')
    evidence = [region_evidence(img, box) for box in regions]
    uniform = all(lo == hi for lo, hi in img.getextrema())
    kinds = {item['status'] for item in evidence}
    if intention == 'intentionally_blank':
        status = 'pass' if kinds == {'empty_or_rules'} else 'needs_review'
        reason = 'intentional_blank' if status == 'pass' else 'unexpected_detail_on_intentional_blank'
    elif uniform:
        status, reason = 'fail', 'uniform_page_with_expected_body'
    elif kinds == {'empty_or_rules'}:
        status, reason = 'fail', 'no_body_detail_in_expected_region'
    elif kinds == {'visible'}:
        status, reason = 'pass', 'body_detail_visible'
    else:
        status, reason = 'needs_review', 'faint_sparse_or_unconfirmed_body_region'
    return {'page_number': expected['page_number'], 'expected_content': intention, 'status': status,
            'reason': reason, 'uniform': uniform, 'regions': evidence}


def apply_type_report(report, comparison, reference_hash):
    """Merge only measurements from this native export and the approved PowerPoint render."""
    rows = comparison.get('pages') if isinstance(comparison, dict) else None
    if (not isinstance(reference_hash, str) or not re.fullmatch(r'[a-f0-9]{64}', reference_hash) or
            not isinstance(rows, list) or comparison.get('pptx_pdf_sha256') != reference_hash or
            comparison.get('slides_pdf_sha256') != report['pdf_sha256'] or
            comparison.get('page_count') != report['page_count'] or len(rows) != report['page_count']):
        raise ValueError('recompare the current native and PowerPoint renders')
    report['pptx_pdf_sha256'] = reference_hash
    for page, measurements in zip(report['pages'], rows):
        if (not isinstance(measurements, dict) or measurements.get('page') != page['page_number'] or
                measurements.get('status') not in ('pass', 'repair', 'needs_review') or
                not isinstance(measurements.get('issues'), list) or
                not isinstance(measurements.get('unmatched'), list)):
            raise ValueError('incomplete rendered text comparison')
        if measurements['issues'] or measurements['status'] == 'repair':
            page['status'] = 'fail'
            page['reason'] = 'rendered_text_size_changed'
            page['type_measurements'] = measurements
        elif measurements['unmatched'] or measurements['status'] == 'needs_review':
            if page['status'] == 'pass':
                page['status'] = 'needs_review'
                page['reason'] = 'review_unmatched_rendered_text'
            page['type_measurements'] = measurements


def check(plan, pdf_path, type_report=None):
    for key in ('artifact_id', 'output_revision'):
        if not isinstance(plan.get(key), str) or not plan[key].strip():
            raise ValueError(f'bind the actual final output {key}')
    doc_bytes = pdf_path.read_bytes()
    digest = hashlib.sha256(doc_bytes).hexdigest()
    report = {'artifact_id':plan['artifact_id'], 'output_revision':plan['output_revision'],
              'pdf_sha256':digest, 'page_count':0, 'status':'fail', 'pages':[], 'errors':[]}
    if plan.get('pdf_sha256') is not None and digest != plan['pdf_sha256']:
        report['errors'].append('expected final PDF digest differs')
        return report
    pages = plan.get('pages')
    if not isinstance(pages, list) or not pages or any(
            not isinstance(row, dict) or type(row.get('page_number')) is not int or row['page_number'] != i
            for i, row in enumerate(pages,1)):
        raise ValueError('adopted pages must be nonempty and correspond to output order')
    with pymupdf.open(stream=doc_bytes, filetype='pdf') as doc:
        report['page_count'] = len(doc)
        if len(doc) != len(pages):
            report['errors'].append('page count differs from adopted plan')
            return report
        for page, expected in zip(doc,pages):
            scale = LONG_EDGE/max(page.rect.width,page.rect.height)
            pix = page.get_pixmap(matrix=pymupdf.Matrix(scale,scale), colorspace=pymupdf.csRGB, alpha=False)
            img = Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
            result = inspect_page(img,expected)
            with BytesIO() as png:
                img.save(png,format='PNG')
                result['render_sha256'] = hashlib.sha256(png.getvalue()).hexdigest()
            report['pages'].append(result)
    if type_report is not None or plan.get('pptx_pdf_sha256') is not None:
        apply_type_report(report, type_report, plan.get('pptx_pdf_sha256'))
    statuses = {row['status'] for row in report['pages']}
    report['status'] = 'fail' if 'fail' in statuses else 'needs_review' if 'needs_review' in statuses else 'pass'
    return report


if __name__ == '__main__':
    try:
        args = argparse.ArgumentParser(description=__doc__)
        args.add_argument('plan', type=Path)
        args.add_argument('pdf', type=Path)
        args.add_argument('--type-report', type=Path, help='JSON from compare-rendered-type.py')
        options = args.parse_args()
        comparison = json.loads(options.type_report.read_text(encoding='utf-8')) if options.type_report else None
        report = check(json.loads(options.plan.read_text(encoding='utf-8')), options.pdf, comparison)
    except (OSError, RuntimeError, TypeError, ValueError, KeyError) as error:
        report = {'status':'fail','pages':[],'errors':[str(error)]}
    print(json.dumps(report,ensure_ascii=False))
    sys.exit({'pass':0, 'needs_review':2, 'fail':1}[report['status']])
