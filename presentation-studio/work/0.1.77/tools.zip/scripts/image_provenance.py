"""Keep AI-image provenance outside the visible copy of a verbatim source redesign."""
import argparse
from collections import defaultdict
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import tempfile
import unicodedata

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE as Shape

from semantic_icons import page_options


DEFAULT_LABEL = "AI 生成示意"
# Entire standalone captions only. Ordinary uses of "示意圖", titles, table values,
# notes and prose that mentions generative AI have no special status.
CAPTIONS = re.compile(
    r"(?:ai|人工智慧|人工智能|chatgpt)(?:原生)?(?:生成|繪製)(?:示意(?:圖|圖片|照片)?|圖像|圖片|照片|插圖)"
    r"|(?:ai|人工智慧)(?:生成|示意圖)|(?:圖片|照片|插圖)由(?:ai|人工智慧|chatgpt)生成"
    r"|ai-?generated(?:illustration|image|photo(?:graph)?)(?:forillustrativepurposes(?:only)?)?",
    re.I)
DISPLAY = r"標示|標記|標明|標註|注明|註明|註記|顯示|加註|加上|標上|呈現|標出"
PROVENANCE = r"ai\s*(?:生成|繪製|圖片|示意)|生成(?:式\s*ai|的?(?:圖片|照片)|圖像來源|來源)|(?:圖片|照片|配圖)來源|人工智(?:慧|能)生成"

def normal(text):
    return "".join(unicodedata.normalize("NFKC",text).lower().split())

def captions_allowed(plan,n):
    owners = [plan,plan.get("settings") or {},plan.get("requirements") or {},page_options(plan,n)]
    for owner in reversed(owners):
        setting=owner.get("visible_ai_attribution",owner.get("image_attribution"))
        if isinstance(setting,bool):
            return setting
        if isinstance(setting,str) and setting in {"visible","on_slide","alt_text","delivery_only","none"}:
            return setting in {"visible","on_slide"}
    for owner in owners:
        for key in ("additional_requirements","custom_instructions","instructions"):
            text=owner.get(key)
            if not isinstance(text,str):
                continue
            for phrase in re.split(r"[，,。；;.!?\n]|但(?:是)?|but ",unicodedata.normalize("NFKC",text).lower()):
                if re.search(r"不(?:要|必|需|得|可|用)|禁止|嚴禁|毋須|勿|don't|do not|never|only in.*(?:alt|notes)|替代文字|備註|交付訊息",phrase):
                    continue
                if re.search(f"(?:{DISPLAY}).{{0,25}}(?:{PROVENANCE})|(?:{PROVENANCE}).{{0,20}}(?:{DISPLAY})",phrase):
                    return True
                if re.search(r"(?:show|label|mark|disclose|credit|caption).{0,35}(?:ai[- ]generated|image attribution|image credit)",phrase):
                    return True
    return False

def annot(shape,label):
    tag=shape._element.xpath("./p:nvPicPr/p:cNvPr")[0]
    previous=tag.get("descr","").strip()
    if normal(label) not in normal(previous):
        tag.set("descr",previous+"\n"+label if previous else label)

def shapes_in(shapes):
    for shape in shapes:
        if shape.shape_type==Shape.GROUP:
            yield from shapes_in(shape.shapes)
        else:
            yield shape

def visible_lines(shapes):
    for sh in shapes:
        if sh.has_text_frame:
            yield sh.text
        elif sh.has_table:
            yield from (c.text for c in sh.table.iter_cells() if not c.is_spanned)
        elif sh.has_chart:
            yield from (node.text or "" for node in sh.chart._chartSpace.xpath(".//c:v|.//a:t"))

def added_captions(originals,candidates):
    grouped=defaultdict(list)
    other=[]
    for shape in candidates:
        if shape.shape_type==Shape.TEXT_BOX and not shape.is_placeholder and CAPTIONS.fullmatch(normal(shape.text)):
            grouped[normal(shape.text)].append(shape)
        else:
            other.append(shape)
    if not grouped:
        return []
    source_text=normal("".join(visible_lines(originals)))
    other_text=normal("".join(visible_lines(other)))
    added=[]
    for caption,shapes in grouped.items():
        keep=max(0,source_text.count(caption)-other_text.count(caption))
        original_boxes=[o for o in originals if o.has_text_frame and normal(o.text)==caption]
        def original_match(shape):
            return any(o.shape_id==shape.shape_id and o.name==shape.name for o in original_boxes)
        ranked=sorted(shapes,key=original_match,reverse=True)
        added.extend(ranked[keep:])
    return added

def digest(pic):
    return sha256(pic.image.blob).hexdigest()

def scan(source, final, plan, ready=(), repair=False):
    issues=[];moved=[]
    if plan.get("mode") not in (3,"3"):
        return {"issues":[],"moved":[],"status":"pass"}
    if len(source.slides)!=len(final.slides):
        raise ValueError("Verify the confirmed source-to-output page mapping first.")
    for n,(a,b) in enumerate(zip(source.slides,final.slides),1):
        options=page_options(plan,n)
        policy=options.get("text_policy",(plan.get("settings") or {}).get("text_policy","preserve"))
        if policy not in {"preserve","verbatim","keep"} or captions_allowed(plan,n):
            continue
        originals=list(shapes_in(a.shapes));candidates=list(shapes_in(b.shapes))
        labels=added_captions(originals,candidates)
        if not labels:
            continue
        original_images={digest(p) for p in originals if p.shape_type==Shape.PICTURE}
        pictures=[p for p in candidates if p.shape_type==Shape.PICTURE and digest(p) not in original_images]
        slots=[r for r in ready if r.get("page_number",r.get("page"))==n]
        if slots:
            known={r.get("sha256") for r in slots if r.get("sha256")}
            pictures=[p for p in pictures if digest(p) in known]
        if not pictures and not slots:
            continue  # no new picture to which a new AI-photo caption could apply
        for label in labels:
            row={"page":n,"caption":label.text,"shape_id":label.shape_id,"shape":label.name}
            if not repair:
                issues.append(row);continue
            # Bind a unique new picture if possible. Never guess which of several
            # pictures is generated or mark a retained source picture.
            if len(pictures)==1:
                annot(pictures[0],label.text)
                row["alt_text_on"]=pictures[0].name
            else:
                row["report_in_delivery"]=True
            label._element.getparent().remove(label._element)
            moved.append(row)
    return {"issues":issues,"moved":moved,"status":"repair" if issues else "pass"}

def save_fresh(deck,destination):
    with tempfile.NamedTemporaryFile(dir=destination.parent,suffix=".pptx",delete=False) as f:
        temp=Path(f.name)
    try:
        deck.save(temp)
        os.link(temp,destination)
    finally:
        temp.unlink(missing_ok=True)

def cli():
    cmd=argparse.ArgumentParser(description=__doc__)
    cmd.add_argument("action",choices=("check","repair"));cmd.add_argument("source",type=Path)
    cmd.add_argument("candidate",type=Path);cmd.add_argument("--plan",required=True,type=Path)
    cmd.add_argument("--out",type=Path);opts=cmd.parse_args()
    doc=json.loads(opts.plan.read_text());plan=doc.get("plan",doc)
    a,b=Presentation(opts.source),Presentation(opts.candidate)
    fix=opts.action=="repair"
    if fix and (not opts.out or opts.out.exists() or opts.out.resolve() in {opts.source.resolve(),opts.candidate.resolve()}):
        cmd.error("Use --out with a fresh work-copy filename.")
    report=scan(a,b,plan,repair=fix)
    if fix:
        save_fresh(b,opts.out)
    print(json.dumps(report,ensure_ascii=False))
    return 2 if report["issues"] else 0

if __name__=="__main__":
    raise SystemExit(cli())
