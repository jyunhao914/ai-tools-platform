"""Inspect a release receipt from the exact current rendered revision."""
import re


def digest(value):
    return isinstance(value, str) and re.fullmatch("[a-fA-F0-9]{64}", value) is not None


def release_state(report, artifact, revision, pages, blank):
    if (not artifact or not revision or type(pages) is not int or pages < 1 or
            not isinstance(report, dict) or report.get("artifact_id") != artifact or
            report.get("output_revision") != revision or not digest(report.get("pdf_sha256")) or
            report.get("page_count") != pages or not isinstance(report.get("pages"), list) or
            len(report["pages"]) != pages or report.get("status") not in ("pass","needs_review","fail")):
        return "render", []
    if report.get("errors"):
        return "render", []
    failed, uncertain = [], []
    for n, row in enumerate(report["pages"], 1):
        expected = "intentionally_blank" if n in blank else "body"
        if (not isinstance(row, dict) or row.get("page_number") != n or row.get("expected_content") != expected
                or not digest(row.get("render_sha256"))):
            return "render", []
        if row.get("status") == "needs_review":
            decision = row.get("visual_review") or {}
            if not (decision.get("pass") is True and decision.get("page") == n and
                    decision.get("pdf_sha256") == report["pdf_sha256"] and
                    isinstance(decision.get("observation"), str) and decision["observation"].strip()):
                uncertain.append(n)
        elif row.get("status") != "pass":
            failed.append(n)
    if failed or report["status"] == "fail":
        return "repair", failed
    if uncertain:
        return "review", uncertain
    return "deliver", []
