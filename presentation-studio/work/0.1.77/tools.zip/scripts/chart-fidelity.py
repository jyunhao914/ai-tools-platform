#!/usr/bin/env python3
"""Recover visible PowerPoint value labels and prepare native Sheets repairs. See visible-delivery.md."""
import argparse
import copy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re

import fitz
from pptx import Presentation
from pptx.oxml.ns import qn


def child_val(nodes, tag, default=None, attribute="val"):
    for node in nodes:
        if node is not None:
            child = node.find(qn("c:" + tag))
            if child is not None and attribute in child.attrib:
                return child.get(attribute)
    return default


def label_text(value, fmt):
    n = Decimal(value)
    if fmt == "General":
        return format(n.normalize(), "f")
    pattern = re.fullmatch(r"(#,##)?0(?:\.(0+))?(%)?", fmt)
    if not pattern:
        return None
    precision = len(pattern[2] or "")
    modifier = "," if pattern[1] else ""
    return format(n * (100 if pattern[3] else 1), f"{modifier}.{precision}f") + (pattern[3] or "")


def label_contract(shape):
    series = []
    review = []
    for group in shape.chart._chartSpace.xpath(".//c:plotArea/*[c:ser]"):
        for ser in group.xpath("c:ser"):
            labels = []
            tx = ser.xpath("c:tx//c:v")
            name = tx[0].text if tx else None
            if not name:
                name = "series " + ser.xpath("c:idx")[0].get("val")
            fmt = ser.xpath("c:val//c:formatCode")
            global_fmt = fmt[0].text if fmt else "General"
            s_labels, g_labels = ser.find(qn("c:dLbls")), group.find(qn("c:dLbls"))
            point_overrides = {}
            for node in [g_labels, s_labels]:
                if node is not None:
                    for flag in node.findall(qn("c:dLbl")):
                        point_overrides.setdefault(child_val([flag],"idx"), []).insert(0,flag)
            flags = [s_labels,g_labels]
            points = ser.xpath("c:val//c:pt | c:yVal//c:pt")
            for point in points:
                idx = point.get("idx")
                rules = point_overrides.get(idx,[]) + flags
                if child_val(rules,"delete") in ("1","true"):
                    continue
                custom = any(el is not None and el.find(qn("c:tx")) is not None for el in rules)
                if custom or any(child_val(rules,key) in ("1","true") for key in ["showCatName","showSerName","showPercent","showBubbleSize"]):
                    labels.append({"point":int(idx),"text":None})
                    review.append(f"{name}[{idx}]: custom label needs source-render review")
                    continue
                if child_val(rules,"showVal") not in ("1","true"):
                    continue
                text = label_text(point.findtext(qn("c:v")),child_val(rules,"numFmt",global_fmt,"formatCode"))
                if text is None:
                    review.append(f"{name}[{idx}]: inspect the source number format")
                labels.append({"point":int(idx),"text":text})
            series.append({"name":name,"point_count":len(points),"labels":labels})
    roles = []
    if shape.chart._chartSpace.xpath(".//c:legend"):
        roles.append("legend")
    for axis in shape.chart._chartSpace.xpath(".//c:plotArea/c:valAx|.//c:plotArea/c:catAx|.//c:plotArea/c:dateAx"):
        if child_val([axis], "delete") in ("1","true") or child_val([axis],"tickLblPos")=="none":
            continue
        pos = child_val([axis],"axPos")
        if pos:
            roles.append("axis_"+pos)
    return {"shape_id":shape.shape_id, "series":series, "review":review, "required_type_roles":sorted(set(roles))}


def chart_shapes(shapes, grouped=False):
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from chart_shapes(shape.shapes, True)
        elif shape.has_chart:
            yield shape, grouped


def frame(deck, shape):
    return [shape.left/deck.slide_width, shape.top/deck.slide_height,
            (shape.left+shape.width)/deck.slide_width, (shape.top+shape.height)/deck.slide_height]


def inventory(path):
    deck = Presentation(path)
    charts = []
    for page, slide in enumerate(deck.slides, 1):
        for shape, grouped in chart_shapes(slide.shapes):
            row = {"page":page, **label_contract(shape)}
            if not grouped:
                row["region"] = frame(deck, shape)
                plots=shape.chart._chartSpace.xpath(".//c:plotArea/*[c:ser]")
                bar=shape.chart._chartSpace.xpath(".//c:plotArea/c:barChart")
                if ({"axis_l","axis_r","legend"}.issubset(row["required_type_roles"]) and
                    len(plots) == 2 and len(bar) == 1 and len(bar[0].xpath("c:ser")) == 1 and
                    bar[0].xpath("c:barDir/@val")==["col"] and bar[0].xpath("c:grouping/@val") not in (["stacked"],["percentStacked"]) and
                    shape.chart._chartSpace.xpath(".//c:plotArea/c:lineChart") and all(s["point_count"]>=3 for s in row["series"])):
                    row["dual_axis_combo"] = True
            charts.append(row)
    return {"pptx_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "charts":charts}


def verify_export(pdf, audit):
    """Check the locations submitted by the visual reviewer against the final native export."""
    digest=hashlib.sha256(pdf.read_bytes()).hexdigest()
    issues=[]
    if digest!=audit.get("slides_pdf_sha256"):
        return {"issues":[{"issue":"Read the final native Google PDF for this audit."}]}
    with fitz.open(pdf) as doc:
        for row in audit.get("rows",[]):
            page_num=row["page"]
            page=doc[page_num-1]
            width,height=page.rect.width,page.rect.height
            image_boxes=[fitz.Rect(i["bbox"]) for i in page.get_image_info()]
            spans=[(str(span["text"]).strip(), fitz.Rect(span["bbox"]))
                   for block in page.get_text("dict",flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)["blocks"]
                   for line in block.get("lines",[]) for span in line["spans"]]
            used=set()
            for label in row.get("labels",[]):
                coords=label.get("rect")
                if not isinstance(coords,list) or len(coords)!=4 or not all(isinstance(v,(int,float)) and 0<=v<=1 for v in coords):
                    issues.append({"page":page_num,"issue":"Supply the measured label rectangle."})
                    continue
                box=fitz.Rect(coords[0]*width,coords[1]*height,coords[2]*width,coords[3]*height)
                if box.is_empty:
                    issues.append({"page":page_num,"issue":"Empty label rectangle."})
                    continue
                matches=[i for i,(t,b) in enumerate(spans) if "".join(t.split())=="".join(label["text"].split()) and
                         (b&box).get_area() >= .65*max(b.get_area(),box.get_area())]
                if len(matches)==1 and matches[0] not in used:
                    used.add(matches[0])
                    continue
                problem={"page":page_num,"series":label.get("series"),"point":label.get("point"),"text":label["text"]}
                if any((im&box).get_area()>=.9*box.get_area() for im in image_boxes):
                    # A chart rendered into one image has no PDF text layer. Bind a
                    # visual transcription to these exact pixels of the final export.
                    pix=page.get_pixmap(matrix=fitz.Matrix(4,4),clip=box,alpha=False)
                    pixel_hash=hashlib.sha256(pix.tobytes("png")).hexdigest()
                    sample=label.get("pixel_review") or {}
                    shades=pix.samples
                    varying=any(max(shades[k::pix.n])-min(shades[k::pix.n])>=24 for k in range(pix.n))
                    if varying and sample.get("crop_sha256")==pixel_hash and sample.get("transcription")==label["text"]:
                        continue
                    problem.update({"crop_sha256":pixel_hash,"rect":coords,"issue":"Inspect the actual chart crop and transcribe the visible label, or repair and re-export."})
                else:
                    problem["issue"]="Data label absent or ambiguous at the reported location."
                issues.append(problem)
    return {"slides_pdf_sha256":digest,"issues":issues}


def chart_plan(pptx, pdf, page_num, chart_index, region):
    deck = Presentation(pptx)
    shape, grouped = list(chart_shapes(deck.slides[page_num-1].shapes))[chart_index]
    if region is None:
        if grouped:
            raise ValueError("Supply the displayed chart --region for a nested group.")
        region = frame(deck, shape)
    with fitz.open(pdf) as document:
        page = document[page_num-1]
        width, height = page.rect.width, page.rect.height
        clip = fitz.Rect(region[0]*width, region[1]*height,region[2]*width,region[3]*height)
        spans = [span for b in page.get_text("dict", clip=clip)["blocks"]
                 for line in b.get("lines",[]) for span in line["spans"] if span["text"].strip()]

    reference = label_contract(shape)
    taken = set()
    def find(token):
        return [(n, span) for n, span in enumerate(spans)
                if "".join(span["text"].split()) == "".join((token or "").split())]
    def cx(span):
        return (span["bbox"][0]+span["bbox"][2])/2
    for ser, details in zip(shape.chart._chartSpace.xpath(".//c:plotArea/*[c:ser]/c:ser"),reference["series"]):
        # In a vertical column / line chart identical labels can belong to different
        # categories. Use real category centers only when the render identifies them.
        cats = {int(pt.get("idx")):find(pt.findtext(qn("c:v"))) for pt in ser.xpath("c:cat//c:pt")}
        places = {i:cx(hits[0][1]) for i,hits in cats.items() if len(hits)==1}
        vertical = ser.getparent().tag == qn("c:lineChart") or (
            ser.getparent().tag == qn("c:barChart") and child_val([ser.getparent()],"barDir")=="col")
        for label in details["labels"]:
            if label["text"] is None:
                continue
            i=label["point"]
            hits=find(label["text"])
            if len(hits)>1 and vertical and i in places and len(places)>1:
                spacing=min(abs(places[i]-other) for j,other in places.items() if i!=j)
                hits=[(n,span) for n,span in hits if spacing>0 and abs(cx(span)-places[i])<spacing*.45]
            if len(hits)!=1 or hits[0][0] in taken:
                reference["review"].append(f"{details['name']}[{i}]: locate distinct label in reference rendering")
                continue
            n,span=hits[0]
            taken.add(n)
            label["font_pt"]=round(span["size"]*(deck.slide_width/12700)/width,2)
            label["rect"]=[round(x/(height if j%2 else width),6) for j,x in enumerate(span["bbox"])]
    return {**reference, "page":page_num,"region":region,
            "pptx_sha256":hashlib.sha256(pptx.read_bytes()).hexdigest(),
            "pptx_pdf_sha256":hashlib.sha256(pdf.read_bytes()).hexdigest()}


def sheet_update(chart, plan, mapping):
    """Input mapping uses source names resolved from the sheet's actual ranges."""
    spec = copy.deepcopy(chart["spec"])
    target = spec["basicChart"]["series"]
    if len(mapping) != len(target) or len(set(mapping)) != len(mapping):
        raise ValueError("Pass a unique source series name for each Sheets series in actual order.")
    named = {s["name"]:s for s in plan["series"]}
    if len(named)!=len(plan["series"]) or set(named)!=set(mapping):
        raise ValueError("Series names differ; resolve actual source ranges before modification.")
    if plan["review"]:
        raise ValueError("Verify unresolved visible labels and their measured sizes in the PowerPoint PDF first.")
    for source_name, series in zip(mapping, target):
        labels = named[source_name]["labels"]
        if not labels:
            series["dataLabel"] = {"type":"NONE"}
            continue
        if len(labels) != named[source_name]["point_count"]:
            raise ValueError("Per-point label visibility must be reproduced with CUSTOM helper cells or native text.")
        text_format = dict(series.get("dataLabel",{}).get("textFormat",{}))
        text_format["fontSize"] = max(1,round(max(l["font_pt"] for l in labels)))
        label = {"type":"DATA", "textFormat":text_format}
        if series.get("type") in ("BAR","COLUMN"):
            label["placement"]="INSIDE_BASE"
        elif series.get("type") == "LINE":
            label["placement"]="ABOVE"
        series["dataLabel"] = label
    return {"updateChartSpec":{"chartId":chart["chartId"],"spec":spec}}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    sub = cli.add_subparsers(dest="mode",required=True)
    inv = sub.add_parser("inventory",help="Read every native chart's data-label visibility directly from its PowerPoint file.")
    inv.add_argument("pptx",type=Path)
    verify = sub.add_parser("verify-export",help="Check the claimed data-label rectangles on a fresh Google Slides PDF.")
    verify.add_argument("pdf",type=Path)
    verify.add_argument("audit",type=argparse.FileType("r",encoding="utf-8"))
    p = sub.add_parser("plan",help="Read original visible value labels and font sizes from the actual local render.")
    p.add_argument("pptx",type=Path)
    p.add_argument("pdf",type=Path)
    p.add_argument("page",type=int)
    p.add_argument("--chart-index",type=int,default=0)
    p.add_argument("--region",type=float,nargs=4)
    q = sub.add_parser("sheets",help="Build an updateChartSpec request from a complete Sheets chart readback.")
    q.add_argument("chart",type=Path)
    q.add_argument("plan",type=Path)
    q.add_argument("names",type=Path,help="JSON list of verified source names in current Sheets order")
    args=cli.parse_args()
    if args.mode == "verify-export":
        out=verify_export(args.pdf,json.load(args.audit))
    elif args.mode == "inventory":
        out=inventory(args.pptx)
    elif args.mode == "plan":
        out=chart_plan(args.pptx,args.pdf,args.page,args.chart_index,args.region)
    else:
        out=sheet_update(*(json.loads(x.read_text()) for x in [args.chart,args.plan,args.names]))
    print(json.dumps(out,ensure_ascii=False,indent=2))
