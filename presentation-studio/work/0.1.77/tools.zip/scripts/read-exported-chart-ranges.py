"""Resolve Sheets chart data ranges when its connector exposes native chart IDs but no chart spec.
Usage: read-exported-chart-ranges.py WORKBOOK_META.json DRIVE_EXPORT_META.json EXPORTED.xlsx
Reads the actual export. An ambiguous chart-to-ID match is left unresolved.
"""
import hashlib
import json
import posixpath
import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from openpyxl.utils.cell import range_boundaries

DOCREL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def related(z, part, kind):
    directory, name = posixpath.split(part)
    relfile = posixpath.join(directory, "_rels", name + ".rels")
    if relfile not in z.namelist():
        return {}
    dest = {}
    for rel in ET.fromstring(z.read(relfile)):
        if rel.get("TargetMode") == "External" or not rel.get("Type", "").endswith("/" + kind):
            continue
        target = rel.get("Target", "")
        dest[rel.get("Id")] = (target.lstrip("/") if target.startswith("/") else
                               posixpath.normpath(posixpath.join(directory, target)))
    return dest


def xml_charts(z, sheet):
    parts = []
    draws = related(z, sheet, "drawing")
    for d in ET.fromstring(z.read(sheet)).findall(".//{*}drawing"):
        drawing = draws.get(d.get("{%s}id" % DOCREL))
        if drawing:
            rels = related(z, drawing, "chart")
            for tag in ET.fromstring(z.read(drawing)).findall(".//{*}chart"):
                part = rels.get(tag.get("{%s}id" % DOCREL))
                if part:
                    parts.append(ET.fromstring(z.read(part)))
    return parts


def grid_range(formula, tabs):
    title, sep, address = formula.rpartition("!")
    if title.startswith("'") and title.endswith("'"):
        title = title[1:-1].replace("''", "'")
    if not sep or title not in tabs or not re.fullmatch(r"\$?[A-Z]+\$?[1-9]\d*(?::\$?[A-Z]+\$?[1-9]\d*)?", address):
        return None
    c1, r1, c2, r2 = range_boundaries(address)
    return {"sheetId": tabs[title], "startColumnIndex": c1 - 1, "endColumnIndex": c2,
            "startRowIndex": r1 - 1, "endRowIndex": r2}


def read(meta, export, path):
    book_id = meta["spreadsheetId"]
    if export.get("file_id") != book_id or export.get("mime_type") != XLSX:
        raise ValueError("Use the authenticated XLSX export from this exact source workbook.")
    blob = path.read_bytes()
    if len(blob) != int(export["size"]):
        raise ValueError("Exported file size differs from the connector receipt.")
    tabs = {s["properties"]["title"]: s["properties"]["sheetId"] for s in meta["sheets"]}
    native = {s["properties"]["title"]: s.get("charts", []) for s in meta["sheets"]}
    results = []
    with ZipFile(path) as z:
        book = "xl/workbook.xml"
        linked = related(z, book, "worksheet")
        for tab in ET.fromstring(z.read(book)).findall(".//{*}sheet"):
            title = tab.get("name")
            sheet_part = linked.get(tab.get("{%s}id" % DOCREL))
            if not sheet_part or not native.get(title):
                continue
            charts = xml_charts(z, sheet_part)
            for row in native[title]:
                if len(charts) == len(native[title]) == 1:
                    match = charts[0]
                else:
                    label = (row.get("spec") or {}).get("title")
                    names = [(c, "".join(t.text or "" for t in c.findall("./{*}chart/{*}title//{*}t"))) for c in charts]
                    candidates = [c for c, text in names if text == label]
                    if not label or len(candidates) != 1 or sum((n.get("spec") or {}).get("title") == label for n in native[title]) != 1:
                        continue
                    match = candidates[0]
                # Restrict to chart series data (including domain, XY or bubble values); exclude series titles.
                series = match.findall(".//{*}plotArea//{*}ser")
                refs = [f.text for s in series for kind in ("cat","val","xVal","yVal","bubbleSize")
                        for f in s.findall("./{*}%s//{*}f" % kind) if f.text]
                if not refs:
                    continue
                ranges = [grid_range(ref,tabs) for ref in dict.fromkeys(refs)]
                if all(ranges):
                    results.append({"sheetId": tabs[title], "chartId": row["chartId"], "ranges": ranges})
    return {"spreadsheetId": book_id, "export_sha256": hashlib.sha256(blob).hexdigest(), "charts":results}


if __name__ == "__main__":
    metadata, receipt, path = map(Path, sys.argv[1:4])
    print(json.dumps(read(json.loads(metadata.read_text()), json.loads(receipt.read_text()), path)))
