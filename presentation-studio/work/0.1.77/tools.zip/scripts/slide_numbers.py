"""Clear presentation folios without treating ordinary numbers as page numbers."""
import re

FOLIO_NAME = re.compile(r"^(?:slide number|page number|投影片編號|投影片號碼|頁碼|幻燈片編號)(?:[ \t_-]*(?:placeholder|版面配置區|預留位置))?[ \t_-]*\d*$", re.I)
FOLIO_VALUE = re.compile(r"(?:第\s*\d+\s*頁|(?:page\s*)?\d+(?:\s*[/／]\s*\d+)?)", re.I)

def inherited_types(root, parent):
    resolved = {}
    for ph in root.xpath(".//p:sp/p:nvSpPr/p:nvPr/p:ph"):
        idx = ph.get("idx", "0")
        resolved[idx] = ph.get("type", parent.get(idx))
    return resolved

def clear_layer(root, inherited):
    changed = False
    for shape in list(root.xpath(".//p:sp")):
        ph = shape.xpath("./p:nvSpPr/p:nvPr/p:ph")
        typed = ph and ph[0].get("type", inherited.get(ph[0].get("idx", "0"))) == "sldNum"
        names = shape.xpath("./p:nvSpPr/p:cNvPr/@name")
        visible = "".join(shape.xpath("./p:txBody//a:t/text()")).strip()
        named_folio = names and FOLIO_NAME.fullmatch(names[0].strip()) and FOLIO_VALUE.fullmatch(visible)
        if typed or named_folio:
            shape.getparent().remove(shape)
            changed = True
            continue
        for field in shape.xpath(".//a:fld"):
            if field.get("type", "").lower() == "slidenum":
                field.getparent().remove(field)
                changed = True
    for hf in root.xpath("./p:hf"):
        if hf.get("sldNum") not in ("0", "false"):
            hf.set("sldNum", "0")
            changed = True
    return changed

def strip_slide_numbers(deck):
    # Capture placeholder inheritance before any layout or master is changed.
    layers = []
    layout_types = {}
    for master in deck.slide_masters:
        master_types = inherited_types(master._element, {})
        for layout in master.slide_layouts:
            layout_types[layout.part] = inherited_types(layout._element, master_types)
            layers.append((layout._element, master_types))
        layers.append((master._element, {}))
    layers.extend((slide._element, layout_types[slide.slide_layout.part]) for slide in deck.slides)
    changed = False
    for root, inherited in layers:
        if clear_layer(root, inherited):
            changed = True
    return changed
