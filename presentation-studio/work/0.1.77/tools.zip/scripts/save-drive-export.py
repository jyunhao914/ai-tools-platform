"""Persist an actual Google native Slides export delivered inline by an authorized tool.

Pass only the structured connector result (or its keyed fields) through stdin.
Never use a download URL, preview, error body, or the file name as the contents.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import posixpath
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

PDF = "application/pdf"
PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}


def pptx_pages(path):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError("The PPTX ZIP checksum failed.")
        ET.fromstring(archive.read("[Content_Types].xml"))
        presentation = ET.fromstring(archive.read("ppt/presentation.xml"))
        rels = ET.fromstring(archive.read("ppt/_rels/presentation.xml.rels"))
        targets = {r.get("Id"): r.get("Target") for r in rels if r.get("Type", "").endswith("/slide")
                   and r.get("TargetMode") != "External"}
        slides = presentation.findall("p:sldIdLst/p:sldId", NS)
        for slide in slides:
            target = targets[slide.get("{" + NS["r"] + "}id")]
            location = posixpath.normpath(posixpath.join("ppt", target)).lstrip("/")
            part = ET.fromstring(archive.read(location))
            if part.tag != "{" + NS["p"] + "}sld":
                raise ValueError("A slide relationship does not resolve to a presentation slide.")
        return len(slides)


def pdf_pages(path):
    with path.open("rb") as stream:
        if stream.read(5) != b"%PDF-":
            raise ValueError("The file lacks its PDF header.")
        stream.seek(max(0,path.stat().st_size-2048))
        if b"%%EOF" not in stream.read():
            raise ValueError("The PDF export is truncated.")
    try:
        import fitz
    except ImportError:
        try:
            from pypdf import PdfReader
        except ImportError:
            if not shutil.which("pdfinfo"):
                raise ValueError("Use an installed PDF reader to verify the export.")
            report = subprocess.run(["pdfinfo", str(path)], capture_output=True, text=True, check=True)
            return int(next(line.split(":",1)[1] for line in report.stdout.splitlines() if line.startswith("Pages:")))
        return len(PdfReader(path).pages)
    with fitz.open(path) as document:
        for page in document:
            _ = page.rect
        return document.page_count


def save(result, dest, native_id, mime, expected_pages=None):
    if not isinstance(result,dict) or result.get("isError") or result.get("error"):
        raise ValueError("The export tool did not return a successful result.")
    body = result.get("structuredContent", result)
    if not isinstance(body,dict) or body.get("id") != native_id or body.get("mime_type") != mime or body.get("is_empty"):
        raise ValueError("The structured result does not match the requested native file and export type.")
    data = body.get("b64_string")
    size = body.get("file_size_bytes")
    if not isinstance(data,str) or not data or type(size) is not int or size <= 0:
        raise ValueError("The connector did not return inline bytes with a positive byte length.")
    if len(data) != ((size+2)//3)*4:
        raise ValueError("The inline response is incomplete or has an inconsistent size.")
    raw = base64.b64decode(data, validate=True)
    if len(raw) != size:
        raise ValueError("Decoded bytes differ from the connector's announced size.")
    if mime not in (PDF, PPTX) or dest.suffix.lower() != (".pdf" if mime == PDF else ".pptx"):
        raise ValueError("Use the actual PDF/PPTX export format and a matching destination.")
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=dest.parent, prefix=".drive-export-", suffix=dest.suffix, delete=False) as out:
        tmp = Path(out.name)
        try:
            out.write(raw)
            out.flush()
            pages = pdf_pages(tmp) if mime == PDF else pptx_pages(tmp)
            if not pages or (expected_pages is not None and pages != expected_pages):
                raise ValueError("The export has an unexpected page count.")
            digest = hashlib.sha256(raw).hexdigest()
            try:
                os.link(tmp,dest)
            except FileExistsError:
                if hashlib.sha256(dest.read_bytes()).hexdigest() != digest:
                    raise ValueError("This output path already contains a different export.")
        finally:
            tmp.unlink(missing_ok=True)
    return {"source_id":native_id,"mime_type":mime,"size_bytes":size,"pages":pages,"sha256":digest,"path":str(dest)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--source-id", required=True)
    parser.add_argument("--mime-type", choices=[PDF,PPTX], required=True)
    parser.add_argument("--pages", type=int)
    args = parser.parse_args()
    try:
        print(json.dumps(save(json.load(sys.stdin),args.destination,args.source_id,args.mime_type,args.pages)))
    except (ValueError,OSError,ET.ParseError,zipfile.BadZipFile,KeyError,RuntimeError,StopIteration,subprocess.CalledProcessError) as error:
        parser.exit(2, str(error)+"\n")
