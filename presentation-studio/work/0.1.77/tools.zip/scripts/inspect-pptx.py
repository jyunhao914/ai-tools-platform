#!/usr/bin/env python3
"""Read ordered PPTX structure and extract referenced images; never claim visual reading."""
import argparse
import hashlib
import json
import posixpath
import urllib.parse
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
REL = '{http://schemas.openxmlformats.org/package/2006/relationships}'


STRICT_NS = {
    'http://purl.oclc.org/ooxml/presentationml/main': NS['p'],
    'http://purl.oclc.org/ooxml/drawingml/main': NS['a'],
    'http://purl.oclc.org/ooxml/officeDocument/relationships': NS['r'],
}


def transitional(name):
    if name.startswith('{'):
        namespace, tag = name[1:].split('}', 1)
        return '{' + STRICT_NS.get(namespace, namespace) + '}' + tag
    return name


def raw_picture_equivalent(pic):
    """Only shortcut directly to an unstyled rectangular image with no masks/effects."""
    if any(node.get('hidden') in ('1', 'true') for node in pic.iter()):
        return False
    props = pic.find('p:spPr', NS)
    fill = pic.find('p:blipFill', NS)
    if props is None or fill is None:
        return False
    allowed = {f"{{{NS['a']}}}{tag}" for tag in ('xfrm', 'prstGeom', 'noFill', 'ln', 'effectLst')}
    if any(node.tag not in allowed for node in props):
        return False
    geom = props.find('a:prstGeom', NS)
    line = props.find('a:ln', NS)
    effects = props.find('a:effectLst', NS)
    if ((geom is not None and (geom.get('prst') != 'rect' or geom.find('.//a:gd', NS) is not None))
            or (line is not None and line.find('a:noFill', NS) is None)
            or (effects is not None and len(effects)) or pic.find('p:style', NS) is not None):
        return False
    blip = fill.find('a:blip', NS)
    rect = fill.find('a:stretch/a:fillRect', NS)
    if blip is None or rect is None or any(int(rect.get(k, 0)) != 0 for k in ('l', 't', 'r', 'b')):
        return False
    # Even a transparent rectangular source can reveal patterned backgrounds and master
    # graphics. Limit the unrendered shortcut to JPEGs or demonstrably opaque PNGs.
    return len(blip) == 0 and fill.find('a:tile', NS) is None


def opaque_raster(path):
    with open(path, 'rb') as stream:
        header = stream.read(33)
        if header.startswith(b'\xff\xd8\xff'):
            return True
        if not header.startswith(b'\x89PNG\r\n\x1a\n') or len(header) < 33 or header[25] not in (0, 2, 3):
            return False
        while True:
            chunk = stream.read(8)
            if len(chunk) != 8:
                return False
            if chunk[4:] == b'IDAT':
                return True
            if chunk[4:] in (b'tRNS', b'IEND'):
                return False
            stream.seek(int.from_bytes(chunk[:4], 'big') + 4, 1)


def inspect(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    assets = output / 'images'
    assets.mkdir(exist_ok=True)
    with zipfile.ZipFile(source) as z:
        if sum(i.file_size for i in z.infolist()) > 1024 ** 3:
            raise ValueError('UNCOMPRESSED_PACKAGE_TOO_LARGE')
        bad = z.testzip()
        if bad:
            raise ValueError('ZIP_CRC_FAILED: ' + bad)
        names = set(z.namelist())

        if len(names) != len(z.infolist()):
            raise ValueError('DUPLICATE_PACKAGE_PART')
        def xml(part):
            root = ET.fromstring(z.read(part))
            if root.tag.startswith('{http://purl.oclc.org/ooxml/'):
                for node in root.iter():
                    node.tag = transitional(node.tag)
                    node.attrib = {transitional(k): v for k, v in node.attrib.items()}
            return root

        def rels(part):
            folder, name = posixpath.split(part)
            rp = posixpath.join(folder, '_rels', name + '.rels')
            if rp not in names:
                return {}
            result = {}
            for el in xml(rp).findall(REL + 'Relationship'):
                if not el.get('Id') or el.get('Id') in result:
                    raise ValueError('DUPLICATE_OR_MISSING_RELATIONSHIP: ' + part)
                target = urllib.parse.unquote(el.get('Target', ''))
                external = el.get('TargetMode') == 'External'
                resolved = None if external else posixpath.normpath(
                    target.lstrip('/') if target.startswith('/') else posixpath.join(folder, target))
                result[el.get('Id')] = {'type': el.get('Type', '').rsplit('/', 1)[-1],
                                       'part': resolved, 'external': external}
            return result

        presentation = xml('ppt/presentation.xml')
        pr = rels('ppt/presentation.xml')
        page_size = presentation.find('p:sldSz', NS)
        pages, slide_parts, slide_ids = [], set(), set()
        for index, entry in enumerate(presentation.findall('p:sldIdLst/p:sldId', NS), 1):
            rid = entry.get('{' + NS['r'] + '}id')
            slide = pr.get(rid, {}).get('part')
            if pr.get(rid, {}).get('type') != 'slide' or not slide or slide not in names:
                raise ValueError('MISSING_SLIDE_RELATIONSHIP: ' + str(rid))
            root = xml(slide)
            if root.tag != '{' + NS['p'] + '}sld' or slide in slide_parts or not entry.get('id') or entry.get('id') in slide_ids:
                raise ValueError('INVALID_OR_DUPLICATE_SLIDE: ' + str(index))
            slide_parts.add(slide)
            slide_ids.add(entry.get('id'))
            show = root.get('show', '1')
            if show not in ('0', 'false', '1', 'true'):
                raise ValueError('INVALID_SLIDE_VISIBILITY: ' + str(index))
            hidden = show in ('0', 'false')
            texts = [el.text for el in root.findall('.//a:t', NS) if el.text]
            images, missing, seen = [], [], set()

            def collect(part, inherited=False):
                if part in seen:
                    return
                seen.add(part)
                relationships = rels(part)
                for blip in xml(part).findall('.//a:blip', NS):
                    ref = blip.get('{' + NS['r'] + '}embed') or blip.get('{' + NS['r'] + '}link')
                    rel = relationships.get(ref)
                    if not rel or rel['external'] or rel['type'] != 'image' or rel['part'] not in names:
                        missing.append({'part': part, 'relationship': ref,
                                        'reason': 'external' if rel and rel['external'] else 'missing'})
                        continue
                    data = z.read(rel['part'])
                    digest = hashlib.sha256(data).hexdigest()
                    suffix = Path(rel['part']).suffix.lower()
                    dest = assets / (digest + suffix)
                    if not dest.exists():
                        dest.write_bytes(data)
                    images.append({'package_part': rel['part'], 'path': str(dest),
                                   'bytes': len(data), 'sha256': digest,
                                   'inherited': inherited, 'referenced_from': part})
                for rel in relationships.values():
                    if rel['type'] in ('slideLayout', 'slideMaster') and not rel['external']:
                        if rel['part'] in names:
                            collect(rel['part'], True)
                        else:
                            missing.append({'part': part, 'reason': 'missing_layout_or_master'})

            collect(slide)
            # Identify native charts by their actual frame relationship, not by screenshot appearance.
            chart_refs = []
            slide_rels = rels(slide)
            for frame in root.findall('.//p:graphicFrame', NS):
                identity = frame.find('p:nvGraphicFramePr/p:cNvPr', NS)
                if identity is not None and identity.get('hidden') in ('true','1'):
                    continue
                graphic = frame.find('a:graphic/a:graphicData', NS)
                if graphic is None:
                    continue
                for item in graphic:
                    rid = item.get('{' + NS['r'] + '}id')
                    relation = slide_rels.get(rid, {})
                    if item.tag.rsplit('}', 1)[-1] != 'chart' or relation.get('type') not in ('chart', 'chartEx'):
                        continue
                    chart_refs.append({'shape_id': identity.get('id') if identity is not None else None,
                                       'relationship': rid, 'part': relation.get('part'),
                                       'available': not relation.get('external') and relation.get('part') in names})
            # Only a single, uncropped, unrotated full-slide picture is a safe
            # substitute for a rendered page. Mixed pages must be rendered.
            tree = root.find('p:cSld/p:spTree', NS)
            objects = [] if tree is None else [e for e in tree if e.tag.rsplit('}', 1)[-1] not in ('nvGrpSpPr', 'grpSpPr', 'extLst')]
            full_image = None
            if (len(objects) == 1 and objects[0].tag == '{' + NS['p'] + '}pic' and not missing
                    and raw_picture_equivalent(objects[0])):
                pic = objects[0]
                transform = pic.find('p:spPr/a:xfrm', NS)
                crop = pic.find('p:blipFill/a:srcRect', NS)
                direct = [im for im in images if not im['inherited']]
                if transform is not None and page_size is not None and len(direct) == 1:
                    off, ext = transform.find('a:off', NS), transform.find('a:ext', NS)
                    if (off is not None and ext is not None
                            and all(abs(int(off.get(k, '0'))) <= int(page_size.get(dim)) * 0.005 for k, dim in (('x', 'cx'), ('y', 'cy')))
                            and all(abs(int(ext.get(k, '0')) - int(page_size.get(k))) <= int(page_size.get(k)) * 0.005 for k in ('cx', 'cy'))
                            and all(transform.get(k, '0') in ('0', 'false') for k in ('rot', 'flipH', 'flipV'))
                            and (crop is None or all(int(v) == 0 for v in crop.attrib.values()))):
                        if opaque_raster(direct[0]['path']):
                            full_image = direct[0]['path']
            pages.append({'number': index, 'part': slide, 'hidden': hidden, 'texts': texts,
                          'pictures': len(root.findall('.//p:pic', NS)),
                          'shapes': len(root.findall('.//p:sp', NS)),
                          'native_charts': chart_refs,
                          'graphic_frames': len(root.findall('.//p:graphicFrame', NS)),
                          'images': images, 'unresolved_images': missing,
                          'text_extraction_empty': not texts,
                          'reading_action': 'read_image' if full_image else 'render_then_read',
                          'page_image_path': full_image,
                          'visual_read_required': True})
        if not pages:
            raise ValueError('NO_SLIDES_IN_PRESENTATION_ORDER')
    report = {'ok': True, 'source': str(source), 'size_bytes': source.stat().st_size,
              'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'page_count': len(pages),
              'page_size_emu': dict(page_size.attrib) if page_size is not None else None,
              'pages': pages, 'content_read_complete': False,
              'note': 'Structure only. Read actual page images/rendered pages before redesign. Empty extracted text does not mean an empty slide.'}
    manifest = output / 'manifest.json'
    manifest.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    queue = [{'page': p['number'], 'action': p['reading_action'], 'hidden': p['hidden'],
              'image_path': p['page_image_path'], 'status': 'pending'} for p in pages]
    queue_file = output / 'reading-queue.json'
    queue_file.write_text(json.dumps({'source': str(source), 'pages': queue}, ensure_ascii=False, indent=2), encoding='utf-8')
    return {'ok': True, 'manifest': str(manifest), 'page_count': len(pages),
            'next_action': 'execute_reading_queue', 'reading_queue': str(queue_file),
            'direct_image_pages': [p['number'] for p in pages if p['page_image_path']],
            'empty_text_pages': [p['number'] for p in pages if p['text_extraction_empty']],
            'image_references': sum(len(p['images']) for p in pages),
            'unresolved_images': sum(len(p['unresolved_images']) for p in pages),
            'content_read_complete': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', help='Actual local PPTX path')
    parser.add_argument('output', help='Inspection output directory')
    args = parser.parse_args()
    try:
        print(json.dumps(inspect(args.source, args.output), ensure_ascii=False))
    except (OSError, ValueError, KeyError, ET.ParseError, zipfile.BadZipFile) as exc:
        print(json.dumps({'ok': False, 'error': str(exc)}, ensure_ascii=False))
        sys.exit(1)
