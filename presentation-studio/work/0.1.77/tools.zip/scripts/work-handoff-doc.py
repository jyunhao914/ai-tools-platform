"""Prepare revision-guarded Google Docs connector calls and verify their readback."""
import argparse
import base64
import hashlib
import json
import re
import runpy
from pathlib import Path
from tempfile import TemporaryDirectory

core = runpy.run_path(str(Path(__file__).with_name("web-confirmation.py")))
HEADER = "Presentation Studio Work handoff v1"
RECEIPT = "Receipt: "


STAGE_HEADER = "Presentation Studio private settings draft v1"
COMMAND_PREFIX = "PS-WORK-CARD/1 "
CARD_FIELDS = {"settings", "delivery", "page_overrides", "object_overrides", "page_profiles",
               "requirements", "layout_instruction", "slide_size", "image_policy"}


def read_document(doc):
    # Accept the single get_document resource or its MCP structured result.
    for key in ("result", "structuredContent", "document"):
        doc = doc.get(key, doc)
    doc_id = doc.get("documentId") or doc.get("document_id")
    revision = doc.get("revisionId") or doc.get("revision_id")
    if not doc_id or not revision:
        raise ValueError("Read documentId, revisionId and body from get_document.")
    body = doc.get("body")
    tabs = doc.get("tabs") or []
    if tabs:
        if len(tabs) != 1 or tabs[0].get("childTabs") or tabs[0].get("child_tabs"):
            raise ValueError("Expected the one-tab handoff document.")
        tab = tabs[0]
        body = tab.get("body") or (tab.get("documentTab") or tab.get("document_tab") or {}).get("body")
    if not isinstance(body, dict) or not body.get("content"):
        raise ValueError("Request the full unabridged Google document body.")
    chunks = []
    for block in body["content"]:
        if "sectionBreak" in block or "section_break" in block:
            continue
        if "paragraph" not in block or not block["paragraph"].get("elements"):
            raise ValueError("Unexpected non-text block in the handoff document.")
        for element in block["paragraph"]["elements"]:
            run = element.get("textRun") or element.get("text_run")
            if not run or not isinstance(run.get("content"), str):
                raise ValueError("Expected complete text runs in the handoff document.")
            chunks.append(run["content"])
    if not isinstance(doc_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", doc_id):
        raise ValueError("Expected a Google document ID.")
    # GetDocument reliably returns documentId, but does not require webViewLink.
    return doc_id, revision, "".join(chunks), "https://docs.google.com/document/d/" + doc_id + "/edit"


def receipt_line(receipt):
    return RECEIPT + json.dumps(receipt, ensure_ascii=True, separators=(",", ":"), sort_keys=True)


def decode(text, digest, directory):
    # ASCII transport keeps even private-use Unicode and original JSON whitespace
    # byte-for-byte intact through the Docs insertText normalization.
    # Docs may append additional empty paragraphs after a Work receipt. Ignore
    # only those terminal newlines; all four payload lines must remain exact.
    lines = text.rstrip("\n").split("\n")
    if len(lines) != 4 or lines[:2] != [HEADER, "SHA-256: " + digest] or not lines[3].startswith(RECEIPT):
        raise ValueError("This document does not match the expected handoff.")
    packet = base64.b64decode(lines[2], validate=True)
    if hashlib.sha256(packet).hexdigest() != digest:
        raise ValueError("The downloaded packet does not match its confirmation fingerprint.")
    saved = core["persist"](directory, "studio-work-", packet)
    path = Path(saved["snapshot"])
    plan = core["load_work"](path, digest)
    def unique_keys(pairs):
        record = dict(pairs)
        if len(record) != len(pairs):
            raise ValueError("Duplicate receipt keys cannot be reconciled.")
        return record
    receipt = json.loads(lines[3][len(RECEIPT):], object_pairs_hook=unique_keys)
    core["receipt_identity"](plan, digest, receipt)
    # Existing hosts serialized valid JSON in different key orders. Match the
    # original unmodified line under Docs revision control when updating it.
    return path, receipt, lines[3]


def update(doc_id, revision, request):
    return {"action": "write_then_reread", "tool_args": {
        "document_id": doc_id, "write_control": {"requiredRevisionId": revision}, "requests": [request]}}


def as_stage(plan):
    core["validate_work_plan"](core["normalize_portable_revision"](plan))
    raw = core["canonical"](plan)
    digest = hashlib.sha256(raw).hexdigest()
    return "\n".join([STAGE_HEADER, digest, base64.b64encode(raw).decode("ascii")])


def read_stage(text):
    lines = text.rstrip("\n").split("\n")
    if len(lines) != 3 or lines[0] != STAGE_HEADER:
        raise ValueError("Read the original private settings draft.")
    raw = base64.b64decode(lines[2], validate=True)
    if hashlib.sha256(raw).hexdigest() != lines[1]:
        raise ValueError("The draft revision differs from its fingerprint.")
    plan = core["normalize_portable_revision"](json.loads(raw))
    core["validate_work_plan"](plan)
    return lines[1], plan


def card_values(command, url):
    markers = list(re.finditer(r"(?m)^[ \t]*PS-WORK-CARD/1(?=\s|$)", command))
    if len(markers) != 1:
        raise ValueError("Copy the complete instruction from the confirmed card.")
    core["verify_launch_release"](command[:markers[0].start()])
    payload = command[markers[0].end():].lstrip()
    packet, end = json.JSONDecoder().raw_decode(payload)
    rest = payload[end:]
    if rest.strip() and (not rest.lstrip(" \t").startswith(("\n","\r")) or
                         any(line.lstrip().startswith(("{","[")) for line in rest.splitlines())):
        raise ValueError("Copy one complete settings card.")
    if not isinstance(packet, dict) or set(packet) != {"doc_url", "draft_sha256", "changes"} or packet["doc_url"] != url:
        raise ValueError("The Work instruction must point to this exact private document.")
    if not isinstance(packet["draft_sha256"], str) or not re.fullmatch(r"[a-f0-9]{64}", packet["draft_sha256"]):
        raise ValueError("Invalid draft fingerprint.")
    changes = packet["changes"]
    if not isinstance(changes, dict) or changes.keys() - CARD_FIELDS:
        raise ValueError("Only the settings and output fields displayed in the card may change.")
    core["check_portable"](changes)
    return packet


def confirmed_text(snapshot, digest):
    return "\n".join([HEADER, "SHA-256: " + digest,
                      base64.b64encode(snapshot.read_bytes()).decode("ascii"), receipt_line(None)])


def activate(text, url, doc_id, revision, command):
    packet = card_values(command, url)
    activation = hashlib.sha256(core["canonical"](packet)).hexdigest()
    lines = text.rstrip("\n").split("\n")
    with TemporaryDirectory() as tmp:
        directory = Path(tmp)
        if lines[0] == HEADER and len(lines) == 4:
            digest = lines[1].removeprefix("SHA-256: ")
            snapshot, _, _ = decode(text, digest, directory)
            if core["load_work"](snapshot, digest).get("card_activation") != activation:
                raise ValueError("This document already has another confirmed selection. Reopen the correct card.")
            return {"action": "already_activated", "document_id": doc_id, "sha256": digest}
        draft_sha, plan = read_stage(text)
        if packet["draft_sha256"] != draft_sha:
            raise ValueError("This instruction refers to a different draft revision.")
        # Each changed section carries its full effective value, including all surviving
        # per-object choices. This also allows clearing a conditional field.
        plan.update(packet["changes"])
        plan["card_activation"] = activation
        saved = core["pack_work"](plan, directory)
        body = confirmed_text(Path(saved["snapshot"]), saved["sha256"])
        # Stage representation is ASCII, so these offsets are also Docs UTF-16 indices.
        old_len = len(text.rstrip("\n"))
        return {"action": "write_then_reread", "sha256": saved["sha256"], "document_id": doc_id,
                "tool_args": {"document_id": doc_id, "write_control": {"requiredRevisionId": revision},
                              "requests": [{"deleteContentRange": {"range": {"startIndex": 1, "endIndex": 1 + old_len}}},
                                           {"insertText": {"location": {"index": 1}, "text": body}}]}}


def process(args):
    doc_id, revision, text, record_url = read_document(json.loads(args.doc.read_bytes()))
    if args.command in {"claim", "complete", "activate"} and getattr(args, "surface", None) != "work":
        return {"action": "handoff_to_work", "record_url": record_url}
    if args.command == "stage":
        body = as_stage(json.loads(args.plan.read_bytes()))
        if not text.strip("\n"):
            return update(doc_id, revision, {"insertText": {"location": {"index": 1}, "text": body}})
        if text.rstrip("\n") != body:
            raise ValueError("A different draft or confirmed job is already stored here.")
    if args.command in {"stage", "reread-stage"} or (args.command == "read" and text.startswith(STAGE_HEADER + "\n")):
        draft_sha, plan = read_stage(text)
        return {"action": "read_stage", "document_id": doc_id, "revision_id": revision,
                "card_binding": {"doc_url": record_url, "draft_sha256": draft_sha,
                                 "production_choices":core["card_production_choices"](plan),
                                 "source_note": core["attachment_note"](plan), "directions": core["work_directions"](plan)}}
    if args.command == "activate":
        return activate(text, record_url, doc_id, revision, args.message.read_text(encoding="utf-8"))
    digest = args.sha256
    if args.command == "init":
        core["load_work"](args.snapshot, digest)
        if text and not text.strip("\n"):
            body = confirmed_text(args.snapshot, digest)
            return update(doc_id, revision, {"insertText": {"location": {"index": 1}, "text": body}})
    with TemporaryDirectory() as temp:
        directory = args.directory if args.command == "read" else Path(temp)
        snapshot, receipt, original_line = decode(text, digest, directory)
        if args.command == "init":
            return {"action": "already_initialized", "document_id": doc_id, "sha256": digest}
        plan = core["load_work"](snapshot, digest)
        display = core["receipt_display"](receipt, plan, record_url)
        if args.command == "read":
            result = {"action": "read", "document_id": doc_id, "revision_id": revision,
                      "snapshot": str(snapshot), "sha256": digest, "receipt": receipt,
                      "record_url": record_url, "display": display}
            if core["receipt_state"](receipt) == "ready" and record_url:
                launch = core["work_message"](snapshot, digest, record_url)
                result["launch_message"] = launch["message"]
                if "display_text" in launch:
                    result["display_text"] = launch["display_text"]
            return result
        link = core["observed_work_link"](args.observed_work_url, args.url_origin)
        if args.command == "claim":
            decision = core["receive_work"](snapshot, digest, "work", args.source_version, args.work_ref, receipt,
                                            work_url=args.observed_work_url, url_origin=args.url_origin,
                                            native_id=getattr(args,"source_id",None), native_verification=getattr(args,"native_verification",None))
            if decision["action"] == "claim_before_production":
                next_receipt = decision["proposed_receipt"]
            elif decision["action"] == "resume" and link and receipt.get("work_link") != link:
                next_receipt = {**receipt, "work_link": link}
            else:
                return {**core["start_claimed_work"](decision, args), "display": display}
        else:
            state = core["receipt_state"](receipt)
            if state not in ("accepted", "complete"):
                raise ValueError("Only a job claimed by Work can be completed.")
            if state == "complete" or receipt["work_ref"] != args.work_ref:
                return {"action": "use_existing_work", "receipt": receipt, "display": display}
            outputs = json.loads(args.outputs.read_bytes())
            if not isinstance(outputs, dict) or not outputs:
                raise ValueError("Provide the verified outputs as a non-empty JSON object.")
            core["check_portable"](outputs)
            next_receipt = {**receipt, "state": "complete", "outputs": outputs, **({"work_link": link} if link else {})}
        return update(doc_id, revision, {"replaceAllText": {
            "containsText": {"text": original_line, "matchCase": True},
            "replaceText": receipt_line(next_receipt)}})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("stage", "reread-stage", "activate"):
        cmd = sub.add_parser(name)
        cmd.add_argument("doc", type=Path)
        if name == "stage":
            cmd.add_argument("plan", type=Path)
        if name == "activate":
            cmd.add_argument("message", type=Path)
            cmd.add_argument("--surface", required=True)
    for name in ("init", "read", "claim", "complete"):
        cmd = sub.add_parser(name)
        cmd.add_argument("doc", type=Path)
        if name == "init":
            cmd.add_argument("snapshot", type=Path)
        cmd.add_argument("sha256")
        if name == "read":
            cmd.add_argument("directory", type=Path)
        if name == "claim":
            cmd.add_argument("--source-version", required=True)
            cmd.add_argument("--source-id")
            cmd.add_argument("--native-verification", type=Path)
            core["production_start_options"](cmd)
        if name in ("claim", "complete"):
            cmd.add_argument("--surface", required=True)
            cmd.add_argument("--work-ref", required=True)
            core["work_link_options"](cmd)
        if name == "complete":
            cmd.add_argument("--outputs", required=True, type=Path)
    try:
        print(json.dumps(process(parser.parse_args()), ensure_ascii=False))
    except (ValueError, OSError) as exc:
        parser.exit(2, str(exc) + "\n")


if __name__ == "__main__":
    main()
