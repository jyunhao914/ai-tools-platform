"""Check preserved picture pixels, crop and projected dimensions; repair a private working copy."""
import argparse
from collections import defaultdict
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
import json
import math
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZipFile

from lxml import etree
from PIL import Image, UnidentifiedImageError
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.oxml.ns import qn

# Two percent allows harmless import-unit rounding. Existing distortion may be reduced
# on the same side of the natural ratio, never amplified or reversed past tolerance.
RATIO_TOL = math.log(1.02)
I = (1., 0., 0., 1.)


def mat(a, b):
    return (a[0]*b[0]+a[1]*b[2], a[0]*b[1]+a[1]*b[3],
            a[2]*b[0]+a[3]*b[2], a[2]*b[1]+a[3]*b[3])


def orientation(xfrm):
    v = xfrm.attrib if xfrm is not None else {}
    ang = math.radians(int(v.get("rot", 0))/60000)
    c, s = math.cos(ang), math.sin(ang)
    x = -1 if v.get("flipH") in ("true", "1") else 1
    y = -1 if v.get("flipV") in ("true", "1") else 1
    return (x*c, -y*s, x*s, y*c)


def offsets(node):
    def fraction(side):
        n = node.get(side, "0") if node is not None else "0"
        return float(n[:-1])/100 if n.endswith("%") else float(n)/100000
    return tuple(fraction(k) for k in "ltrb")


def mask(shape):
    nodes = shape._element.xpath("./p:spPr/a:prstGeom|./p:spPr/a:custGeom")
    if not nodes:
        return ("rect", ())
    node = nodes[0]
    if node.get("prst"):
        return (node.get("prst"), tuple(sorted((x.get("name"), x.get("fmla")) for x in node.xpath("./a:avLst/a:gd"))))
    return ("custom", etree.tostring(node, method="c14n", exclusive=True))


@dataclass
class Occurrence:
    shape: object
    raw: str
    pixels: str
    crop: tuple
    fill_rect: tuple
    natural: float | None
    ratio: float
    skew: float
    mirrored: bool
    mask: tuple
    tile: bytes | None
    lengths: tuple


def occurrences(slide, shapes, cache, parent=I):
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            x = shape._element.xpath("./p:grpSpPr/a:xfrm")[0]
            e = x.find(qn("a:chExt"))
            cx, cy = int(e.get("cx")), int(e.get("cy"))
            if not cx or not cy:
                if shape._element.xpath(".//a:blip"):
                    raise ValueError(f"Degenerate picture group: {shape.name}")
                continue
            group = mat(mat(parent, orientation(x)), (shape.width/cx, 0, 0, shape.height/cy))
            yield from occurrences(slide, shape.shapes, cache, group)
            continue
        for b in shape._element.xpath("./p:blipFill/a:blip|./p:spPr/a:blipFill/a:blip"):
            rid = b.get(qn("r:embed"))
            if not rid:
                raise ValueError(f"Read the embedded pixels of the linked picture before geometry verification: {shape.name}")
            blob = slide.part.related_part(rid).blob
            raw = sha256(blob).hexdigest()
            if raw not in cache:
                try:
                    with Image.open(BytesIO(blob)) as im:
                        rgba = im.convert("RGBA")
                        pix = sha256(str(im.size).encode() + rgba.tobytes()).hexdigest()
                        cache[raw] = (pix, im.width/im.height)
                except (UnidentifiedImageError, OSError, ValueError):
                    # A vector/metafile with no readable pixel dimensions still has a source frame ratio.
                    cache[raw] = (raw, None)
            pixels, native = cache[raw]
            fill = b.getparent()
            crop = offsets(fill.find(qn("a:srcRect")))
            stretch = fill.find(qn("a:stretch"))
            m = offsets(stretch.find(qn("a:fillRect")) if stretch is not None else None)
            cw, ch = 1-crop[0]-crop[2], 1-crop[1]-crop[3]
            fw, fh = 1-m[0]-m[2], 1-m[1]-m[3]
            transform = shape._element.xpath("./p:spPr/a:xfrm")
            basis = mat(parent, orientation(transform[0] if transform else None))
            sx, sy = math.hypot(basis[0], basis[2]), math.hypot(basis[1], basis[3])
            w, h = sx*shape.width*fw, sy*shape.height*fh
            if min(cw, ch, fw, fh, w, h) <= 0:
                raise ValueError(f"Degenerate crop/frame: {shape.name}")
            tile = fill.find(qn("a:tile"))
            yield Occurrence(shape, raw, pixels, crop, m, native*cw/ch if native else None, w/h,
                             (basis[0]*basis[1]+basis[2]*basis[3])/(sx*sy),
                             basis[0]*basis[3]-basis[1]*basis[2] < 0, mask(shape),
                             etree.tostring(tile, method="c14n", exclusive=True) if tile is not None else None, (w,h))


def exclusions(run_dir):
    rows = []
    if run_dir:
        for name in ("assets.json", "redraws.json"):
            path = Path(run_dir)/name
            if name == "assets.json" or path.exists():
                plan=json.loads(path.read_bytes())
                rows.extend([*plan["assets"],*plan.get("native_source_replacements",[])])
    return rows


def compatible_mask(src, dst):
    if src.mask == dst.mask:
        return True
    # Native Slides may unwrap a rounded rectangle on export, exposing its full corners.
    return src.mask[0] == "roundRect" and dst.mask[0] == "rect"


def assessment(source, candidate, slots=(), repair=False):
    a, b = Presentation(source), Presentation(candidate)
    if len(a.slides) != len(b.slides):
        raise ValueError("Page count differs. Provide the confirmed page mapping before comparing evidence.")
    skip = {(r.get("page_number"), r.get("source_shape_id"), r.get("source_sha256")) for r in slots
            if not r.get("protected") and (r.get("action") == "redraw" or r.get("replaces_source"))}
    issues, repaired, checked, parts = [], [], 0, {}
    cache = {}
    for pg, (sa, sb) in enumerate(zip(a.slides, b.slides), 1):
        images = defaultdict(list)
        for dest in occurrences(sb, sb.shapes, cache):
            images[dest.pixels].append(dest)
        for src in occurrences(sa, sa.shapes, cache):
            if (pg, src.shape.shape_id, src.raw) in skip:
                continue
            rec = {"page":pg, "source_name":src.shape.name, "source_id":src.shape.shape_id}
            pool = images[src.pixels]
            matches = [c for c in pool if max(abs(x-y) for x,y in zip(src.crop,c.crop)) <= .00003]
            if not matches:
                issues.append({**rec, "reason":"source_crop_changed" if pool else "source_pixels_missing"})
                continue
            # Retain stable IDs/names where available; native exports often rename every object.
            dst = min(matches, key=lambda c: (c.shape.name != src.shape.name,
                       not compatible_mask(src,c), c.shape.shape_id != src.shape.shape_id, abs(math.log(c.ratio/src.ratio))))
            pool.remove(dst)
            rec.update(candidate_id=dst.shape.shape_id, candidate_name=dst.shape.name,
                       source_ratio=src.ratio, effective_ratio=dst.ratio, natural_ratio=src.natural)
            checked += 1
            if max(abs(x-y) for x,y in zip(src.fill_rect,dst.fill_rect)) > .00003:
                issues.append({**rec, "reason":"changed_fill_viewport", "next":"Restore the original fill rectangle before changing the frame."})
                continue
            if not compatible_mask(src, dst):
                issues.append({**rec, "reason":"changed_mask", "next":"Restore the original mask or verify a lossless native reconstruction."})
                continue
            if src.mirrored != dst.mirrored or abs(src.skew-dst.skew) > .015:
                issues.append({**rec, "reason":"changed_shear_or_mirror", "next":"Restore original transform; reflow the group before rechecking."})
                continue
            if src.tile is not None or dst.tile is not None:
                if src.tile != dst.tile or any(abs(math.log(x/y)) > .001 for x,y in zip(src.lengths,dst.lengths)):
                    issues.append({**rec, "reason":"tile_footprint_changed", "next":"Restore the original tiled fill and physical coverage."})
                continue
            target = src.natural or src.ratio
            lo, hi = sorted((math.log(src.ratio), math.log(target)))
            if lo-RATIO_TOL <= math.log(dst.ratio) <= hi+RATIO_TOL:
                continue
            sh = dst.shape
            f = target/dst.ratio
            new_w = max(1,round(sh.width*min(1., f)))
            new_h = max(1,round(sh.height*min(1., 1/f)))
            box = [sh.left+round((sh.width-new_w)/2), sh.top+round((sh.height-new_h)/2), new_w, new_h]
            rec["recommended_frame_in_parent_emu"] = box
            if not repair:
                issues.append({**rec, "reason":"stretched", "next":"Contain at the original crop's natural ratio within this frame; re-export and recheck."})
                continue
            if sh.has_text_frame and sh.text.strip():
                issues.append({**rec, "reason":"text_shares_picture_frame", "next":"Separate editable text from the picture fill, preserving its exact text frame before resizing."})
                continue
            # Keep center and rotation fixed. Shrink only one local dimension, so the new
            # quadrilateral stays inside the original even under a nested affine transform.
            sh.left, sh.top, sh.width, sh.height = box
            parts[str(sb.part.partname).lstrip("/")] = sb.part
            repaired.append(rec)
    return {"status":"repair_required" if issues else "pass", "checked":checked, "issues":issues, "repaired":repaired}, parts


def fix(source, candidate, out, slots):
    if source.resolve() == out.resolve() or (out.exists() and out.samefile(source)):
        raise ValueError("Choose the working copy or a separate output; the original must remain usable.")
    result, parts = assessment(source, candidate, slots, repair=True)
    if result["issues"]:
        return result
    with NamedTemporaryFile(dir=out.parent, suffix=".pptx", delete=False) as f:
        tmp=Path(f.name)
    try:
        if parts:
            with ZipFile(candidate) as before, ZipFile(tmp, "w") as after:
                for entry in before.infolist():
                    part=parts.get(entry.filename)
                    after.writestr(entry, part.blob if part is not None else before.read(entry))
        else:
            import shutil
            shutil.copyfile(candidate,tmp)
        verified, _ = assessment(source, tmp, slots)
        if verified["issues"]:
            return verified
        os.replace(tmp,out)
        return result
    finally:
        tmp.unlink(missing_ok=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command",choices=("check","repair"))
    parser.add_argument("source",type=Path)
    parser.add_argument("candidate",type=Path)
    parser.add_argument("--run-dir",type=Path)
    parser.add_argument("--out",type=Path)
    a=parser.parse_args()
    if (a.command=="repair") != bool(a.out):
        parser.error("Supply --out only for repair, with the private working copy or a new path.")
    try:
        slots=exclusions(a.run_dir)
        if a.run_dir and (a.run_dir/"work.json").exists():
            checkpoint=json.loads((a.run_dir/"work.json").read_bytes())
            if sha256(a.source.read_bytes()).hexdigest()!=checkpoint["source_sha256"]:
                raise ValueError("Read the source revision bound to this run.")
        if a.command=="repair":
            r=fix(a.source,a.candidate,a.out,slots)
        else:
            r=assessment(a.source,a.candidate,slots)[0]
    except (ValueError,OSError,KeyError) as e:
        r={"status":"repair_required","issues":[{"reason":str(e)}]}
    print(json.dumps(r,ensure_ascii=False))
    return 0 if r["status"]=="pass" else 2


if __name__=="__main__":
    raise SystemExit(main())
