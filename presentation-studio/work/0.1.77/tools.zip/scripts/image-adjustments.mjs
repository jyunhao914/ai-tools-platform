// Apply the sparse edits submitted by the slide/image picker to the current job's visual plan.
// The catalogue comes from reading the source. The form supplies only identities, actions and text.
const present = value => typeof value === "string" && value.trim().length > 0;
const keyFor = (page, name) => JSON.stringify([page, name]);

export function applyImageAdjustments(job) {
  if (!job?.image_adjustments) return job;
  const {image_adjustments: review, ...plan} = job;
  const slideMode = Array.isArray(plan.pages);
  const pageCount = slideMode ? plan.pages.length : plan.pages;
  const revision = plan.revision ?? plan.content_revision;
  if (!present(plan.source_key) || !present(revision) ||
      review.source_key !== plan.source_key || review.revision !== revision)
    throw new Error("Image choices belong to a different source or revision.");
  if (!Array.isArray(review.catalogue) || !Array.isArray(review.edits))
    throw new Error("Supply the source catalogue and submitted image choices.");
  if (!Number.isSafeInteger(pageCount) || pageCount < 1)
    throw new Error("Image choices require a confirmed page count.");

  const catalogue = new Map();
  for (const row of review.catalogue) {
    const key = keyFor(row.page, row.name);
    if (!Number.isInteger(row.page) || row.page < 1 || row.page > pageCount ||
        !present(row.name) || !["original", "empty_page"].includes(row.kind) || catalogue.has(key))
      throw new Error("Invalid or duplicate source image slot.");
    catalogue.set(key, row);
  }

  const edits = new Map();
  const noImages = new Set();
  for (const change of review.edits) {
    const key = keyFor(change.page, change.name);
    const row = catalogue.get(key);
    if (!row || edits.has(key)) throw new Error("Unknown or repeated image choice.");
    const allowed = row.kind === "original" ? ["inherit", "keep", "redraw", "replace"] : ["inherit", "skip", "add"];
    if (!allowed.includes(change.action) || (row.protected && !["inherit","keep"].includes(change.action)))
      throw new Error("This action is unavailable for this source image.");
    if (["redraw","replace","add"].includes(change.action) && !present(change.brief))
      throw new Error("Enter a description for the selected image.");
    if (change.action === "redraw" && !present(row.reference))
      throw new Error("Redrawing needs the actual source image.");
    edits.set(key, change);
    if (change.action === "skip" && (row.scope === "page" ||
        row.kind === "empty_page" && row.scope !== "object" && review.catalogue.filter(item=>item.page===change.page).length===1)) {
      noImages.add(change.page);
    }
  }

  function applyToList(page, existing, identifier) {
    const result = [];
    const seen = new Set();
    function apply(original, name) {
      const key = keyFor(page, name);
      const row = catalogue.get(key);
      const change = edits.get(key);
      const action = row?.protected ? "keep" : change?.action;
      if ((!action || action === "inherit") && !(noImages.has(page) && original?.action === "add")) {
        if (original) result.push(original);
        return;
      }
      if (action === "keep" && slideMode) {
        if (!present(row.reference) || !present(row.sha256)) throw new Error("The retained source region is missing.");
        result.push({id:name, action:"keep", reference:row.reference, sha256:row.sha256});
        return;
      }
      // Editable baselines already contain every original. A missing queued replacement leaves it in place.
      if (!["add","redraw","replace"].includes(action)) return;
      const image = {[identifier]:name, action:action === "replace" ? "add" : action,
                     brief:change.brief, subject:change.brief};
      if (!slideMode) image.page = page;
      if (action === "replace" && !slideMode) image.replace_original = true;
      if (action === "redraw") {
        image.reference = row.reference;
        if (row.sha256) image.sha256 = row.sha256;
      }
      const style = change.media_style ?? row.media_style ?? original?.media_style;
      if (present(style)) image.media_style = style;
      const role = row.role ?? original?.role;
      if (role) image.role = role;
      if (!slideMode) {
        // The catalogue's "original"/"empty_page" describes a source, not a rendering method.
        // Editing the subject does not discard the destination layer's cutout or pixel contract.
        for (const field of ["kind", "transparent_cutout", "placement_px"]) {
          if (original?.[field] !== undefined) image[field] = original[field];
        }
      }
      result.push(image);
    }
    for (const image of existing) {
      seen.add(image[identifier]);
      apply(image, image[identifier]);
    }
    for (const row of review.catalogue) {
      if (row.page === page && !seen.has(row.name) && (edits.has(keyFor(page,row.name)) || row.protected))
        apply(undefined, row.name);
    }
    return result;
  }

  if (slideMode) {
    plan.pages = plan.pages.map(page => ({...page, visuals:applyToList(page.page_number, page.visuals, "id")}));
  } else {
    const byPage = new Map();
    for (const asset of plan.assets) {
      if (!byPage.has(asset.page)) byPage.set(asset.page, []);
      byPage.get(asset.page).push(asset);
    }
    const affectedPages = new Set([...byPage.keys(), ...review.catalogue.map(row => row.page)]);
    plan.assets = [...affectedPages].sort((a,b) => a-b)
      .flatMap(page => applyToList(page, byPage.get(page) ?? [], "name"));
  }
  return plan;
}
