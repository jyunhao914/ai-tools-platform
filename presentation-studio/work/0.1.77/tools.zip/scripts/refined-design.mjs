// Consume an actual final-render review from the host. This checks coverage and provenance,
// not whether a particular slide is attractive. The reviewer must inspect the rendered slides.
import { requiresCutout } from "./generated-asset.mjs";

const nonempty = value => typeof value === "string" && Boolean(value.trim());
const sha256 = value => typeof value === "string" && /^[a-f0-9]{64}$/i.test(value);

function cutoutTargets(job, required) {
  const targets = new Map();
  const identify = (page, item) => JSON.stringify([page, item.name]);
  function add(page, item) {
    if (!required.has(page) || item?.protected === true || item?.action === "keep") return;
    const native = item?.native_icon === true || ["native_icon","icon_group"].includes(item?.kind) ||
      (["vector","shape","auto_shape","freeform","group"].includes(item?.kind) && requiresCutout(item));
    if (!native && !requiresCutout(item)) return;
    targets.set(identify(page, item), {page, name:item.name, kind:native ? "native_icon" : "picture"});
  }
  for (const item of job.assets ?? []) add(item.page, item);
  for (const page of job.visual_plan?.pages ?? [])
    for (const object of page.objects ?? []) add(page.page_number, object);
  return targets;
}

function cutoutIssues(job, verified, required) {
  const targets = cutoutTargets(job, required);
  if (!targets.size) return [];
  const report = verified.design_review?.cutout_delivery;
  const formats = job.deliverables ?? ["pptx", "slides"];
  const files = report?.artifacts;
  const planDigest = job.visual_plan_sha256 ?? verified.visual_plan_sha256;
  const valid = report?.schema === "presentation-studio/cutout-delivery/v1" &&
    sha256(planDigest) && report.plan_sha256 === planDigest && Array.isArray(report.checked_targets) &&
    formats.every(format => report.surfaces?.includes(format) && sha256(files?.[format + "_pdf_sha256"]) &&
      files[format + "_pdf_sha256"] === verified.visible_reports?.[format]?.pdf_sha256);
  const native = verified.chart_delivery?.presentation ?? verified.presentation;
  const revision = verified.slides_revision ?? native?.revisionId;
  const bound = valid && (!formats.includes("slides") ||
    (files.presentation_id === verified.native_id && nonempty(revision) && files.slides_revision === revision)) &&
    (!formats.includes("pptx") || (sha256(verified.pptx_sha256) && files.pptx_sha256 === verified.pptx_sha256));
  const issues = [];
  for (const [key, target] of targets) {
    const rows = bound ? report.checked_targets.filter(row => JSON.stringify([row?.page, row?.name]) === key) : [];
    const row = rows[0];
    if (!bound || rows.length !== 1 || row.kind !== target.kind ||
        !formats.every(format => row.surfaces?.[format]?.status === "pass")) {
      const reason = !bound || !row ? "缺少這版成品的逐件透底驗收" : "圖件需修復或重新檢查成品畫面";
      issues.push({page:target.page, reason:target.name + "：" + reason,
        needs_review:!bound || !row || !formats.some(f => row.surfaces?.[f]?.status === "fail")});
    }
  }
  if (bound && !issues.length && report.status !== "pass")
    issues.push({page:targets.values().next().value.page, reason:"請核對透底檢查中的未決項目", needs_review:true});
  return issues;
}

export function refinedPages(job) {
  const profile = job.settings?.editable_profile ?? job.editable_profile;
  return Array.from({length:job.pages}, (_, i) => i+1)
    .filter(page => (job.page_profiles?.[page] ?? profile) === "refined");
}

export function refinedDesignIssues(job, verified) {
  const review = verified.design_review;
  const required = refinedPages(job);
  const all = message => required.map(page => ({page, reason:message, needs_review:true}));
  if (!review || review.profile !== "refined" || review.source_key !== job.source_key ||
      review.revision !== job.revision || review.native_id !== verified.native_id ||
      !nonempty(verified.output_revision) || review.output_revision !== verified.output_revision ||
      !Array.isArray(review.pages)) {
    return all("缺少這版成品的逐頁精緻型畫面驗收");
  }
  const rows = new Map();
  for (const row of review.pages) {
    if (!Number.isInteger(row?.page) || row.page < 1 || row.page > job.pages || rows.has(row.page))
      return all("渲染頁與成品頁序無法一一對應");
    rows.set(row.page, row);
  }
  const issues = [];
  const referenceUse = new Map();
  for (const page of required) {
    const value = rows.get(page)?.render_ref;
    if (nonempty(value)) {
      const reference = value.trim();
      referenceUse.set(reference, (referenceUse.get(reference) ?? 0) + 1);
    }
  }
  const chartRequirements = new Map((job.editable_charts ?? []).map(chart => [chart.page, chart]));
  for (const page of required) {
    const row = rows.get(page);
    if (!row || !nonempty(row.render_ref) || !nonempty(row.focal_point) || !nonempty(row.observation)) {
      issues.push({page, reason:"尚未核對這一頁的最終畫面、閱讀重心和構圖", needs_review:true});
    } else if (referenceUse.get(row.render_ref.trim()) > 1) {
      issues.push({page, reason:"請使用可識別這一頁的最終渲染引用", needs_review:true});
    } else if (chartRequirements.has(page) && (chartRequirements.get(page).formats ?? ["pptx","slides"]).some(
      format => !(Number.isInteger(row.chart_counts?.[format]) && row.chart_counts[format] >= chartRequirements.get(page).count))) {
      issues.push({page, reason:"交付格式中的原生資料圖表或其可編輯數據尚未核實", needs_review:false});
    } else if (row.status !== "pass" || row.editable_ok !== true) {
      issues.push({page, reason:row.reason || row.observation, needs_review:false});
    }
  }
  return issues.concat(cutoutIssues(job, verified, new Set(required)));
}

export async function verifyEditableResult(job, host, base, ready) {
  const required = new Set(refinedPages(job));
  const hasCutouts = cutoutTargets(job, required).size > 0;
  const scope = job.layout_change_pages == null ? null : new Set(job.layout_change_pages);
  let targetId;
  let previousRevision;
  for (let pass=0;;pass++) {
    let verified = await host.verify(base, job, ready);
    if (!nonempty(verified?.native_id) || !nonempty(verified.url) || !verified.url.startsWith("https://docs.google.com/presentation/")
        || verified.pages !== job.pages || (targetId && targetId !== verified.native_id))
      throw new Error("Read back the same native Slides file and confirmed page count.");
    targetId = verified.native_id;
    if (!required.size) return {verified, issues:[]};
    let inspectionError;
    if (hasCutouts && !verified.visible_reports && typeof host.inspectVisible === "function") {
      try {
        verified = {...verified, visible_reports:await host.inspectVisible(job, verified, job.deliverables ?? ["pptx", "slides"])};
      } catch (error) { inspectionError = error; }
    }
    let issues = refinedDesignIssues(job, verified);
    if (issues.some(issue => issue.needs_review) && typeof host.reviewDesign === "function") {
      verified = {...verified, design_review: await host.reviewDesign(base, job, verified)};
      issues = refinedDesignIssues(job, verified);
    }
    if (hasCutouts && verified.design_review && typeof host.inspectCutouts === "function" &&
        cutoutIssues(job, verified, required).some(issue => issue.needs_review)) {
      try {
        const receipt = await host.inspectCutouts(base, job, verified);
        verified = {...verified, design_review:{...verified.design_review, cutout_delivery:receipt}};
        issues = refinedDesignIssues(job, verified);
      } catch (error) { inspectionError = error; }
    }
    if (inspectionError && issues.length) {
      issues = issues.map(issue => ({...issue, inspection_error:String(inspectionError.message ?? inspectionError)}));
    }
    const repairable = issues.filter(issue => !issue.needs_review && (!scope || scope.has(issue.page)));
    if (!repairable.length || typeof host.repairLayout !== "function" || pass >= 2 ||
        (pass > 0 && previousRevision === verified.output_revision)) return {verified, issues};
    previousRevision = verified.output_revision;
    // Update the same private working file and linked deliverables, preserving the original and other pages.
    await host.repairLayout(base, job, ready, repairable);
  }
}
