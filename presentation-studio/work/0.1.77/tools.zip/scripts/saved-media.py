#!/usr/bin/env python3
"""Save or recover actual generated media for exactly the same source, settings and layer brief."""
import hashlib
import io
import json
import os
import sys
import tempfile
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile

from PIL import Image

SCHEMA = "presentation-studio-media/1"
FORMATS = {"PNG":"png", "JPEG":"jpg", "WEBP":"webp"}
LIMIT = 32 * 1024 * 1024

def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def source_digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

def nonblank(s):
    return isinstance(s, str) and bool(s.strip())

def spec(entry):
    allowed = {k:v for k,v in entry.items() if k not in {"file","generation_ref","sha256","asset_path"}}
    require(type(allowed.get("page")) is int and allowed["page"] > 0 and nonblank(allowed.get("name"))
            and nonblank(allowed.get("brief")), "Missing page, stable layer name or approved brief.")
    require(allowed.get("action") == "add" or (allowed.get("action") == "redraw" and nonblank(allowed.get("reference"))),
            "Only authorised additions and source-bound redraws may be cached.")
    return allowed

def binding(source, job):
    require(nonblank(job.get("revision")) and isinstance(job.get("settings"),dict) and job["settings"],
            "Bind the adopted content revision and complete effective settings.")
    require(isinstance(job.get("assets"),list), "Supply the approved asset list.")
    keys = [(spec(a)["page"],a["name"]) for a in job["assets"]]
    require(len(keys)==len(set(keys)), "Duplicate page or layer name.")
    result = {"source_sha256":source_digest(source), "revision":job["revision"], "settings":job["settings"]}
    if job["settings"].get("fresh_images_only") is True:
        require(nonblank(job.get("job_id")), "Fresh-only media archives require the current job ID.")
        result["job_id"] = job["job_id"]
    return result

def image_record(blob):
    require(0<len(blob)<=LIMIT, "Missing or oversized asset.")
    with Image.open(io.BytesIO(blob)) as im:
        require(im.format in FORMATS and im.width*im.height <= 55_000_000, "Invalid image format or dimensions.")
        ext=FORMATS[im.format]; im.load()
    sha=digest(blob)
    return sha, "assets/"+sha+"."+ext

def pack(source, jobfile, dest):
    job=json.loads(jobfile.read_text())
    manifest={"schema":SCHEMA,"binding":binding(source,job),"assets":[]}
    require(dest.resolve() not in {source.resolve(),jobfile.resolve()}, "Use a separate archive.")
    with tempfile.NamedTemporaryFile(dir=dest.parent, delete=False) as temp:
        tmp=Path(temp.name)
    try:
        with ZipFile(tmp,"w",compression=ZIP_STORED) as archive:
            stored=set()
            for item in job["assets"]:
                require(nonblank(item.get("generation_ref")), "Each file needs a real prior generation or verified asset reference.")
                f=jobfile.parent/item["file"]
                require(0<f.stat().st_size<=LIMIT,"Invalid asset size.")
                blob=f.read_bytes(); sha,member=image_record(blob)
                if member not in stored:
                    archive.writestr(member,blob); stored.add(member)
                manifest["assets"].append({**spec(item),"sha256":sha,"asset_path":member,"generation_ref":item["generation_ref"]})
            archive.writestr("manifest.json",canonical(manifest))
        if dest.exists():
            # Never silently overwrite another revision or a previous receipt.
            with ZipFile(dest) as prior:
                require(prior.read("manifest.json")==canonical(manifest),"Existing archive is a different revision.")
                require(prior.testzip() is None, "Existing archive is damaged.")
        else:
            os.link(tmp,dest)
    finally:
        tmp.unlink(missing_ok=True)
    return {"assets":len(manifest["assets"]), "source_sha256":manifest["binding"]["source_sha256"]}

def recover(source, jobfile, archive_path, output):
    job=json.loads(jobfile.read_text()); expected=binding(source,job)
    hits=[];missing=[]
    with ZipFile(archive_path) as archive:
        require(len(archive.namelist())==len(set(archive.namelist())), "Duplicate ZIP member.")
        info=archive.getinfo("manifest.json")
        require(info.file_size<=1024*1024,"Oversized manifest.")
        manifest=json.loads(archive.read(info))
        require(manifest.get("schema")==SCHEMA and manifest.get("binding")==expected,
                "Source bytes, adopted revision or settings differ from the recorded job.")
        require(isinstance(manifest.get("assets"),list),"Malformed manifest.")
        known={}
        for item in manifest["assets"]:
            key=canonical(spec(item));require(key not in known,"Duplicate saved layer.");known[key]=item
        output.mkdir(parents=True,exist_ok=True)
        for expected_asset in job["assets"]:
            request=spec(expected_asset); item=known.get(canonical(request))
            if not item:
                missing.append(request);continue
            sha=item["sha256"];member=item["asset_path"]
            require(nonblank(item.get("generation_ref")) and len(sha)==64 and
                    member in {"assets/"+sha+"."+v for v in FORMATS.values()}, "Invalid saved image receipt.")
            info=archive.getinfo(member)
            require(info.file_size<=LIMIT, "Oversized asset.")
            data=archive.read(info);require(image_record(data)==(sha,member),"Saved image bytes changed.")
            target=output/Path(member).name
            if not target.exists():
                with tempfile.NamedTemporaryFile(dir=output,delete=False) as temp:
                    tmp=Path(temp.name)
                    try:temp.write(data);temp.flush();os.fsync(temp.fileno())
                    except BaseException:tmp.unlink(missing_ok=True);raise
                try:
                    try:os.link(tmp,target)
                    except FileExistsError:pass
                finally:tmp.unlink(missing_ok=True)
            require(not target.is_symlink() and target.read_bytes()==data, "A different file already occupies the output.")
            hits.append({**request,"status":"ready","file":str(target.resolve()),"generation_ref":item["generation_ref"],"sha256":sha})
    return {"assets":hits,"missing":missing}

if __name__=="__main__":
    try:
        action,*args=sys.argv[1:]
        paths=list(map(Path,args))
        if action=="pack" and len(paths)==3: result=pack(*paths)
        elif action=="recover" and len(paths)==4: result=recover(*paths)
        else: raise ValueError("Use pack SOURCE JOB.json ARCHIVE.zip or recover SOURCE JOB.json ARCHIVE.zip OUTPUT_DIR")
        print(json.dumps(result,ensure_ascii=False))
    except Exception as error:
        print(str(error),file=sys.stderr);sys.exit(1)
