"""Keep the approved settings available to the document worker across a web Chat button click."""
import argparse
import base64
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys
from pathlib import Path
from tempfile import NamedTemporaryFile
from urllib.parse import parse_qsl, urlparse
from urllib.request import HTTPRedirectHandler, build_opener


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def persist(directory, prefix, body):
    digest = hashlib.sha256(body).hexdigest()
    directory.mkdir(parents=True, exist_ok=True)
    dest = directory / (prefix + digest + ".json")
    with NamedTemporaryFile(dir=directory, delete=False) as temp:
        name = Path(temp.name)
        try:
            temp.write(body)
            temp.flush()
            os.fsync(temp.fileno())
        except BaseException:
            name.unlink(missing_ok=True)
            raise
    try:
        os.replace(name, dest)
    finally:
        name.unlink(missing_ok=True)
    return {"snapshot": str(dest), "sha256": digest}


def freeze(plan, directory, *, surface=None, production_surface=None):
    # Only a known production host can issue an in-place start. Older cards may
    # omit the surface or carry an obsolete request to produce in ordinary Chat.
    handing_off = surface not in ("work", "codex")
    if not isinstance(plan, dict):
        raise ValueError("Bind the current source and actual selected settings.")
    has_source = plan.get("source_ref") or (handing_off and (
        plan.get("source_url") or plan.get("sources") or plan.get("adopted_outline")))
    if not has_source or not plan.get("settings"):
        raise ValueError("Bind the current source and actual selected settings.")
    if not isinstance(plan.get("settings"), dict) or not plan.get("delivery"):
        raise ValueError("Supply the settings object and selected outputs.")
    body = canonical(plan)
    digest = hashlib.sha256(body).hexdigest()
    links = [("原稿", "source_url"), ("存放位置", "destination_url"), ("版本工具", "tool_url")]
    if handing_off:
        if not bound(plan.get("source_revision")):
            raise ValueError("Bind the actual source revision or adopted outline revision before confirmation.")
        lines = []
        links.extend((("原稿所在資料夾", "source_parent_url"), ("待製作資料夾", "pending_folder_url")))
    else:
        lines = ["確認設定，開始製作", "沿用本對話已確認設定 " + digest[:16]]
    for label, key in links:
        url = plan.get(key)
        if not url:
            continue
        if not isinstance(url, str):
            raise ValueError("Expected a confirmed routing URL for " + key)
        parsed = urlparse(url)
        if parsed.scheme != "https" or not parsed.netloc or any(ch.isspace() for ch in url):
            raise ValueError("Invalid confirmed routing URL for " + key)
        if handing_off:
            check_portable(url)
            if key in {"source_parent_url", "pending_folder_url"} and (parsed.hostname != "drive.google.com" or
                    not re.fullmatch(r"/drive/(?:u/[0-9]+/)?folders/[A-Za-z0-9_-]+/?", parsed.path)):
                raise ValueError("Use the verified direct Google Drive folder URL for " + key)
        lines.append(label + " " + url)
    snapshot = persist(directory, "studio-settings-", body)
    if handing_off:
        return {**snapshot, "action": "save_handoff_for_work"}
    return {**snapshot, "action": "start_on_current_host", "submit_text": "\n".join(lines)}


def restore(path, expected):
    if len(expected) not in (16, 64) or any(ch not in "0123456789abcdef" for ch in expected):
        raise ValueError("Invalid confirmation fingerprint.")
    body = path.read_bytes()
    if not hashlib.sha256(body).hexdigest().startswith(expected):
        raise ValueError("The saved settings differ from the submitted form.")
    return json.loads(body)


WORK_FORMAT = "presentation-studio/work-handoff/v1"
SECRET_FIELDS = {"authorization", "access_token", "refresh_token", "id_token", "api_key",
                 "client_secret", "password", "cookie", "set-cookie", "signed_url", "download_token"}
SIGNED_PARAMS = {"x-goog-signature", "x-amz-signature", "signature", "access_token", "x-api-key"}


def check_portable(value, field=""):
    if isinstance(value, dict):
        for key, child in value.items():
            if key.casefold() in SECRET_FIELDS and child:
                raise ValueError("Replace credentials with a durable file or operation reference.")
            check_portable(child, key.casefold())
    elif isinstance(value, list):
        for child in value:
            check_portable(child, field)
    elif isinstance(value, str):
        reference = field.endswith(("_ref", "_url", "_path", "_file")) or field in {
            "reference", "path", "sources", "file", "assets", "attachments"}
        if reference and re.match(r"^(?:sandbox:|file:|/mnt/data/|/Users/|/private/var/folders/|/var/folders/|[A-Za-z]:[\\/])", value):
            raise ValueError("Materialize local attachments in a location Work can read.")
        if value.startswith(("http://", "https://")):
            parsed = urlparse(value)
            query = {key.casefold() for key, _ in parse_qsl(parsed.query)}
            if parsed.username or parsed.password or query & SIGNED_PARAMS:
                raise ValueError("Replace the temporary or credential-bearing URL with a durable reference.")


def bound(value):
    return isinstance(value, str) and bool(value.strip())


def validate_work_plan(plan):
    if not isinstance(plan, dict) or not all(bound(plan.get(k)) for k in ("job_id", "revision", "source_revision")):
        raise ValueError("Bind the stable job ID, approved content revision and source version.")
    if not (plan.get("source_ref") or plan.get("source_url") or plan.get("sources") or plan.get("adopted_outline")):
        raise ValueError("Include the exact readable source references or the approved outline.")
    if not isinstance(plan.get("settings"), dict) or not plan["settings"] or not plan.get("delivery"):
        raise ValueError("Include all selected settings and requested deliverables.")
    check_portable(plan)
    if "source_native" in plan:
        validate_native_binding(plan)
    if "source_storage" in plan and source_preparation_action(plan) != "ready":
        raise ValueError("Complete the source read or authorized private-copy attempt before preparing this handoff.")


PORTABLE_PREFIX = "PS-WORK-PLAN/1 "
PLATFORM_RELEASE = "https://jyunhao914.github.io/ai-tools-platform/presentation-studio/release.json"
UPLOAD_ID = re.compile(r"file_[0-9a-f]{32}")
SHA256 = re.compile(r"[0-9a-f]{64}")
DRIVE_FILE_ID = re.compile(r"[A-Za-z0-9_-]+")


def normalize_portable_revision(plan):
    if not isinstance(plan, dict):
        return plan
    if type(plan.get("revision")) is int and plan["revision"] > 0:
        plan = {**plan, "revision": str(plan["revision"])}
    if "source_revision" not in plan:
        ref, digest = plan.get("source_ref"), plan.get("source_sha256")
        if isinstance(ref, str) and UPLOAD_ID.fullmatch(ref) and isinstance(digest, str) and SHA256.fullmatch(digest):
            plan = {**plan, "source_revision": "upload:" + ref}
    return plan


def upload_sha256(plan):
    digest = plan.get("source_sha256")
    if "source_sha256" in plan and not (isinstance(digest, str) and SHA256.fullmatch(digest)):
        raise ValueError("Use the full lowercase SHA-256 of the original bytes.")
    if "source_mirror" not in plan:
        return digest
    mirror = plan["source_mirror"]
    if not isinstance(mirror, dict) or set(mirror) != {"file_id", "sha256"}:
        raise ValueError("Bind a verified private Drive copy with its file ID and byte-level SHA-256.")
    file_id, mirror_digest = mirror["file_id"], mirror["sha256"]
    if (not isinstance(file_id, str) or not DRIVE_FILE_ID.fullmatch(file_id)
            or UPLOAD_ID.fullmatch(file_id) or file_id.startswith("libfile_")):
        raise ValueError("Use the file ID returned by Drive for the private copy.")
    if not isinstance(mirror_digest, str) or not SHA256.fullmatch(mirror_digest) or (digest and digest != mirror_digest):
        raise ValueError("The private copy must match the original bytes.")
    return mirror_digest


def validate_native_binding(plan):
    evidence = plan["source_native"]
    if not isinstance(evidence, dict) or evidence.get("private_native_source_allowed") is not True:
        raise ValueError("A converted source needs authorization for the private Google copy.")
    if (plan.get("requirements") or {}).get("verify_original_bytes_in_work"):
        raise ValueError("This job requires the receiving Work to verify the original binary.")
    target, source = evidence.get("native_file_id"), evidence.get("original_ref")
    if not (isinstance(target, str) and DRIVE_FILE_ID.fullmatch(target) and portable_source(source)):
        raise ValueError("Bind the real original reference and the imported presentation ID.")
    if (source == plan.get("source_ref") or plan.get("source_ref") != "https://docs.google.com/presentation/d/"+target+"/edit"
            or plan.get("source_mime_type") != "application/vnd.google-apps.presentation"
            or not bound(evidence.get("native_revision")) or plan["source_revision"] != evidence["native_revision"]
            or not (portable_source(evidence.get("verification_ref")) or isinstance(evidence.get("verification"), dict))
            or not isinstance(evidence.get("import_source_id"), str) or not DRIVE_FILE_ID.fullmatch(evidence["import_source_id"])
            or evidence["import_source_id"] == target or type(evidence.get("original_page_count")) is not int
            or evidence["original_page_count"] <= 0):
        raise ValueError("The conversion receipt does not match the source, revision or private evidence.")
    for key in ("original_sha256", "verification_sha256"):
        if not isinstance(evidence.get(key), str) or not SHA256.fullmatch(evidence[key]):
            raise ValueError("Bind the SHA-256 of the original and the private verification record.")
    if "source_sha256" in plan or "source_mirror" in plan or "source_storage" in plan:
        raise ValueError("Keep binary-origin proofs in the original record, separate from the native source.")


def check_native_readback(plan, actual_id, verification):
    if "source_native" not in plan:
        return
    binding = plan["source_native"]
    if actual_id != binding["native_file_id"]:
        raise ValueError("Read the verified native presentation in Work.")
    report = json.loads(Path(verification).read_bytes()) if verification is not None else binding.get("verification")
    if not isinstance(report,dict) or hashlib.sha256(canonical(report)).hexdigest() != binding["verification_sha256"]:
        raise ValueError("Read the complete qualification record; its canonical digest must match.")
    for key in ("native_file_id", "native_revision", "original_ref", "original_sha256", "import_source_id"):
        if report.get(key) != binding[key]:
            raise ValueError("The qualification record refers to another source or revision.")
    pages = report.get("pages")
    if not isinstance(pages,list) or len(pages) != report.get("source_page_count") or len(pages) != binding["original_page_count"]:
        raise ValueError("The qualification record is missing original pages.")
    ids = set()
    for index, page in enumerate(pages, 1):
        if (not isinstance(page,dict) or page.get("source_page") != index or not bound(page.get("native_page_id"))
                or page["native_page_id"] in ids or page.get("unresolved") != []
                or page.get("structure_verified") is not True or page.get("protected_visuals_verified") is not True):
            raise ValueError("Repair and recheck all original pages, editable objects and protected visual regions.")
        ids.add(page["native_page_id"])
        for key in ("source_render_sha256", "native_render_sha256"):
            if not isinstance(page.get(key),str) or not SHA256.fullmatch(page[key]):
                raise ValueError("Keep the real source and Google page renders used for the visual checks.")


SOURCE_FAILURES = {"access_denied", "dns", "transfer_failed", "not_materialized", "tool_unavailable",
                   "private_folder_unverified", "copy_not_verified"}


def private_source_folder(plan):
    storage = plan.get("source_storage")
    if storage is None or storage == {"mode": "attachment_only"}:
        return None
    if (isinstance(storage, dict) and set(storage) == {"mode", "folder_id"} and
            storage["mode"] == "private_folder" and isinstance(storage["folder_id"], str) and
            DRIVE_FILE_ID.fullmatch(storage["folder_id"])):
        return storage["folder_id"]
    raise ValueError("Use attachment_only or the actual authorized private_folder ID.")


def source_preparation_action(plan):
    folder = private_source_folder(plan)
    if "source_mirror" in plan and not folder:
        raise ValueError("Do not carry a private copy when source storage is attachment only.")
    if "source_read_error" in plan and plan["source_read_error"] not in SOURCE_FAILURES:
        raise ValueError("Record the observed source read failure.")
    if "source_copy_error" in plan and plan["source_copy_error"] not in SOURCE_FAILURES:
        raise ValueError("Record the observed private copy failure.")
    digest = upload_sha256(plan)
    if folder and plan.get("source_mirror") and plan.get("source_mirror_folder_id") != folder:
        return "verify_private_source_copy"
    if plan.get("source_read_error") and not plan.get("source_mirror"):
        return "ready"
    if not digest:
        return "read_original"
    if folder and not plan.get("source_mirror") and not plan.get("source_copy_error"):
        return "verify_private_source_copy"
    return "ready"


def prepare_source(plan, *, source_file=None, source_id=None, read_error=None, copy_error=None,
                   drive_metadata=None, downloaded_file=None, account_email=None):
    # The handoff carrier (plain text / private settings document) plays no role here.
    plan = dict(plan)
    plan.setdefault("source_storage", {"mode": "attachment_only"})
    folder = private_source_folder(plan)
    if drive_metadata is not None and (not folder or source_file is None):
        raise ValueError("Private backup readback requires the authorized folder and original file.")
    if read_error and source_file is not None or copy_error and (not folder or drive_metadata is not None):
        raise ValueError("Record either a real success or a failure for each operation.")
    if read_error:
        plan["source_read_error"] = read_error
    if source_file is not None:
        if not source_id or source_id not in (plan.get("source_ref"), plan.get("source_url")):
            raise ValueError("Supply the original that was read from this job's confirmed source reference.")
        digest = fingerprint_source(source_file)
        expected = upload_sha256(plan)
        if expected and expected != digest:
            raise ValueError("This source differs from the confirmed original bytes.")
        plan["source_sha256"] = digest
        plan.pop("source_read_error", None)
        if drive_metadata is not None:
            base = Path(__file__).resolve().parent
            verifier = base / "verify-source-copy.py"
            if not verifier.is_file():
                verifier = base.parents[1] / "studio-content/scripts/verify-source-copy.py"
            verify = runpy.run_path(str(verifier))["verify"]
            plan.update(verify(Path(source_file), drive_metadata, folder, digest, downloaded_file, account_email))
            plan["source_mirror_folder_id"] = folder
            plan.pop("source_copy_error", None)
    if copy_error:
        plan["source_copy_error"] = copy_error
    return {"action": source_preparation_action(plan), "plan": plan}


def portable_source(value):
    if not isinstance(value, str):
        return False
    if re.fullmatch(r"(?:libfile_[A-Za-z0-9_-]+|file[-_][A-Za-z0-9_-]+|drive:[A-Za-z0-9_-]+)", value):
        return True
    if not durable_url(value):
        return False
    u = urlparse(value)
    if u.netloc == "chatgpt.com":
        return bool(re.fullmatch(r"/space/file/libfile_[A-Za-z0-9_-]+/?", u.path))
    if u.netloc == "drive.google.com":
        return bool(re.fullmatch(r"/file/(?:u/\d+/)?d/[\w-]+(?:/(?:view|edit|preview))?/?", u.path)
                    or (u.path == "/open" and re.fullmatch(r"[\w-]+", dict(parse_qsl(u.query)).get("id",""))))
    return bool(u.netloc == "docs.google.com" and
                re.fullmatch(r"/(?:presentation|document|spreadsheets)/(?:u/\d+/)?d/[\w-]+(?:/(?:edit|view|preview))?/?", u.path))


def check_manual_transport(value):
    # Card-only routes send references. A manual message contains the whole plan,
    # so also reject sensitive metadata copied under nonstandard field names.
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = re.sub(r"(?<=[a-z])(?=[A-Z])", "_", key).lower().replace("-", "_")
            if child and normalized in SECRET_FIELDS | {"token", "api_token", "bearer_token", "session_token", "credentials", "private_key"}:
                raise ValueError("Remove credentials from the portable text.")
            check_manual_transport(child)
    elif isinstance(value, list):
        for item in value:
            check_manual_transport(item)
    elif isinstance(value, str):
        if re.search(r"(?i)(?:^|[\s(])(?:sandbox:/|file:/+|/(?:Users|home|mnt/data|tmp|private/var|var/folders)/|[A-Z]:[\\/]|~/)",value):
            raise ValueError("Use a durable reference instead of a device-only path.")
        if re.search(r"(?i)\bBearer\s+[A-Za-z0-9._~+/-]{8,}|[?&](?:access_token|refresh_token|token|x-(?:amz|goog)-(?:signature|credential)|x-api-key|signature)=", value):
            raise ValueError("Remove credentials and temporary download URLs.")


def portable_source_kind(plan):
    validate_work_plan(plan)
    check_manual_transport(plan)
    ref, revision = plan.get("source_ref"), plan["source_revision"]
    if isinstance(ref, str) and revision.startswith("upload:"):
        if not UPLOAD_ID.fullmatch(ref) or revision != "upload:" + ref:
            raise ValueError("Bind the exact immutable file ID returned by the selected upload.")
        upload_sha256(plan)
        return "upload"
    if ref == "attached-in-work":
        if not SHA256.fullmatch(revision):
            raise ValueError("Bind the original file's full SHA-256 before requesting reattachment in Work.")
        return "reattach"
    if ref in (None, "adopted-outline") and plan.get("adopted_outline") and not plan.get("source_url") and not plan.get("sources"):
        if str(plan.get("mode")) not in ("1", "2"):
            raise ValueError("A redesign needs the actual existing presentation.")
        outline = plan["adopted_outline"]
        if not isinstance(outline, (str, list, dict)) or (isinstance(outline, str) and not outline.strip()):
            raise ValueError("Include the complete adopted outline.")
        digest = hashlib.sha256(canonical(outline)).hexdigest()
        if revision not in ("adopted-outline", digest):
            raise ValueError("The adopted outline does not match its source revision.")
        return "outline"
    candidates = [x for x in (ref, plan.get("source_url")) if x]
    sources = plan.get("sources") or []
    if not isinstance(sources, list):
        raise ValueError("Include the verified source references.")
    for entry in sources:
        if isinstance(entry, dict):
            entry = next((entry[k] for k in ("url","library_file_id","file_id","id","reference") if portable_source(entry.get(k))), None)
        if not portable_source(entry):
            raise ValueError("Every source must have a durable file identity.")
        candidates.append(entry)
    if not any(portable_source(candidate) for candidate in candidates):
        raise ValueError("Use the actual Drive or Library file reference, the adopted outline, or attached-in-work with SHA-256.")
    if revision in ("adopted-outline", "attached-in-work") or revision.startswith("upload:"):
        raise ValueError("Use the verified revision for this source.")
    expected = upload_sha256(plan)
    if expected and SHA256.fullmatch(revision) and expected != revision:
        raise ValueError("The confirmed source revision and the recorded SHA-256 differ.")
    if "source_mirror" in plan and len(sources) > 1:
        raise ValueError("Bind a private backup to one exact source.")
    return "reference"


def required_attachment(plan):
    """Return the display label of originals the recipient must attach, if any."""
    def drive_source(value):
        return portable_source(value) and (value.startswith("drive:") or
                urlparse(value).netloc in {"drive.google.com", "docs.google.com"})

    def drive_entry(item):
        if isinstance(item, dict):
            return any(drive_source(item.get(key)) for key in ("url", "reference", "id", "file_id"))
        return drive_source(item)

    ref = plan.get("source_ref")
    entries = plan.get("sources") or []
    local_entries = [item for item in entries if not drive_entry(item)]
    needs_source = True
    if plan.get("adopted_outline") and ref in (None, "adopted-outline") and not plan.get("source_url") and not entries:
        needs_source = False
    elif ref != "attached-in-work":
        if plan.get("source_mirror") and len(entries) <= 1:
            try:
                mirror_sha = upload_sha256(plan)
                revision = plan.get("source_revision", "")
                needs_source = bool(SHA256.fullmatch(revision) and mirror_sha != revision)
            except (ValueError, TypeError):
                pass
        if needs_source and not str(plan.get("source_revision", "")).startswith("upload:"):
            if entries:
                needs_source = bool(local_entries)
            else:
                needs_source = not (drive_source(ref) or drive_source(plan.get("source_url")))

    if not needs_source:
        return None
    names = [item.get("name") for item in local_entries if isinstance(item, dict) and item.get("name")]
    if len(entries) <= 1 and plan.get("source_name"):
        names = [plan["source_name"]]
    return "、".join("「" + " ".join(name.split()) + "」" for name in names if isinstance(name, str) and name.strip()) or "這次使用的原稿"


def attachment_note(plan):
    target = required_attachment(plan)
    if not target:
        return ""
    return ("送出前，請在 Work 的「檔案 → 搜尋空間中的檔案」選取" + target +
            "，看到原稿出現在輸入框再與本指令一起送出。\n"
            "Work 收件後，請優先讀取這則訊息實際附入的原檔，核對來源與內容後接續製作。")


def work_directions(plan, *, attach_settings=False):
    source = required_attachment(plan)
    steps = ["複製下方完整指令，在同一帳號的 ChatGPT 首頁開啟「工作（Work）」，選用 Presentation Studio，再貼上指令。"]
    if source:
        steps.append("按「檔案」→「搜尋空間中的檔案」（有些介面顯示「檔案庫」），選取" +
                     source + "，核對檔名與版本。若檔案庫找不到，直接附上這次的原檔。")
    if attach_settings:
        steps.append("請將本次已確認的交接設定檔一併附在 Work 訊息中。")
    if source or attach_settings:
        steps.append("看到檔案出現在輸入框後，將檔案和指令一起送出一次。")
    else:
        steps.append("將指令送出一次。")
    return "\n".join(steps)


FINAL_ACCEPTANCE = '只驗收本次所選成品。從 Drive 下載實際交付的 PPTX；Google 簡報用原生 API、PDF 及圖件或頁面縮圖核對，試算表用 Sheets 讀回。沿用既有私人權限，所選檔案全部通過，就在同一回合交付各自連結。略過 Google 簡報轉回 PPTX 和瀏覽器下載授權。'


def launch_header(version):
    if not isinstance(version, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+){2}", version):
        raise ValueError("Read the installed Presentation Studio release before issuing a refined card.")
    release = PLATFORM_RELEASE.rsplit("/", 1)[0] + "/work/" + version + "/release.json"
    return (f"接續製作。請在 Work 依 Presentation Studio {version} 正式流程執行。先讀 {release}，核對同版工具並執行收件，再按下列已確認設定製作。"
            "\n精緻型依內容換構圖，小圖與圖示做真正透明背景；Google 使用可更新的連結圖表；刻度及資料標籤留在圖表本身，修改試算表時數值隨刷新改變。逐軸、逐筆核對圖表本身與實際投影片。\n" + FINAL_ACCEPTANCE)


def portable_message(plan):
    portable_source_kind(normalize_portable_revision(plan))
    digest = hashlib.sha256(canonical(plan)).hexdigest()
    body = json.dumps({"sha256": digest, "plan": plan}, ensure_ascii=False, separators=(",",":"), allow_nan=False)
    # Use one machine-readable line even when original slide text contains
    # Unicode line separators. Decoding JSON restores these exact characters.
    body = body.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    refined = refined_instruction(plan)
    message = "\n".join(filter(None, (launch_header(production_tools(plan)["version"]) if refined else
                                       "接續製作。請在 Work 讀取這次的原稿與設定，核對後照選定範圍製作並交付。",
                                       "" if refined else FINAL_ACCEPTANCE, attachment_note(plan), refined, delivery_folder_instruction(plan),
                                       PORTABLE_PREFIX + body)))
    steps = work_directions(plan)
    return {"action": "show_work_instruction", "message": message, "copy_label": "複製 Work 啟動指令",
            "portable_sha256": digest, "directions": steps, "display_text": steps + "\n\n```text\n" + message + "\n```"}


def fingerprint_source(path):
    path = Path(path)
    if not path.is_file():
        raise ValueError("The Work host has not materialized the source file.")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        block = stream.read(1024 * 1024)
        if not block:
            raise ValueError("The Work source file contains no bytes.")
        while block:
            digest.update(block)
            block = stream.read(1024 * 1024)
    return digest.hexdigest()


def drive_reference_id(value):
    if not isinstance(value, str):
        return None
    match = re.fullmatch(r"drive:([\w-]+)", value)
    if match:
        return match[1]
    url = urlparse(value)
    if url.scheme != "https" or url.netloc != "drive.google.com":
        return None
    match = re.fullmatch(r"/file/(?:u/[0-9]+/)?d/([\w-]+)(?:/(?:view|edit|preview))?/?", url.path)
    if match:
        return match[1]
    file_id = dict(parse_qsl(url.query)).get("id", "")
    if url.path == "/open" and DRIVE_FILE_ID.fullmatch(file_id):
        return file_id
    return None


def bind_drive_download(plan, file_id, metadata, source_file):
    """metadata must be the independent Drive files.get response, never part of the pasted card."""
    if isinstance(metadata, dict) and isinstance(metadata.get("structuredContent"), dict):
        metadata = metadata["structuredContent"]
    if not isinstance(metadata, dict) or metadata.get("id") != file_id or metadata.get("trashed") is True or not source_file:
        raise ValueError("Read the exact Drive file metadata and download that same file in Work (--drive-readback and --source-file).")
    source_file = Path(source_file)
    actual = fingerprint_source(source_file)
    revisions = {str(metadata[k]) for k in ("modifiedTime", "modified_time", "version", "headRevisionId") if metadata.get(k)}
    if plan["source_revision"] not in revisions | {actual}:
        raise ValueError("The confirmed Drive revision differs from the actual file revision.")
    size = source_file.stat().st_size
    if str(metadata.get("size", metadata.get("file_size_bytes", ""))) != str(size) or ("source_size" in plan and str(plan["source_size"]) != str(size)):
        raise ValueError("The Drive file size differs from the confirmed or downloaded file.")
    if plan.get("source_name") and (metadata.get("name") or metadata.get("file_name") or metadata.get("title")) != plan["source_name"]:
        raise ValueError("The confirmed Drive filename differs from its readback.")
    if editable_pptx_entry(plan) and (metadata.get("mimeType") or metadata.get("mime_type")) != "application/vnd.openxmlformats-officedocument.presentationml.presentation":
        raise ValueError("The bound source is not the expected PowerPoint file.")
    checks = [("sha256Checksum", actual)]
    if not metadata.get("sha256Checksum") and metadata.get("md5Checksum"):
        md5 = hashlib.md5(usedforsecurity=False)
        with source_file.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                md5.update(block)
        checks.append(("md5Checksum", md5.hexdigest()))
    server_match = any(metadata.get(key) == checksum for key, checksum in checks)
    if not server_match and not (metadata.get("sha256Checksum") or metadata.get("md5Checksum")):
        # The official connector's fetch response omits Google's checksums but supplies the exact bytes.
        inline = metadata.get("b64_string")
        if isinstance(inline, str) and len(inline) == (size + 2) // 3 * 4:
            server_match = hashlib.sha256(base64.b64decode(inline, validate=True)).hexdigest() == actual
        else:
            attachment = metadata.get("file_uri") or {}
            link = attachment.get("download_url") if isinstance(attachment, dict) else None
            uri = urlparse(link or "")
            if (uri.scheme == "https" and uri.netloc == uri.hostname and uri.hostname and
                    uri.hostname.endswith(".oaiusercontent.com") and uri.path.startswith("/files/") and
                    re.fullmatch(r"sediment://file_[0-9a-f]{32}", str(attachment.get("file_id", "")))):
                class DirectOnly(HTTPRedirectHandler):
                    def redirect_request(self, *args):
                        return None
                digest = hashlib.sha256()
                length = 0
                with build_opener(DirectOnly).open(link, timeout=45) as source:
                    for block in iter(lambda: source.read(1024 * 1024), b""):
                        length += len(block)
                        if length > size:
                            break
                        digest.update(block)
                server_match = length == size and digest.hexdigest() == actual
    if not server_match:
        raise ValueError("Drive's content checksum must match the downloaded source.")
    if plan.get("source_sha256", actual) != actual:
        raise ValueError("The downloaded file differs from the confirmed SHA-256.")
    return {**plan, "source_sha256": actual}


def verify_launch_release(prefix):
    # Literal release controls are part of a new copied card. Legacy cards had
    # none. A current card belongs to the version the user actually confirmed.
    release_root = re.escape(PLATFORM_RELEASE.rsplit("/", 1)[0] + "/work/")
    pins = set(re.findall(release_root + r"([0-9]+(?:\.[0-9]+){2})/release\.json", prefix))
    if pins and pins != {production_tools({}).get("version")}:
        raise ValueError("Use the official tool release fixed in this copied Work card.")

def open_portable(command, directory, surface, source_version=None, source_id=None, source_file=None, native_verification=None, drive_readback=None):
    if surface != "work":
        return {"action":"handoff_to_work","next_step":"在同一帳號開啟工作（Work），選 Presentation Studio，再貼上完整指令。"}
    markers = list(re.finditer(r"(?m)^[ \t]*PS-WORK-PLAN/1(?=\s|$)", command))
    if len(markers) != 1:
        raise ValueError("Copy the complete instruction containing one PS-WORK-PLAN/1 packet.")

    verify_launch_release(command[:markers[0].start()])

    def unique_object(pairs):
        data = dict(pairs)
        if len(pairs) != len(data):
            raise ValueError("A portable instruction contains duplicate fields.")
        return data

    def invalid_number(_):
        raise ValueError("Expected finite JSON numbers in the portable instruction.")

    payload = command[markers[0].end():].lstrip()
    envelope, end = json.JSONDecoder(object_pairs_hook=unique_object, parse_constant=invalid_number).raw_decode(payload)
    tail = payload[end:].lstrip(" \t")
    # Human directions may follow the complete JSON on a separate line.
    # They never contribute settings, source IDs, or permissions to the packet.
    if tail.strip() not in ("", "```") and (
            not tail.startswith(("\n", "\r")) or
            any(line.lstrip().startswith(("{", "[", "PS-WORK-PLAN/")) for line in tail.splitlines())):
        raise ValueError("Copy the complete Work instruction by itself.")
    if not isinstance(envelope, dict) or set(envelope) not in ({"plan"}, {"plan","sha256"}):
        raise ValueError("Invalid portable instruction.")
    plan = envelope["plan"]
    digest = hashlib.sha256(canonical(plan)).hexdigest()
    if "sha256" in envelope and envelope["sha256"] != digest:
        raise ValueError("The portable instruction changed or was truncated; copy it again.")
    plan = normalize_portable_revision(plan)
    kind = portable_source_kind(plan)
    if "sha256" not in envelope:
        # Tool origins are release-owned. A host-written instruction carries only user selections.
        plan = {key: value for key, value in plan.items() if key not in
                {"tool_version", "tool_url", "tool_sha256", "production_entry", "production_tools", "production_recipe", "production_instruction"}}
    drive_id = drive_reference_id(plan.get("source_ref")) or drive_reference_id(plan.get("source_url"))
    if kind == "reference" and drive_id and not plan.get("source_native") and not plan.get("source_mirror") and (
            drive_readback is not None or "sha256" not in envelope and len(plan.get("sources") or []) <= 1):
        plan = bind_drive_download(plan, drive_id, drive_readback, source_file)
        if source_version is not None and source_version != plan["source_revision"]:
            raise ValueError("The supplied version differs from the verified Drive revision.")
        source_version = plan["source_revision"]
    check_native_readback(plan, source_id, native_verification)
    expected = upload_sha256(plan) if kind in ("upload", "reference") else None
    mirror_id = (plan.get("source_mirror") or {}).get("file_id") if kind in ("upload", "reference") else None
    reference_mirror = kind == "reference" and mirror_id is not None and source_id == mirror_id
    if source_file is not None:
        actual = fingerprint_source(source_file)
        if expected and actual != expected:
            raise ValueError("The source differs from its previously recorded SHA-256.")
        # A service revision and the content hash may be independent proofs.
        if reference_mirror:
            if source_version is not None and source_version != actual:
                raise ValueError("Supply the SHA-256 read from the bound private copy.")
            source_version = plan["source_revision"]
        elif kind != "reference" or SHA256.fullmatch(plan["source_revision"]):
            if source_version is not None and source_version != actual:
                raise ValueError("The Work source bytes differ from the supplied source SHA-256.")
            source_version = actual
    elif reference_mirror:
        raise ValueError("Read the bound private copy of the reference and supply its materialized source file.")
    elif kind == "reference" and expected and source_version != expected:
        raise ValueError("Read this exact source file in Work and verify its recorded SHA-256 as well as its revision.")
    if kind == "upload":
        candidate = plan.get("source_native_fallback")
        if (source_id and isinstance(candidate, dict) and candidate.get("id") == source_id
                and drive_reference_id(candidate.get("url")) == source_id and expected and source_file is not None):
            # User's original fallback filename can differ (e.g. a re-upload
            # suffix). Equality is established by both independent byte hashes.
            check = {**plan, "source_revision": expected}
            check.pop("source_name", None)
            bind_drive_download(check, source_id, drive_readback, source_file)
            mirror_id = source_id
        if not isinstance(source_version, str) or not SHA256.fullmatch(source_version):
            raise ValueError("Read the exact file in Work and supply its actual file ID and bytes SHA-256.")
        if expected and source_version != expected:
            raise ValueError("The Work source bytes differ from the confirmed upload.")
        if source_id != plan["source_ref"]:
            known_attachment = isinstance(source_id, str) and UPLOAD_ID.fullmatch(source_id)
            # Some Work attachment mounts expose the local bytes but no file ID.
            exact_bytes = source_id is None and source_file is not None and expected == source_version
            if not expected or not (exact_bytes or known_attachment or (source_id and source_id == mirror_id)):
                raise ValueError("Retrieve the original upload, its bound Drive copy, or a reattachment matching its known SHA-256.")
        plan = {**plan, "source_revision":source_version}
    elif kind == "outline":
        actual = hashlib.sha256(canonical(plan["adopted_outline"])).hexdigest()
        if source_version is not None and source_version != actual:
            raise ValueError("The supplied version differs from the adopted outline's SHA-256.")
        plan = {**plan, "source_revision":actual}
    elif source_version != plan["source_revision"]:
        raise ValueError("Read the exact source in Work and verify its version before opening this job.")
    # Work must register/read/claim the same private handoff before any production.
    # The transport key survives recomputing a snapshot on another runtime release.
    return {**pack_work(plan, directory, previously_confirmed=True), "action":"register_handoff","job_id":plan["job_id"],
            "revision":plan["revision"], "source_revision":plan["source_revision"], "portable_sha256":digest}


def chart_workflow(plan):
    return {
        "applies_when": "可編輯 Google 簡報有一組直條、雙軸及折線的連結圖表",
        "tool_url": plan.get("tool_url"),
        "reference": "references/linked-chart-run.md",
        "command": "python3 scripts/linked-chart-run.py FINAL.pptx PPT.pdf GOOGLE.pdf slides.json chart.json sheet.xlsx state.json --page N",
        "final_acceptance": FINAL_ACCEPTANCE,
        "native_import": "python3 scripts/native-combo-workbook.py FINAL.pptx PPT.pdf CHARTS.xlsx --page N",
        "native_link": "先將 CHARTS.xlsx 匯入為本次要交付的 Google 試算表，取得其 chartId，於正式 Slides 原圖位建立 LINKED 圖表，刷新並匯出。",
        "inputs": "保留本次完整 Sheets EmbeddedChart（spec、position）、實際 Slides/Sheets ID、修訂及兩份成品渲染。",
        "acceptance": "在最終 Google 原生 PDF 對照兩軸端點、讀值、圖例、文字與圖表周邊。確認所有標籤清楚、資料點位置與原圖相符且原生圖能更新後，保留匯入的圖表規格完成驗收。有實際缺陷時才執行修復命令並重新驗收。",
        "outside_chart": "python3 scripts/repair-short-labels.py FINAL.pptx PPT.pdf --slides-pdf GOOGLE.pdf --slides-native slides.json；對全份原有短標籤的單行、字級與遮字逐一檢查，採用工具的修正請求後匯出刷新再核對。",
        "on_difference": "使用同版工具與本次實際輸出修復；只核對數字存在或肉眼看見標籤不能取得 verified。",
        "continue": {"prepare": "寫入工作 Sheets、刷新同一個連結圖表、重新匯出並重跑。",
                     "refresh": "刷新同一個 Slides 圖表，再讀回原生 PDF 和簡報修訂重跑。",
                     "project": "依指定修訂寫入 Slides 校正圖層，重新匯出原生 PDF 並重跑。",
                     "read_sheet_metadata": "讀回原工作試算表的分頁 ID 及標題，以 --sheet-meta 同一 state 接續。",
                     "formula_axis": "原生圖表兩軸像素實測偏離時，寫入公式校正分頁、刷新並讀回原始數列、公式、計算值，繼續同一份簡報。",
                     "restore_formula_series": "同一圖表在移動後如被服務清空數列，寫回本工作原圖規格與專用公式系列，讀回相同 ID、數列和原生 PDF，再沿用此狀態驗收。",
                     "reposition": "依指定修訂將連結圖表與其校正物件同步移入安全位置，再匯出核對邊界與圖說。",
                     "verified": "核對來源、成品 PDF 的 SHA 與逐項量測後計入驗收。"},
    }


def pack_work(plan, directory, *, previously_confirmed=False):
    validate_work_plan(plan)
    packet = {"format": WORK_FORMAT, "confirmed": True, "production_surface": "work", "plan": plan}
    packet["chart_workflow"] = chart_workflow(plan)
    packet.update(editable_pptx_entry(plan))
    packet["production_tools"] = production_tools(plan, confirming=not previously_confirmed)
    packet.update(refined_recipe(plan))
    packet["production_instruction"] = production_instruction(plan)
    return persist(directory, "studio-work-", canonical(packet))


def load_work(path, digest):
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("A Work handoff uses the full confirmation SHA-256.")
    packet = restore(path, digest)
    if not isinstance(packet, dict) or packet.get("format") != WORK_FORMAT or packet.get("confirmed") is not True or packet.get("production_surface") != "work":
        raise ValueError("Expected a confirmed Chat-to-Work handoff.")
    validate_work_plan(packet.get("plan"))
    return packet["plan"]


def work_message(path, digest, url=None, attached=False):
    plan = load_work(path, digest)
    if bool(url) == bool(attached):
        raise ValueError("Supply either a verified private Drive URL or the attached handoff file.")
    if url:
        p = urlparse(url)
        doc = p.netloc == "docs.google.com" and re.fullmatch(r"/document/(?:u/[0-9]+/)?d/[\w-]+(?:/(?:edit|view|preview))?/?", p.path)
        drive_file = p.netloc == "drive.google.com" and (
            re.fullmatch(r"/file/(?:u/[0-9]+/)?d/[\w-]+(?:/(?:view|edit|preview))?/?", p.path)
            or (p.path == "/open" and re.fullmatch(r"[\w-]+", dict(parse_qsl(p.query)).get("id", ""))))
        if not durable_url(url) or not (doc or drive_file):
            raise ValueError("Use the private handoff file link returned and read back by Drive.")
    item = url if url else "本訊息所附的設定檔"
    message = ("接續製作 " + digest[:16] + "，" + production_instruction(plan)
               + " 已確認交接檔為 " + item + "（SHA-256 " + digest + "）。")
    if refined_instruction(plan):
        lines = (launch_header(production_tools(plan)["version"]), message, attachment_note(plan))
    else:
        lines = (message, FINAL_ACCEPTANCE, attachment_note(plan))
    message = "\n".join(filter(None, lines))
    steps = work_directions(plan, attach_settings=attached)
    return {"message": message, "copy_label": "複製 Work 啟動指令",
            "directions": steps, "display_text": steps + "\n\n```text\n" + message + "\n```"}


def delivery_folder_instruction(plan):
    delivery = plan.get("delivery")
    choices = delivery if isinstance(delivery, dict) else {}
    folder = choices.get("folder_id") or plan.get("work_folder_id") or plan.get("destination_folder_id")
    link = plan.get("destination_url")
    if not folder and isinstance(link, str):
        match = re.fullmatch(r"https://drive\.google\.com/drive/(?:u/\d+/)?folders/([\w-]+)/?(?:\?usp=(?:sharing|drivesdk))?", link)
        if match:
            folder = match[1]
    if isinstance(folder, str) and DRIVE_FILE_ID.fullmatch(folder):
        dest = "將本次 Drive 成品都存入已選工作資料夾 " + folder + "。"
    elif choices.get("new_folder") is True:
        dest = "依本次設定建立一個私人工作資料夾，取得其實際 ID，將本次 Drive 成品存入其中。"
    else:
        return ""
    return dest + "交付前逐檔讀回 Drive parents；若簡報或試算表仍在根目錄，移到該工作資料夾再讀回。"


def refined_instruction(plan, tools=None):
    settings = plan.get("settings", {})
    profiles = plan.get("page_profiles") or {}
    if settings.get("format") not in (None, "editable") or (
            settings.get("editable_profile") != "refined" and
            not (isinstance(profiles, dict) and "refined" in profiles.values())):
        return ""
    tools = production_tools(plan) if tools is None else tools
    version = tools.get("version")
    identity = "Presentation Studio " + version if version else "本次確認的 Presentation Studio 版本"
    steps = [f"可編輯・精緻型使用 {identity}。Work 先實際開啟同版外掛的 studio-production/scripts 及 references。"]
    url = tools.get("url", "")
    drive = re.fullmatch(r"https://drive\.google\.com/file/d/([\w-]+)/view(?:\?usp=(?:drivesdk|sharing))?", url)
    if version and drive and SHA256.fullmatch(tools.get("sha256") or ""):
        steps.append(f"未掛載時，從 Google Drive 正式下載工具 ZIP，file ID {drive[1]}，核對 ZIP SHA-256 {tools['sha256']} 與 release.json 版本 {version} 後解開。")
    steps.append(f"若取不到工具，讀官方 AI 資源平台 {PLATFORM_RELEASE}，比對 version 與本件一致，從 download_url 取得安裝 ZIP，核對整包 sha256 和內部 plugin.json 版本，取出 studio-production。")
    if editable_pptx_entry(plan):
        steps.append("Work 用本次原稿執行 claim 或 receive-work，帶 --start-dir RUN_DIR --source-file SOURCE.pptx。收據回讀後這個入口會自動啟動 python3 scripts/editable-image-queue.py start-work RECEIVED.json SOURCE.pptx RUN_DIR；接著執行傳回的 foreground_action。可自動編排的頁實際使用 compose-refined.py 產出的 RUN_DIR/base.pptx；逐頁處理 requires_custom_layout，再沿用同一底稿完成製作。")
    else:
        steps.append("依已採用內容建立可編輯工作稿；適合自動重排的頁可在這份 PPTX 工作副本實跑 scripts/compose-refined.py，並沿用其成品。")
    steps.append("版面依確認的自訂風格、鎖定頁和逐件例外。工具未掛載時先取回同版工具並使用可執行的 Python 環境。需客製的頁才以原生物件另排，流程用順序與節點，對照用同一比較基準並排，主張以大標帶證據。若同版製作工具仍無法執行，繼續完成可獨立處理的頁和素材，明列受阻步驟。沿用配圖授權，逐頁檢視實際輸出；圖表核對每個原有可見標籤。")
    steps.append("Work 依本次圖片授權執行藝術設計。允許依內容自動配圖時，先挑需要真照片、去背物件及語意圖示的頁；"
                 "從原文擬具體場景與主體，實際取得本次獨立素材，再以 compose-refined.py --art 將已驗收原件及可編輯文字一起構圖。"
                 "優先用已回傳的帶圖工作稿；依照片主體調整出血及裁切、讓去背物與色塊分層。流程用能辨識動作的原生透明圖示。"
                 "原圖、截圖、圖表及無圖頁的個別指定優先。禁止新增時用字級、段落與資料關係設計。"
                 "交付前實看兩份成品的主圖裁切、背景透出及文字可編輯性，逐頁核對必要圖位。")
    steps.append("組裝後先用 refined-design.py check 核對實際構圖與完整透明輪廓。有雙軸柱線圖時，用 native-combo-workbook.py 從正式 PowerPoint 和本機渲染 PDF 取出帶圖 XLSX，匯入為這次要交付的 Google 試算表，在原圖位建立 LINKED 圖表。從正式 Google PDF 核對數值和版面後交付。")
    return "\n".join(steps)


def card_production_choices(plan):
    settings=plan["settings"]
    variant={**plan, "settings":{**settings,"format":"editable","editable_profile":"refined"}}
    choices={"refined":refined_instruction(variant), "launch_header":launch_header(production_tools(plan)["version"])}
    if settings.get("format"):
        choices["format"]=settings["format"]
    if settings.get("editable_profile"):
        choices["profile"]=settings["editable_profile"]
    if plan.get("page_profiles"):
        choices["page_profiles"]=plan["page_profiles"]
    folder=delivery_folder_instruction(plan)
    fixed_folder=delivery_folder_instruction({**plan,"delivery":[]})
    if folder:
        choices["folder"]=folder
    if fixed_folder:
        choices["fixed_folder"]=fixed_folder
    return choices


def production_instruction(plan):
    labels = {"pptx":"PowerPoint（.pptx）","powerpoint":"PowerPoint（.pptx）",
              "slides":"Google 簡報","google_slides":"Google 簡報",
              "sheets":"圖表試算表（Google Sheets）","google_sheets":"圖表試算表（Google Sheets）",
              "pdf":"PDF","xlsx":"Excel 試算表","png":"PNG 圖片","images":"投影片圖片"}
    delivery = plan["delivery"]
    if isinstance(delivery, dict):
        keys = [k for k,v in delivery.items() if v and not (isinstance(v,dict) and v.get("required") is False)]
        formats = delivery.get("formats")
        if isinstance(formats,list):
            keys.extend(formats)
    else:
        keys = delivery if isinstance(delivery,list) else [delivery]
    names = []
    for key in keys:
        if isinstance(key,dict):
            if key.get("required") is False:
                continue
            key = key.get("format") or key.get("type")
        if isinstance(key,str) and key.lower() in labels and labels[key.lower()] not in names:
            names.append(labels[key.lower()])
    target = "、".join(names) if names else "設定中選定的全部成品"
    instruction = ("在本次 Work 完成已確認的製作與交付。用 Presentation Studio 讀回同一筆工作，"
                   "建立底稿後直接完成其餘已授權步驟，驗收後在本對話交付" + target + "。")
    if editable_pptx_entry(plan):
        guidance = "依已確認的文字政策排版，按原稿逐件比對各交付版本中受保護圖片的裁切與顯示比例。"
        settings = plan["settings"]
        overrides = plan.get("page_profiles")
        profiles = overrides.values() if isinstance(overrides, dict) else ()
        if settings.get("editable_profile") == "refined" or "refined" in profiles:
            variety = settings.get("photo_layout_variety")
            if variety is True:
                guidance += "已要求大圖構圖錯落，依 references/work-start.md 比對可自由安排的各頁圖框、位置與占幅。"
            elif variety is not False:
                guidance += "若已明確要求大圖構圖錯落，依 references/work-start.md 量測各頁的大圖位置與占幅。"
        instruction += guidance + "遇到落差就在同一工作修正與重驗，沿用本次確認。"
    return "\n".join(filter(None, (instruction, refined_instruction(plan), delivery_folder_instruction(plan))))


def production_tools(plan, *, confirming=False):
    # The unpacked tools and installed plugin have different roots. Neither
    # embeds a self-referential ZIP hash. Keep retrieval data separate below.
    here = Path(__file__).resolve()
    source, version = None, None
    manifests = [(here.parent.parent/"release.json","release.json")]
    if len(here.parents) > 3:
        manifests.append((here.parents[3]/"plugin.json","plugin.json"))
    for path, label in manifests:
        if path.is_file():
            manifest = json.loads(path.read_bytes())
            if manifest.get("package",manifest.get("name")) == "presentation-studio-text" and bound(manifest.get("version")):
                source,version = label,manifest["version"]
                break
    claimed = plan.get("tool_version")
    if confirming and version and claimed and version != claimed:
        raise ValueError("The confirmed tool version differs from this release. Read the current release and its verified tool reference.")
    current = {"package":"presentation-studio-text"}
    if version:
        current.update(version=version,version_source=source)
        current["reference"] = "release.json" if source == "release.json" else "skills/studio-production/references/web-production-tools.md"
    elif bound(claimed):
        current.update(version=claimed,version_source="confirmed_tool_reference")
    if source == "plugin.json":
        guide = here.parents[2]/"studio-production/references/web-production-tools.md"
        if guide.is_file():
            note = guide.read_text(encoding="utf-8")
            links = re.findall(r"https://drive\.google\.com/file/d/[\w-]+/view(?:\?usp=drivesdk)?", note)
            digests = re.findall(r"`([0-9a-f]{64})`", note)
            if (f"Presentation-Studio-tools-{version}.zip" in note and
                    len(set(links)) == 1 and len(set(digests)) == 1):
                current.update(url=links[0],sha256=digests[0])
    url,sha = plan.get("tool_url"), plan.get("tool_sha256")
    if bound(claimed) and claimed == current.get("version") and durable_url(url) and isinstance(sha,str) and re.fullmatch("[0-9a-f]{64}",sha):
        if current.get("sha256") and sha != current["sha256"]:
            if confirming:
                raise ValueError("The confirmed ZIP checksum differs from this installed release.")
        else:
            current.update(url=url,sha256=sha)
    return current


def receipt_identity(plan, digest, receipt):
    identity = {"job_id": plan["job_id"], "revision": plan["revision"], "packet_sha256": digest}
    if receipt is not None and (not isinstance(receipt, dict) or any(receipt.get(k) != v for k, v in identity.items())):
        raise ValueError("Read the receipt for this exact job, revision and confirmation.")
    return identity


def durable_url(value):
    if not isinstance(value, str) or not value.startswith("https://") or any(c.isspace() for c in value):
        return None
    try:
        if not urlparse(value).hostname:
            return None
        check_portable(value, "url")
    except ValueError:
        return None
    return value


def observed_work_link(url, origin):
    # The caller supplies a real permalink returned by Work or the final URL of
    # this job after opening it. The execution ID is deliberately not an input.
    if origin not in ("host_permalink", "opened_work_conversation") or not durable_url(url):
        return None
    parsed = urlparse(url)
    if (parsed.netloc != "chatgpt.com" or parsed.query or parsed.fragment
            or not re.fullmatch(r"/(?:g/[\w-]+/)?c/[\w-]+/?", parsed.path)):
        return None
    return {"url": url, "origin": origin}


def receipt_state(receipt):
    state = receipt.get("state") if receipt is not None else "ready"
    return "complete" if state == "completed" else state


def receipt_display(receipt, plan, record_url=None):
    # Never promote a legacy work_ref (including a URL-shaped one) to a link.
    if not receipt:
        return {}
    view = {"state": receipt_state(receipt)}
    if view["state"] == "complete":
        links = {}
        for outputs in (receipt.get("outputs"), receipt.get("verified_outputs")):
            if isinstance(outputs, list):
                outputs = {item.get("format") or item.get("type") or item.get("name"):item
                           for item in outputs if isinstance(item,dict)}
            if isinstance(outputs, dict):
                for key, value in outputs.items():
                    url = (value.get("url") or value.get("webViewLink")) if isinstance(value, dict) else value
                    if isinstance(key,str) and durable_url(url):
                        links[key] = url
        if links:
            return {**view, "outputs": links}
    proof = receipt.get("work_link")
    if isinstance(proof, dict) and observed_work_link(proof.get("url"), proof.get("origin")):
        return {**view, "work_url": proof["url"]}
    if durable_url(record_url) and urlparse(record_url).hostname in {"drive.google.com", "docs.google.com"}:
        return {**view, "record_url": record_url}
    if durable_url(plan.get("destination_url")) and urlparse(plan["destination_url"]).hostname == "drive.google.com":
        return {**view, "folder_url": plan["destination_url"]}
    return view


def find_pending(inventory, folder_id, selection=None, work_ref=None):
    # The host supplies a complete Drive listing plus actual downloaded packet
    # files, official parent/owner metadata and the current shared job receipts.
    if not bound(folder_id) or inventory.get("folder_id") != folder_id or inventory.get("complete") is not True:
        raise ValueError("Read all pages of the verified private pending-jobs folder.")
    if work_ref is not None and not bound(work_ref):
        raise ValueError("Supply the actual current Work reference, or omit it for discovery.")
    items = inventory.get("items")
    if not isinstance(items, list):
        raise ValueError("Expected the complete list of downloaded Work packet entries.")
    pending = {}
    existing = []
    seen = {}
    file_ids = {}
    for item in items:
        native = item.get("mimeType", item.get("mime_type")) == "application/vnd.google-apps.document"
        match = re.fullmatch(r"studio-work-([0-9a-f]{64})\.json", item.get("name", ""))
        if not (native or match) or item.get("trashed") or folder_id not in item.get("parents", []):
            continue
        owned = item.get("ownedByMe", item.get("owned_by_me"))
        if owned is not True or item.get("shared") is not False:
            if owned is False or item.get("shared") is True:
                continue
            raise ValueError("Read the pending file's owner and visibility before choosing a job.")
        if item.get("parents") != [folder_id]:
            raise ValueError("A pending file must have the verified folder as its only parent.")
        file_id = item.get("id")
        created = item.get("createdTime", item.get("created_time"))
        if not bound(file_id) or not bound(created):
            raise ValueError("Supply the real Drive file ID and creation time for each pending job.")
        if native:
            record = item.get("doc_read", item)
            if (not isinstance(record, dict) or record.get("document_id") != file_id
                    or not bound(record.get("revision_id"))):
                raise ValueError("Read the current revision of this exact handoff document.")
            if record.get("action") == "read_stage":
                # A verified card draft is not an approved job until its explicit
                # activation arrives. It must never win automatic selection.
                continue
            if (record.get("action") != "read"
                    or "receipt" not in record or not bound(record.get("sha256")) or not record.get("snapshot")):
                raise ValueError("Read the same native document with the handoff adapter, including its receipt.")
            digest = record["sha256"]
        else:
            record = item
            digest = match.group(1)
        plan = load_work(Path(record["snapshot"]), digest)
        receipt = record.get("receipt")
        receipt_identity(plan, digest, receipt)
        if file_id in seen:
            if seen[file_id] != (digest, receipt):
                raise ValueError("Reread the pending document to reconcile inconsistent listing entries.")
            continue
        seen[file_id] = (digest, receipt)
        file_ids.setdefault(digest, []).append(file_id)
        title = plan.get("title") or plan.get("source_name") or plan["job_id"]
        detail = {"title": title, "confirmed_file_created": created, "short_id": digest[:16],
                  "file_id": file_id, "sha256": digest, "job_id": plan["job_id"]}
        state = receipt_state(receipt)
        detail["state"] = state
        if state in ("complete", "accepted"):
            if state == "accepted" and not bound(receipt.get("work_ref")):
                raise ValueError("Read the existing Work reference before resolving this job.")
            if state == "accepted" and work_ref == receipt["work_ref"]:
                # Re-enter through claim so the current source and the same owner
                # are both verified again. Do not issue a new receipt.
                pending[digest] = detail
                continue
            record_url = record.get("record_url") or item.get("webViewLink") or item.get("url")
            existing.append({**detail, "display": receipt_display(receipt, plan, record_url)})
        elif state in ("ready", "requested", "unknown", "awaiting_confirmation", "failed_before_start"):
            pending[digest] = detail
        else:
            raise ValueError("Resolve the pending confirmation's current state.")
    conflicts = [{"sha256": digest, "file_ids": ids} for digest, ids in file_ids.items() if len(ids) > 1]
    if conflicts:
        return {"action": "resolve_duplicate_packets", "conflicts": conflicts}
    if selection:
        if not re.fullmatch(r"[0-9a-f]{16}|[0-9a-f]{64}", selection):
            raise ValueError("Choose one of the listed confirmation fingerprints.")
        chosen = [job for digest, job in pending.items() if digest.startswith(selection)]
        previous = [job for job in existing if job["sha256"].startswith(selection)]
        if len(chosen) + len(previous) != 1:
            raise ValueError("The selected pending job is missing or ambiguous.")
        if previous:
            return {"action": "use_existing_work", "job": previous[0], "display": previous[0]["display"]}
    else:
        chosen = list(pending.values())
    if not chosen:
        return {"action": "no_pending", "existing": existing}
    if len(chosen) > 1:
        return {"action": "choose_job", "choices": chosen}
    job = chosen[0]
    action = "receive_packet" if job["state"] in ("ready", "failed_before_start", "accepted") else "reconcile_original_operation"
    return {"action": action, "job": job}


def editable_pptx_entry(plan):
    settings = plan["settings"]
    form = settings.get("format")
    if str(plan.get("mode")) != "3" or not (form == "editable" or (
            form is None and settings.get("editable_profile") in ("quick", "refined"))):
        return {}
    # Do not treat a Drive /presentation/ URL as a PPTX; the same URL form
    # also addresses native Slides. Use the confirmed source's name or MIME.
    source_url = plan.get("source_url")
    source_ref = plan.get("source_ref")
    sources = plan.get("sources")
    candidates = [s for s in sources if isinstance(s, dict)] if isinstance(sources, list) else []
    if len(candidates) > 1:
        candidates = [s for s in candidates if (source_url and s.get("url") == source_url) or
                      (source_ref and source_ref in (s.get("id"), s.get("file_id"), s.get("reference")))]
    source = candidates[0] if len(candidates) == 1 else {}
    mime = plan.get("source_mime_type") or source.get("mime_type") or source.get("mimeType")
    name = plan.get("source_name") or source.get("name") or ""
    if mime:
        is_pptx = mime == "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    else:
        is_pptx = isinstance(name, str) and name.casefold().endswith(".pptx")
    if not is_pptx:
        return {}
    return {"production_entry": {"script": "scripts/editable-image-queue.py", "command": "start-work",
                                 "inputs": ["RECEIVED.json", "SOURCE.pptx", "RUN_DIR"]}}


def refined_recipe(plan):
    settings = plan["settings"]
    if not editable_pptx_entry(plan) or (
            settings.get("editable_profile") != "refined" and "refined" not in (plan.get("page_profiles") or {}).values()):
        return {}
    # This contract is resolved in the receiving package, independent of what the Chat UI rendered.
    release = production_tools({})
    if not release.get("version"):
        raise ValueError("Resolve the installed Presentation Studio release and its matching tool manifest in Work.")
    return {"production_recipe": {
        "final_acceptance": FINAL_ACCEPTANCE,
        "schema": "presentation-studio/refined-work/1", "version": release["version"],
        "tools": release, "official_installer_index": PLATFORM_RELEASE,
        "entry_argv": ["python3", "scripts/editable-image-queue.py", "start-work", "RECEIVED.json", "SOURCE.pptx", "RUN_DIR"],
        "foreground": {"module": "scripts/work-foreground.mjs", "function": "runWorkForeground"},
        "next_argv": ["python3", "scripts/editable-image-queue.py", "work-next", "RUN_DIR"],
        "assemble_base": "files.base",
        "composition_check": ["python3", "scripts/refined-design.py", "check", "SOURCE.pptx", "FINAL.pptx", "--plan", "PLAN.json"],
        "composition_repair": ["python3", "scripts/refined-design.py", "repair", "SOURCE.pptx", "FINAL.pptx", "--plan", "PLAN.json", "--out", "FIXED.pptx"],
        "dual_axis_google_chart": chart_workflow(plan),
        "reviewed_art_cli": ["python3", "scripts/compose-refined.py", "SOURCE.pptx", "--plan", "PLAN.json",
                             "--art", "REVIEWED_ART.json", "--out", "COMPOSED.pptx", "--report", "COMPOSITION.json"],
        "verify_argv": ["node", "scripts/work-foreground.mjs", "verify", "RUN_DIR", "CURRENT_EVIDENCE.json"]}}


def receive_work(path, digest, surface, source_version=None, work_ref=None, receipt=None, *, work_url=None, url_origin=None, record_url=None, native_id=None, native_verification=None):
    plan = load_work(path, digest)
    identity = receipt_identity(plan, digest, receipt)
    if surface != "work":
        if receipt_state(receipt) in ("accepted", "complete"):
            return {"action": "use_existing_work", "display": receipt_display(receipt, plan, record_url)}
        result = {"action": "handoff_to_work", "job_id": plan["job_id"]}
        if record_url and receipt_state(receipt) == "ready":
            result.update(work_message(path, digest, url=record_url))
        else:
            result["next_action"] = "read_handoff_document"
        return result
    if not bound(work_ref):
        raise ValueError("Bind the actual receiving Work conversation or host-provided run reference.")
    check_portable(work_ref, "work_ref")
    link = observed_work_link(work_url, url_origin)
    if receipt is not None:
        state = receipt_state(receipt)
        if state in ("requested", "unknown", "awaiting_confirmation"):
            return {"action": "reconcile_original_operation", "receipt": receipt}
        if state in ("accepted", "complete"):
            if state == "accepted" and not bound(receipt.get("work_ref")):
                raise ValueError("A received Work job needs its actual owning reference.")
            if state == "complete" or receipt["work_ref"] != work_ref:
                return {"action": "use_existing_work", "receipt": receipt, "display": receipt_display(receipt, plan)}
        if state not in ("accepted", "ready", "failed_before_start"):
            raise ValueError("Resolve the previous operation before dispatching another.")
    check_native_readback(plan, native_id, native_verification)
    if plan["source_revision"] != source_version:
        raise ValueError("The resolved source version differs from the confirmed one.")
    if receipt is not None and receipt.get("state") == "accepted":
        tools = production_tools(plan)
        workflow = chart_workflow(plan)
        if plan.get("tool_version") and tools.get("version") != plan["tool_version"]:
            workflow["tool_url"] = tools.get("url")
        return {"action": "resume", "plan": plan, "receipt": receipt, "chart_workflow": workflow,
                "display": receipt_display(receipt, plan), "production_tools": tools,
                "production_instruction": production_instruction(plan), **editable_pptx_entry(plan), **refined_recipe(plan)}
    # Producing this proposed receipt does not submit work. The caller must claim
    # the durable record once and read it back before beginning production.
    return {"action": "claim_before_production", "proposed_receipt":
            {**identity, "state": "accepted", "work_ref": work_ref, **({"work_link": link} if link else {})}}


def work_link_options(command):
    command.add_argument("--observed-work-url", help="Exact host permalink or final browser URL for this Work job")
    command.add_argument("--url-origin", choices=("host_permalink", "opened_work_conversation"))


def production_start_options(command):
    command.add_argument("--start-dir", type=Path, help="On the same Work owner's confirmed receipt, run the refined entry in this job directory.")
    command.add_argument("--source-file", type=Path)
    command.add_argument("--source-readback", type=Path, help="Independent authenticated download proof for legacy private records without a source SHA-256.")


def start_claimed_work(decision, args):
    directory = getattr(args, "start_dir", None)
    if not directory or decision.get("action") != "resume" or not decision.get("production_recipe"):
        return decision
    if not args.source_file:
        raise ValueError("Pass the PowerPoint file resolved by this Work with --source-file.")
    scripts = Path(__file__).resolve().parent
    queue = scripts / "editable-image-queue.py"
    if not queue.is_file():
        queue = scripts.parents[1] / "studio-production/scripts/editable-image-queue.py"
    if not queue.is_file():
        raise ValueError("Load the verified tool bundle for this Work release, then repeat the same claim.")
    received = persist(directory, "studio-received-", canonical(decision))["snapshot"]
    argv = [sys.executable, str(queue), "start-work", str(received), str(args.source_file), str(directory)]
    if args.source_readback:
        argv.extend(["--source-readback", str(args.source_readback)])
    proc = subprocess.run(argv, capture_output=True, text=True)
    if proc.returncode:
        raise ValueError("The refined entry could not start: " + (proc.stdout or proc.stderr).strip())
    action = json.loads(proc.stdout)
    return {**decision, "received_file": received, "run_dir": str(directory), "foreground_action": action}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    capture = sub.add_parser("freeze")
    capture.add_argument("plan", type=Path)
    capture.add_argument("directory", type=Path)
    capture.add_argument("--surface", help="Actual host. Missing or unrecognized hosts hand off to Work.")
    capture.add_argument("--production-surface", choices=("work", "chat", "codex"),
                         help="Accepted for older cards; ordinary Chat always hands off to Work.")
    resume = sub.add_parser("restore")
    resume.add_argument("snapshot", type=Path)
    resume.add_argument("fingerprint")
    pack = sub.add_parser("pack-work")
    pack.add_argument("plan", type=Path)
    pack.add_argument("directory", type=Path)
    message = sub.add_parser("work-message")
    receive = sub.add_parser("receive-work")
    for cmd in (message, receive):
        cmd.add_argument("snapshot", type=Path)
        cmd.add_argument("sha256")
    carrier = message.add_mutually_exclusive_group(required=True)
    carrier.add_argument("--private-url")
    carrier.add_argument("--attached", action="store_true")
    receive.add_argument("--surface", required=True)
    receive.add_argument("--source-id", help="Actual native source ID for a converted-source handoff.")
    receive.add_argument("--native-verification", type=Path)
    receive.add_argument("--source-version", help="Actual source version read by the receiving Work.")
    receive.add_argument("--work-ref", help="Actual Work execution reference. A Chat handoff does not have one.")
    receive.add_argument("--receipt", type=Path)
    receive.add_argument("--private-url", help="This exact handoff document's verified Drive URL for redisplaying a launch instruction in Chat.")
    work_link_options(receive)
    production_start_options(receive)
    prep = sub.add_parser("prepare-source")
    prep.add_argument("plan", type=Path)
    prep.add_argument("--source-file", type=Path)
    prep.add_argument("--source-id")
    prep.add_argument("--drive-meta", type=Path)
    prep.add_argument("--downloaded-file", type=Path)
    prep.add_argument("--account-email")
    prep.add_argument("--read-error", choices=sorted(SOURCE_FAILURES))
    prep.add_argument("--copy-error", choices=sorted(SOURCE_FAILURES))
    portable = sub.add_parser("portable-message")
    portable.add_argument("plan", type=Path)
    open_command = sub.add_parser("open-portable")
    open_command.add_argument("--native-verification", type=Path)
    open_command.add_argument("message", type=Path)
    open_command.add_argument("directory", type=Path)
    open_command.add_argument("--surface", required=True)
    open_command.add_argument("--source-version", help="Actual source version or byte-level SHA-256 read by Work.")
    open_command.add_argument("--source-id", help="Immutable file ID actually retrieved in Work for an upload-bound plan.")
    open_command.add_argument("--source-file", type=Path, help="Source file actually materialized in Work; read and hash its bytes here.")
    open_command.add_argument("--drive-readback", type=Path, help="Independent authenticated Drive files.get metadata for the downloaded file.")
    lookup = sub.add_parser("find-pending")
    lookup.add_argument("inventory", type=Path)
    lookup.add_argument("--folder-id", required=True)
    lookup.add_argument("--select")
    lookup.add_argument("--work-ref", help="The current host's verified Work reference when resuming its accepted job.")
    args = parser.parse_args()
    if args.command == "freeze":
        result = freeze(json.loads(args.plan.read_text()), args.directory,
                        surface=args.surface, production_surface=args.production_surface)
    elif args.command == "prepare-source":
        result = prepare_source(json.loads(args.plan.read_bytes()), source_file=args.source_file, source_id=args.source_id,
                                read_error=args.read_error, copy_error=args.copy_error, account_email=args.account_email,
                                drive_metadata=json.loads(args.drive_meta.read_bytes()) if args.drive_meta else None,
                                downloaded_file=args.downloaded_file)
    elif args.command == "portable-message":
        result = portable_message(json.loads(args.plan.read_bytes()))
    elif args.command == "open-portable":
        result = open_portable(args.message.read_text(encoding="utf-8"), args.directory, args.surface,
                               args.source_version, args.source_id, args.source_file, args.native_verification,
                               json.loads(args.drive_readback.read_bytes()) if args.drive_readback else None)
    elif args.command == "pack-work":
        result = pack_work(json.loads(args.plan.read_text()), args.directory)
    elif args.command == "restore":
        result = restore(args.snapshot, args.fingerprint)
    elif args.command == "work-message":
        result = work_message(args.snapshot, args.sha256, args.private_url, args.attached)
    elif args.command == "find-pending":
        result = find_pending(json.loads(args.inventory.read_text()), args.folder_id, args.select, args.work_ref)
    else:
        previous = json.loads(args.receipt.read_text()) if args.receipt else None
        result = receive_work(args.snapshot, args.sha256, args.surface, args.source_version, args.work_ref, previous,
                              work_url=args.observed_work_url, url_origin=args.url_origin, record_url=args.private_url, native_id=args.source_id, native_verification=args.native_verification)
        result = start_claimed_work(result, args)
    print(json.dumps(result, ensure_ascii=False))
