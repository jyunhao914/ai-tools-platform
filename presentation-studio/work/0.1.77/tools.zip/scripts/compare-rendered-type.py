#!/usr/bin/env python3
"""Compare effective text sizes in a final PPTX render and an export of native Slides."""
import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
import math
from pathlib import Path
import unicodedata

import fitz


@dataclass
class Glyph:
    text: str
    size: float
    box: tuple


def read_lines(page, relative_to_width):
    """All sizes use the PowerPoint page width as reference; boxes are normalized."""
    lines = []
    width, height = page.rect.width, page.rect.height
    for block in page.get_text("rawdict", flags=fitz.TEXTFLAGS_RAWDICT & ~fitz.TEXT_PRESERVE_IMAGES)["blocks"]:
        for line in block.get("lines", []):
            glyphs = []
            for span in line["spans"]:
                size = span["size"] * relative_to_width / width
                for char in span["chars"]:
                    x0, y0, x1, y1 = char["bbox"]
                    box = (x0 / width, y0 / height, x1 / width, y1 / height)
                    for c in unicodedata.normalize("NFKC", char["c"]):
                        if not c.isspace() and c not in ("\u00ad", "\u200b"):
                            glyphs.append(Glyph(c, size, box))
            if glyphs:
                lines.append(glyphs)
    return lines


def bounds(glyphs):
    return [round(op(g.box[i] for g in glyphs), 5) for i, op in enumerate((min, min, max, max))]


def point_distance(a, b):
    return math.hypot(a.box[0] - b.box[0], a.box[1] - b.box[1])


def find_line(needle, haystack, target, source, used):
    """Match across line wraps and font runs; don't reuse an identical label twice."""
    matches = []
    start = haystack.find(needle)
    while start != -1:
        if used.isdisjoint(range(start, start + len(needle))):
            matches.append((point_distance(source[0], target[start]), start))
        start = haystack.find(needle, start + 1)
    if not matches:
        return None, "text_or_reading_order"
    matches.sort()
    if len(matches) > 1 and (matches[0][0] > 0.15 or matches[1][0] - matches[0][0] < 0.025):
        return None, "ambiguous_duplicate"
    return matches[0][1], None


def shrank(source_size, target_size):
    return source_size - target_size > 1.0 and target_size < source_size * 0.92


def compare_page(original, native, index):
    source_lines = read_lines(original, original.rect.width)
    target = [g for line in read_lines(native, original.rect.width) for g in line]
    haystack = "".join(g.text for g in target)
    used = set()
    result = {"page": index, "compared": 0, "issues": [], "unmatched": []}
    if not math.isclose(original.rect.width / original.rect.height,
                        native.rect.width / native.rect.height, rel_tol=0.01):
        result["unmatched"].append({"reason": "page_aspect_changed"})
    if not source_lines:
        result["unmatched"].append({"reason": "no_reference_text"})
    for line in source_lines:
        text = "".join(g.text for g in line)
        start, why = find_line(text, haystack, target, line, used)
        if start is None:
            result["unmatched"].append({"text": text, "source_bbox": bounds(line), "reason": why})
            continue
        used.update(range(start, start + len(line)))
        result["compared"] += len(line)
        # Preserve mixed-size paragraphs (for example a small caption inside a title).
        i = 0
        while i < len(line):
            source_size, target_size = line[i].size, target[start + i].size
            if not shrank(source_size, target_size):
                i += 1
                continue
            end = i + 1
            while (end < len(line) and abs(line[end].size - source_size) < 0.2 and
                   abs(target[start + end].size - target_size) < 0.2 and
                   shrank(line[end].size, target[start + end].size)):
                end += 1
            result["issues"].append({"text": text[i:end], "expected_pt": round(source_size, 2),
                                     "actual_pt": round(target_size, 2), "source_bbox": bounds(line[i:end]),
                                     "slides_bbox": bounds(target[start + i:start + end])})
            i = end
    result["status"] = "repair" if result["issues"] else "needs_review" if result["unmatched"] else "pass"
    return result


def hash_file(path):
    with path.open("rb") as source:
        digest = sha256()
        for chunk in iter(lambda: source.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def compare(pptx_pdf, slides_pdf):
    with fitz.open(pptx_pdf) as pptx, fitz.open(slides_pdf) as slides:
        if not len(pptx) or len(pptx) != len(slides):
            raise ValueError("Render the same complete page sequence in both formats.")
        pages = [compare_page(p, s, n) for n, (p, s) in enumerate(zip(pptx, slides), 1)]
    statuses = {p["status"] for p in pages}
    status = "repair" if "repair" in statuses else "needs_review" if "needs_review" in statuses else "pass"
    return {"pptx_pdf_sha256": hash_file(pptx_pdf), "slides_pdf_sha256": hash_file(slides_pdf),
            "page_count": len(pages), "status": status, "pages": pages}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx_pdf", type=Path)
    parser.add_argument("slides_pdf", type=Path)
    args = parser.parse_args()
    report = compare(args.pptx_pdf, args.slides_pdf)
    print(json.dumps(report, ensure_ascii=False))
    raise SystemExit({"pass": 0, "repair": 1, "needs_review": 2}[report["status"]])
