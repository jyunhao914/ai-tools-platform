"""Measure dual-axis registration and prepare an idempotent formula-backed Sheets chart repair."""
from copy import deepcopy
import hashlib
import math
import re

import numpy as np
from openpyxl.utils import get_column_letter, quote_sheetname


def require(ok, message):
    if not ok:
        raise ValueError(message)


def registration(axes, labels, height):
    """Compare both chart scales at the same source-rendered heights, including unequal axis minima."""
    actual = {r['key']: r['center'][1] * height for r in labels}
    fitted = {}
    for name, rows in axes.items():
        values = [r['value'] for r in rows]
        source = [r['y'] for r in rows]
        rendered = [actual[name.lower()+str(i)] for i in range(len(rows))]
        fitted[name] = [np.polyfit(values, yy, 1) for yy in (source, rendered)]
    (ls,lb),(la,lc) = fitted['LEFT_AXIS']
    (rs,rb),(ra,rc) = fitted['RIGHT_AXIS']
    require(math.isfinite(ls) and ls != 0 and rs/ls > 0, 'Use linear axes with compatible chart directions.')
    left = sorted(axes['LEFT_AXIS'],key=lambda r:r['value'])
    right = sorted(axes['RIGHT_AXIS'],key=lambda r:r['value'])
    a, b = float(rs/ls), float((rb-lb)/ls)
    if all(abs(left[i]['y']-right[i]['y']) <= 1 for i in (0,-1)):
        a = (left[-1]['value']-left[0]['value'])/(right[-1]['value']-right[0]['value'])
        b = left[0]['value'] - a*right[0]['value']
    ends = []
    for data in (right[0], right[-1]):
        v = data['value']
        ends.append({'right_value':v,'equivalent_left_value':a*v+b,
                     'gap_pt':float(abs(la*(a*v+b)+lc-(ra*v+rc)))})
    threshold = max(1.5, abs(right[-1]['y']-right[0]['y'])*.012)
    return {'gain':a,'offset':b,'ends':ends,'tolerance_pt':threshold,
            'fits':all(e['gap_pt'] <= threshold for e in ends)}


def measure_current(text, pdf, native, element, chart, names, sources, axes, page, width, height):
    """Measure the underlying linked chart pixels even after editable labels were added."""
    u=text.measure(native['pageSize']['width'])/width
    tr=element['transform']
    require(not tr.get('shearX') and not tr.get('shearY') and tr['scaleX']>0 and tr['scaleY']>0,
            'Measure the axis-aligned linked chart in its native presentation.')
    unit=12700 if tr.get('unit','EMU')=='EMU' else 1
    x,y=tr.get('translateX',0)/(u*unit),tr.get('translateY',0)/(u*unit)
    box=text.fitz.Rect(x,y,x+text.measure(element['size']['width'])*tr['scaleX']/u,
                       y+text.measure(element['size']['height'])*tr['scaleY']/u)
    pixels, frame=text.chart_pixels(pdf,page,box,width)
    basic,visible=text.chart_spec(chart); source={s['name']:s for s in sources}
    rows=[dict(source[n],axis=c.get('targetAxis','LEFT_AXIS'),type=c.get('type',basic['chartType']),color=text.rgb(c))
          for n,c in zip(names,visible)]
    _,fit,_,_,_=text.plot_geometry(pixels,frame,rows)
    labels=[{'key':a.lower()+str(i),'center':[0,(fit[a][0]*s['value']+fit[a][1])/height]}
            for a,ticks in axes.items() for i,s in enumerate(ticks)]
    return registration(axes,labels,height)


def single_range(data, count):
    src = data.get('sourceRange',{}).get('sources',[])
    require(len(src)==1, 'Use one source grid per series for formula calibration.')
    r = src[0]; col = r.get('startColumnIndex',0); start = r.get('startRowIndex',0)
    require(r.get('endColumnIndex') == col+1 and r.get('endRowIndex') == start+count,
            'Read the source header and every category row from each range.')
    return r


def sheet_titles(meta, book_id):
    require(meta.get('spreadsheetId') == book_id, 'Read sheet IDs and titles from the linked workbook.')
    return {s['properties']['sheetId']:s['properties']['title'] for s in meta['sheets']}


def prepare(chart, book, meta, book_id, names, rows, report, identity):
    require(not report['fits'], 'No formula repair needed for a physically matched chart.')
    tabs = sheet_titles(meta,book_id)
    source = {s['name']:s for s in rows}
    basic = chart['spec']['basicChart']
    viable = [s for s in basic['series'] if s.get('lineStyle',{}).get('type')!='INVISIBLE']
    require(len(viable)==len(names) and len(basic['domains'])==1 and basic.get('headerCount',1)==1,
            'Check all column/line series, one domain and one header before calibrating.')
    n = len(rows[0]['values'])+1
    digest = hashlib.sha256((book_id+'|'+str(chart['chartId'])+'|'+identity).encode()).hexdigest()
    sid = int(digest[:8],16) % 2000000000 + 1
    title = 'PS chart '+str(chart['chartId'])+' '+digest[:10]
    require(sid not in tabs and title not in tabs.values(), 'Reconcile the existing calibration tab in the same workbook first.')
    cols = [basic['domains'][0]['domain']]+[s['series'] for s in viable]
    axes = ['DOMAIN']+[s.get('targetAxis','LEFT_AXIS') for s in viable]
    origins = []
    for index, col in enumerate(cols):
        grid = single_range(col,n); origin = tabs[grid.get('sheetId',0)]
        first = grid.get('startRowIndex',0)+1; col_num = grid.get('startColumnIndex',0)+1
        actual = [book[origin].cell(first+j,col_num).value for j in range(1,n)]
        expected = source[names[index-1]]['values'] if index else rows[0]['cats']
        if index:
            require(all(isinstance(x,(int,float)) and math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-12)
                        for x,y in zip(actual,expected)), 'The original source numeric values changed.')
        else:
            require(all(''.join(str(x).split())==''.join(str(y).split()) for x,y in zip(actual,expected)),
                    'The original categories changed.')
        origins.append({'title':origin,'column':col_num,'row':first})
    # An unknown hidden series may carry a user-authored purpose. Preserve that chart for review.
    for hidden in (s for s in basic['series'] if s.get('lineStyle',{}).get('type')=='INVISIBLE'):
        h = single_range(hidden['series'],n); tab = book[tabs[h.get('sheetId',0)]]
        first=h.get('startRowIndex',0)+1; column=h.get('startColumnIndex',0)+1
        header = str(tab.cell(first,column).value)
        bounds=[e['right_value'] for e in report['ends']]
        cells=[tab.cell(first+j,column).value for j in range(1,n)]
        known=header in ('Axis scale','右側刻度校正') or header.startswith('Presentation Studio axis ')
        require(hidden.get('targetAxis')=='RIGHT_AXIS' and known and
                all(isinstance(v,(int,float)) and not isinstance(v,bool) for v in cells) and
                math.isclose(min(cells),min(bounds),abs_tol=1e-10) and math.isclose(max(cells),max(bounds),abs_tol=1e-10),
                'Resolve the purpose of an existing hidden series before rebuilding the displayed chart.')
    contract = {'id':sid,'title':title,'rows':n,'origins':origins,'axes':axes,'categories':list(rows[0]['cats']),'gain':report['gain'],
                'offset':report['offset'],'original_chart':chart,'names':names,'marker':'Presentation Studio '+digest}
    matrix = formula_rows(contract)
    writes = [[{'userEnteredValue':{'formulaValue':f}} for f in row] for row in matrix]
    writes[0].append({'userEnteredValue':{'stringValue':contract['marker']}})
    spec = deepcopy(chart['spec']); b = spec['basicChart']
    b['axis']=[a for a in b.get('axis',[]) if a['position']!='RIGHT_AXIS']
    b['series']=[s for s in b['series'] if s.get('lineStyle',{}).get('type')!='INVISIBLE']
    plain = lambda i:{'sourceRange':{'sources':[{'sheetId':sid,'startRowIndex':0,'endRowIndex':n,
                                                'startColumnIndex':i,'endColumnIndex':i+1}]}}
    b['domains'][0]['domain']=plain(0)
    for i,s in enumerate(b['series'],1):
        s['series']=plain(i);s['targetAxis']='LEFT_AXIS'
    position=deepcopy(chart['position']['overlayPosition']);position['anchorCell']={'sheetId':sid,'rowIndex':n+2,'columnIndex':0}
    requests=[{'addSheet':{'properties':{'sheetId':sid,'title':title,
                                         'gridProperties':{'rowCount':max(1000,n+25),'columnCount':max(26,len(cols)+1)}}}},
              {'updateCells':{'start':{'sheetId':sid,'rowIndex':0,'columnIndex':0},'rows':[{'values':v} for v in writes],'fields':'userEnteredValue'}},
              {'updateEmbeddedObjectPosition':{'objectId':chart['chartId'],'newPosition':{'overlayPosition':position},'fields':'anchorCell'}},
              {'updateChartSpec':{'chartId':chart['chartId'],'spec':spec}}]
    return contract,requests


def formula_rows(contract):
    data = []
    for i in range(contract['rows']):
        row = []
        for axis,src in zip(contract['axes'],contract['origins']):
            cell = quote_sheetname(src['title'])+'!'+get_column_letter(src['column'])+str(src['row']+i)
            if i and axis=='RIGHT_AXIS':
                cell += '*('+format(contract['gain'],'.15g')+')+('+format(contract['offset'],'.15g')+')'
            row.append('='+cell)
        data.append(row)
    return data


def verify(contract,chart,values,formulas,meta,book_id):
    """Bind every original sheet/range, live formula, displayed value and still-linked chart before projecting labels."""
    tabs = sheet_titles(meta,book_id); sid = contract['id']; title = contract['title']; n = contract['rows']
    require(tabs.get(sid)==title and title in formulas.sheetnames,'Read back the dedicated formula tab.')
    series = chart['spec']['basicChart']['series']; domains = chart['spec']['basicChart']['domains']
    require(chart['chartId']==contract['original_chart']['chartId'] and len(domains)==1 and len(series)+1==len(contract['axes'])
            and all(r.get('targetAxis','LEFT_AXIS')=='LEFT_AXIS' for r in series),'Unexpected chart or series after formula update.')
    mapped = [domains[0]['domain']]+[s['series'] for s in series]
    for col,r in enumerate(mapped):
        grid=single_range(r,n)
        require((grid.get('sheetId',0),grid.get('startRowIndex',0),grid.get('startColumnIndex',0))==(sid,0,col),
                'A chart column no longer references the verified formula range.')
    sheet=formulas[title]; cached=values[title]
    require(sheet.cell(1,len(mapped)+1).value==contract['marker'],'The calibration tab belongs to another job.')
    for i,row in enumerate(formula_rows(contract)):
        for j,expected in enumerate(row):
            src=contract['origins'][j]; origin=values[src['title']].cell(src['row']+i,src['column']).value
            if j==0 and i:
                require(''.join(str(origin).split())==''.join(str(contract['categories'][i-1]).split()),
                        'The original chart categories changed after confirmation.')
            found=sheet.cell(i+1,j+1).value; quoted=quote_sheetname(src['title'])+'!'
            valid = found in (expected,expected.replace(quoted,src['title']+'!',1))
            if not valid and i and contract['axes'][j]=='RIGHT_AXIS' and isinstance(found,str):
                # Sheets exports number literals at spreadsheet precision. Verify the
                # exact source reference and permitted affine expression separately.
                cell = get_column_letter(src['column'])+str(src['row']+i)
                left = re.escape('='+quoted+cell)+'|'+re.escape('='+src['title']+'!'+cell)
                number = r'([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?)'
                parsed = re.fullmatch('(?:'+left+r')\*\('+number+r'\)\+\('+number+r'\)', found)
                valid = bool(parsed and math.isclose(float(parsed[1]), contract['gain'],rel_tol=1e-13,abs_tol=1e-15)
                             and math.isclose(float(parsed[2]), contract['offset'],rel_tol=1e-13,abs_tol=1e-15))
            require(valid, 'A calibration formula changed.')
            val=cached.cell(i+1,j+1).value
            if i and contract['axes'][j]=='RIGHT_AXIS':
                origin=origin*contract['gain']+contract['offset']
            # The exported cached result of a formula can have ten significant digits
            # even when the source cell retains its full precision.
            same = math.isclose(origin,val,rel_tol=5e-10,abs_tol=1e-9) if isinstance(origin,(int,float)) and isinstance(val,(int,float)) else val==origin
            require(same,'Read the recalculated formula values from a fresh XLSX export.')
    semantic=deepcopy(chart)
    original=[s for s in contract['original_chart']['spec']['basicChart']['series'] if s.get('lineStyle',{}).get('type')!='INVISIBLE']
    for axis,s,old in zip(contract['axes'][1:],semantic['spec']['basicChart']['series'],original):
        s['targetAxis']=axis
        if 'colorStyle' not in s and 'color' not in s:
            s['colorStyle']=deepcopy(old['colorStyle'])
    return semantic
