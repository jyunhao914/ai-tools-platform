#!/usr/bin/env python3
"""Assemble image slides or check playback visibility on any PPTX. Requires python-pptx.
Use assemble MANIFEST OUT.pptx or check PLAN DECK.pptx.
"""
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches


def has_dynamic_number(slide):
    layout = slide.slide_layout
    layout_types = {node.get("idx", "0"): node.get("type") for node in layout._element.xpath(".//p:ph")}
    for placeholder in slide._element.xpath(".//p:ph"):
        if placeholder.get("type", layout_types.get(placeholder.get("idx", "0"))) == "sldNum":
            return True
    for field in slide._element.xpath(".//a:fld"):
        if field.get("type", "").lower() == "slidenum":
            return True
    # Dormant slide-number placeholders in standard Office masters need no change.
    # Non-placeholder inherited shapes can still draw dynamic fields on the page.
    if slide._element.get("showMasterSp", "1") not in ("0", "false"):
        layers = [layout]
        if layout._element.get("showMasterSp", "1") not in ("0", "false"):
            layers.append(layout.slide_master)
        for layer in layers:
            for shape in layer._element.xpath(".//p:sp"):
                if not shape.xpath("./p:nvSpPr/p:nvPr/p:ph") and any(
                        f.get("type", "").lower() == "slidenum" for f in shape.xpath(".//a:fld")):
                    return True
    return False


def check(deck, pages):
    if len(deck.slides) != len(pages):
        raise ValueError("Unexpected slide count.")
    for n, (slide, page) in enumerate(zip(deck.slides, pages), 1):
        if type(page.get("page_number")) is not int or page.get("page_number") != n or type(page.get("hidden")) is not bool:
            raise ValueError(f"Invalid visibility plan at slide {n}.")
        if has_dynamic_number(slide):
            raise ValueError(f"Unapproved dynamic page numbering at slide {n}. Keep source-visible folios as fixed text.")
        flag = slide._element.get("show", "1")
        if flag not in ("0", "1", "false", "true") or (flag in ("0", "false")) != page["hidden"]:
            raise ValueError(f"Playback visibility differs at slide {n}.")


def run(cmd, plan_path, target):
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    pages = plan["pages"]
    if cmd == "check":
        check(Presentation(str(target)), pages)
        return
    if cmd != "assemble" or plan.get("schema_version") != 3:
        raise ValueError("Use assemble with a full-page v3 queue manifest, or check with a page plan.")
    # A repeated assembly after an interrupted upload can reuse the existing deck
    # only after verifying every image, page, and visibility flag against this manifest.
    spec = importlib.util.spec_from_file_location("image_deck_gate", Path(__file__).with_name("validate-image-deck.py"))
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    count, _, records = gate.validate_manifest(plan_path)
    if target.exists():
        verified, errors = gate.validate_pptx(target, count, records)
        if verified == count and not errors:
            return
        raise FileExistsError("Existing deck differs from this manifest. Choose a new output filename.")
    deck = Presentation()
    deck.slide_width, deck.slide_height = Inches(12.8), Inches(7.2)
    for page in pages:
        path = (plan_path.parent / page["image_path"]).resolve()
        if hashlib.sha256(path.read_bytes()).hexdigest() != page["image_sha256"]:
            raise ValueError(f"Changed image at slide {page['page_number']}.")
        slide = deck.slides.add_slide(deck.slide_layouts[6])
        slide._element.set("showMasterSp", "0")
        if page["hidden"]:
            slide._element.set("show", "0")
        slide.shapes.add_picture(str(path), 0, 0, deck.slide_width, deck.slide_height)
    check(deck, pages)
    with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".pptx", delete=False) as handle:
        tmp = Path(handle.name)
    try:
        deck.save(str(tmp))
        check(Presentation(str(tmp)), pages)
        os.link(tmp, target)
    finally:
        tmp.unlink(missing_ok=True)


if __name__ == "__main__":
    try:
        run(sys.argv[1], Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve())
        print('{"ok":true}')
    except Exception as error:
        sys.exit(str(error))
