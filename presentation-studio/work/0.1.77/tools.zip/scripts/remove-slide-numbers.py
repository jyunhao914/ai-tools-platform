#!/usr/bin/env python3
"""Remove real slide-number fields and inherited placeholders from a working PPTX copy."""
import os
import sys
import tempfile
from pathlib import Path
from pptx import Presentation

from slide_numbers import strip_slide_numbers

def write_copy(source, output):
    if source.resolve()==output.resolve() or (output.exists() and source.samefile(output)):
        raise ValueError("Use a working copy distinct from the source file.")
    deck=Presentation(source)
    strip_slide_numbers(deck)
    with tempfile.NamedTemporaryFile(dir=output.parent,suffix=".pptx",delete=False) as f:
        tmp=Path(f.name)
    try:
        deck.save(tmp)
        probe=Presentation(tmp)
        if len(probe.slides)!=len(deck.slides):raise ValueError("Page count changed.")
        # A fresh destination prevents accidental replacement of a different job.
        os.link(tmp,output)
    finally:tmp.unlink(missing_ok=True)

if __name__=="__main__":
    try:write_copy(*(Path(x) for x in sys.argv[1:]))
    except Exception as e:sys.exit(str(e))
