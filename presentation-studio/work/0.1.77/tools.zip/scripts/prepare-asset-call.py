#!/usr/bin/env python3
"""Prepare a single image tool call. Keep deck metadata outside the provider arguments."""
import argparse
import hashlib
import json
import math
import os
import re
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw

REFERENCE_KEYS = {"referenced_image_paths", "referenced_image_ids", "num_last_images_to_include"}
# Neutral compositional guides. The planner can instead specify the actual subject silhouette
# using normalized primitives. None of these geometries contains lettering or a slide canvas.
PRESETS = {
    "object": [["ellipse", [.23,.23,.77,.77], "foreground"]],
    "person": [["ellipse", [.40,.12,.60,.34], "foreground"], ["polygon", [.37,.36,.62,.36,.72,.90,.27,.90], "subject"]],
    "people": [["ellipse",[.22,.18,.38,.38],"foreground"],["polygon",[.20,.40,.40,.40,.47,.86,.12,.86],"subject"],
               ["ellipse",[.58,.15,.74,.35],"foreground"],["polygon",[.55,.37,.77,.37,.83,.85,.49,.85],"subject"]],
    "environment": [["polygon",[0,0,.37,.30,.37,.68,0,1],"background"],["polygon",[1,0,.65,.30,.65,.68,1,1],"background"],
                    ["polygon",[0,1,.37,.68,.65,.68,1,1],"subject"]],
    "detail": [["ellipse",[.10,.26,.60,.83],"subject"],["polygon",[.47,.44,.85,.25,.90,.37,.60,.60],"foreground"]]
}
COLORS = {"background":"#e4e7e8", "subject":"#b7c3c6", "foreground":"#76898d"}


def draw_guide(asset):
    box = asset.get("placement_px") or {}
    ratio = float(box.get("width", 1)) / max(1, float(box.get("height", 1)))
    if not math.isfinite(ratio) or ratio <= 0:
        raise ValueError("Expected a positive frame ratio.")
    ratio = min(4., max(.25, ratio))
    w, h = (1024, round(1024/ratio)) if ratio >= 1 else (round(1024*ratio), 1024)
    guide = asset.get("composition_guide") or {}
    scene = " ".join(str(asset.get(k) or "") for k in ("subject","resolved_subject","brief")).lower()
    preset = guide.get("preset")
    if not preset:
        for pattern, mode in ((r"手部|雙手|手指|handwashing|hands? (under|washing|at work)|close.up|特寫","detail"),
                              (r"團隊|團體|多人|數人|兩人|group|team|colleagues","people"),
                              (r"走廊|街道|建築|室內|樓梯|hallway|corridor|interior|landscape","environment"),
                              (r"人員|人物|工作人員|醫護|護理師|worker|person|portrait|nurse|doctor","person")):
            if re.search(pattern,scene):
                preset=mode
                break
    items = guide.get("primitives") or PRESETS[preset or "object"]
    if not (1 <= len(items) <= 32):
        raise ValueError("Supply 1–32 unlabeled geometric shapes for this single scene.")
    image = Image.new("RGB", (w,h), "white")
    draw = ImageDraw.Draw(image)
    for kind, coords, tone in items:
        if (kind not in ("ellipse", "rectangle", "polygon", "line") or tone not in COLORS or
                not isinstance(coords,list) or len(coords)%2 or len(coords)<4 or len(coords)>64 or
                any(type(v) not in (float,int) or not math.isfinite(v) or not 0<=v<=1 for v in coords)):
            raise ValueError("Invalid primitive or color for the composition guide.")
        pts = [(round(x*(w-1)),round(y*(h-1))) for x,y in zip(coords[::2],coords[1::2])]
        if kind in ("ellipse","rectangle") and (len(pts)!=2 or pts[0][0]>=pts[1][0] or pts[0][1]>=pts[1][1]):
            raise ValueError("Use a positive bounding box.")
        if kind=="polygon" and len(pts)<3:
            raise ValueError("Polygons require at least three points.")
        if kind=="line":
            draw.line(pts, fill=COLORS[tone], width=max(2, min(w,h)//35), joint="curve")
        else:
            getattr(draw,kind)(pts,fill=COLORS[tone])
    return image


def prepare(action, directory, key=None, registered=None, original=None, isolated=False, last_shown=None, supports_transparency=False):
    prompt = action.get("prompt")
    request = action.get("request_id")
    if not isinstance(request,str) or not request or not isinstance(prompt,str) or not prompt.strip():
        raise ValueError("Supply one confirmed scene and the original queue request ID.")
    extra = {"transparent_background": True} if supports_transparency and action.get("transparent_background") is True else {}
    kind = action.get("reference_kind", "none")
    if kind not in ("none","original","guide") or (key is not None and key not in REFERENCE_KEYS):
        raise ValueError("Unknown reference kind or unsupported provider input field.")
    result = {"request_id":request, "reference_kind":kind}
    if kind=="none" or (kind=="guide" and isolated):
        result.update(action="generate", provider_input={**extra,"prompt":prompt})
        return result
    if kind=="original":
        approved=(action.get("asset") or {}).get("reference")
        if not approved:
            raise ValueError("A redraw requires its approved single visual source.")
        if original is None and key=="referenced_image_ids" and registered:
            return {**result,"action":"generate","provider_input":{**extra,"prompt":prompt,key:[registered]}}
        path=Path(original or approved).resolve(strict=True)
        with Image.open(path) as image:
            image.load()
        expected=(action.get("asset") or {}).get("sha256")
        if expected and hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            raise ValueError("The file differs from the approved source image.")
    else:
        image = draw_guide(action["asset"])
        seed=hashlib.sha256(request.encode()).hexdigest()[:30]
        folder=Path(directory).resolve()
        folder.mkdir(exist_ok=True,parents=True)
        path=folder/("scene-"+seed+".png")
        # Keep the original guide for a retried call with the same request ID.
        with tempfile.NamedTemporaryFile(dir=folder,delete=False) as tmp:
            name=tmp.name
        try:
            image.save(name,format="PNG")
            if path.exists() and Path(name).read_bytes()!=path.read_bytes():
                raise ValueError("Existing request has a different guide.")
            if not path.exists():
                os.replace(name,path)
        finally:
            Path(name).unlink(missing_ok=True)
        prompt="依這張無字構圖草稿的主體位置重新製作完整素材。"+prompt
    result.update(reference_file=str(path),reference_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    if key is None: return {**result,"action":"resolve_reference"}
    if key=="num_last_images_to_include":
        if last_shown != result["reference_sha256"]:
            return {**result,"action":"show_single_reference"}
        return {**result,"action":"generate","provider_input":{**extra,"prompt":prompt,key:1}}
    if key=="referenced_image_ids" and not registered: return {**result,"action":"register_reference"}
    ref=str(path) if key=="referenced_image_paths" else registered
    return {**result,"action":"generate","provider_input":{**extra,"prompt":prompt,key:[ref]}}


def prepare_native(action, directory, advertised, unavailable=None, registered=None, original=None, isolated=False, last_shown=None, supports_transparency=False):
    # The caller supplies only arguments discovered on the currently bound native tool.
    # Fields already tried unsuccessfully are skipped before any provider dispatch.
    unavailable=set(unavailable or [])
    if action.get("reference_kind")=="guide_if_supported":
        has_reference=any(field in REFERENCE_KEYS and field not in unavailable for field in (advertised or ()))
        if advertised and not has_reference and not isolated:
            return {"action":"hold_reference","request_id":action["request_id"],"reason":"All declared native reference methods are unavailable."}
        action={**action,"reference_kind":"guide" if has_reference and not isolated else "none"}
    if not advertised or action.get("reference_kind","none")=="none" or (isolated and action.get("reference_kind")=="guide"):
        return prepare(action,directory,None,registered,original,isolated,last_shown,supports_transparency)
    pending=None
    errors=[]
    for field in dict.fromkeys(advertised):
        if field in unavailable: continue
        try:
            result=prepare(action,directory,field,registered,original,isolated,last_shown,supports_transparency)
        except (ValueError,OSError) as exc:
            errors.append(field+": "+str(exc))
            continue
        if result["action"]=="generate": return result
        if pending is None: pending=result
    return pending or {"action":"hold_reference","request_id":action["request_id"],
        "reason":"; ".join(errors) or "No usable declared native image-reference argument remains."}


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("action",help="JSON from the queue, or - for standard input.")
    cli.add_argument("working_dir",type=Path)
    cli.add_argument("--reference-key",choices=sorted(REFERENCE_KEYS),action="append",
                     help="Repeat only for distinct argument types the current native tool actually supports.")
    cli.add_argument("--unavailable-reference-key",choices=sorted(REFERENCE_KEYS),action="append",
                     help="Skip a declared argument only after its real registration or display failed.")
    cli.add_argument("--registered-ref",help="Actual tool-accepted ID for the sole reference.")
    cli.add_argument("--last-shown-sha",help="Hash of the sole reference actually shown immediately before the edit.")
    cli.add_argument("--original-file",type=Path,help="Resolved original image for a redraw.")
    cli.add_argument("--isolated-text",action="store_true",help="Only for an independently scoped, text-only generator.")
    cli.add_argument("--supports-transparent-background",action="store_true",help="The bound tool declares transparent_background.")
    args=cli.parse_args()
    import sys
    action=json.load(sys.stdin) if args.action=="-" else json.loads(Path(args.action).read_text())
    print(json.dumps(prepare_native(action,args.working_dir,args.reference_key,args.unavailable_reference_key,args.registered_ref,
                                    args.original_file,args.isolated_text,args.last_shown_sha,args.supports_transparent_background),ensure_ascii=False))
