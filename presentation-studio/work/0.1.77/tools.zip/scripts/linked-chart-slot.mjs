// Verify the visible Sheets chart in the final PowerPoint chart's slot. The CLI
// prints a repair packet for the host; it never writes to Google.
import {createHash} from "node:crypto";
import {readFileSync} from "node:fs";
import {pathToFileURL} from "node:url";

const pt = (value,unit) => value / (unit==="PT" ? 1 : 12700);
const dimension = obj => pt(obj?.magnitude,obj?.unit);
const identity = [1,0,0,1,0,0];
const area = r => Math.max(0,r[2]-r[0])*Math.max(0,r[3]-r[1]);
const intersection = (a,b) => area([Math.max(a[0],b[0]),Math.max(a[1],b[1]),Math.min(a[2],b[2]),Math.min(a[3],b[3])]);
const valid = r => Array.isArray(r) && r.length===4 && r.every(Number.isFinite) && area(r)>0;

function matrix(transform) {
  const t=transform??{};
  return [t.scaleX??1,t.shearY??0,t.shearX??0,t.scaleY??1,
    pt(t.translateX??0,t.unit),pt(t.translateY??0,t.unit)];
}

function compose([a,b,c,d,x,y],[e,f,g,h,u,v]) {
  return [a*e+c*f,b*e+d*f,a*g+c*h,b*g+d*h,a*u+c*v+x,b*u+d*v+y];
}

function items(deck,page) {
  const width=dimension(deck.pageSize?.width), height=dimension(deck.pageSize?.height);
  const out=[];
  function walk(elements,parent,top) {
    for (const e of elements??[]) {
      const world=compose(parent,matrix(e.transform));
      if (e.elementGroup) {walk(e.elementGroup.children,world,top??e.objectId); continue;}
      const w=dimension(e.size?.width), h=dimension(e.size?.height);
      const [a,b,c,d,x,y]=world;
      const xs=[x,x+a*w,x+c*h,x+a*w+c*h], ys=[y,y+b*w,y+d*h,y+b*w+d*h];
      out.push({e,top:top??e.objectId,box:[Math.min(...xs)/width,Math.min(...ys)/height,
        Math.max(...xs)/width,Math.max(...ys)/height]});
    }
  }
  walk(deck.slides?.[page-1]?.pageElements,identity,null);
  return out;
}

function fullCover(e) {
  if (e.image) return (e.image.imageProperties?.transparency??0)<0.05;
  if (!["RECTANGLE","ROUND_RECTANGLE"].includes(e.shape?.shapeType)) return false;
  const paint=e.shape.shapeProperties?.shapeBackgroundFill;
  return paint?.solidFill && paint.propertyState!=="NOT_RENDERED" && (paint.solidFill.alpha??1)>.95;
}

function sameSlot(box,region) {
  if (!valid(box)||!valid(region)) return false;
  const common=intersection(box,region);
  // The native combo repair may adjust the plot and its surrounding margins.
  return common/area(region)>=.65 && common/area(box)>=.65;
}

export function visibleChartIssue(deck,page,id,region) {
  const rows=items(deck,page), index=rows.findIndex(row=>row.e.objectId===id);
  const placed=rows[index], link=placed?.e.sheetsChart;
  if (!link?.spreadsheetId || !Number.isInteger(link.chartId) || link.chartId<0) return "missing_link";
  if ((link.sheetsChartProperties?.chartImageProperties?.transparency??0)>=.95) return "transparent_chart";
  if (!sameSlot(placed.box,region) || intersection(placed.box,[0,0,1,1])/area(placed.box)<.8) return "wrong_frame";
  const cover=rows.slice(index+1).find(row=>valid(row.box) && fullCover(row.e) && intersection(placed.box,row.box)/area(placed.box)>.85);
  return cover ? "covered_by:"+cover.e.objectId : null;
}

function sheetLink(e) {
  const link=e.image?.imageProperties?.link?.url;
  if (!link) return null;
  try {
    const url=new URL(link);
    return url.origin==="https://docs.google.com" ? /^\/spreadsheets\/d\/([^/]+)/.exec(url.pathname)?.[1] : null;
  } catch { return null; }
}

export function relinkSlot(deck,workbook,chartId,reference,staticImage) {
  const {page,region}=reference, slide=deck.slides?.[page-1], bookId=workbook.spreadsheetId;
  if (!deck.presentationId || !deck.revisionId || !slide?.objectId || !valid(region) || !bookId ||
      !Number.isInteger(chartId) || !(workbook.sheets??[]).some(s=>s.charts?.some(c=>c.chartId===chartId))) {
    throw Error("Read the final Slides revision, PowerPoint chart region and matching chart ID in its actual working spreadsheet.");
  }
  const rows=items(deck,page);
  const links=rows.filter(r=>r.e.sheetsChart?.spreadsheetId===bookId && r.e.sheetsChart.chartId===chartId);
  const inSlot=links.filter(r=>sameSlot(r.box,region));
  const visible=inSlot.find(r=>!visibleChartIssue(deck,page,r.e.objectId,region));
  if (visible) {
    return {stage:"linked",page,spreadsheet_id:bookId,chart_id:chartId,element_id:visible.e.objectId};
  }
  // Only replace a confirmed chart image: a matched working-sheet hyperlink, or
  // the exact image ID identified by the host against this PowerPoint rendering.
  const candidates=rows.filter(r=>r.e.image && sameSlot(r.box,region) &&
    (staticImage ? r.e.objectId===staticImage : sheetLink(r.e)===bookId));
  if (candidates.length>1 || (staticImage && candidates.length!==1)) throw Error("Identify the converted chart's exact image object on this page.");
  const image=candidates[0];
  if (image && sheetLink(image.e) && sheetLink(image.e)!==bookId) throw Error("The selected image links to another workbook.");
  if (image && image.top!==image.e.objectId) throw Error("Resolve the grouped chart image and its z-order before relinking.");
  if (inSlot.length>1 || (links.length && !inSlot.length && !image)) throw Error("The same source chart is already used elsewhere on this page. Identify this slot's chart image before creating a separate visible instance.");
  const existing=inSlot[0];
  if (existing && (!image || visibleChartIssue(deck,page,existing.e.objectId,region)!=="covered_by:"+image.e.objectId)) {
    throw Error("Inspect and clear the obstruction above the linked chart, then refresh the same object.");
  }
  if (!image && rows.some(r=>valid(r.box) && sameSlot(r.box,region) && (r.e.image||r.e.sheetsChart))) {
    throw Error("Confirm the visually matched converted chart image with --static-image before replacing it.");
  }
  const id=existing?.e.objectId??"ps_chart_"+createHash("sha256").update([deck.presentationId,slide.objectId,reference.shape_id,bookId,chartId].join("|")).digest("hex").slice(0,22);
  if (!existing && rows.some(r=>r.e.objectId===id)) throw Error("The planned linked chart ID already belongs to another object.");
  const requests=[];
  if (!existing) {
    const w=dimension(deck.pageSize.width), h=dimension(deck.pageSize.height);
    const box=image?.box??region;
    const geom={
      size:{width:{magnitude:(box[2]-box[0])*w,unit:"PT"},height:{magnitude:(box[3]-box[1])*h,unit:"PT"}},
      transform:{scaleX:1,scaleY:1,translateX:box[0]*w,translateY:box[1]*h,unit:"PT"}};
    requests.push({createSheetsChart:{objectId:id,spreadsheetId:bookId,chartId,linkingMode:"LINKED",elementProperties:{pageObjectId:slide.objectId,...geom}}});
  }
  if (image) {
    requests.push({deleteObject:{objectId:image.e.objectId}});
    if (!existing) {
      const above=slide.pageElements.length-1-slide.pageElements.findIndex(e=>e.objectId===image.e.objectId);
      for (let i=0;i<above;i++) requests.push({updatePageElementsZOrder:{pageElementObjectIds:[id],operation:"SEND_BACKWARD"}});
    }
  }
  requests.push({refreshSheetsChart:{objectId:id}});
  return {stage:"relink",presentation_id:deck.presentationId,write_control:{requiredRevisionId:deck.revisionId},
    page,spreadsheet_id:bookId,chart_id:chartId,element_id:id,slides_requests:requests,
    next:"Apply to the working revision, read back the linked object, export the native PDF, then measure and project missing labels on this chart."};
}

if (process.argv[1] && import.meta.url===pathToFileURL(process.argv[1]).href) {
  const [native,sheets,id,pptxRef,option,image]=process.argv.slice(2);
  if (native==="--stdin") {
    const packet=JSON.parse(readFileSync(0,"utf8"));
    console.log(JSON.stringify(relinkSlot(packet.deck,packet.workbook,packet.chart_id,packet.reference,packet.static_image)));
  } else {
    if (!native||!sheets||!id||!pptxRef||(option && (option!=="--static-image"||!image))) {
      throw Error("Usage: node linked-chart-slot.mjs slides.json spreadsheet-with-charts.json chartId pptx-chart-reference.json [--static-image objectId]");
    }
    const load=file=>JSON.parse(readFileSync(file,"utf8"));
    console.log(JSON.stringify(relinkSlot(load(native),load(sheets),Number(id),load(pptxRef),image)));
  }
}
