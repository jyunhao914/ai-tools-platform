"""Build native Google Slides requests for authorized, independent visual layers.

Supply actual destination identifiers and the number of destination EMUs per
source inch. This module performs no network calls and only creates new objects.
The caller checks source identity, placement and stacking against the live deck.
"""
from hashlib import sha256
from math import dist, hypot, sqrt
import os
from pathlib import Path
import re
from tempfile import NamedTemporaryFile

from editable_visuals import (_box, _color, _keys, _number, _path, cropped_png, image_asset,
                              photo_geometry, require_clean_cutout, select_visual_layers)


def _paint(color):
    components = _color(color)
    return {"solidFill": {"color": {"rgbColor": dict(zip(
        ("red", "green", "blue"), (channel / 255 for channel in components)
    ))}, "alpha": 1}}


def _geometry(page, x, y, width, height):
    return {
        "pageObjectId": page,
        "size": {key: {"magnitude": size, "unit": "EMU"}
                 for key, size in (("width", width), ("height", height))},
        "transform": {"scaleX": 1, "scaleY": 1, "translateX": x, "translateY": y, "unit": "EMU"},
    }


def prepare_focal_image(layer, asset_root, output_dir, canvas, *, editable_profile, protected=(), occupied=()):
    """For direct Slides editing, crop only the independent asset. Keep its original file."""
    if editable_profile != "refined" or "photo_layout" not in layer:
        raise ValueError("Supply an approved refined image with a focal placement.")
    layer, = select_visual_layers([layer], editable_profile)
    if layer["action"] not in ("add", "redraw") or layer["kind"] not in ("background", "cutout", "picture"):
        raise ValueError("Supply a single approved image layer.")
    root = Path(asset_root).resolve()
    data, size, source_sha = image_asset(layer, root, orient=True)
    if layer["kind"] == "cutout":
        require_clean_cutout(data)
    geometry = photo_geometry(layer, _box(layer["box"]), size, editable_profile, canvas, protected,
                              data=data, occupied=occupied)
    display = cropped_png(data, geometry["crop"])
    if layer["kind"] == "cutout":
        require_clean_cutout(display)
    digest = sha256(display).hexdigest()
    directory = Path(output_dir).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"focal-{digest}.png"
    if not path.is_file() or sha256(path.read_bytes()).hexdigest() != digest:
        with NamedTemporaryFile(dir=directory, delete=False) as tmp:
            temp_path = Path(tmp.name)
            try:
                tmp.write(display)
            except BaseException:
                temp_path.unlink(missing_ok=True)
                raise
        try:
            os.replace(temp_path, path)
        finally:
            temp_path.unlink(missing_ok=True)
    source = root / layer["file"]
    return {**geometry, "file": str(path), "display_sha256": digest, "source_file": str(source),
            "source_sha256": source_sha}


def focal_add_requests(layer, prepared, page_id, object_id, *, units_per_inch=914400):
    """Build one createImage and its sidecar. Named anchors are resolved by the caller."""
    if layer.get("action") != "add" or "replace" in layer:
        raise ValueError("Use the imported editable PowerPoint or a verified existing image for redraw.")
    if not page_id or not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_:.\-]{4,49}", object_id):
        raise ValueError("Supply the actual page and new image IDs.")
    scale = _number(units_per_inch)
    if scale <= 0:
        raise ValueError("The destination scale must be positive.")
    frame = [round(value * scale) for value in _box(prepared["box"])]
    path = prepared["file"]
    requests = [{"createImage": {"objectId": object_id, "url": path,
                                  "elementProperties": _geometry(page_id, *frame)}},
                {"updatePageElementAltText": {"objectId": object_id, "title": layer["name"]}}]
    position = layer.get("position", "back" if layer["kind"] == "background" else "front")
    if position == "back":
        requests.append({"updatePageElementsZOrder": {"pageElementObjectIds": [object_id],
                                                     "operation": "SEND_TO_BACK"}})
    return {"image_uris": path, "requests": requests}


def _shape_requests(page, oid, kind, rect, fill, stroke, weight):
    style = {"shapeBackgroundFill": _paint(fill) if fill else {"propertyState": "NOT_RENDERED"},
             "outline": {"propertyState": "NOT_RENDERED"}}
    if stroke:
        style["outline"] = {"propertyState": "RENDERED", "outlineFill": _paint(stroke),
                            "weight": {"magnitude": weight, "unit": "PT"}, "dashStyle": "SOLID"}
    return [
        {"createShape": {"objectId": oid, "shapeType": kind, "elementProperties": _geometry(page, *rect)}},
        {"updateShapeProperties": {"objectId": oid, "shapeProperties": style, "fields": "shapeBackgroundFill,outline"}},
    ]


def _line_requests(page, oid, start, end, stroke, weight):
    dx, dy = end[0] - start[0], end[1] - start[1]
    side = hypot(dx, dy) / sqrt(2)
    props = _geometry(page, *start, side, side)
    # Slides draws its default straight line from top-left to bottom-right.
    cosine, sine = (dx + dy) / (2 * side), (dy - dx) / (2 * side)
    props["transform"].update(scaleX=cosine, scaleY=cosine, shearX=-sine, shearY=sine)
    style = {"lineFill": _paint(stroke), "weight": {"magnitude": weight, "unit": "PT"},
             "dashStyle": "SOLID"}
    return [
        {"createLine": {"objectId": oid, "lineCategory": "STRAIGHT", "elementProperties": props}},
        {"updateLineProperties": {"objectId": oid, "lineProperties": style, "fields": ",".join(style)}},
    ]


def _distance_to_chord(p, start, end):
    dx, dy = end[0] - start[0], end[1] - start[1]
    if dx == dy == 0:
        return dist(p, start)
    u = min(1, max(0, ((p[0] - start[0]) * dx + (p[1] - start[1]) * dy) / (dx*dx + dy*dy)))
    return dist(p, (start[0] + u*dx, start[1] + u*dy))


def _flatten(points):
    # Quarter of a screen pixel at 96 dpi, measured in destination coordinates.
    if all(_distance_to_chord(p, points[0], points[-1]) <= 2381 for p in points[1:-1]):
        yield points[-1]
        return
    levels = [points]
    while len(levels[-1]) > 1:
        row = levels[-1]
        levels.append([((a[0]+b[0])/2, (a[1]+b[1])/2) for a, b in zip(row, row[1:])])
    yield from _flatten([row[0] for row in levels])
    yield from _flatten([row[-1] for row in reversed(levels)])


def _lines(commands, frame):
    _path(commands)  # Use the same coordinate and command validation as PowerPoint.
    x, y, width, height = frame
    start = current = None
    for op, *coords in commands:
        pts = [(x + px * width/100, y + py * height/100)
               for px, py in zip(coords[::2], coords[1::2])]
        if op == "M":
            start = current = pts[0]
            continue
        ends = [start] if op == "Z" else _flatten([current, *pts])
        for end in ends:
            if current != end:
                yield (current, end)
            current = end


def vector_requests(layer, page_id, object_id, units_per_inch=914400, point_scale=None, *,
                    editable_profile=None, auto_visuals=False, report=None):
    """Return creation requests. Nonrectangular filled freeforms require native reconstruction.

    Primitives and stroked paths are supported. Objects appear in front until the
    caller applies its verified z-order. On retry, read the supplied object_id first.
    """
    _keys(layer, {"name", "action", "kind", "box", "position", "replace", "parts",
                  "explicit_request", "explanation_for", "role", "transparent_cutout"})
    if layer.get("kind") != "vector" or layer.get("action") not in {"add", "redraw"}:
        raise ValueError("Supply one approved vector layer.")
    if not select_visual_layers([layer], editable_profile, auto_visuals=auto_visuals, report=report):
        return []
    if layer["action"] == "redraw":
        source = layer.get("replace")
        _keys(source, {"name", "source_sha256"})
        if not isinstance(source.get("name"), str) or not source["name"].strip():
            raise ValueError("A redraw needs the verified source name.")
        if not re.fullmatch(r"[A-Fa-f0-9]{64}", str(source.get("source_sha256", ""))):
            raise ValueError("A redraw needs the verified source image SHA-256.")
    elif "replace" in layer:
        raise ValueError("An add action cannot replace an existing object.")
    position = layer.get("position", "front")
    if isinstance(position, dict):
        if len(position) != 1 or set(position) - {"before", "after"} or not all(
            isinstance(v, str) and v.strip() for v in position.values()
        ):
            raise ValueError("Specify one named before or after anchor.")
    elif position not in ("front", "back"):
        raise ValueError("Unknown drawing position.")
    if not isinstance(layer.get("name"), str) or not layer["name"].strip():
        raise ValueError("A vector needs a name.")
    if not isinstance(page_id, str) or not page_id:
        raise ValueError("Supply the actual slide objectId.")
    if not isinstance(object_id, str) or not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_:.\-]{4,49}", object_id):
        raise ValueError("Supply a valid new Google Slides objectId.")
    scale = _number(units_per_inch)
    factor = scale / 914400 if point_scale is None else _number(point_scale)
    if min(scale, factor) <= 0:
        raise ValueError("Scale must be positive.")
    frame = tuple(v*scale for v in _box(layer["box"]))
    x, y, width, height = frame
    parts = layer["parts"]
    if not isinstance(parts, list) or not parts:
        raise ValueError("A vector needs at least one part.")
    drawings = []
    types = {"rect": "RECTANGLE", "roundRect": "ROUND_RECTANGLE", "ellipse": "ELLIPSE"}
    for p in parts:
        typ, fill = p["type"], p.get("fill")
        stroke = p.get("stroke", None if fill else "24343A")
        if not (stroke or fill):
            raise ValueError("A vector part must be visible.")
        weight = _number(p.get("width_pt", 1.5))*factor if stroke else 0
        if stroke and weight <= 0:
            raise ValueError("Stroke width must be positive.")
        attrs = {"type", "fill", "stroke", "width_pt"}
        if typ == "path":
            _keys(p, attrs | {"commands"})
            if fill:
                raise ValueError("Google Slides cannot create an arbitrary filled path. Use equivalent native shapes or preserve this layer in the editable PowerPoint.")
            for segment in _lines(p["commands"], frame):
                drawings.append((_line_requests, (*segment, stroke, weight)))
        elif typ in types:
            _keys(p, attrs | {"box"})
            a,b,w,h = _box(p["box"], local=True)
            rect = (x+a*width/100, y+b*height/100, w*width/100, h*height/100)
            drawings.append((_shape_requests, (types[typ], rect, fill, stroke, weight)))
        else:
            raise ValueError(f"Unsupported native vector primitive: {typ!r}.")
    if not drawings:
        raise ValueError("The vector has no drawable geometry.")
    prefix = "psv_" + sha256(object_id.encode()).hexdigest()[:24]
    many = len(drawings) > 1
    children, ops = [], []
    for i, (create, args) in enumerate(drawings):
        oid = f"{prefix}_{i}" if many else object_id
        children.append(oid)
        ops.extend(create(page_id, oid, *args))
    # The Slides API accepts alt text on constituent elements. Use the stable
    # group ID to identify the composite, and label its first constituent.
    ops.append({"updatePageElementAltText": {"objectId": children[0], "title": layer["name"]}})
    if many:
        ops.append({"groupObjects": {"groupObjectId": object_id, "childrenObjectIds": children}})
    return ops
