#!/usr/bin/env python3
"""Restore only approved source regions onto a generated slide. Also supplies font metrics for preflight."""
import hashlib
import json
import os
import sys
import tempfile
import unicodedata
from pathlib import Path
from PIL import Image, ImageChops, ImageOps


def require(condition, message):
    if not condition:
        raise ValueError(message)


def font_lines(text, font, width):
    lines = []
    for paragraph in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = ""
        for char in paragraph:
            if line and font.getlength(line + char) > width and not unicodedata.combining(char):
                lines.append(line)
                line = ""
            line += char
        lines.append(line)
    return lines


def check_assets(planned, evidence, directory):
    require(isinstance(evidence, list) and len(planned) == len(evidence),
            "Supply evidence for every authorized visual, including empty [] on a no-picture page.")
    require(isinstance(planned, list) and all(isinstance(a, dict) and a.get("action") in ("keep","redraw","add")
            and isinstance(a.get("id"), str) and a["id"].strip() for a in planned)
            and len({a["id"] for a in planned}) == len(planned), "Invalid visual plan.")
    for asset, entry in zip(planned, evidence):
        require(isinstance(entry, dict) and entry.get("id") == asset["id"] and entry.get("action") == asset["action"],
                "Asset receipt differs from the approved visual list or order.")
        if asset["action"] == "add":
            continue
        require(entry.get("reference") == asset["reference"] and entry.get("sha256") == asset.get("sha256")
                and isinstance(entry.get("path"), str) and entry["path"].strip(),
                "Keep/redraw evidence must identify the approved source reference and bytes.")
        source = directory / entry["path"]
        require(hashlib.sha256(source.read_bytes()).hexdigest() == entry["sha256"], "Wrong source asset bytes.")
        with Image.open(source) as im:
            im.verify()


def restored_image(base, evidence, directory):
    with Image.open(base) as raw:
        canvas = ImageOps.exif_transpose(raw).convert("RGBA")
    restored = []
    for item in evidence:
        if item["action"] != "keep":
            continue
        box = item.get("box")
        require(isinstance(box, list) and len(box) == 4 and all(type(v) is int for v in box),
                "Provide the actual reserved pixel box for this protected asset.")
        x, y, width, height = box
        require(width > 0 and height > 0 and 0 <= x <= canvas.width-width and 0 <= y <= canvas.height-height,
                "Protected source rectangle falls outside the generated page.")
        with Image.open(directory / item["path"]) as s:
            original = ImageOps.exif_transpose(s).convert("RGBA")
        fitted = ImageOps.contain(original, (width, height), method=Image.Resampling.LANCZOS)
        require(fitted.size != canvas.size, "Use approved_original_page for full-page reuse.")
        left, top = x+(width-fitted.width)//2, y+(height-fitted.height)//2
        right, bottom = left+fitted.width, top+fitted.height
        require(all(right <= l or r <= left or bottom <= t or b <= top for l,t,r,b in restored),
                "One protected object obscures another; reserve distinct slots.")
        restored.append((left, top, right, bottom))
        canvas.alpha_composite(fitted, (left, top))
    require(sum((r-l)*(b-t) for l,t,r,b in restored) < canvas.width*canvas.height,
            "Protected overlays obscure the entire generated composition.")
    return canvas


def verify(plan, receipt, directory, final_image):
    check_assets(plan, receipt.get("asset_evidence"), directory)
    require(isinstance(receipt.get("generation_ref"), str) and receipt["generation_ref"].strip()
            and isinstance(receipt.get("generated_path"), str) and receipt["generated_path"].strip(),
            "A generated page requires the actual tool result reference and saved image bytes.")
    base = directory / receipt["generated_path"]
    base_hash = hashlib.sha256(base.read_bytes()).hexdigest()
    require(not receipt.get("generated_sha256") or receipt["generated_sha256"] == base_hash, "Generated base bytes changed.")
    if not any(asset["action"] == "keep" for asset in plan):
        require(hashlib.sha256(final_image.read_bytes()).hexdigest() == base_hash,
                "With no protected overlays, deliver the exact generated image.")
    else:
        expected = restored_image(base, receipt["asset_evidence"], directory)
        with Image.open(final_image) as file:
            actual = file.convert("RGBA")
        require(actual.size == expected.size and
                all(channel.getbbox() is None for channel in ImageChops.difference(actual, expected).split()),
                "Page pixels must match the generated base with only approved original regions restored.")
    return base_hash


def compose(job, number, receipt, directory, dest):
    page = job["pages"][number-1]
    require(number == receipt["page_number"] == page["page_number"] and
            page.get("source_kind") != "approved_original_page", "Wrong page or an explicitly unchanged page.")
    check_assets(page["visuals"], receipt["asset_evidence"], directory)
    require(any(a["action"] == "keep" for a in page["visuals"]), "Use the generated bytes directly when there are no protected regions.")
    canvas = restored_image(directory / receipt["generated_path"], receipt["asset_evidence"], directory)
    require(dest.suffix.lower() == ".png", "Choose a PNG output.")
    with tempfile.NamedTemporaryFile(dir=dest.parent, suffix=".png", delete=False) as f:
        tmp = Path(f.name)
    try:
        canvas.save(tmp, "PNG")
        if dest.exists():
            require(dest.read_bytes() == tmp.read_bytes(), "A different output already exists.")
        else:
            os.link(tmp, dest)
    finally:
        tmp.unlink(missing_ok=True)


if __name__ == "__main__":
    try:
        job_file, n, receipt_file, destination = sys.argv[1:]
        rp = Path(receipt_file).resolve()
        compose(json.loads(Path(job_file).read_text()), int(n), json.loads(rp.read_text()), rp.parent, Path(destination))
        print(json.dumps({"image_path": str(Path(destination).resolve())}))
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        sys.exit(str(error))
