"""Check or reframe editable hero photographs after explicit approval of varied framing."""
import argparse
import json
import re
import runpy
from io import BytesIO
from itertools import combinations
from pathlib import Path

from PIL import Image
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE as ST

HERE = Path(__file__).resolve().parent
SIDES = ("left", "top", "right", "bottom")
PROTECTED = {"evidence","protected","screenshot","chart","data_chart","table","logo","thumbnail",
             "icon","cutout","subject_cutout","small_illustration","vector","background","supporting"}


def requested(plan):
    settings = plan.get("settings", {})
    explicit = settings.get("photo_layout_variety")
    if explicit is not None:
        return explicit is True or explicit == "varied"
    requirements = plan.get("requirements", [])
    if isinstance(requirements, str):
        requirements = [requirements]
    if not isinstance(requirements, list):
        return False
    # Match prior confirmed, photo-specific instructions; a general style preference is insufficient.
    for line in [*requirements,settings.get("layout_instruction","")]:
        if not isinstance(line, str):
            continue
        for phrase in re.split(r"[。；;\n，,]", line):
            if not re.search(r"大圖|主圖|照片|hero photos?|photo (?:frames?|layouts?)", phrase, re.I):
                continue
            if re.search(r"不要|無需|不需|不必|不要求|do not|no need|without",phrase,re.I):
                continue
            if re.search(r"錯落|多樣構圖|不同構圖|不同圖框|varied|staggered|vary",phrase,re.I):
                return True
    return False


def read(path):
    return json.loads(path.read_bytes())


def load_work(root):
    cp = read(root/"work.json")
    slots = []
    for filename in ("assets.json", "redraws.json"):
        if (root/filename).exists():
            slots.extend(read(root/filename)["assets"])
    return cp,slots


def has_alpha(blob):
    with Image.open(BytesIO(blob)) as im:
        if "A" not in im.getbands() and "transparency" not in im.info:
            return False
        return sum(im.convert("RGBA").getchannel("A").histogram()[:32]) > im.width*im.height*.03


def photo_rows(deck,cp,slots):
    width,height=deck.slide_width,deck.slide_height
    rows=[]
    for slot in slots:
        n,name=slot["page_number"],slot["name"]
        profile=cp.get("page_profiles",{}).get(str(n),cp["settings"].get("editable_profile"))
        if profile!="refined" or slot.get("action") not in {"add","redraw","replace"}:
            continue
        if (slot.get("protected") or slot.get("fixed_frame") or slot.get("layout_locked") or slot.get("transparent_cutout")
            or slot.get("kind") in PROTECTED or slot.get("role") in PROTECTED):
            continue
        slide=deck.slides[n-1]
        # Group transforms and inherited frame crops need independent inspection. Never silently
        # exclude a named large picture just because it was placed in a group.
        def matching(shapes,grouped=False):
            for sh in shapes:
                if sh.shape_type==ST.GROUP:
                    yield from matching(sh.shapes,True)
                elif sh.shape_type==ST.PICTURE and sh.name==name:
                    yield sh,grouped
        matches=list(matching(slide.shapes))
        if len(matches)!=1:
            rows.append({"page":n,"name":name,"issue":"missing or ambiguous picture frame"})
            continue
        sh,grouped=matches[0]
        if has_alpha(sh.image.blob):
            continue
        if grouped or sh.rotation or sh._element.xpath("./p:spPr/a:xfrm[@flipV='1' or @flipH='1']"):
            rows.append({"page":n,"name":name,"issue":"inspect group/rotation before reframing"})
            continue
        l,t,r,b=max(0,sh.left/width),max(0,sh.top/height),min(1,(sh.left+sh.width)/width),min(1,(sh.top+sh.height)/height)
        box=[l,t,max(0,r-l),max(0,b-t)]
        rows.append({"page":n,"name":name,"box":box,"crop":[getattr(sh,"crop_"+k) for k in SIDES],
                     "family":family(box), "area":box[2]*box[3]})
    return rows


def family(box):
    x,y,w,h=box
    if w>=.80 and h>=.79:
        return "full_bleed"
    if w<=.68 and h>=.76:
        return "tall_panel"
    if w>=.65 and h<=.70:
        return "wide_band"
    if min(x, y,1-x-w,1-y-h)<=.025:
        return "partial_bleed"
    return "inset"


def distinct(a,b):
    x,y=a["box"][2:];w,h=b["box"][2:]
    if min(x,y,w,h)<=0:
        return False
    aspect_ratio=max(x*h/(y*w),w*y/(h*x))
    size_difference=max(abs(x-w),abs(y-h))
    # Mirroring or moving a frame does not change these shape measurements.
    return a["family"]!=b["family"] and size_difference>=.15 and (aspect_ratio>=1.32 or size_difference>=.33)


def check(deck,cp,slots):
    result={"status":"not_applicable","frames":[]}
    if not requested(cp):
        return result
    rows=photo_rows(deck,cp,slots)
    # Only the largest authorized, unlocked scene on each page establishes the composition.
    pages={}
    for row in rows:
        if row["page"] not in pages or row.get("area",0)>pages[row["page"]].get("area",0):
            pages[row["page"]]=row
    result["frames"]=list(pages.values())
    if len(pages)<3:
        result["reason"]="Fewer than three pages have a movable main photograph."
        return result
    result["status"]="repair_layout"
    if any("issue" in r for r in result["frames"]):
        result["reason"]="Locate and measure the approved picture at its final page coordinates."
        return result
    main=[r for r in result["frames"] if r["area"]>=.10]
    if len(main)>=2 and any(distinct(a,b) for a,b in combinations(main,2)):
        result["status"]="pass"
    else:
        result["reason"]="The confirmed varied compositions still use similar photo frames. Reframe a safe page; preserve text, evidence and the photographed subject."
    return result


def check_cloud(report,native,presentation_id=None,revision=None):
    if report["status"]!="pass":
        return report
    if (not native.get("presentationId") or not native.get("revisionId")
        or (presentation_id and native["presentationId"]!=presentation_id)
        or (revision and native["revisionId"]!=revision)):
        return {**report,"status":"repair_layout","reason":"Wrong or missing native Google presentation/revision."}
    util=runpy.run_path(str(HERE/"check-refined-cutout-delivery.py"))
    width,height=[util["pts"](native["pageSize"][k]) for k in ("width","height")]
    google=[]
    for row in report["frames"]:
        page=row["page"]
        matches=[]
        if page<=len(native["slides"]):
            for e,b,_,matrix in util["flatten"](util["google_nodes"](native["slides"][page-1].get("pageElements",[]))):
                if "image" not in e or not b or abs(matrix[0,1])+abs(matrix[1,0])>.0001:
                    continue
                left,top,right,bot=util["normalized"](b,width,height)
                left,top,right,bot=max(left,0),max(top,0),min(right,1),min(bot,1)
                box=[left,top,right-left,bot-top]
                crop=e["image"].get("imageProperties",{}).get("cropProperties",{})
                if max(abs(a-b) for a,b in zip(box,row["box"]))<=.008 and max(abs(crop.get(k+"Offset",0)-v) for k,v in zip(SIDES,row["crop"]))<=.008:
                    matches.append({"page":page,"object_id":e["objectId"],"box":box,"family":family(box),"area":box[2]*box[3]})
        if len(matches)!=1:
            return {**report,"status":"repair_layout","reason":f"Native photo frame/crop differs or is ambiguous on page {page}.","native_matches":google}
        google.extend(matches)
    return {**report,"status":"pass" if any(distinct(a,b) for a,b in combinations([g for g in google if g["area"]>=.10],2)) else "repair_layout",
            "native_matches":google,"slides_revision":native["revisionId"],"presentation_id":native["presentationId"]}


def protected_zones(slide,photo,canvas):
    zones=[]
    for obj in slide.shapes:
        if obj.shape_id==photo.shape_id or obj.width is None or obj.height is None:
            continue
        # Plain shape/line overlays, art and mastheads all keep their location. A full-slide
        # empty background behind the photo is safe to span. General text remains editable.
        if not obj.width or not obj.height:
            continue
        if (obj.shape_type==ST.AUTO_SHAPE and not obj.text.strip() and obj.left<=0 and obj.top<=0
            and obj.width>=canvas[0] and obj.height>=canvas[1]):
            continue
        zones.append({"box":list(map(int,(obj.left,obj.top,obj.width,obj.height))),"name":obj.name})
    return zones


def alternatives(deck,row,others,spec):
    geometry=runpy.run_path(str(HERE/"refined-photo-layout.py"))
    slide=deck.slides[row["page"]-1]
    photo=next(p for p in slide.shapes if p.name==row["name"] and p.shape_type==ST.PICTURE)
    cw,ch=int(deck.slide_width),int(deck.slide_height)
    zones=protected_zones(slide,photo,(cw,ch))
    reviewed={k:v for k,v in spec.items() if k in ("focus","subject","anchor")}
    # A crop without reviewed subject bounds must show the entire source.
    fit="cover" if "subject" in reviewed else "contain"
    options=[]
    for l,t,r,b in geometry["free_regions"]((cw,ch),zones):
        w,h=r-l,b-t
        # Try a naturally wide band, a partial-edge panel and an inset with real room around it.
        for fw,fh in [(w,h),(w,min(h,.49*ch)),(.92*w,min(.63*ch,h)),(.86*w,.73*h)]:
            for y in (t,t+(h-fh)/2,b-fh):
                frame=[l+(w-fw)/2,y,fw,fh]
                try:
                    proposal=geometry["layout_photo"](photo.image.size,frame,(cw,ch),reviewed,fit=fit,extra_zones=zones)
                except geometry["NoPhotoFit"]:
                    continue
                bx,by,bw,bh=proposal["box"];norm=[bx/cw,by/ch,bw/cw,bh/ch]
                fam=family(norm);area=norm[2]*norm[3]
                if area<max(.12,row["area"]*.48) or not any(distinct({"box":norm,"family":fam},v) for v in others if v.get("area",0)>=.10):
                    continue
                crop=proposal["crop"]
                retained=(1-crop["left"]-crop["right"])*(1-crop["top"]-crop["bottom"])
                options.append((area**.5*retained,proposal))
    return sorted(options,key=lambda a:-a[0])


def repair(root,source,out,focus):
    cp,slots=load_work(root)
    deck=Presentation(source)
    report=check(deck,cp,slots)
    if report["status"]!="repair_layout":
        return report
    if source.resolve()==out.resolve() or out.exists():
        raise ValueError("Choose a new staging output path for the repaired presentation.")
    measurements={(s["page"],s["name"]):s for s in focus}
    candidates=[]
    for r in report["frames"]:
        if "issue" in r:
            continue
        for score,layout in alternatives(deck,r,[t for t in report["frames"] if t is not r],measurements.get((r["page"],r["name"]),{}))[:1]:
            candidates.append((score,r,layout))
    for _,r,layout in sorted(candidates,key=lambda t:-t[0]):
        sh=next(p for p in deck.slides[r["page"]-1].shapes if p.name==r["name"] and p.shape_type==ST.PICTURE)
        old_values=[sh.left,sh.top,sh.width,sh.height,*[getattr(sh,"crop_"+k) for k in SIDES]]
        sh.left,sh.top,sh.width,sh.height=map(round,layout["box"])
        for side in SIDES:setattr(sh,"crop_"+side,layout["crop"][side])
        verified=check(deck,cp,slots)
        if verified["status"]=="pass":
            from tempfile import NamedTemporaryFile
            with NamedTemporaryFile(dir=out.parent,suffix=".pptx") as tmp:
                # Save only the changed slide XML, leaving charts, embedded workbooks, media
                # and every other package part byte-for-byte unchanged.
                from zipfile import ZipFile
                slide=deck.slides[r["page"]-1].part
                member=str(slide.partname).lstrip("/")
                with ZipFile(source) as original,ZipFile(tmp.name,"w") as repaired:
                    for info in original.infolist():
                        repaired.writestr(info,slide.blob if info.filename==member else original.read(info))
                actual=check(Presentation(tmp.name),cp,slots)
                if actual["status"]=="pass":
                    import os
                    os.link(tmp.name,out)
                    return {**actual,"updated_page":r["page"],"photo":r["name"],"output":str(out),"verified_complete":False}
        sh.left,sh.top,sh.width,sh.height=old_values[:4]
        for side,v in zip(SIDES,old_values[4:]):setattr(sh,"crop_"+side,v)
    return {**report,"next_action":"Recompose an authorized photo page around its original text and evidence; provide observed subject bounds or regenerate for a wider/partial frame. Re-run on the new staged file."}


def main():
    p=argparse.ArgumentParser(description=__doc__);cmd=p.add_subparsers(dest="op",required=True)
    c=cmd.add_parser("check");r=cmd.add_parser("repair")
    for a in (c,r):
        a.add_argument("run_dir",type=Path);a.add_argument("pptx",type=Path)
    c.add_argument("--slides-json",type=Path);c.add_argument("--slides-id");c.add_argument("--slides-revision")
    r.add_argument("--out",type=Path,required=True);r.add_argument("--focus",type=Path)
    args=p.parse_args()
    if args.op=="repair":
        result=repair(args.run_dir,args.pptx,args.out,read(args.focus) if args.focus else [])
    else:
        cp,slots=load_work(args.run_dir)
        result=check(Presentation(args.pptx),cp,slots)
        if args.slides_json:
            result=check_cloud(result,read(args.slides_json),args.slides_id,args.slides_revision)
    print(json.dumps(result,ensure_ascii=False))
    return 2 if result["status"]=="repair_layout" else 0

if __name__=="__main__":
    raise SystemExit(main())
