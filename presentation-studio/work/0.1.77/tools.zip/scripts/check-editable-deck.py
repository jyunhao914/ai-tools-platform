#!/usr/bin/env python3
"""Verify an editable PPTX. Run with PLAN.json DECK.pptx [REVIEW.json].

Report text differences separately from structural failures. Refined pages also
require the reviewer's assessment of the final rendered slides.
"""
import hashlib
import importlib.util
import json
import sys
from io import BytesIO
from itertools import combinations
from math import ceil, floor
from pathlib import Path
from functools import lru_cache

from PIL import Image
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE as ShapeType


@lru_cache(maxsize=None)
def sibling(name):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


playback = sibling("slide-output")
compare = sibling("page-text-review")
KIND = {"text", "shape", "table", "chart", "picture", "icon_group"}
NATIVE_GEOMETRY = {ShapeType.AUTO_SHAPE, ShapeType.CALLOUT, ShapeType.LINE, ShapeType.FREEFORM}
GEOMETRY_REVIEW = {"text", "table", "chart"}


def shapes_with_names(collection, grouped=False, named_groups=()):
    for shape in collection:
        if shape.shape_type == ShapeType.GROUP:
            if shape.name in named_groups:
                yield shape, grouped
            yield from shapes_with_names(shape.shapes, True, named_groups)
        else:
            yield shape, grouped


def native_text(shape):
    if shape.has_table:
        return "\n".join(cell.text for cell in shape.table.iter_cells() if not cell.is_spanned)
    return shape.text_frame.text if shape.has_text_frame else ""


def matches(shape, kind):
    if kind == "text":
        return shape.has_text_frame and bool(shape.text_frame.text.strip())
    if kind == "shape":
        return shape.shape_type in NATIVE_GEOMETRY
    if kind == "icon_group":
        if shape.shape_type != ShapeType.GROUP:
            return False
        parts = [child for child, _ in shapes_with_names(shape.shapes)]
        return bool(parts) and all(
            child.shape_type in NATIVE_GEOMETRY and not native_text(child).strip()
            and not child._element.xpath(".//a:blipFill|.//a:blip")
            for child in parts
        )
    if kind == "picture":
        return shape._element.tag.rsplit("}", 1)[-1] == "pic"
    return shape.has_table if kind == "table" else shape.has_chart


def rectangle(shape):
    x, y = shape.left, shape.top
    return (x, y, x + shape.width, y + shape.height)


def intersection(a, b):
    return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))


def area(box):
    return (box[2] - box[0]) * (box[3] - box[1])


def is_layout_anchor(item, box, canvas):
    """Compare principal content placements, ignoring chrome and tiny decorations."""
    if item.get("role") in {"title", "header", "footer", "background", "decoration"}:
        return False
    if item["kind"] == "shape" and not item.get("text"):
        return False
    width, height = canvas[2:]
    _, top, _, bottom = box
    visible = intersection(box, canvas)
    return (.025 * width * height <= visible < .90 * width * height
            and bottom > .16 * height and top < .88 * height)


def same_placement(previous, current):
    # Match by geometry, ignoring construction order, wording and shape IDs.
    if len(previous) != len(current) or len(current) < 2:
        return False
    remaining = list(current)
    for box in sorted(previous, key=area, reverse=True):
        def similarity(candidate):
            overlap = intersection(box, candidate)
            return overlap / (area(box) + area(candidate) - overlap)
        match = max(remaining, key=similarity)
        if similarity(match) < .80:
            return False
        remaining.remove(match)
    return True


def review_adjacent_layouts(previous, page, boxes, report):
    if previous is None or page.get("layout_locked") or page.get("approved_original_page"):
        return
    other, other_boxes = previous
    if other.get("layout_locked") or other.get("approved_original_page") or page["hidden"] or other["hidden"]:
        return
    purpose = str(page.get("purpose") or "").strip()
    other_purpose = str(other.get("purpose") or "").strip()
    if not purpose or not other_purpose or purpose == other_purpose:
        return
    if page.get("comparison_group") and page["comparison_group"] == other.get("comparison_group"):
        return
    if same_placement(other_boxes, boxes):
        report["visual_review"].append({
            "page_number": page["page_number"], "name": "",
            "issue": (f"Different purposes on slides {other['page_number']} and {page['page_number']} "
                      "use nearly identical main-content placements. Compare both renders for fit."),
        })


def opaque_rectangle(shape):
    if shape.shape_type != ShapeType.PICTURE or shape.rotation:
        return False
    if shape._element.xpath("./p:spPr/a:custGeom") or any(
        node.get("prst") != "rect" for node in shape._element.xpath("./p:spPr/a:prstGeom")
    ):
        return False
    blip = shape._element.xpath("./p:blipFill/a:blip")
    if not blip or len(blip[0]):
        return False  # DrawingML effects can introduce transparency.
    try:
        with Image.open(BytesIO(shape.image.blob)) as image:
            if "A" not in image.getbands() and "transparency" not in image.info:
                return True
            return image.convert("RGBA").getchannel("A").getextrema() == (255, 255)
    except (OSError, ValueError):
        return False  # Some Office vector media cannot be decoded by Pillow.


def cutout_alpha(shape):
    """Return the opacity mask of the embedded PNG after cropping and flipping."""
    try:
        with Image.open(BytesIO(shape.image.blob)) as image:
            if image.format != "PNG" or ("A" not in image.getbands() and "transparency" not in image.info):
                return None
            mask = image.convert("RGBA").getchannel("A")
    except (OSError, ValueError):
        return None
    width, height = mask.size
    # An extended source rectangle is not evidence of transparency in the PNG.
    left, top = round(width * shape.crop_left), round(height * shape.crop_top)
    right, bottom = round(width * (1 - shape.crop_right)), round(height * (1 - shape.crop_bottom))
    clipped = max(0, left), max(0, top), min(width, right), min(height, bottom)
    if clipped[0] >= clipped[2] or clipped[1] >= clipped[3]:
        return None
    mask = mask.crop(clipped)
    counts = mask.histogram()
    # A few transparent pixels, a flat translucent rectangle and an empty PNG
    # do not provide a visible subject with a usable transparent surround.
    minimum = max(1, ceil(mask.width * mask.height * .01))
    if sum(counts[:17]) < minimum or sum(counts[128:]) < minimum:
        return None
    transform = shape._element.xpath("./p:spPr/a:xfrm")
    if transform:
        if transform[0].get("flipH") in {"1", "true"}:
            mask = mask.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        if transform[0].get("flipV") in {"1", "true"}:
            mask = mask.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    return mask


def foreground_opacity(shape, box, content, mask):
    """Inspect an enclosed content rectangle only for plain, unrotated pictures."""
    if (mask is None or min(shape.crop_left, shape.crop_top, shape.crop_right, shape.crop_bottom) < 0
            or shape._element.xpath("./p:spPr/a:custGeom|./p:blipFill/a:blip/*|./p:blipFill/a:tile")
            or any(node.attrib for node in shape._element.xpath("./p:blipFill/a:stretch/a:fillRect"))
            or any(node.get("prst") != "rect" for node in shape._element.xpath("./p:spPr/a:prstGeom"))):
        return None
    scale_x, scale_y = mask.width / (box[2] - box[0]), mask.height / (box[3] - box[1])
    region = (floor((content[0] - box[0]) * scale_x), floor((content[1] - box[1]) * scale_y),
              ceil((content[2] - box[0]) * scale_x), ceil((content[3] - box[1]) * scale_y))
    return mask.crop(region).getextrema()


def check_slide(slide, page, canvas, report, *, refined=False):
    number = page["page_number"]

    def note(bucket, name, issue):
        report[bucket].append({"page_number": number, "name": name, "issue": issue})

    objects = page.get("objects")
    if not isinstance(objects, list) or not objects:
        raise ValueError(f"Provide the intended objects for page {number}.")
    layered = any("above" in item or item.get("transparent_cutout") is True for item in objects)
    by_name = {}
    drawing_order = {}
    named_groups = {item.get("name") for item in objects if item.get("kind") == "icon_group"
                    and isinstance(item.get("name"), str)}
    for index, (shape, grouped) in enumerate(shapes_with_names(slide.shapes, named_groups=named_groups)):
        by_name.setdefault(shape.name, []).append((shape, grouped))
        drawing_order[shape.name] = index
    named = set()
    text_boxes = {}
    covering_pictures = []
    has_native_content = False
    layout_boxes = []
    content_rects = {}
    cutouts = {}
    verified_original = False
    verified_photo = False
    for item in objects:
        name, kind = item.get("name"), item.get("kind")
        if not isinstance(name, str) or not name.strip() or name in named or kind not in KIND:
            raise ValueError(f"Invalid or duplicate object in plan at slide {number}: {name}, {kind}.")
        named.add(name)
        found = by_name.get(name, [])
        if len(found) != 1:
            note("errors", name, f"Expected one planned {kind}; found {len(found)} matching names.")
            continue
        shape, grouped = found[0]
        if not matches(shape, kind):
            note("errors", name, f"Expected editable {kind}; actual shape is {shape.shape_type}.")
            continue
        if (refined and kind == "picture" and item.get("action") != "keep" and not item.get("protected")
                and sibling("check-cutout").requires_cutout(item)):
            proof = sibling("check-cutout").inspect_bytes(shape.image.blob)
            if proof["status"] != "ready":
                note("errors", name, "Embedded decorative artwork: " + ", ".join(proof["reasons"]))
            elif cutout_alpha(shape) is None:
                note("errors", name, "The placed decoration lost its transparent surround after cropping.")
        if "transparent_cutout" in item:
            if kind != "picture" or not isinstance(item["transparent_cutout"], bool):
                raise ValueError(f"transparent_cutout needs a Boolean on a picture at slide {number}: {name}.")
            if item["transparent_cutout"]:
                mask = cutout_alpha(shape)
                if mask is None:
                    note("errors", name, "Expected a PNG cutout with visible subject pixels and meaningful transparent area after cropping.")
                else:
                    cutouts[name] = mask
        text = native_text(shape)
        if "text" in item:
            if not isinstance(item["text"], str) or kind not in {"text", "shape", "table"}:
                raise ValueError(f"Invalid text specification at slide {number}: {name}.")
            diffs = compare.differences(item["text"], text.replace("\v", "\n"))
            if diffs:
                report["text_differences"].append({"page_number": number, "name": name, "differences": diffs})
        if kind in {"text", "chart", "table"} or (kind == "shape" and text.strip()):
            has_native_content = True
        checked_source = False
        if "source_sha256" in item:
            if kind != "picture":
                raise ValueError(f"source_sha256 is valid only for a picture at slide {number}: {name}.")
            digest = hashlib.sha256(shape.image.blob).hexdigest()
            checked_source = digest == item["source_sha256"]
            if not checked_source:
                note("errors", name, "Embedded image differs from the specified source or approved crop.")
        if grouped or shape.rotation:
            # Local coordinates inside transformed groups are not slide coordinates.
            note("visual_review", name, "Inspect transformed bounds, cropping and readability in the rendered slide.")
            continue
        box = rectangle(shape)
        if is_layout_anchor(item, box, canvas):
            layout_boxes.append(box)
        visible_area = intersection(box, canvas)
        if kind != "shape" and not visible_area:
            note("errors", name, "Planned content has no visible area on the page.")
        elif kind in GEOMETRY_REVIEW and visible_area < area(box) * .999:
            note("visual_review", name, "Inspect content extending beyond the slide.")
        if kind == "picture" and visible_area >= .98 * area(canvas):
            covering_pictures.append(name)
            if checked_source:
                verified_photo = True
                if all(getattr(shape, crop) == 0 for crop in ("crop_left", "crop_right", "crop_top", "crop_bottom")):
                    verified_original = True
        if kind == "text" or (kind == "shape" and text.strip()):
            text_boxes[name] = box
        protected_picture = layered and checked_source and item.get("role") not in {"background", "decoration"}
        if kind in GEOMETRY_REVIEW or (kind == "shape" and text.strip()) or protected_picture:
            content_rects[shape.shape_id] = (name, box)
    for item in objects:
        if "above" not in item:
            continue
        name, below = item["name"], item["above"]
        if not isinstance(below, list) or any(not isinstance(other, str) or other not in named or other == name for other in below):
            raise ValueError(f"above must list other planned objects on slide {number}: {name}.")
        for other in below:
            if len(by_name.get(name, [])) == len(by_name.get(other, [])) == 1 and drawing_order[name] <= drawing_order[other]:
                note("errors", name, f"Incorrect picture or object stacking order: expected above {other!r}.")
    for name, entries in by_name.items():
        if name not in named and any(shape.has_chart or shape.has_table or native_text(shape).strip() or
                                     shape._element.tag.rsplit("}", 1)[-1] == "pic"
                                     for shape, _ in entries):
            note("errors", name, "Unplanned text, data or picture object; match it to the approved content and visual plan.")
    # A foreground flattened image can obscure actual editable text left behind it.
    # Deliberate full-bleed backgrounds below the text remain valid.
    earlier_content = []
    for shape in slide.shapes:
        if earlier_content and shape.shape_type == ShapeType.PICTURE and not shape.rotation:
            box = rectangle(shape)
            covered = [(name, source) for name, source in earlier_content if area(source) > 0
                       and intersection(box, source) == area(source)]
            if covered:
                opaque = opaque_rectangle(shape)
                for name, source in covered:
                    opacity = foreground_opacity(shape, box, source, cutouts.get(shape.name))
                    if opaque or opacity == (255, 255):
                        note("errors", name, f"Planned content is wholly covered by foreground picture {shape.name!r}.")
                    elif opacity != (0, 0):
                        note("visual_review", name, f"Inspect transparency where foreground picture {shape.name!r} spans this content.")
        if shape.shape_id in content_rects:
            earlier_content.append(content_rects[shape.shape_id])
    if page.get("approved_original_page") is True:
        if not verified_original or not isinstance(page.get("authorization"), str) or not page["authorization"].strip():
            note("errors", "", "Whole-page reuse needs the authorized, content-matched source image.")
    elif covering_pictures and not has_native_content:
        # A legitimate approved photo-only slide can be an independently editable photo.
        # Both its provenance and the decision to use only this image must be recorded.
        if (page.get("image_only") is not True or not verified_photo
                or not isinstance(page.get("authorization"), str) or not page["authorization"].strip()):
            note("errors", covering_pictures[0], "Full-page picture without planned editable content or verified image-only approval.")
    for a, b in combinations(text_boxes, 2):
        smaller = min(area(text_boxes[a]), area(text_boxes[b]))
        if smaller and intersection(text_boxes[a], text_boxes[b]) > .20 * smaller:
            note("visual_review", a, f"Inspect overlapping text bounds with {b!r} in the rendered slide.")
    return layout_boxes


def rendered_design_issues(plan, deck_path, review_path):
    default = (plan.get("settings") or {}).get("editable_profile") or plan.get("editable_profile")
    overrides = plan.get("page_profiles") or {}
    required = {p["page_number"] for p in plan["pages"]
                if (p.get("editable_profile") or overrides.get(str(p["page_number"])) or default) == "refined"}
    if not required:
        return None
    def missing(reason):
        return [{"page_number": n, "issue": reason} for n in sorted(required)]
    if not deck_path or not review_path:
        return missing("Review the final rendered slide before marking refined design complete.")
    try:
        review = json.loads(review_path.read_text(encoding="utf-8"))
        if review.get("pptx_sha256") != hashlib.sha256(deck_path.read_bytes()).hexdigest():
            return missing("Design review is for a different output file.")
        rows = review["pages"]
        numbers = [row["page"] for row in rows]
        if any(type(n) is not int or not 1 <= n <= len(plan["pages"]) for n in numbers) or len(numbers) != len(set(numbers)):
            return missing("Invalid or duplicated rendered page.")
        indexed = {row["page"]:row for row in rows}
        issues = []
        used_paths = set()
        for n in sorted(required):
            row = indexed.get(n, {})
            def issue(reason):
                issues.append({"page_number": n, "issue": reason})
            if not all(isinstance(row.get(k), str) and row[k].strip()
                       for k in ("render_path","render_sha256","focal_point","observation")):
                issue("Missing final render or page-specific observations.")
                continue
            render = (review_path.parent / row["render_path"]).resolve()
            if render in used_paths:
                issue("Use the individual render for this slide.")
                continue
            used_paths.add(render)
            try:
                if hashlib.sha256(render.read_bytes()).hexdigest() != row["render_sha256"]:
                    issue("Reviewed image changed.")
                    continue
                with Image.open(render) as preview:
                    preview.load()
            except (OSError, ValueError):
                issue("The reviewed render cannot be opened.")
                continue
            if row.get("status") != "pass" or row.get("editable_ok") is not True:
                issue(row.get("reason") or row["observation"])
        return issues
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return missing("Cannot read the current design review.")


def inspect(plan, deck, deck_path=None, review_path=None):
    pages = plan["pages"]
    if not isinstance(pages, list) or not pages:
        raise ValueError("Plan must list pages in delivery order.")
    playback.check(deck, pages)
    report = {"passed": False, "pages": len(pages), "errors": [], "text_differences": [], "visual_review": []}
    previous = None
    default = (plan.get("settings") or {}).get("editable_profile") or plan.get("editable_profile")
    profiles = plan.get("page_profiles") or {}
    for slide, page in zip(deck.slides, pages):
        profile = page.get("editable_profile") or profiles.get(str(page["page_number"])) or default
        boxes = check_slide(slide, page, (0, 0, deck.slide_width, deck.slide_height), report, refined=profile == "refined")
        review_adjacent_layouts(previous, page, boxes, report)
        previous = page, boxes
    report["structure_passed"] = not report["errors"]
    report["passed"] = report["structure_passed"]
    design = rendered_design_issues(plan, deck_path, review_path)
    if design is not None:
        report["refined_design_issues"] = design
        report["passed"] = report["passed"] and not design
    return report


if __name__ == "__main__":
    try:
        if len(sys.argv) not in (3, 4):
            raise ValueError("Usage: check-editable-deck.py PLAN.json DECK.pptx [REVIEW.json]")
        plan_path, deck_path = map(Path, sys.argv[1:3])
        review_path = Path(sys.argv[3]) if len(sys.argv) == 4 else None
        result = inspect(json.loads(plan_path.read_text(encoding="utf-8")), Presentation(deck_path), deck_path, review_path)
    except Exception as error:
        result = {"passed": False, "error": str(error)}
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["passed"] else 1)
