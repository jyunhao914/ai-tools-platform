"""Verify editable Google objects directly against the delivery PPTX and the native slide PDF."""
import argparse
import hashlib
import io
import json
import math
import runpy
from pathlib import Path

import fitz
import numpy as np
from PIL import Image
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.oxml.ns import qn

G = runpy.run_path(str(Path(__file__).with_name("check-refined-cutout-delivery.py")))
SIDES = ("left", "top", "right", "bottom")
I = np.eye(3)


def translate(x, y):
    return np.array([[1,0,x],[0,1,y],[0,0,1]])


def geometry(shape, parent):
    group = shape.shape_type == MSO_SHAPE_TYPE.GROUP
    nodes = shape._element.xpath("./p:grpSpPr/a:xfrm" if group else "./p:spPr/a:xfrm|./p:xfrm")
    x = nodes[0] if nodes else None
    w,h = shape.width,shape.height
    dx,dy = shape.left,shape.top
    angle = math.radians(shape.rotation or 0)
    c,s = math.cos(angle),math.sin(angle)
    rotation = np.array([[c,-s,0],[s,c,0],[0,0,1]])
    flip = np.diag([-1 if x is not None and x.get("flipH") in ("1","true") else 1,
                    -1 if x is not None and x.get("flipV") in ("1","true") else 1,1])
    matrix = parent @ translate(dx+w/2,dy+h/2) @ rotation @ flip @ translate(-w/2,-h/2)
    bounds = G["bounds"]([(matrix@v)[:2] for v in ((0,0,1),(w,0,1),(w,h,1),(0,h,1))])
    if group and x is not None:
        origin,ext = x.find(qn("a:chOff")),x.find(qn("a:chExt"))
        if ext is not None and int(ext.get("cx")) and int(ext.get("cy")):
            matrix = matrix @ np.diag([w/int(ext.get("cx")),h/int(ext.get("cy")),1]) @ translate(-int(origin.get("x")),-int(origin.get("y")))
    return bounds,matrix


def objects(page, shapes, frame, parent=I):
    for shape in shapes:
        box,matrix = geometry(shape,parent)
        box = G["normalized"](box,*frame)
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            # Studio-created icon groups and other purely vector artwork must stay editable.
            if vector_group(shape):
                yield "vector",shape.name,box,shape
                continue
            yield from objects(page,shape.shapes,frame,matrix)
            continue
        blips = shape._element.xpath("./p:blipFill/a:blip|./p:spPr/a:blipFill/a:blip")
        if blips:
            blip, = blips
            crop = blip.getparent().find(qn("a:srcRect"))
            offsets = tuple(int(crop.get(k,0))/100000 if crop is not None else 0 for k in ("l","t","r","b"))
            geom=shape._element.xpath("./p:spPr/a:prstGeom")
            fill_shape=(geom[0].get("prst","rect") if geom else "rect") if shape.shape_type!=MSO_SHAPE_TYPE.PICTURE else None
            yield "picture",shape.name,box,(page.part.related_part(blip.get(qn("r:embed"))).blob,offsets,fill_shape)
        elif shape.has_text_frame and shape.text.strip():
            yield "text",shape.name,box,"".join(shape.text.split())


def vector_group(group):
    leaves=[]
    def visit(shapes):
        for s in shapes:
            if s.shape_type==MSO_SHAPE_TYPE.GROUP:
                visit(s.shapes)
            else:
                leaves.append(s)
    visit(group.shapes)
    if not leaves:return False
    return group.name.startswith("PS art ") or all(
        s.shape_type in (MSO_SHAPE_TYPE.LINE,MSO_SHAPE_TYPE.AUTO_SHAPE,MSO_SHAPE_TYPE.FREEFORM) and
        not (s.has_text_frame and s.text.strip()) and not s._element.xpath(".//a:blip") for s in leaves)


def native_text(shape):
    return "".join("".join(t.get("textRun",{}).get("content","").split()) for t in
                   shape.get("shape",{}).get("text",{}).get("textElements",[]))


def scoped(page, frame, nodes):
    for sh in page.shapes:
        items=list(objects(page,[sh],frame))
        if sh.shape_type!=MSO_SHAPE_TYPE.GROUP or vector_group(sh) or not items:
            for item in items:yield (*item,nodes)
            continue
        # Locate a native compound exhibit using all its editable legends. Google may
        # scale/move the whole group around a live chart. Every child must then still
        # land in its own projected frame within that group.
        labels=sorted(v for k,_,_,v in items if k=="text")
        origin=G["normalized"](geometry(sh,I)[0],*frame)
        span=(origin[2]-origin[0],origin[3]-origin[1])
        candidates=[]
        if labels and min(span)>0:
            for elem,b,children,_ in nodes:
                if not children or not same_box(origin,b,.16):continue
                descendants={e["objectId"] for e,_,_,_ in G["flatten"](children)}
                members=[entry for entry in nodes if entry[0].get("objectId") in descendants]
                texts=sorted(text for e,_,_,_ in members if (text:=native_text(e)))
                if labels!=texts:continue
                scale=(b[2]-b[0])/span[0],(b[3]-b[1])/span[1]
                if min(scale)>.55 and max(scale)<1.65 and abs(math.log(scale[0]/scale[1]))<.065:
                    candidates.append((b,members,scale))
        if len(candidates)!=1:
            for item in items:yield (*item,nodes)
            continue
        b,members,scale=candidates[0]
        for k,name,box,data in items:
            adjusted=tuple(b[i%2]+(v-origin[i%2])*scale[i%2] for i,v in enumerate(box))
            yield k,name,adjusted,data,members


def pixels(im):
    rgba = np.asarray(im.convert("RGBA").resize((96,96),Image.Resampling.LANCZOS),dtype=float)
    rgb,alpha = rgba[:,:,:3],rgba[:,:,3:4]/255
    return np.concatenate([rgb*alpha,alpha*255],axis=2)


def same_pixels(a,b):
    if abs(math.log((a.width*b.height)/(b.width*a.height)))>.025:
        return False
    av,bv = pixels(a),pixels(b)
    diff = np.abs(av-bv)
    meaningful=(av[:,:,3]>20)|(bv[:,:,3]>20)
    if not meaningful.any():
        return False
    return (np.mean(diff[meaningful])<4 and np.quantile(diff[meaningful],.97)<22
            and np.mean((av[:,:,3]<16)!=(bv[:,:,3]<16))<.012)


def pdf_layers(doc,page):
    masks = {r[0]:r[1] for r in page.get_images(full=True)}
    for entry in page.get_image_info(xrefs=True):
        ref=entry.get("xref")
        if not ref:
            continue
        yield ref,masks.get(ref),G["normalized"](entry["bbox"],page.rect.width,page.rect.height)


def pdf_pixels(doc,ref,smask):
    def read(x):
        return Image.open(io.BytesIO(doc.extract_image(x)["image"]))
    im=read(ref).convert("RGBA")
    if smask:
        im.putalpha(read(smask).convert("L"))
    return im


def visible_in_pdf(im,crop,frame,page):
    """Sample the drawn subject and its high-contrast details to detect opaque overpainting."""
    l,t,r,b=crop;x0,y0,x1,y1=frame
    x,y,X,Y=max(0,x0),max(0,y0),min(1,x1),min(1,y1)
    if x>=X or y>=Y:return False
    a,bx=(1-l-r)/(x1-x0),(1-t-b)/(y1-y0)
    sub=(l+(x-x0)*a,t+(y-y0)*bx,l+(X-x0)*a,t+(Y-y0)*bx)
    clip=fitz.Rect(x*page.rect.width,y*page.rect.height,X*page.rect.width,Y*page.rect.height)
    mat=min(3,210/max(clip.width,clip.height))
    pix=page.get_pixmap(matrix=fitz.Matrix(mat,mat),clip=clip,colorspace=fitz.csRGB,alpha=False)
    size=(min(96,pix.width),min(96,pix.height))
    rendered=np.asarray(Image.frombytes('RGB',(pix.width,pix.height),pix.samples).resize(size,Image.Resampling.LANCZOS),dtype=float)
    original=im.convert('RGBA').crop(tuple(round(v*(im.width if i%2==0 else im.height)) for i,v in enumerate(sub))).resize(size,Image.Resampling.LANCZOS)
    arr=np.asarray(original,dtype=float);mask=arr[:,:,3]>220
    if min(size)>6:mask[:2,:]=mask[-2:,:]=False;mask[:,:2]=mask[:,-2:]=False
    if mask.sum()<12:return False
    rgb=arr[:,:,:3]
    flat=rgb[mask]
    salient=np.abs(flat-np.median(flat,axis=0)).max(1)
    keep=salient>=max(22,np.quantile(salient,.75))
    diff=abs(flat-rendered[mask]).mean(1)
    both=(diff<30).mean();detail=(diff[keep]<38).mean() if keep.sum()>=10 else both
    return both>=.54 and detail>=.40


def same_box(a,b,tol=.008):
    return max(abs(x-y) for x,y in zip(a,b))<=tol


def check_image(doc,pdf_page,source,box,nodes,media,base,used):
    blob,crop,fill_shape=source
    with Image.open(io.BytesIO(blob)) as im:
        im.load()
        l,t,r,b=crop
        vw,vh=1-l-r,1-t-b
        if min(vw,vh)<=0:
            return None,"Invalid source crop."
        matches=[]
        for element,frame,_,_ in nodes:
            pic=element.get("image")
            if element.get("objectId") in used or not same_box(box,frame):
                continue
            if pic:
                opts=pic.get("imageProperties",{}).get("cropProperties",{})
                offsets=tuple(opts.get(k+"Offset",0) for k in SIDES)
                if not same_box(offsets,crop) or abs(opts.get("angle",0))>1e-5:
                    continue
            else:
                # Google can keep an image-filled shape editable, but omits the
                # picture bytes of this fill in presentations.get. Its individual PDF
                # layer and native shape type/position must independently agree.
                shape=element.get("shape",{})
                compatible={"rect":{"RECTANGLE"},"roundRect":{"ROUND_RECTANGLE","RECTANGLE"},"ellipse":{"ELLIPSE"}}
                if not fill_shape or shape.get("shapeType") not in compatible.get(fill_shape,set()) or native_text(element):
                    continue
                fill=shape.get("shapeProperties",{}).get("shapeBackgroundFill",{})
                if fill.get("propertyState")=="NOT_RENDERED" or fill.get("solidFill"):
                    continue
            matches.append((element,frame))
        if len(matches)!=1:
            return None,"Read the matching native image frame and crop; the match is missing or ambiguous."
        element,frame=matches[0];oid=element["objectId"]
        w,h=(frame[2]-frame[0])/vw,(frame[3]-frame[1])/vh
        full=(frame[0]-w*l,frame[1]-h*t,frame[2]+w*r,frame[3]+h*b)
        layers=[(ref,mask) for ref,mask,layer_box in pdf_layers(doc,pdf_page) if same_box(layer_box,full)]
        for ref,mask in layers:
            if same_pixels(im,pdf_pixels(doc,ref,mask)):
                # A full-bleed hero can intentionally carry a veil/title. Smaller
                # exhibits and alpha art must also be visible after all PDF marks.
                area=(frame[2]-frame[0])*(frame[3]-frame[1])
                if area<.38 and not visible_in_pdf(im,crop,frame,pdf_page):
                    return oid,"The native PDF contains this picture but its subject or important details are hidden."
                return oid,None
        if "image" not in element:
            return oid,"Native shape's own PDF image layer, pixels or mask do not match the delivery PowerPoint."
        record=media.get(oid,{})
        url=element["image"].get("contentUrl")
        if url and record.get("content_url")==url and record.get("file"):
            with Image.open(base/record["file"]) as remote:
                if same_pixels(im,remote):
                    if not visible_in_pdf(im,crop,frame,pdf_page):
                        return oid,"Native media matches, but its visible PDF placement or content differs."
                    return oid,None
                return oid,"The current native image pixels or alpha differ from the delivery PowerPoint."
        return oid,"Read this object's current image.contentUrl bytes and save {content_url,file} under its object ID in files.slides_media."


def text_frame(box, frame, text, page):
    if same_box(box,frame,.016):return True
    # A longer editable box may have been used to prevent a short figure label from
    # clipping. Verify its ink still falls inside the expected cell on the actual PDF.
    if len(text)>64 or max(abs(box[i]-frame[i]) for i in (0,1))>.014:return False
    for axis in (0,1):
        extent=box[axis+2]-box[axis]
        if extent<=0 or not .55<=(frame[axis+2]-frame[axis])/extent<=1.9:return False
    for hit in page.search_for(text):
        b=G["normalized"](hit,page.rect.width,page.rect.height)
        center=((b[0]+b[2])/2,(b[1]+b[3])/2)
        if all(box[i]-.012<=center[i]<=box[i+2]+.012 and frame[i]-.005<=center[i]<=frame[i+2]+.005 for i in (0,1)):
            return True
    return False


def solid_box(element):
    shape=element.get("shape",{})
    if shape.get("shapeType") not in {"RECTANGLE","ROUND_RECTANGLE"}:return False
    fill=shape.get("shapeProperties",{}).get("shapeBackgroundFill",{})
    return fill.get("propertyState")!="NOT_RENDERED" and bool(fill.get("solidFill")) and fill["solidFill"].get("alpha",1)>=.98


def decoration_overlay(oid,nodes,transparent):
    i=next(k for k,row in enumerate(nodes) if row[0].get("objectId")==oid)
    _,box,_,_=nodes[i]
    for j,(e,b,_,_) in enumerate(nodes):
        if j==i or not solid_box(e):continue
        if transparent and G["nearly_same"](b,box):
            return "A solid native backplate covers the cutout's clear surround."
        if j>i and b[0]<=box[0]+.001 and b[1]<=box[1]+.001 and b[2]>=box[2]-.001 and b[3]>=box[3]-.001:
            return "A later opaque shape hides this image or editable illustration in native Slides."
    return None


def check(pptx,native,pdf,deck_id,revision,media_file=None):
    deck=Presentation(pptx)
    result={"issues":[],"pictures":[],"text_frames":0,"native_vectors":[]}
    if (not deck_id or not revision or native.get("presentationId")!=deck_id or native.get("revisionId")!=revision
            or len(native.get("slides",[]))!=len(deck.slides)):
        return {**result,"issues":[{"reason":"Read the exact native Slides ID, revision and every pageElement."}]}
    size=tuple(G["pts"](native["pageSize"][k]) for k in ("width","height"))
    media=json.loads(media_file.read_text()) if media_file else {}
    base=media_file.parent if media_file else Path(".")
    with fitz.open(pdf) as doc:
        if len(doc)!=len(deck.slides):
            return {**result,"issues":[{"reason":"Native PDF page count differs."}]}
        for n,(ppt,cloud,page) in enumerate(zip(deck.slides,native["slides"],doc),1):
            nodes=[(e,G["normalized"](frame,*size),children,matrix) for e,frame,children,matrix in
                   G["flatten"](G["google_nodes"](cloud.get("pageElements",[]))) if frame]
            used=set()
            rendered=None
            for kind,name,box,data,allowed in scoped(ppt,(deck.slide_width,deck.slide_height),nodes):
                oid=None;issue=None
                if kind=="picture":
                    try:
                        oid,issue=check_image(doc,page,data,box,allowed,media,base,used)
                        if oid and not issue:
                            with Image.open(io.BytesIO(data[0])) as im:
                                alpha=np.asarray(im.convert("RGBA").resize((64,64)))[:,:,3]
                                transparent=(alpha<16).mean()>=.08 and (alpha>180).mean()>=.03
                            issue=decoration_overlay(oid,nodes,transparent)
                    except (ValueError,KeyError,TypeError,OSError) as err:
                        issue=str(err)
                    if not issue:result["pictures"].append({"page":n,"name":name,"object_id":oid})
                elif kind=="vector":
                    hits=[e["objectId"] for e,frame,children,_ in allowed if children and same_box(frame,box,.014)
                          and e["objectId"] not in used]
                    if len(hits)!=1:
                        issue="Restore this editable artwork as its own native Google group."
                    else:
                        oid=hits[0]
                        try:
                            parts=G["native_ppt"](data)
                            _,_,proof=G["google_object"](native,n,{"slides_object_id":oid},"native_icon",{},base)
                            if parts>1 and proof.get("native_parts",0)<2:raise ValueError("The multi-part icon was flattened")
                            issue=decoration_overlay(oid,nodes,True)
                            if not issue and (name.startswith("PS art ") or "icon" in name.casefold() or "圖示" in name):
                                if rendered is None:rendered=G["render"](doc,n)
                                G["probe_render"](rendered,box,None,True,None)
                            if not issue:result["native_vectors"].append({"page":n,"name":name,**proof})
                        except (ValueError,KeyError,TypeError) as err:issue=str(err)
                else:
                    def matches(e,frame):
                        text=e.get("shape",{}).get("text",{}).get("textElements",[])
                        content="".join("".join(t.get("textRun",{}).get("content","").split()) for t in text)
                        return content==data and text_frame(box,frame,data,page) and e.get("objectId") not in used
                    hits=[e["objectId"] for e,frame,_,_ in allowed if matches(e,frame)]
                    if len(hits)==1:
                        oid=hits[0]
                        issue=decoration_overlay(oid,nodes,False)
                        if not issue:result["text_frames"]+=1
                    else:issue="Read the editable text and its native frame; it differs from the verified PowerPoint."
                if issue:result["issues"].append({"page":n,"shape":name,"object_id":oid,"reason":issue})
                elif oid:used.add(oid)
    return result


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    for name in ("pptx","native","pdf"):cli.add_argument(name,type=Path)
    cli.add_argument("--id",required=True);cli.add_argument("--revision",required=True)
    cli.add_argument("--media",type=Path)
    a=cli.parse_args()
    result=check(a.pptx,json.loads(a.native.read_bytes()),a.pdf,a.id,a.revision,a.media)
    print(json.dumps(result,ensure_ascii=False))
