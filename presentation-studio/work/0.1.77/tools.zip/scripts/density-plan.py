#!/usr/bin/env python3
"""Mode 3 only. Measure ordered, indivisible content groups; apply only approved splits.
analyze SOURCE_JOB SOURCE_PAGE PROFILE
screen SOURCE_JOB PROFILES_JSON SCREENED_JOB
apply SOURCE_JOB DECISIONS_JSON OUTPUT_JOB
"""
import hashlib
import importlib.util
import json
import os
import math
import sys
import tempfile
from pathlib import Path
from PIL import ImageFont
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("compose_page", Path(__file__).with_name("compose-page.py"))
composer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(composer)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def demand(condition, message):
    if not condition:
        raise ValueError(message)


def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def require_redesign(job):
    demand(job.get("schema_version") == 2 and job.get("mode") == 3 and job.get("pages"),
           "Density-based repagination requires a mode 3 source job.")


def source_number(page):
    return page.get("source_page", page["page_number"])


def source_page(job, number):
    require_redesign(job)
    demand(type(number) is int and number >= 1, "Unknown original page.")
    matches = [p for p in job["pages"] if source_number(p) == number]
    demand(len(matches) == 1, "Use an existing, unsplit source page for this decision.")
    page = matches[0]
    demand(page.get("density_status") not in ("approved_split", "approved_original"),
           "This original page already has an applied decision.")
    return page


def source_revision(job, page):
    # Before 0.1.29 partially applied jobs retained the baseline revision in each pending proposal.
    return job.get("density_source_revision", page.get("density_proposal", {}).get("source_revision",
                                                                              job["content_revision"]))


def validate_groups(page, groups):
    demand(isinstance(groups, list) and groups, "Provide the source page's indivisible groups.")
    cursor = 0
    ids = []
    for group in groups:
        a, b = group["start"], group["end"]
        demand(type(a) is int and type(b) is int and a == cursor <= b <= len(page["text"]),
               "Groups must cover the locked manuscript exactly in reading order.")
        demand(nonnegative(group.get("visual_height", 0)) and nonnegative(group.get("reserved_height", 0)),
               "Reserve the measured non-text height for photos, tables, and diagrams.")
        demand(group.get("role", "body") in ("body", "title", "caption", "table"),
               "Unknown content group role.")
        demand(isinstance(group.get("visual_ids", []), list), "Expected a list of visual IDs.")
        demand(not group.get("visual_ids") or group.get("visual_height", 0) > 0,
               "Reserve space for each visual group before measuring.")
        ids.extend(group.get("visual_ids", []))
        cursor = b
    demand(cursor == len(page["text"]) and len(ids) == len(set(ids)) and
           set(ids) == {v["id"] for v in page["visuals"]}, "Text or visual coverage is incomplete.")


def nonnegative(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def measure(page, profile, variant, base):
    width, available = variant["width"], variant["height"]
    demand(nonnegative(width) and width > 0 and nonnegative(available) and available > 0, "Use the actual available content area.")
    gap = variant.get("gap", 0)
    demand(nonnegative(gap), "Group spacing must be nonnegative.")
    breaks = profile.get("break_before_groups", [])
    segments = []
    used = 0
    for idx, g in enumerate(profile["groups"]):
        role = g.get("role", "body")
        fmt = variant.get("roles", {}).get(role, {})
        size = fmt.get("font_size", variant["font_size"])
        minimum = profile.get("role_minimums", {}).get(role, profile["min_readable_size"])
        demand(type(size) is int and minimum > 0, "Use a valid font size and a positive readability minimum.")
        if size < minimum:
            return None
        font = ImageFont.truetype(str(base / fmt.get("font", variant["font"])), size, index=fmt.get("font_index", variant.get("font_index", 0)))
        column_width = fmt.get("width", width)
        demand(0 < column_width <= width, "Use an actual column width.")
        raw = page["text"][g["start"]:g["end"]]
        # A single boundary newline separates semantic groups; internal empty lines consume space.
        if raw.endswith("\r\n"):
            raw = raw[:-2]
        elif raw.endswith(("\n", "\r")):
            raw = raw[:-1]
        metrics = sum(font.getmetrics())
        advance = fmt.get("line_height", variant.get("line_height", metrics))
        if advance < metrics:
            return None
        rows = composer.font_lines(raw, font, column_width) if raw else []
        if any(font.getlength(line) > column_width for line in rows):
            return None
        text_height = (len(rows)-1)*advance + metrics if rows else 0
        h = text_height + g.get("visual_height", 0) + g.get("reserved_height", 0)
        measured = variant.get("measured_group_heights", {}).get(str(idx))
        if measured is not None:
            demand(nonnegative(measured) and measured > 0, "Use measured full-group height.")
            if role == "table" or g.get("visual_ids"):
                h = max(measured, g.get("visual_height", 0), g.get("reserved_height", 0))
            else:
                h = max(h, measured)
        if h > available:
            return None
        overflow = used + gap + h > available
        if breaks and segments and idx not in breaks and overflow:
            return None  # A user-specified segment would need an additional, unapproved break.
        if not segments or idx in breaks or overflow:
            segments.append({"start": g["start"], "end": g["end"], "visual_ids": [], "labels": []})
            used = h
        else:
            used += gap + h
        segment = segments[-1]
        segment["end"] = g["end"]
        segment["visual_ids"].extend(g.get("visual_ids", []))
        if g.get("label"):
            segment["labels"].append(g["label"])
    return segments


def analyze(job, number, profile_path):
    page, profile = source_page(job, number), read(profile_path)
    demand(profile["source_page"] == number, "Profile belongs to another original page.")
    validate_groups(page, profile["groups"])
    demand(profile.get("variants"), "Provide at least one readable layout.")
    breaks = profile.get("break_before_groups", [])
    demand(isinstance(breaks, list) and all(type(i) is int and 0 < i < len(profile["groups"]) for i in breaks)
           and breaks == sorted(set(breaks)), "Custom breaks must be distinct, ascending group boundaries.")
    best = None
    for variant in profile["variants"]:
        result = measure(page, profile, variant, profile_path.parent)
        if result is not None and (best is None or len(result) < len(best["segments"])):
            best = {"layout": variant["name"], "segments": result}
    plan = {"source_page": number, "source_revision": source_revision(job, page), "hidden": page["hidden"]}
    if best is None:
        reason = ("The requested segments do not fit any readable candidate layout."
                  if breaks else "The tested layouts could not place all source groups at readable sizes.")
        plan.update(action="needs_group_review", reason=reason)
    else:
        n = len(best["segments"])
        plan.update(best, action="fits" if n == 1 else "suggest_split", suggested_pages=n)
    base_page = {k: v for k, v in page.items() if k not in ("density_status", "density_proposal", "source_page", "source_range")}
    base_page["page_number"] = number
    plan["proposal_id"] = fingerprint([base_page, profile, plan])
    return plan


def screen(job, profiles, directory):
    require_redesign(job)
    pages = [dict(p) for p in job["pages"]]
    seen = set()
    for item in profiles:
        n = item["source_page"]
        demand(n not in seen, "Duplicate page density profile.")
        seen.add(n)
        plan = analyze(job, n, directory / item["profile"])
        index = source_page(job, n)["page_number"] - 1
        pages[index].update(density_status="fits" if plan["action"] == "fits" else "needs_decision",
                          density_proposal=plan)
    return dict(job, pages=pages)


def apply(job, decisions, directory):
    require_redesign(job)
    new_pages, selected = [], {}
    for d in decisions:
        n = d["source_page"]
        source_page(job, n)
        demand(n not in selected and isinstance(d.get("authorization"), str) and d["authorization"].strip(),
               "Each exception needs one explicit decision for this original page.")
        selected[n] = d
    if not selected:
        return dict(job)
    for page in job["pages"]:
        n, original = source_number(page), page["text"]
        if n not in selected:
            updated = dict(page, page_number=len(new_pages)+1, source_page=n)
            updated.setdefault("source_range", [0, len(original)])
            new_pages.append(updated)
            continue
        d = selected[n]
        proposal = analyze(job, n, directory / d["profile"])
        demand(d["proposal_id"] == proposal["proposal_id"], "The approved proposal changed. Show the new preview.")
        if d["choice"] == "split":
            demand(proposal["action"] == "suggest_split", "No applicable split proposal.")
            segments = proposal["segments"]
        elif d["choice"] == "keep_original":
            segments = [{"start": 0, "end": len(original), "visual_ids": [a["id"] for a in page["visuals"]]}]
            demand(isinstance(d.get("reference"), str) and d["reference"].strip(), "Supply the actual original page reference.")
        else:
            raise ValueError("Unknown density decision.")
        parts = []
        for segment in segments:
            a, b = segment["start"], segment["end"]
            item = dict(page, page_number=len(new_pages)+1, source_page=n, source_range=[a,b],
                        text=original[a:b], visuals=[v for v in page["visuals"] if v["id"] in segment["visual_ids"]])
            item.update(density_authorization=d["authorization"], proposal_id=d["proposal_id"],
                        density_status="approved_split" if d["choice"] == "split" else "approved_original")
            item.pop("density_proposal", None)
            if d["choice"] == "keep_original":
                source_hash = d.get("sha256")
                if source_hash is None and (directory / d["reference"]).is_file():
                    source_hash = hashlib.sha256((directory / d["reference"]).read_bytes()).hexdigest()
                demand(isinstance(source_hash, str) and len(source_hash) == 64,
                       "Bind the approved original page to the verified SHA256 of its 16:9 source image.")
                item.update(source_kind="approved_original_page", reference=d["reference"], sha256=source_hash,
                            authorization=d["authorization"])
            parts.append(item["text"])
            new_pages.append(item)
        demand("".join(parts) == original, "Split changed the locked source text.")
    return dict(job, expected_pages=len(new_pages), pages=new_pages,
                density_source_revision=source_revision(job, source_page(job, next(iter(selected)))),
                content_revision=job["content_revision"]+"-"+fingerprint(new_pages)[:12])


if __name__ == "__main__":
    try:
        cmd, src = sys.argv[1], Path(sys.argv[2]).resolve()
        if cmd == "analyze":
            result = analyze(read(src), int(sys.argv[3]), Path(sys.argv[4]).resolve())
        elif cmd in ("apply", "screen"):
            inputs = Path(sys.argv[3]).resolve()
            transform = apply if cmd == "apply" else screen
            result = transform(read(src), read(inputs), inputs.parent)
            out = Path(sys.argv[4]).resolve()
            if out.exists():
                demand(read(out) == result, "Choose a new path for a changed page plan.")
            else:
                with tempfile.NamedTemporaryFile(dir=out.parent, mode="w", encoding="utf-8", delete=False) as f:
                    temp = Path(f.name)
                    json.dump(result, f, ensure_ascii=False)
                try:
                    os.link(temp, out)
                finally:
                    temp.unlink(missing_ok=True)
            result = {"output": str(out), "pages": len(result["pages"])}
        else:
            raise ValueError("Use analyze, screen, or apply.")
        print(json.dumps(result, ensure_ascii=False))
    except (OSError, KeyError, ValueError, IndexError, TypeError) as error:
        sys.exit(str(error))
