// Verify source workbooks from native Slides, Sheets and Drive readbacks for this delivery.
import {visibleChartIssue} from "./linked-chart-slot.mjs";
const mime = {
  folder: "application/vnd.google-apps.folder",
  slides: "application/vnd.google-apps.presentation",
  sheets: "application/vnd.google-apps.spreadsheet",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation"
};
const present = value => typeof value === "string" && value.trim().length > 0;

function chartsOnPage(elements) {
  const charts = [];
  for (const element of elements ?? []) {
    if (element.sheetsChart) charts.push(element.sheetsChart);
    if (element.elementGroup) charts.push(...chartsOnPage(element.elementGroup.children));
  }
  return charts;
}

function sourceRanges(value) {
  if (!value || typeof value !== "object") return [];
  if (value.sourceRange) return value.sourceRange.sources ?? [];
  return Object.values(value).flatMap(sourceRanges);
}

function rangeHasData(workbook, range, headers) {
  const sheet = workbook.sheets?.find(tab => tab.properties?.sheetId === range.sheetId);
  if (!sheet) return false;
  const {startRowIndex=0, endRowIndex:r2=Infinity, startColumnIndex=0, endColumnIndex:c2=Infinity} = range;
  const horizontal = r2-startRowIndex === 1 && c2-startColumnIndex !== 1;
  const r1 = startRowIndex + (horizontal ? 0 : headers);
  const c1 = startColumnIndex + (horizontal ? headers : 0);
  return (sheet.data ?? []).some(block => (block.rowData ?? []).some((row, ri) => {
    const r = (block.startRow ?? 0) + ri;
    return r >= r1 && r < r2 && (row.values ?? []).some((cell, ci) => {
      const c = (block.startColumn ?? 0) + ci;
      if (c < c1 || c >= c2) return false;
      const value = cell.effectiveValue ?? cell.userEnteredValue;
      return value && (typeof value.numberValue === "number" || typeof value.boolValue === "boolean" || present(value.stringValue));
    });
  }));
}

function filed(file, id, expectedMime, folderId) {
  return present(id) && file?.id === id && (file.mimeType ?? file.mime_type) === expectedMime &&
    file.trashed !== true && (file.parents ?? file.parent_ids)?.includes(folderId) === true;
}

export function chartWorkbookDelivery(job, base, verified, formats) {
  const books = [], issues = [];
  const requiredCharts = (job.editable_charts ?? []).filter(row => row.formats == null || row.formats.includes("slides"));
  const data = verified.chart_delivery;
  const deck = data?.presentation ?? verified.presentation;
  if (deck?.presentationId !== verified.native_id || deck?.slides?.length !== job.pages ||
      !deck.slides.every(slide => Array.isArray(slide.pageElements))) {
    return {books, issues:["讀回本次原生 Google 簡報各頁的完整 pageElements，以檢查連結圖表。"]};
  }
  const slidesRevision=verified.output_revisions?.slides;
  if (present(slidesRevision) && deck.revisionId!==slidesRevision) {
    return {books,issues:["讀回本次最終 Google 簡報修訂的圖表物件，再核對相同修訂的匯出。"]};
  }
  const pagesByBook = new Map();
  const chartsPerPage = deck.slides.map(slide => chartsOnPage(slide.pageElements));
  for (const row of requiredCharts) {
    if ((chartsPerPage[row.page-1]?.length??0) < row.count) issues.push("第 "+row.page+" 頁缺少來源圖表的可更新連結。以 linked-chart-slot.mjs 把工作試算表的真正圖表放回定稿位置，重新整理，再用 linked-chart-run.py 校正標籤與字級。");
  }
  chartsPerPage.forEach((charts, i) => {
    for (const chart of charts) {
      if (!present(chart.spreadsheetId) || !Number.isInteger(chart.chartId) || chart.chartId < 0) {
        issues.push("第 "+(i+1)+" 頁的連結圖表缺少有效 spreadsheetId 或 chartId。");
        continue;
      }
      let links = pagesByBook.get(chart.spreadsheetId);
      if (!links) {links = []; pagesByBook.set(chart.spreadsheetId, links);}
      links.push({page:i+1, chartId:chart.chartId});
    }
  });
  if (!pagesByBook.size) return {books, issues};
  const folderId = job.work_folder_id ?? base.folder_id;
  const folder = data?.folder;
  const folderOK = present(folderId) && folder?.id === folderId &&
    (folder.mimeType ?? folder.mime_type) === mime.folder && folder.trashed !== true;
  if (!folderOK) issues.push("核對這份工作的 Drive 資料夾。");
  if (!filed(data?.slides_file, verified.native_id, mime.slides, folderId))
    issues.push("將本次原生 Google 簡報歸入工作資料夾並讀回 parents。");
  if (formats.includes("pptx") && !filed(data?.pptx_file, verified.pptx_file_id, mime.pptx, folderId))
    issues.push("將本次交付的 PowerPoint 檔歸入同一資料夾，核對檔案身分及 parents。");
  for (const [id, links] of pagesByBook) {
    const record = data?.workbooks?.find(row => row.spreadsheet?.spreadsheetId === id && row.drive_file?.id === id);
    if (!folderOK || !filed(record?.drive_file, id, mime.sheets, folderId)) {
      issues.push("核對第 "+links[0].page+" 頁圖表的 Sheets 資料檔與工作資料夾。");
      continue;
    }
    const book = record.spreadsheet;
    let complete = true;
    for (const link of links) {
      const tab = (book.sheets ?? []).find(s => s.charts?.some(c => c.chartId === link.chartId));
      const chart = tab?.charts.find(item => item.chartId === link.chartId);
      let ranges = sourceRanges(chart?.spec);
      let headers = chart?.spec?.basicChart?.headerCount ?? 0;
      const exported = record.exported_ranges;
      if (chart && !ranges.length && exported?.spreadsheetId === id && /^[a-f0-9]{64}$/.test(exported.export_sha256)) {
        ranges = exported.charts?.find(row => row.chartId === link.chartId && row.sheetId === tab.properties?.sheetId)?.ranges ?? [];
        headers = 0; // OOXML cat/val formulas already exclude series headers.
      }
      if (!ranges.length || !ranges.every(range => rangeHasData(book, range, headers))) {
        issues.push("讀回第 "+link.page+" 頁對應的 Sheets 圖表 "+link.chartId+" 與其資料範圍。");
        complete = false;
      }
    }
    if (complete) books.push({id,title:book.properties?.title ?? record.drive_file.name ?? id,
      url:"https://docs.google.com/spreadsheets/d/"+encodeURIComponent(id)+"/edit",
      pages:[...new Set(links.map(link => link.page))]});
  }
  return {books, issues};
}

const validSha256 = value => typeof value === "string" && /^[a-f0-9]{64}$/i.test(value);

function readablyMatches(metric) {
  if (!metric || typeof metric.reference_pt !== "number" || !Number.isFinite(metric.reference_pt) ||
      typeof metric.actual_pt !== "number" || !Number.isFinite(metric.actual_pt) ||
      metric.reference_pt <= 0 || metric.actual_pt <= 0) return false;
  return metric.actual_pt >= metric.reference_pt * .92 || metric.reference_pt - metric.actual_pt <= 1;
}

function physicalLabelMap(series) {
  if (!Array.isArray(series) || !series.every(s=>s && typeof s.name==="string" && Array.isArray(s.labels))) return null;
  return series.map(s => ({name:s.name, points:s.point_count,
    labels:s.labels.map(l=>[l.point,l.text])})).sort((a,b)=>a.name.localeCompare(b.name));
}

function matchesPhysicalChart(reference, chart) {
  if (!reference || !chart) return false;
  const actual=physicalLabelMap(chart.series), reported=physicalLabelMap(reference.series);
  if (!actual || !reported || actual.length!==reported.length) return false;
  return actual.every((s,i)=>{
    const r=reported[i];
    return s.name===r.name && s.points===r.points && s.labels.length===r.labels.length &&
      s.labels.every(([point,text],j)=>point===r.labels[j][0] && (text==null || text===r.labels[j][1]));
  }) && [...chart.required_type_roles].sort().join() === [...reference.required_type_roles??[]].sort().join();
}

// Reconcile handoff metadata with native chart objects from both actual PowerPoint files.
export function chartRequirements(declared, source, final) {
  const required=new Map(declared.map(row=>[row.page,{...row}]));
  const issues=[];
  const pages=new Set(source.charts.concat(final.charts).map(chart=>chart.page));
  for (const page of pages) {
    const originals=source.charts.filter(chart=>chart.page===page);
    const delivered=final.charts.filter(chart=>chart.page===page);
    const row=required.get(page)??{page};
    row.count=Math.max(row.count??0,originals.length,delivered.length);
    required.set(page,row);
    const remaining=delivered.slice();
    for (const chart of originals) {
      const index=remaining.findIndex(candidate=>matchesPhysicalChart(candidate,chart));
      if (index>=0) remaining.splice(index,1);
      else issues.push("第 "+page+" 頁 PowerPoint 的數列、可見資料標籤或圖例與原稿不符，須先修正。");
    }
  }
  return {required:[...required.values()],issues};
}

function chartRenderMatches(row, reference, physical) {
  if (!reference || !present(row.native_object_id) || row.axes_legend_reviewed !== true ||
      !Array.isArray(reference.required_type_roles) || !Array.isArray(row.type_samples) ||
      !reference.required_type_roles.every(role => row.type_samples.some(sample => sample.role === role)) ||
      !row.type_samples.every(m => present(m.text) && readablyMatches(m)) ||
      physical && !matchesPhysicalChart(reference, physical)) return false;
  const expected = new Map();
  const locations = new Set();
  for (const series of reference.series ?? []) {
    for (const label of series.labels ?? []) {
      if (!present(label.text) || !Number.isFinite(label.font_pt) || label.font_pt <= 0) return false;
      const key=JSON.stringify([series.name,label.point]);
      if (expected.has(key)) return false;
      expected.set(key, label);
    }
  }
  if (reference.review?.length || !Array.isArray(row.labels) || row.labels.length !== expected.size) return false;
  for (const label of row.labels) {
    const key = JSON.stringify([label.series,label.point]), source = expected.get(key);
    if (!source || label.text !== source.text || !readablyMatches({reference_pt:source.font_pt,actual_pt:label.actual_pt}) ||
        label.at_data_point !== true || !Array.isArray(label.rect) || label.rect.length !== 4 ||
        !label.rect.every(v => Number.isFinite(v) && v >= 0 && v <= 1) ||
        label.rect[0] >= label.rect[2] || label.rect[1] >= label.rect[3]) return false;
    const location=JSON.stringify(label.rect);
    if (locations.has(location)) return false;
    locations.add(location);
    expected.delete(key);
  }
  return !expected.size;
}

// A provenance check on reports read from actual final files. The host must render and inspect pixel-only charts.
export function chartArtifactIssues(job, verified, formats) {
  if (job.chart_fidelity_version !== 1 || !job.editable_charts?.length) return [];
  const issues = [];
  const required = kind => job.editable_charts.filter(r => formats.includes(kind) && (!r.formats || r.formats.includes(kind)));
  const pptx = required("pptx");
  if (pptx.length) {
    const report = verified.pptx_chart_audit;
    if (!validSha256(verified.pptx_sha256) || report?.pptx_sha256 !== verified.pptx_sha256 ||
        !Array.isArray(report.issues) || report.issues.length || !Array.isArray(report.charts) ||
        pptx.some(r => (new Set(report.charts.filter(c => c.page === r.page && c.verified_cells > 0 && !c.issue)
          .map(c => c.shape_id))).size < r.count)) {
      issues.push("以實際交付的 PPTX 執行 prepare-editable-delivery.py --audit；修復外部 Excel 引用或工作簿數據並驗讀。");
    }
  }
  const slides = required("slides");
  if (slides.length) {
    const audit = verified.chart_visual_audit;
    const nativePdf = verified.visible_reports?.slides?.pdf_sha256;
    const refPdf = verified.visible_reports?.pptx?.pdf_sha256 ?? audit?.reference_pdf_sha256;
    if (!validSha256(nativePdf) || !validSha256(refPdf) || audit?.slides_pdf_sha256 !== nativePdf ||
        !Array.isArray(audit?.rows) || !Array.isArray(audit.references)) {
      issues.push("讀回本版 Slides 渲染與 PPTX 圖表參照，逐項量測可見資料標籤、圖例及刻度。");
    } else {
      for (const r of slides) {
        const native=verified.chart_delivery?.presentation??verified.presentation;
        const linked=new Map();
        function collect(elements) {
          for (const element of elements??[]) {
            if (element.sheetsChart) linked.set(element.objectId,element.sheetsChart);
            if (element.elementGroup) collect(element.elementGroup.children);
          }
        }
        collect(native?.slides?.[r.page-1]?.pageElements);
        const checked = audit.rows.filter(row => {
          if (row.page!==r.page) return false;
          const physical=job.physical_charts?.find(c=>c.page===r.page && c.shape_id===row.shape_id);
          const chart=linked.get(row.native_object_id);
          if (!chart || (job.physical_charts && !physical) ||
              (row.spreadsheet_id!=null && chart.spreadsheetId!==row.spreadsheet_id) ||
              (row.chart_id!=null && chart.chartId!==row.chart_id)) return false;
          const ref=audit.references.find(ref=>ref.page===r.page && ref.shape_id===row.shape_id &&
            ref.pptx_pdf_sha256===refPdf && (pptx.length===0 && !physical || ref.pptx_sha256===verified.pptx_sha256));
          if (visibleChartIssue(native,r.page,row.native_object_id,physical?.region??ref?.region)) return false;
          return chartRenderMatches(row,ref,physical);
        });
        if (new Set(checked.map(row=>row.shape_id)).size < r.count ||
            new Set(checked.map(row=>row.native_object_id)).size < r.count) {
          issues.push("第 "+r.page+" 頁圖表未完整驗收。核對 sheetsChart 的工作試算表、chartId、定稿位置及前景遮擋。保留真圖，依原數列及點位補可編輯標籤與刻度，再重新整理及匯出比對。");
        }
      }
    }
  }
  return issues;
}
