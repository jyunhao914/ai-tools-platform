// The host inspects the unmodified provider output and binds its visual observation to these bytes.
const text = value => typeof value === "string" && value.trim() !== "";
const hash = value => typeof value === "string" && /^[0-9a-f]{64}$/i.test(value);
const size = value => Number.isSafeInteger(value) && value > 0;

const cutoutRoles = new Set(["cutout", "icon", "small_illustration", "subject_cutout"]);
const protectedRoles = new Set(["protected", "evidence", "screenshot", "data_chart", "chart", "table"]);
export function requiresCutout(asset) {
  const kind = asset?.kind, role = asset?.role;
  if (asset?.protected === true || asset?.action === "keep" || protectedRoles.has(kind) || protectedRoles.has(role)) return false;
  if (typeof asset?.transparent_cutout === "boolean") return asset.transparent_cutout;
  if (cutoutRoles.has(kind) || cutoutRoles.has(role)) return true;
  if (role) return false;
  if (!["add","redraw"].includes(asset?.action) || ![null,undefined,"","image","picture","raster"].includes(kind)) return false;
  const name = String(asset.name ?? "").normalize("NFKC").trim().toLowerCase();
  if (!name || [...name].length > 48 || name.split(/\s+/u).length > 5 || !/^[\p{L}\p{N}_ -]+$/u.test(name)) return false;
  if (/截圖|圖表|照片|畫面擷取|(?:^|[ _-])(?:screenshot|photo|chart|table)(?:$|[ _-])/u.test(name)) return false;
  return /(?:圖示|小插圖|(?:^|[ _\-\u3400-\u9fff])icon)(?:[ _-]?\d{1,2})?$/u.test(name);
}

export function assetPrompt(asset, settings, cutout=requiresCutout(asset)) {
  const operational = /驗收|回補|重試|佇列|工作資料夾|Google (?:Slides|Drive|Sheets)|PowerPoint|PPTX|request[_ -]?id|job[_ -]?id|acceptance test|retry queue/i;
  const scene = [...new Set([asset.subject, asset.resolved_subject, asset.brief]
    .filter(text).flatMap(s => s.split(/[。；;\n]+/)).map(s => s.trim()).filter(s => s && !operational.test(s)))].join("。");
  if (!scene) return null;
  const style = asset.resolved_media_style ?? asset.media_style ?? settings.media_style;
  const medium = style === "photorealistic" ? "單張寫實攝影。自然光影，真實的材質與比例。" :
    style === "illustration" ? "獨立插畫。" : (text(style) && style !== "auto" ? style + "。" : "");
  const background = cutout ? "輸出真正透明背景的 PNG；完整單一主體四周留透明空間，不要白底、外框、棋盤格或場景底板。" : "";
  return medium + scene + "。只呈現這一個獨立畫面。" + background;
}

function cutoutProof(review) {
  const proof = review?.cutout_check;
  return proof?.checker === "presentation-studio-cutout-v1" && hash(proof.sha256) && proof.sha256 === review.sha256 &&
    (proof.status === "rejected" && Array.isArray(proof.reasons) && proof.reasons.length > 0 ||
     proof.status === "ready" && proof.width === review.width && proof.height === review.height &&
     proof.metrics?.exterior_fraction > 0 && proof.metrics?.visible_fraction > 0 &&
     Array.isArray(proof.reasons) && !proof.reasons.length);
}

// A host with a remote original may run the same byte checker and return its JSON receipt.
export async function inspectCutoutOriginal(receipt, host) {
  const review = receipt?.visual_review;
  if (!review || !hash(review.sha256)) return receipt;
  let proof;
  try {
    if (typeof host.inspectCutout === "function") {
      proof = await host.inspectCutout(receipt.file, review.sha256);
    } else {
      let path = receipt.file.startsWith("/") ? receipt.file : null;
      if (!path && typeof host.resolveImageReference === "function")
        path = await host.resolveImageReference(receipt.file,"referenced_image_paths","generated");
      if (!path?.startsWith("/")) return receipt;
      const {execFile} = await import("node:child_process");
      const {fileURLToPath} = await import("node:url");
      const script = fileURLToPath(new URL("./check-cutout.py", import.meta.url));
      const raw = await new Promise((resolve,reject) => execFile(host.pythonExecutable ?? "python3", [script,path],
        {timeout:30000, maxBuffer:65536}, (error, result) => error ? reject(error) : resolve(result)));
      proof = JSON.parse(raw);
    }
  } catch { return receipt; }
  return {...receipt, visual_review:{...review, cutout_check:proof}};
}

export function assessGenerated(receipt, placement, cutout=false) {
  const review = receipt.visual_review;
  if (!review || review.generation_ref !== receipt.generation_ref || review.file !== receipt.file ||
      !hash(review.sha256) || !hash(review.source_sha256) || review.viewed_sha256 !== review.sha256 ||
      !text(review.observation)) return {status:"unverified"};
  if (review.source_sha256 !== review.sha256) return {status:"rejected", reason:"送審圖檔不是這次產出的完整原圖"};
  const mismatch = {wrong_subject:"主體不符",wrong_medium:"媒材不符",wrong_composition:"取得拼圖、資訊圖或其他不符構圖",
    unusable:"生圖內容無法在此圖位使用"};
  if (Object.hasOwn(mismatch, review.content))
    return {status:"rejected", reason:mismatch[review.content] + "：" + review.observation};
  const target = placement ?? review.placement_px;
  if (review.content !== "matched" || !size(review.width) || !size(review.height) ||
      !size(target?.width) || !size(target?.height)) return {status:"unverified"};
  if (review.width < target.width || review.height < target.height)
    return {status:"rejected", reason:`原生 ${review.width}×${review.height} 像素不足以填入 ${target.width}×${target.height} 圖位`};
  if (cutout) {
    if (!cutoutProof(review)) return {status:"unverified"};
    if (review.cutout_check.status === "rejected")
      return {status:"rejected", reason:review.cutout_check.reasons.join(", ")};
  }
  return {status:"ready"};
}

async function makeGuide(action, host) {
  // Ordinary web Chat runs the same Python helper in its own artwork workspace.
  if (typeof host.makeSceneGuide === "function") return host.makeSceneGuide(action);
  const {execFile} = await import("node:child_process");
  const {fileURLToPath} = await import("node:url");
  const {mkdtemp} = await import("node:fs/promises");
  const {tmpdir} = await import("node:os");
  const {join} = await import("node:path");
  const folder = host.imageWorkDirectory ?? await mkdtemp(join(tmpdir(), "presentation-scene-"));
  const script = fileURLToPath(new URL("./prepare-asset-call.py", import.meta.url));
  const output = await new Promise((resolve,reject) => {
    const child=execFile("python3", [script,"-",folder,"--reference-key","referenced_image_paths"],
      {timeout:15000,maxBuffer:65536}, (error,stdout) => error ? reject(error) : resolve(stdout));
    child.stdin.on("error",reject);
    child.stdin.end(JSON.stringify(action));
  });
  const built = JSON.parse(output);
  return {file:built.reference_file,sha256:built.reference_sha256};
}

// Only provider_input is sent to image generation. The receipt and slot identity remain with the caller.
export async function prepareAssetCall(asset, settings, key, rejected, host, selectedSingle=host.singleImage, firstGuide=false, cutout=requiresCutout(asset)) {
  const prompt=assetPrompt(asset,settings,cutout);
  const supportsTransparency = selectedSingle?.supportsTransparentBackground ?? host.imageSupportsTransparentBackground;
  const extra = cutout && supportsTransparency === true ? {transparent_background:true} : {};
  if (!prompt) throw new Error("Missing a visual scene for this artwork slot.");
  const primary=selectedSingle?.referenceKey ?? host.imageReferenceKey;
  const supported=selectedSingle?.referenceKeys ?? host.imageReferenceKeys ?? [];
  const keys=[...new Set([primary, ...(Array.isArray(supported) ? supported : [])].filter(Boolean))];
  const hasReference=keys.some(k=>["referenced_image_ids","referenced_image_paths","num_last_images_to_include"].includes(k));
  const conversation=selectedSingle?.isolated===false || settings.image_input_scope==="conversation";
  const guide=rejected || (firstGuide && conversation && hasReference);
  const kind=asset.action==="redraw" ? "original" : (guide ? "guide" : "none");
  if (kind==="none" || (kind==="guide" && selectedSingle?.isolated === true))
    return {provider_input:{...extra,prompt},reference_kind:"none"};
  const action={asset,request_id:key,reference_kind:kind,prompt};
  const rendered=kind==="guide" ? await makeGuide(action,host) : null;
  const source=kind==="original" ? asset.reference : (rendered?.file ?? rendered);
  const inputSha=kind==="original" ? asset.sha256 : rendered?.sha256;
  if (!text(source)) throw new Error("Unable to obtain the single reference image.");
  const outPrompt=kind==="guide" ? "依這張無字構圖草稿的主體位置重新製作完整素材。"+prompt : prompt;
  if (!keys.length && !selectedSingle)
    return {provider_input:{...extra,prompt:outPrompt},reference_kind:kind,reference:source,reference_sha256:inputSha};
  const failures=[];
  for (const key of keys) {
    try {
      let value;
      if (key==="num_last_images_to_include") {
        if (!hash(inputSha) || typeof host.showSingleImage!=="function") throw Error("No receipt-capable single-image display.");
        const visible=await host.showSingleImage(source);
        if (visible?.sha256!==inputSha || visible?.sole_image!==true || visible?.latest!==true)
          throw Error("Latest display is not this sole reference.");
        value=1;
      } else if (["referenced_image_paths","referenced_image_ids"].includes(key)) {
        const ref=typeof host.resolveImageReference==="function" ? await host.resolveImageReference(source,key,kind) :
          (key==="referenced_image_paths" && source.startsWith("/") ? source : null);
        if (!text(ref)) throw Error("No verified reference for this argument.");
        value=[ref];
      } else {throw Error("Unsupported reference argument.");}
      return {provider_input:{...extra,prompt:outPrompt,[key]:value},reference_kind:kind,reference:typeof value==="number" ? source : value[0],
        reference_sha256:inputSha};
    } catch (error) { failures.push(key+": "+String(error?.message ?? error)); }
  }
  throw Error(failures.join(" / ") || "The active native image tool has no verified reference capability.");
}


// A traceable full-output card may conclusively rule out an image before its original can be fetched.
// No kind of preview can qualify an image for inclusion.
export function rejectedCard(reply, request) {
  const v=reply?.preview_review, generation=reply?.generation_ref;
  if (!request || !v || !text(generation) || reply.request_key!==request.key || reply.asset_key!==request.asset_key ||
      v.generation_ref!==generation || !text(v.preview_ref) || v.whole_output!==true || !text(v.observation) ||
      !["wrong_subject","wrong_medium","wrong_composition","unusable"].includes(v.content)) return null;
  return {request_key:request.key,generation_ref:generation,preview_ref:v.preview_ref,reason:v.content+"："+v.observation};
}
