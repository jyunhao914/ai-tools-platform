"""Resolve a photo frame, focal crop and protected regions for editable slides.

Rects are [x, y, width, height]. Frame and safe zones share slide units.
Source focus, subject and destination anchor are fractions of their own rectangle.
"""
import argparse
import json
from math import isfinite
from pathlib import Path


class NoPhotoFit(ValueError):
    """The input is valid but its requested composition cannot preserve the content."""


def numbers(value, count, name):
    if (not isinstance(value, (list,tuple)) or len(value) != count
            or any(type(n) not in (int,float) or not isfinite(n) for n in value)):
        raise ValueError(f"{name} needs {count} finite numbers.")
    return tuple(value)


def rect(value, name):
    x,y,w,h = numbers(value,4,name)
    if min(w,h) <= 0:
        raise ValueError(f"{name} needs positive width and height.")
    return x,y,w,h


def edges(box):
    x,y,w,h = box
    return (x,y,x+w,y+h)


def intersect(a,b):
    x,y=max(a[0],b[0]),max(a[1],b[1])
    return x,y,min(a[2],b[2]),min(a[3],b[3])


def overlaps(a,b):
    # Positive area only, so art may meet the edge of a reserved column.
    x,y,r,bottom=intersect(a,b)
    return r>x+1e-9 and bottom>y+1e-9


def layout_photo(image_size, frame, canvas, options, *, fit="cover", extra_zones=()):
    iw,ih=numbers(image_size,2,"image_size")
    cw,ch=numbers(canvas,2,"canvas")
    if min(iw,ih,cw,ch)<=0 or fit not in ("cover","contain"):
        raise ValueError("Supply a positive canvas and image size and a contain or cover fit.")
    if not isinstance(options,dict) or options.keys()-{"focus","anchor","subject","safe_zones"}:
        raise ValueError("Unknown photo_layout setting.")
    x,y,w,h=rect(frame,"frame")
    subject=rect(options["subject"],"subject") if "subject" in options else None
    if subject and (min(subject[:2])<0 or max(edges(subject)[2:])>1+1e-9):
        raise ValueError("The subject must be inside the original image.")
    fx,fy=numbers(options.get("focus", [subject[0]+subject[2]/2,subject[1]+subject[3]/2] if subject else [.5,.5]),2,"focus")
    ax,ay=numbers(options.get("anchor",[.5,.5]),2,"anchor")
    if min(fx,fy,ax,ay)<0 or max(fx,fy,ax,ay)>1:
        raise ValueError("Use fractions from zero to one for focus and anchor.")
    if fit=="contain":
        scale=min(w/iw,h/ih)
        nx,ny=iw*scale,ih*scale
        x,y,w,h=x+(w-nx)*ax,y+(h-ny)*ay,nx,ny
    visible=intersect((x,y,x+w,y+h),(0,0,cw,ch))
    if not overlaps(visible,visible):
        raise NoPhotoFit("The proposed frame lies outside the slide.")
    sw,sh=(min(1,w*ih/(h*iw)),min(1,h*iw/(w*ih))) if fit=="cover" else (1.,1.)
    vl,vt,vr,vb=visible
    fl,ft,fr,fb=(vl-x)/w,(vt-y)/h,(vr-x)/w,(vb-y)/h
    sx,sy,sr,sb=edges(subject) if subject else (fx,fy,fx,fy)
    # Both the visual focus and any supplied subject bounds must survive bleed.
    left=max(0,max(sr,fx)-fr*sw); right=min(1-sw,min(sx,fx)-fl*sw)
    top=max(0,max(sb,fy)-fb*sh); bottom=min(1-sh,min(sy,fy)-ft*sh)
    if left>right+1e-9 or top>bottom+1e-9:
        raise NoPhotoFit("The frame crops the designated subject. Try a wider frame or contain.")

    zones=options.get("safe_zones",[])
    if not isinstance(zones,list):
        raise ValueError("safe_zones must be an array of slide regions.")
    blocked=[]
    for zone in [*zones,*extra_zones]:
        if not isinstance(zone,dict) or zone.keys()-{"box","avoid","name"}:
            raise ValueError("A safe zone needs a box and optional name and avoid mode.")
        box=edges(rect(zone["box"],"safe zone"))
        mode=zone.get("avoid","image")
        if mode=="image":
            if overlaps(visible,box):
                raise NoPhotoFit(f"Frame overlaps protected area: {zone.get('name','safe zone')}.")
        elif mode=="subject" and subject:
            blocked.append(box)
        else:
            raise ValueError("A subject-only safe zone requires a bounded source subject.")

    def clamp(v,lo,hi):
        return max(lo,min(hi,v))
    want_x,want_y=fx-ax*sw,fy-ay*sh
    xs=[clamp(want_x,left,right),left,right]; ys=[clamp(want_y,top,bottom),top,bottom]
    # Along a single cover axis the closest feasible crop is at the preferred
    # anchor, a crop boundary, or where the object's edge meets a safe zone.
    for l,t,r,b in blocked:
        xs.extend([clamp(sr-(l-x)*sw/w,left,right),clamp(sx-(r-x)*sw/w,left,right)])
        ys.extend([clamp(sb-(t-y)*sh/h,top,bottom),clamp(sy-(b-y)*sh/h,top,bottom)])
    best=None
    for ox in xs:
        for oy in ys:
            mapped=(x+(sx-ox)*w/sw,y+(sy-oy)*h/sh,x+(sr-ox)*w/sw,y+(sb-oy)*h/sh)
            if any(overlaps(mapped,area) for area in blocked):
                continue
            cost=((ox-want_x)*w/sw)**2+((oy-want_y)*h/sh)**2
            if best is None or cost<best[0]:
                best=(cost,ox,oy,mapped)
    if best is None:
        raise NoPhotoFit("The subject overlaps reserved content in every allowed crop. Choose another frame.")
    _,ox,oy,mapped=best
    crop=[ox+fl*sw,oy+ft*sh,1-ox-fr*sw,1-oy-fb*sh]
    crop=[clamp(v,0.,1.) for v in crop]
    return {"box":[vl,vt,vr-vl,vb-vt],"crop":dict(zip(("left","top","right","bottom"),crop)),
            "focus_on_slide":[x+(fx-ox)*w/sw,y+(fy-oy)*h/sh],
            "subject_on_slide":([mapped[0],mapped[1],mapped[2]-mapped[0],mapped[3]-mapped[1]] if subject else None)}


def free_regions(canvas, zones):
    """Return maximal empty axis-aligned rectangles. Overlap between candidates is intentional."""
    regions = [(0, 0, *canvas)]
    for zone in zones:
        obstacle = edges(rect(zone["box"], "safe zone"))
        next_regions = set()
        for region in regions:
            if not overlaps(region, obstacle):
                next_regions.add(region)
                continue
            l, t, r, b = region
            ol, ot, oright, ob = intersect(region, obstacle)
            for piece in [(l,t,ol,b), (oright,t,r,b), (l,t,r,ot), (l,ob,r,b)]:
                if overlaps(piece, piece):
                    next_regions.add(piece)
        regions = [region for region in sorted(next_regions) if not any(
            other != region and other[0] <= region[0] and other[1] <= region[1]
            and other[2] >= region[2] and other[3] >= region[3] for other in next_regions)]
    return regions


def recover_photo(image_size, frame, canvas, options, *, extra_zones=(), occupied=()):
    """Fit the entire independent image, respecting original content if moved elsewhere."""
    for zone in [*options.get("safe_zones", []), *extra_zones]:
        if not isinstance(zone, dict) or "box" not in zone:
            raise ValueError("A safe zone requires a box.")
    zones = [*extra_zones, *occupied]
    x,y,w,h = rect(frame,"frame")
    visible = intersect(edges(frame), (0, 0, *canvas))
    if overlaps(visible, visible):
        l, t, r, b = visible
        try:
            return dict(layout_photo(image_size, (l,t,r-l,b-t), canvas, options, fit="contain", extra_zones=zones),
                        recovery="contain_in_planned_frame")
        except NoPhotoFit:
            pass
    iw,ih = image_size
    # Preserve intended visual scale and choose the closest of equally large placements.
    target_scale = min(w/iw,h/ih)
    candidates = []
    for l,t,r,b in free_regions(canvas,[*zones,*options.get("safe_zones",[])]):
        scale = min(target_scale,(r-l)/iw,(b-t)/ih)
        nw, nh = iw*scale, ih*scale
        left = max(l, min(r-nw, x+(w-nw)/2))
        top = max(t, min(b-nh, y+(h-nh)/2))
        distance = (left+nw/2-x-w/2)**2 + (top+nh/2-y-h/2)**2
        candidates.append((-scale, distance, [left,top,nw,nh]))
    for _, _, candidate in sorted(candidates):
        try:
            return dict(layout_photo(image_size, candidate, canvas, options, fit="contain", extra_zones=zones),
                        recovery="contain_in_clear_area")
        except NoPhotoFit:
            continue
    raise NoPhotoFit("No unobstructed area can contain this picture; retain the original content.")


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec",type=Path)
    args=parser.parse_args()
    try:
        print(json.dumps(layout_photo(**json.loads(args.spec.read_bytes())),ensure_ascii=False))
    except (ValueError,KeyError) as error:
        parser.exit(1,f"{error}\n")
