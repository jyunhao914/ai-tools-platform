"""Inspect retained evidence separately from independent small-art redraws in their actual slide frames."""
import argparse
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import runpy
import sys

import numpy as np
from PIL import Image
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE as Shape
from pptx.oxml.ns import qn

import semantic_icons as media

HERE = Path(__file__).resolve().parent
REDRAW = {"redraw", "replace", "photorealistic_redraw", "hyperrealistic_redraw", "超擬真重繪", "重新配圖"}
PROTECTED = {"keep", "preserve", "protected", "evidence", "data_chart", "chart", "table", "diagram",
             "screenshot", "dashboard", "document_scan", "documentary_evidence", "logo", "原圖沿用", "沿用原圖"}
SMALL_ART = {"icon", "decorative_icon", "small_illustration", "cutout", "subject_cutout", "decoration", "illustrative_object"}
SCENES = {"documentary_photo", "scene", "full_scene", "continuous_photo", "hero_photo", "editorial_photo", "background_photo"}
VECTOR = media.ICON_KINDS | {"vector"}

def source_facts(shape, deck, blob):
    """Only propose a visual role from source pixels AND composition. Geometry alone cannot turn data into an icon."""
    box = [round(v / span, 6) for v, span in zip((shape.left, shape.top, shape.width, shape.height),
           (deck.slide_width, deck.slide_height, deck.slide_width, deck.slide_height))]
    x, y, w, h = box
    facts = {"box":box, "recognizable_small_art":False}
    if not (0 < w <= .32 and 0 < h <= .34 and w*h <= .07):
        return facts
    try:
        with Image.open(BytesIO(blob)) as im:
            if not .52 <= im.width / im.height <= 1.95:
                return facts
            rgba = np.asarray(im.convert("RGBA").resize((96,96),Image.Resampling.BILINEAR)).astype(int)
    except (ValueError,OSError,Image.DecompressionBombError):
        return facts
    a, rgb = rgba[:,:,3], rgba[:,:,:3]
    edges = lambda arr: np.concatenate((arr[0],arr[-1],arr[:,0],arr[:,-1]))
    transparent = ((a<16).mean() >= .12 and (edges(a)<16).mean() >= .50)
    corners = np.concatenate([rgb[:5,:5].reshape(-1,3), rgb[-5:,:5].reshape(-1,3),
                              rgb[:5,-5:].reshape(-1,3), rgb[-5:,-5:].reshape(-1,3)])
    bg=np.median(corners,axis=0)
    flat=(abs(rgb-bg).max(axis=2) < 20)
    quiet_border=(bg.min()>=212 and np.ptp(bg)<=24 and edges(flat).mean()>=.82 and .22<=flat.mean()<=.94)
    near_margin=(y+h/2<.27 or y+h/2>.81 or x+w/2<.17 or x+w/2>.83)
    facts["surround"]="transparent" if transparent else "neutral_border" if quiet_border else "continuous"
    facts["recognizable_small_art"]=bool(transparent or (quiet_border and near_margin))
    return facts

def kinds(row):
    return {str(row.get(k,"")).strip().lower() for k in ("source_use","role","kind","source_role","action")}

def protected(row):
    return row.get("protected") is True or bool(kinds(row)&PROTECTED)

def requires_redraw_cutout(source, decision):
    if protected(decision) or kinds(decision)&SCENES:
        return False
    return (decision.get("transparent_cutout") is True or bool(kinds(decision)&(SMALL_ART|VECTOR))
            or source.get("recognizable_small_art") is True)

def bind_redraw(plan, item, source):
    if not media.refined_page(plan,item["page_number"]):
        return
    requires = requires_redraw_cutout(source.get("source_visual",{}),item)
    if requires:
        item.update(role="subject_cutout",transparent_cutout=True)
    if "source_visual" in source:
        item["source_visual"]=source["source_visual"]

def located(slide, deck):
    # Only top-level frames have coordinates in page space. Nested frames are located by name or original SHA.
    def visit(shapes,top):
        for shape in shapes:
            if shape.shape_type==Shape.GROUP:
                if top: yield shape,None,None
                yield from visit(shape.shapes,False)
                continue
            blips=shape._element.xpath("./p:blipFill/a:blip|./p:spPr/a:blipFill/a:blip")
            if not blips and top and shape.shape_type in {Shape.AUTO_SHAPE,Shape.FREEFORM,Shape.LINE,Shape.CALLOUT} and not (shape.has_text_frame and shape.text.strip()):
                yield shape,None,None
            for b in blips:
                rid=b.get(qn("r:embed"))
                if rid:
                    blob=slide.part.related_part(rid).blob
                    yield shape,blob,source_facts(shape,deck,blob) if top else {}
    return list(visit(slide.shapes,True))

def match_identity(row, n, shape_id, name, digest):
    if row.get("page",row.get("page_number",row.get("source_page")))!=n: return False
    if row.get("source_sha256") and row["source_sha256"]!=digest:return False
    if row.get("source_shape_id",row.get("shape_id")) is not None:
        return row.get("source_shape_id",row.get("shape_id"))==shape_id
    return (row.get("source_name") or row.get("name"))==name or row.get("source_sha256")==digest

def explicit(plan):
    result = []
    for obj in (plan,plan.get("settings",{})):
        for key in ("assets","image_assets","image_plan"):
            if key in obj:
                rows=obj[key];rows=rows.get("assets",[]) if isinstance(rows,dict) else rows
                if isinstance(rows,list):result.extend(rows)
    for i,page in enumerate(plan.get("pages") or [],1):
        if isinstance(page,dict):
            for k in ("assets","images"):
                result.extend(dict(row,page_number=page.get("page_number",i)) for row in page.get(k,[]))
    edits=plan.get("image_adjustments") or plan.get("settings",{}).get("image_adjustments") or {}
    if isinstance(edits,dict):
        by={(e.get("page"),e.get("name")):e for e in edits.get("edits",[])}
        result.extend({**r,**by.get((r.get("page"),r.get("name")),{})} for r in edits.get("catalogue",[]))
    requirements=plan.get("requirements") or {}
    if isinstance(requirements,dict):
        result.extend({**v,"protected":True} for v in requirements.get("protected_objects") or [] if isinstance(v,dict))
    return result

def preserves(plan, source):
    return any(protected(row) and match_identity(row,source["page_number"],source["shape_id"],source["name"],source["sha256"])
               for row in explicit(plan))

def near(source, candidate):
    if not source or not candidate:return False
    a,b,w,h=source;x,y,c,d=candidate
    if w<=0 or h<=0 or c<=0 or d<=0 or c*d>.12 or max(c,d)>.50:return False
    return abs((a+w/2)-(x+c/2))<=.16 and abs((b+h/2)-(y+d/2))<=.18

def check(source_path, output_path, plan, rows=()):
    src,final=Presentation(source_path),Presentation(output_path)
    if len(src.slides)!=len(final.slides):return {"status":"repair","issues":[{"reason":"page_count"}],"checked":0}
    delivery=runpy.run_path(str(HERE/"check-refined-cutout-delivery.py"))
    specs=explicit(plan); decisions=list(rows); findings=[]; checks=[]
    for n,(source_slide,output_slide) in enumerate(zip(src.slides,final.slides),1):
        options=media.page_options(plan,n)
        if not media.refined_page(plan,n) or any(options.get(k) for k in ("protected","approved_original_page","preserve_layout")):continue
        policy=media.page_options(plan,n).get("original_images",plan.get("settings",{}).get("original_images"))
        sources=located(source_slide,src);outputs=located(output_slide,final)
        original_hashes={sha256(blob).hexdigest() for _,blob,_ in sources if blob is not None}
        for sh,blob,facts in sources:
            if blob is None:continue
            digest=sha256(blob).hexdigest()
            hints=[v for v in specs+decisions if match_identity(v,n,sh.shape_id,sh.name,digest)]
            if any(protected(v) for v in hints):continue
            declared=next((r for r in reversed(hints) if r.get("action") in REDRAW or r.get("replaces_source")),None)
            if not declared and (policy not in REDRAW or any(k in plan for k in ("assets","image_assets","image_plan"))):
                continue
            row=declared or {}
            if not requires_redraw_cutout(facts,row):continue
            if not declared and any(b is not None and sha256(b).hexdigest()==digest for _,b,_ in outputs):
                continue  # actually retained, no generated decoration was authorized for this source
            names={name for name in (row.get("name"),row.get("final_name"),sh.name) if name}
            vectors_allowed=any(r.get("kind") in VECTOR or r.get("native_icon") is True for r in hints)
            candidates=[(s,b,f) for s,b,f in outputs if b is not None or vectors_allowed]
            # Prefer the approved output layer to a renamed original or a recycled numeric ID.
            final_names={v for v in (row.get("name"),row.get("final_name")) if v}
            bound=[entry for entry in candidates if entry[0].name in final_names]
            if not bound:
                bound=[entry for entry in candidates if entry[0].name in names]
            if not bound:
                bound=[entry for entry in candidates if entry[0].shape_id==sh.shape_id]
            if not bound:
                bound=[(s,b,f) for s,b,f in outputs if b is not None and sha256(b).hexdigest() not in original_hashes
                       and near(facts.get("box"),f.get("box"))]
            evidence={"page":n,"source_shape_id":sh.shape_id,"source_name":sh.name}
            if len(bound)!=1:
                findings.append({**evidence,"reason":"identify_final_decoration","candidates":len(bound)});continue
            item,pixels,_=bound[0]
            try:
                box=delivery["ppt_bounds"](item)
                if delivery["area"](box)<=0:
                    raise ValueError("Small artwork has no visible extent")
                siblings=item._parent
                if any(other.shape_id!=item.shape_id and delivery["solid_white_powerpoint"](other)
                       and delivery["nearly_same"](delivery["ppt_bounds"](other),box) for other in siblings):
                    raise ValueError("Separate opaque white backplate at the delivered decoration")
                if pixels is None:
                    if not any(r.get("kind") in VECTOR or r.get("native_icon") is True for r in hints):
                        raise ValueError("Unapproved vector replacement")
                    delivery["native_ppt"](item)
                else:
                    fill=item._element.xpath("./p:blipFill|./p:spPr/a:blipFill")[0]
                    crop=fill.find(qn("a:srcRect"))
                    fractions=tuple(int(crop.get(k,0))/100000 if crop is not None else 0 for k in ("l","t","r","b"))
                    delivery["approved_pixels"](pixels,fractions)
                checks.append({**evidence,"output_name":item.name,"kind":"native_vector" if pixels is None else "alpha_png"})
            except (ValueError,RuntimeError) as e:
                findings.append({**evidence,"output_name":item.name,"reason":str(e)})
    return {"status":"repair" if findings else "pass","issues":findings,"checked":len(checks)+len(findings),"targets":checks}

def cli():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command",choices=["check"]);ap.add_argument("source",type=Path);ap.add_argument("output",type=Path)
    ap.add_argument("--plan",type=Path,required=True);ap.add_argument("--run-dir",type=Path)
    args=ap.parse_args()
    doc=json.loads(sys.stdin.read() if str(args.plan)=="-" else args.plan.read_text());plan=doc.get("plan",doc)
    rows=[]
    if args.run_dir:
        for name in ("source-decisions.json","assets.json","redraws.json"):
            path=args.run_dir/name
            if path.exists():
                contents=json.loads(path.read_text());rows.extend(contents if isinstance(contents,list) else [*contents["assets"],*contents.get("native_source_replacements",[])])
    result=check(args.source,args.output,plan,rows)
    print(json.dumps(result,ensure_ascii=False))
    return 2 if result["issues"] else 0
if __name__=="__main__":raise SystemExit(cli())
