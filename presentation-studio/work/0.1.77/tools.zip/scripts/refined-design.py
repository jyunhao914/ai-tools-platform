"""Inspect actual editable photo/text relationships and delivered cutouts, including hand-built Work decks."""
import argparse
from collections import Counter, defaultdict
from copy import deepcopy
from hashlib import sha256
from io import BytesIO
import json
import os
import re
import sys
from pathlib import Path
import runpy
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from lxml import etree
from PIL import Image, ImageDraw
import numpy as np
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE as ST
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.oxml.ns import qn

import editorial_art
import semantic_icons as scope

HERE = Path(__file__).resolve().parent
DECOR = runpy.run_path(str(HERE / "source-decoration.py"))
CUTOUT = runpy.run_path(str(HERE / "check-cutout.py"))
REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def editable_copy(slide):
    """Compare literal source text across boxes; reflow may change paragraph boundaries and order."""
    return Counter("".join("".join(node.itertext()).strip() for node in slide._element.xpath(".//a:t")).translate(
        str.maketrans("", "", " \r\n\t\u3000")))


def flexible(plan, n):
    options = scope.page_options(plan, n)
    settings = plan.get("settings", {})
    pages = plan.get("layout_change_pages")
    manual = settings.get("individual_adjustments") or {}
    return (scope.refined_page(plan, n) and (pages is None or n in pages)
            and not (isinstance(manual, dict) and (str(n) in manual or n in manual))
            and not any(options.get(k) for k in ("layout_locked", "approved_original_page", "preserve_layout", "protected"))
            and not any(layer.get("bounds") or layer.get("geometry") or layer.get("layout_locked")
                        for layer in [*(options.get("layers") or []), *(options.get("objects") or [])]
                        if isinstance(layer, dict))
            and settings.get("layout_style") in (None, "auto", "automatic", "依內容設計", "自動", "自動風格")
            and settings.get("photo_layout_variety") is not False)


def box(sh, deck):
    return tuple(round(v / dim, 5) for v, dim in zip((sh.left, sh.top, sh.width, sh.height),
                 (deck.slide_width, deck.slide_height) * 2))


def arrangement(frame, texts):
    x,y,w,h=frame
    if w >= .86 and h >= .8:
        return "full_bleed"
    # Read the actual text relationship. Differently sized rectangles beside the same text
    # column are the same composition. A floating caption alone does not change it.
    runs = [(s,len("".join(t.text.split()))) for t,s in texts]
    if not runs:
        return "standalone"
    total = sum(weight for _,weight in runs)
    def mainly(test):
        return sum(weight for b,weight in runs if test(*b)) >= total*.78
    if .18<y<.47 and any(b[2]>=.72 and b[1]+b[3]<=y+.025 for b,_ in runs):
        return "headline_over_photo_and_copy"
    if w < .82 and mainly(lambda a,b,c,d: a+c <= x+.055):
        return "text_left_photo_right"
    if w < .82 and mainly(lambda a,b,c,d: a >= x+w-.055):
        return "photo_left_text_right"
    if mainly(lambda a,b,c,d: b+d <= y+.04):
        return "photo_below_text"
    if mainly(lambda a,b,c,d: b >= y+h-.04):
        return "photo_above_text"
    return "integrated"


def eligible_original(original, n, slots):
    pictures=[s for s in original.shapes if s.shape_type==ST.PICTURE]
    if len(pictures)>1 or any(s.shape_type!=ST.PICTURE and
        (s.shape_type not in (ST.PLACEHOLDER,ST.AUTO_SHAPE,ST.TEXT_BOX) or not (s.has_text_frame and s.text.strip()))
        for s in original.shapes):
        return False
    if not pictures:
        return True
    source=pictures[0]
    digest=sha256(source.image.blob).hexdigest()
    hints=[s for s in slots if DECOR["match_identity"](s,n,source.shape_id,source.name,digest)]
    return (not any(DECOR["protected"](s) for s in hints)
            and any(s.get("action") in DECOR["REDRAW"] and DECOR["kinds"](s)&
                    (DECOR["SCENES"]|editorial_art.PHOTO) for s in hints))


def observed_rows(source, final, plan, decisions):
    slots = [*editorial_art.assets_in(plan), *decisions]
    results = []
    for n, (original, slide) in enumerate(zip(source.slides,final.slides), 1):
        if not flexible(plan,n):
            continue
        # Sources containing evidentiary content, inherited drawings or object-level locks are
        # ineligible for this automatic reflow. Their selected native layout is author-reviewed.
        if not eligible_original(original,n,slots):
            continue
        if original._element.xpath("./p:timing") or slide._element.xpath("./p:timing"):
            continue
        if any(s.has_chart or s.has_table for s in slide.shapes):
            continue
        pictures=[s for s in slide.shapes if s.shape_type==ST.PICTURE]
        photos=[s for s in pictures if s.width*s.height >= .13*final.slide_width*final.slide_height]
        if len(photos)!=1:
            continue
        shape=photos[0]
        # Identify an objectionable layout even when a human added decorative icons.
        # Recompose only simple pages in which the new picture and native text account for
        # the entire meaningful content. Preserve unexpected illustrations and hyperlinks.
        safe=(len(pictures)==1 and not slide._element.xpath(".//a:hlinkClick|.//a:hlinkHover") and
              all(s.shape_type in (ST.PLACEHOLDER,ST.AUTO_SHAPE,ST.TEXT_BOX,ST.PICTURE) and
                  not s._element.xpath("./p:spPr/a:blipFill") for s in slide.shapes))
        spec=next((s for s in slots if s.get("page_number",s.get("page"))==n and s.get("name")==shape.name),{})
        if DECOR["protected"](spec) or spec.get("fixed_frame") or spec.get("layout_locked") or spec.get("transparent_cutout"):
            continue
        source_photos=[s for s in original.shapes if s.shape_type==ST.PICTURE]
        if not source_photos and not scope.authorized(plan,n,empty=True,slot=shape.name,explicit=spec.get("action")=="add"):
            continue
        if source_photos and sha256(shape.image.blob).digest()==sha256(source_photos[0].image.blob).digest():
            continue
        frame=box(shape, final)
        if frame[2]*frame[3]<.13:
            continue
        with Image.open(BytesIO(shape.image.blob)) as im:
            if "A" in im.getbands() or "transparency" in im.info:
                if (np.asarray(im.convert("RGBA").resize((80,80)))[:,:,3]<64).mean()>.03:
                    continue
        text=[(s,box(s,final)) for s in slide.shapes if s.has_text_frame and s.text.strip()]
        results.append({"page":n,"name":shape.name,"box":frame,"arrangement":arrangement(frame,text),"safe_to_reflow":safe})
    return results


def layout_review(source,final,plan,rows):
    frames=observed_rows(source,final,plan,rows)
    by_side=defaultdict(list)
    for r in frames:
        if r["arrangement"] in ("text_left_photo_right","photo_left_text_right"):
            by_side[r["arrangement"]].append(r["page"])
    lateral=sorted(page for pages in by_side.values() for page in pages)
    # Mirroring three otherwise identical text/photo pairs is still a repeated composition.
    repeats=[lateral] if len(lateral)>=3 and len(lateral)*3>=len(frames)*2 else []
    return {"status":"repair" if repeats else "pass","frames":frames,"repeated_pages":repeats}


def preserve_text(slide_a,slide_b):
    def text(slide):
        return "".join("".join((t.text or "").split()) for t in slide._element.xpath(".//a:t"))
    before,after=text(slide_a),text(slide_b)
    return Counter(before)==Counter(after) and all("".join((t.text or "").split()) in after
           for t in slide_a._element.xpath(".//a:t"))


def relocate_content(target,composed):
    """Transfer only generated editable artwork/text, resolving original relationships at the target."""
    item=deepcopy(composed._element.cSld)
    for node in item.iter():
        for attr,rid in list(node.attrib.items()):
            if not attr.startswith(REL):
                continue
            relation=composed.part.rels[rid]
            if relation.reltype==RT.IMAGE:
                _,new_id=target.part.get_or_add_image_part(BytesIO(relation.target_part.blob))
            elif relation.is_external:
                new_id=target.part.relate_to(relation.target_ref,relation.reltype,is_external=True)
            else:
                raise ValueError("Page has a linked source object that requires a custom composition")
            node.set(attr,new_id)
    target._element.replace(target._element.cSld,item)


def separate_background(blob):
    """Exterior flood through a uniform, pale background only. Retain enclosed light pixels."""
    with Image.open(BytesIO(blob)) as im:
        im=im.convert("RGBA")
    if im.width*im.height>9_000_000:
        return None
    rgba=np.array(im)
    rgb=rgba[:,:,:3].astype(np.int16)
    border=np.concatenate([rgb[0],rgb[-1],rgb[:,0],rgb[:,-1]])
    color=np.median(border,axis=0)
    distance=np.abs(rgb-color).max(axis=2)
    rim=np.abs(border-color).max(axis=1)
    # A cast shadow, clipped foreground or uncertain edge requires a fresh native asset.
    if min(color)<193 or np.ptp(color)>42 or np.percentile(rim,99)>12:
        return None
    tolerance=max(5,min(16,int(np.percentile(rim,99))+5))
    mask=np.pad(distance<=tolerance,1,constant_values=True)
    connected=Image.fromarray(mask.astype(np.uint8)*255).copy()
    ImageDraw.floodfill(connected,(0,0),128)
    exterior=np.asarray(connected)[1:-1,1:-1]==128
    if not .12 <= exterior.mean() <= .94:
        return None
    rgba[exterior,3]=0
    output=BytesIO()
    Image.fromarray(rgba).save(output,"PNG")
    data=output.getvalue()
    return data if CUTOUT["inspect_bytes"](data)["status"]=="ready" else None


def decoration_review(source_path,candidate_path,plan,rows):
    result=DECOR["check"](source_path,candidate_path,plan,rows)
    # Added icons have no source counterpart, so verify these independently of original redraws.
    specs=[*editorial_art.assets_in(plan),*rows]
    added={(s.get("page_number",s.get("page")),s.get("name")):s for s in specs if s.get("action")=="add" and
        not s.get("source_shape_id") and not s.get("replaces_source") and
        (CUTOUT["requires_cutout"](s) or s.get("kind") in DECOR["VECTOR"]) and not DECOR["protected"](s)}
    original=Presentation(source_path)
    final=Presentation(candidate_path)
    for n,(src,slide) in enumerate(zip(original.slides,final.slides),1):
        originals=DECOR["located"](src,original) if scope.refined_page(plan,n) else []
        if not scope.refined_page(plan,n) or not scope.authorized(plan,n,empty=not any(p[1] for p in originals)):
            continue
        names={s.name for s in src.shapes}
        digests={sha256(p[1]).digest() for p in originals if p[1]}
        for sh in slide.shapes:
            if sh.name in names or (n,sh.name) in added:
                continue
            if sh.shape_type==ST.GROUP and sh.name.startswith(f"PS art {n} "):
                # Discover studio-authored native groups even from an older portable plan.
                if any(page==n and sh.name.startswith(f"PS art {n} {slot} ") for page,slot in added):continue
                added[n,sh.name]={"kind":"vector"}
            elif sh.shape_type==ST.PICTURE and sha256(sh.image.blob).digest() not in digests:
                known={"name":sh.name,"action":"add","kind":"picture"}
                if CUTOUT["requires_cutout"](known) or re.fullmatch(r"cutout-\d+(?:-\d+)?",sh.name):
                    added[n,sh.name]={"kind":"cutout"}
                elif re.fullmatch(r"subject-\d+",sh.name):
                    with Image.open(BytesIO(sh.image.blob)) as im:
                        if "A" in im.getbands() or "transparency" in im.info:added[n,sh.name]={"kind":"cutout"}
    if added:
        checks=runpy.run_path(str(HERE/"check-refined-cutout-delivery.py"))
        for (n,name),spec in added.items():
            if not n or not name or not scope.refined_page(plan,n) or scope.forbids_new(plan,n,slot=name,explicit=True):
                continue
            visible=list(final.slides[n-1].shapes)
            names={x for x in (name,spec.get("final_name"),spec.get("object_name")) if x}
            matches=[s for s in visible if s.name in names or
                     (s.shape_type==ST.GROUP and s.name.startswith(f"PS art {n} {name} "))]
            if not matches and spec.get("sha256"):
                matches=[s for s in visible if s.shape_type==ST.PICTURE and
                         sha256(s.image.blob).hexdigest()==spec["sha256"]]
            finding={"page":n,"output_name":name}
            result["checked"]+=1
            try:
                if len(matches)!=1:
                    raise ValueError("Identify the final, approved small-art layer by its name")
                s=matches[0]; bounds=checks["ppt_bounds"](s)
                if any(t.shape_id!=s.shape_id and checks["solid_white_powerpoint"](t) and
                       checks["nearly_same"](checks["ppt_bounds"](t),bounds) for t in visible):
                    raise ValueError("A separate opaque backplate remains behind this small artwork")
                if spec.get("kind") in DECOR["VECTOR"]:
                    checks["native_ppt"](s)
                elif s.shape_type==ST.PICTURE:
                    checks["approved_pixels"](s.image.blob,tuple(getattr(s,"crop_"+k) for k in ("left","top","right","bottom")))
                else:
                    raise ValueError("Missing transparent image")
                result["targets"].append(finding)
            except (ValueError,RuntimeError) as exc:
                result["issues"].append({**finding,"reason":str(exc)})
    result["status"]="repair" if result["issues"] else "pass"
    for issue in result["issues"]:
        issue["next_action"]="Recheck the approved source identity and final shape."
        if issue["reason"]=="Slide crop cuts into the delivered cutout silhouette":
            issue["next_action"]="Restore the entire approved PNG inside its current frame and verify the final crop."
        elif "cutout" in issue["reason"].lower():
            issue["next_action"]="Generate this single subject again using native transparent background, with the complete object inside generous clear margins. Continue other pages, then replace this slot."
    return result


def recompose(source_path,deck,plan,rows,review,tmp):
    target_pages={n for pages in review["repeated_pages"] for n in pages}
    if not target_pages:
        return []
    source=Presentation(source_path)
    assets=[]
    for row in review["frames"]:
        n=row["page"]
        if n not in target_pages or not row["safe_to_reflow"]:
            continue
        shape=next(s for s in deck.slides[n-1].shapes if s.name==row["name"] and s.shape_type==ST.PICTURE)
        file=tmp/f"scene-{n}.img"
        file.write_bytes(shape.image.blob)
        spec=next((s for s in [*editorial_art.assets_in(plan),*rows] if s.get("page_number",s.get("page"))==n and s.get("name")==shape.name),{})
        original_picture=next((s for s in source.slides[n-1].shapes if s.shape_type==ST.PICTURE),None)
        binding={"action":"redraw","source_shape_id":original_picture.shape_id} if original_picture is not None else {"action":"add"}
        assets.append({**spec,**binding,"page_number":n,"name":shape.name,"role":"editorial_photo","file":str(file)})
    staged=tmp/"reflow.pptx"
    effective={**plan,"layout_change_pages":sorted(target_pages),"assets":assets}
    reference=runpy.run_path(str(HERE/"compose-refined.py"))["compose"](source_path,staged,effective,assets)
    composed=Presentation(staged)
    changed=[]
    for row in reference["pages"]:
        n=row["page"]
        if n not in target_pages or not any(s.get("placed") for s in row.get("art_slots",[])):
            continue
        target=deck.slides[n-1]
        new=composed.slides[n-1]
        if editable_copy(target)!=editable_copy(source.slides[n-1]) or not preserve_text(source.slides[n-1],new):
            continue
        # Keep each picture's real alternative text, including its generation credit.
        old_picture=next(s for s in target.shapes if s.shape_type==ST.PICTURE)
        picture=next((s for s in new.shapes if s.name==old_picture.name and s.shape_type==ST.PICTURE),None)
        if picture is None or picture.image.blob!=old_picture.image.blob:
            continue
        picmeta=picture._element.xpath("./p:nvPicPr/p:cNvPr")[0]
        for key in ("descr","title"):
            value=old_picture._element.xpath("./p:nvPicPr/p:cNvPr")[0].get(key)
            if value:picmeta.set(key,value)
        relocate_content(target,new)
        changed.append({"page":n,"composition":row["composition"]})
    return changed


def inspect(source_path,output_path,plan,rows=()):
    src,deck=Presentation(source_path),Presentation(output_path)
    if len(src.slides)!=len(deck.slides):
        raise ValueError("Different slide counts in source and candidate")
    layout=layout_review(src,deck,plan,rows)
    decorations=decoration_review(source_path,output_path,plan,rows)
    issues=[{"reason":"repeated_photo_text_composition","pages":pages} for pages in layout["repeated_pages"]]
    issues.extend(decorations["issues"])
    checked=len(layout["frames"])+decorations["checked"]
    return {"status":"repair" if issues else ("pass" if checked else "not_applicable"),
            "checked":checked,"issues":issues,"layout":layout,"decorations":decorations}


def repair(source_path,candidate_path,plan,out,rows=()):
    if out.exists() or out.resolve() in (source_path.resolve(),candidate_path.resolve()):
        raise ValueError("Use a fresh staging file")
    report=inspect(source_path,candidate_path,plan,rows)
    if report["status"]!="repair":
        return report
    deck=Presentation(candidate_path)
    with TemporaryDirectory(dir=out.parent) as working:
        tmp=Path(working)
        changed=recompose(source_path,deck,plan,rows,report["layout"],tmp)
        cutouts=[]
        restored=[]
        for issue in report["decorations"]["issues"]:
            if "cutout" not in issue["reason"].lower() or "output_name" not in issue:
                continue
            slide=deck.slides[issue["page"]-1]
            shapes=[s for s in slide.shapes if s.shape_type==ST.PICTURE and s.name==issue["output_name"]]
            if len(shapes)!=1:
                continue
            shape=shapes[0]; old=shape.image.blob
            if issue["reason"]=="Slide crop cuts into the delivered cutout silhouette":
                # The approved image itself is intact; restore its aspect and fit it into
                # the same on-slide area. Changing this frame must never shift the evidence.
                iw,ih=shape.image.size
                k=min(shape.width/iw,shape.height/ih)
                w,h=round(iw*k),round(ih*k)
                shape.left+=round((shape.width-w)/2);shape.top+=round((shape.height-h)/2)
                shape.width,shape.height=w,h
                for side in ("top","bottom","left","right"):setattr(shape,"crop_"+side,0)
                restored.append({"page":issue["page"],"name":shape.name})
                continue
            data=separate_background(old)
            if not data:continue
            _,rid=slide.part.get_or_add_image_part(BytesIO(data))
            shape._element.xpath("./p:blipFill/a:blip")[0].set(qn("r:embed"),rid)
            cutouts.append({"page":issue["page"],"name":shape.name,"input_sha256":sha256(old).hexdigest(),
                            "output_sha256":sha256(data).hexdigest()})
        if not changed and not cutouts and not restored:
            return report
        temp=tmp/"updated.pptx"
        deck.save(temp)
        # Reuse all other parts byte-for-byte, including custom chart markup and embedded data.
        edited=set()
        for item in [*changed,*cutouts,*restored]:
            path=str(deck.slides[item["page"]-1].part.partname).lstrip("/")
            edited.update((path,str(Path(path).parent/"_rels"/(Path(path).name+".rels"))))
        # python-pptx may reclaim orphaned relationship or part names on save. Existing
        # media on unaffected pages must have the exact original byte content.
        merged=tmp/"checked.pptx"
        with ZipFile(candidate_path) as original,ZipFile(temp) as updated,ZipFile(merged,"w") as result:
            before=set(original.namelist())
            for info in original.infolist():
                if info.filename=="[Content_Types].xml":
                    ct=etree.fromstring(original.read(info))
                    uct=etree.fromstring(updated.read(info.filename))
                    keys={(e.tag,e.get("Extension"),e.get("PartName")) for e in ct}
                    for e in uct:
                        if (e.tag,e.get("Extension"),e.get("PartName")) not in keys:ct.append(deepcopy(e))
                    data=etree.tostring(ct,xml_declaration=True,encoding="UTF-8",standalone=True)
                else:
                    data=updated.read(info.filename) if info.filename in edited else original.read(info)
                result.writestr(info,data)
            for info in updated.infolist():
                if info.filename not in before:result.writestr(info,updated.read(info))
        verified=inspect(source_path,merged,plan,rows)
        os.link(merged,out)
    return {**verified,"updated_compositions":changed,"removed_backgrounds":cutouts,"restored_cutout_frames":restored,"candidate":str(out)}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("operation",choices=("check","repair"))
    ap.add_argument("source",type=Path);ap.add_argument("candidate",type=Path)
    ap.add_argument("--plan",required=True,type=Path);ap.add_argument("--out",type=Path)
    ap.add_argument("--run-dir",type=Path)
    args=ap.parse_args()
    doc=json.loads(sys.stdin.read() if str(args.plan)=="-" else args.plan.read_text());plan=doc.get("plan",doc)
    rows=[]
    if args.run_dir:
        for name in ("assets.json","redraws.json","source-decisions.json"):
            path=args.run_dir/name
            if path.is_file():
                obj=json.loads(path.read_text());rows.extend(obj if isinstance(obj,list) else obj.get("assets",[]))
    if args.operation=="repair" and not args.out:ap.error("repair requires --out")
    result=repair(args.source,args.candidate,plan,args.out,rows) if args.operation=="repair" else inspect(args.source,args.candidate,plan,rows)
    print(json.dumps(result,ensure_ascii=False))
    return 2 if result["issues"] else 0


if __name__=="__main__":
    raise SystemExit(main())
