#!/usr/bin/env python3
"""One entry point for prepare, project and verify of a working linked chart. No Google credentials used by the script."""
import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
import re
from pathlib import Path
import runpy
import subprocess

import fitz
from openpyxl import load_workbook

loc=Path(__file__).with_name("linked-chart-text.py")
spec=importlib.util.spec_from_file_location("linked_chart_text",loc)
chart_text=importlib.util.module_from_spec(spec)
spec.loader.exec_module(chart_text)
layout = runpy.run_path(str(loc.with_name("linked-chart-clearance.py")))
axis_fallback = runpy.run_path(str(loc.with_name("chart-scale-fallback.py")))


def require(condition,message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def unwrap(doc):
    while isinstance(doc,dict) and isinstance(doc.get("structuredContent"),dict):
        doc=doc["structuredContent"]
    return doc


def get_chart(doc,native,requested_page,book_id=None,chart_id=None,object_id=None):
    all_charts=([doc] if "chartId" in doc else [
        chart for sheet in doc.get("updatedSpreadsheet",doc).get("sheets",[]) for chart in sheet.get("charts",[])])
    found=[]
    for page,slide in enumerate(native["slides"],1):
        if requested_page and page!=requested_page:
            continue
        for element in slide.get("pageElements",[]):
            if object_id and element.get("objectId")!=object_id:
                continue
            linked=element.get("sheetsChart")
            if linked and (not book_id or linked.get("spreadsheetId")==book_id):
                for chart in all_charts:
                    if chart["chartId"]==linked.get("chartId") and (chart_id is None or chart_id==chart["chartId"]):
                        found.append((page,element,chart))
    require(len(found)==1,"Supply the complete EmbeddedChart from the job's create/update response and a page if more than one matches.")
    page,element,chart=found[0]
    require(isinstance(chart.get("spec",{}).get("basicChart"),dict) and "position" in chart,
            "A chart ID/title is insufficient. Save the chart, spec and position from the working chart's actual Sheets create/update response with includeSpreadsheetInResponse=true.")
    return page,element,chart


def slot_preflight(args, deck, chart_doc, metadata):
    """Recover an imported chart image before measuring its linked rendering."""
    requested_id = getattr(args, "chart_id", None)
    book_id = metadata.get("spreadsheetId") if metadata else None
    charts = ([chart_doc] if "chartId" in chart_doc else [
        ch for sheet in chart_doc.get("updatedSpreadsheet", chart_doc).get("sheets", []) for ch in sheet.get("charts", [])])
    if requested_id is not None:
        charts = [ch for ch in charts if ch["chartId"] == requested_id]
    if len(charts) != 1:
        return None
    chart_id = charts[0]["chartId"]
    helper = runpy.run_path(str(loc.with_name("chart-fidelity.py")))
    inventory = helper["inventory"](args.pptx)["charts"]
    if args.page is None and len(inventory)!=1:
        return None
    page = args.page or inventory[0]["page"]
    candidates = [c for c in inventory if c["page"]==page]
    require(0<=args.chart_index<len(candidates), "Read the chart page and chart index from the final PowerPoint.")
    reference=candidates[args.chart_index]
    # When only an EmbeddedChart was supplied, the ID of an existing link
    # preserves the legacy path. A missing link needs the workbook's own ID.
    page_elements = deck["slides"][page-1].get("pageElements", [])
    same_ids = {el["sheetsChart"]["spreadsheetId"] for el in page_elements if el.get("sheetsChart",{}).get("chartId")==chart_id}
    if not book_id:
        if len(same_ids)!=1:
            return {"stage":"read_sheet_metadata","chart_id":chart_id,
                    "next":"Read the confirmed working spreadsheet's spreadsheetId and its chart list. Supply --sheet-meta and retry to create a visible LINKED chart in the PowerPoint chart frame."}
        return None
    if "region" not in reference:
        require(same_ids=={book_id},"Use linked-chart-slot.mjs with the measured chart-plan region for a grouped chart.")
        return None
    ids_in_book = {ch["chartId"] for sheet in metadata.get("sheets",[]) for ch in sheet.get("charts",[])}
    if chart_id not in ids_in_book and same_ids!={book_id}:
        return {"stage":"read_sheet_metadata","spreadsheet_id":book_id,"chart_id":chart_id,
                "next":"Merge the working spreadsheet's sheet IDs/titles and its chart-list readback by sheet ID, then retry."}
    if not ids_in_book:
        # The source spec and this existing linked element prove the association.
        # This fallback cannot create a new link for a missing chart.
        metadata={**metadata, "sheets":[{"charts":charts}]}
    packet={"deck":deck,"workbook":metadata,"chart_id":chart_id,"reference":reference,
            "static_image":getattr(args,"static_image",None)}
    proc=subprocess.run(["node",str(loc.with_name("linked-chart-slot.mjs")),"--stdin"],
                        input=json.dumps(packet),text=True,capture_output=True,check=False)
    require(proc.returncode==0,proc.stderr.strip())
    return json.loads(proc.stdout)


def match_sheet_ranges(workbook,chart,sources,sheet_names=None):
    _,series=chart_text.chart_spec(chart)
    names=[];worksheets=[]
    for config in series:
        ranges=config["series"]["sourceRange"]["sources"]
        require(len(ranges)==1,"Disjoint series ranges need explicit per-range verification.")
        r=ranges[0];col=r.get("startColumnIndex",0)+1;start=r.get("startRowIndex",0)+1
        require(r.get("endColumnIndex",col)==col,"Use a vertical single-column series.")
        matches=[]
        tabs = [workbook[sheet_names[r.get("sheetId",0)]]] if sheet_names else workbook
        for tab in tabs:
            for source in sources:
                n=len(source["values"])
                # Some exporters return a range with header and some start at the first data row.
                for first in (start,start+1):
                    values=[tab.cell(first+i,col).value for i in range(n)]
                    if all(not isinstance(v,bool) and isinstance(v,(int,float)) and
                           math.isclose(v,w,rel_tol=1e-12,abs_tol=1e-14) for v,w in zip(values,source["values"])):
                        header=tab.cell(first-1,col).value if first>1 else ""
                        matches.append((tab,source["name"],chart_text.normalize(str(header))==chart_text.normalize(source["name"])))
        strong=[m for m in matches if m[2]]
        require(len(strong or matches)==1,"Cannot uniquely match workbook source values for this series.")
        tab,name,_=(strong or matches)[0];names.append(name);worksheets.append(tab)
    require(len(set(names))==len(sources)==len(names),"Series counts or resolved source names disagree.")
    require(len({w.title for w in worksheets})==1,"Use a separately verified free helper range for a multi-sheet chart.")
    return names,worksheets[0]


def actual_color_styles(workbook_tab,chart,names):
    """Use the RGB stored in the chart actually exported by Google when the public spec omits a theme color."""
    _,series=chart_text.chart_spec(chart)
    if all(config.get("colorStyle",{}).get("rgbColor") is not None or "color" in config for config in series):
        return
    from openpyxl.utils.cell import range_boundaries
    palettes=[]
    for native in workbook_tab._charts:
        palette={}
        for group in native._charts:
            for s in group.series:
                formula=getattr(getattr(s.val,"numRef",None),"f","")
                if not formula or "!" not in formula:continue
                _,area=formula.rsplit("!",1)
                col,first,last_col,last=range_boundaries(area.replace("$",""))
                if col!=last_col or first<=1:continue
                name=workbook_tab.cell(first-1,col).value
                fill=s.graphicalProperties.solidFill if type(group).__name__=="BarChart" else s.graphicalProperties.line.solidFill
                code=getattr(fill,"srgbClr",None)
                if isinstance(code,str) and len(code)==6 and isinstance(name,str):
                    palette[chart_text.normalize(name)]={k:int(code[i:i+2],16)/255 for k,i in zip(("red","green","blue"),(0,2,4))}
        if all(chart_text.normalize(n) in palette for n in names):palettes.append(palette)
    require(len(palettes)==1,"Use the current chart's resolved series RGB, or its real XLSX export with unambiguous colors.")
    for config,name in zip(series,names):
        if config.get("colorStyle",{}).get("rgbColor") is None and "color" not in config:
            config["colorStyle"]={"rgbColor":palettes[0][chart_text.normalize(name)]}


def rendered_text(path,page,box):
    with fitz.open(path) as pdf:
        p=pdf[page-1];w,h=p.rect.width,p.rect.height
        rect=fitz.Rect([v*(h if i%2 else w) for i,v in enumerate(box)])
        out=[]
        for b in p.get_text("dict",clip=rect)["blocks"]:
            for l in b.get("lines",[]):
                spans=l["spans"];text="".join(s["text"] for s in spans).strip()
                if text:
                    x0,y0,x1,y1=l["bbox"]
                    out.append({"text":chart_text.normalize(text),"measured_pt":min(a["size"] for a in spans),
                                "rect":[x0/w,y0/h,x1/w,y1/h]})
        return out,w,h


def final_check(state,google_pdf):
    items=state["expected"];w0,h0=state["source_size"]
    actual,w,h=rendered_text(google_pdf,state["page"],[0,0,1,1])
    issues=[];checked=[]
    for item in items:
        tx,ty=item["center"]
        matches=[r for r in actual if r["text"]==chart_text.normalize(item["text"])
                 and abs((r["rect"][0]+r["rect"][2])/2-tx)*w0 <= max(6,item["font_pt"]*.85)
                 and abs((r["rect"][1]+r["rect"][3])/2-ty)*h0 <= max(4,item["font_pt"]*.5)]
        if len(matches)!=1:
            issues.append({"role":item["key"],"text":item["text"],"issue":"label missing, wrapped, duplicated or misplaced"})
            continue
        result=matches[0];actual.remove(result)
        actual_pt=result["measured_pt"]*w0/w
        if abs(actual_pt-item["font_pt"])>max(.55,.05*item["font_pt"]):
            issues.append({"role":item["key"],"text":item["text"],"issue":"font size differs"})
        checked.append({**item,**result,"actual_pt":round(actual_pt,3)})
    if not issues:
        issues.extend(layout["clearance"](checked,actual,w0,h0))
    return checked,issues


def source_window(ticks):
    values = sorted({tick["value"] for tick in ticks})
    require(len(values) >= 2, "Read at least two distinct right-axis ticks from the PowerPoint rendering.")
    lo = ticks[0].get("window_min", values[0])
    hi = ticks[0].get("window_max", values[-1])
    require(lo <= values[0] < values[-1] <= hi, "Check the source axis limits against its rendered tick values.")
    return lo, hi


def right_axis_calibration(chart, tab, ticks):
    """Use the rendered source ticks and recognize only a matching, range-backed calibration series."""
    basic, visible = chart_text.chart_spec(chart)
    lo, hi = source_window(ticks)
    windows = [axis for axis in basic.get("axis", []) if axis.get("position") == "RIGHT_AXIS"]
    require(len(windows) <= 1, "Resolve the duplicate right axis in the working chart.")
    window = windows[0].get("viewWindowOptions", {}) if windows else {}
    explicit = window.get("viewWindowMode") == "EXPLICIT"
    limits = [window.get("viewWindowMin"), window.get("viewWindowMax")]
    wrong_window = explicit and limits != [lo, hi]
    sheet_id = visible[0]["series"]["sourceRange"]["sources"][0].get("sheetId", 0)
    label = "Presentation Studio axis " + str(chart["chartId"]) + " RIGHT_AXIS"
    for row in basic["series"]:
        if row.get("targetAxis") != "RIGHT_AXIS" or row.get("lineStyle", {}).get("type") != "INVISIBLE":
            continue
        ranges = row.get("series", {}).get("sourceRange", {}).get("sources", [])
        if len(ranges) != 1 or ranges[0].get("sheetId", 0) != sheet_id:
            continue
        r = ranges[0]
        col = r.get("startColumnIndex", 0) + 1
        first = r.get("startRowIndex", 0) + 1
        if r.get("endColumnIndex") != col or r.get("endRowIndex", 0) < first + 2:
            continue
        if tab.cell(first, col).value not in (label, "Axis scale"):
            continue
        cells = [tab.cell(i, col).value for i in range(first+1, r["endRowIndex"]+1)]
        if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in cells) and min(cells) == lo and max(cells) == hi:
            return None, wrong_window
    return {"sheetId": sheet_id, "rowIndex": 0, "columnIndex": tab.max_column, "axis": "RIGHT_AXIS",
            "min": lo, "max": hi, "label": label}, True


def set_right_window(chart, ticks):
    basic, _ = chart_text.chart_spec(chart)
    axes = basic.setdefault("axis", [])
    axis = next((a for a in axes if a.get("position") == "RIGHT_AXIS"), None)
    if axis is None:
        axis = {"position": "RIGHT_AXIS"}
        axes.append(axis)
    lo, hi = source_window(ticks)
    axis["viewWindowOptions"] = {"viewWindowMode": "EXPLICIT", "viewWindowMin": lo, "viewWindowMax": hi}


def cell_vector(series, titles, workbook, count):
    ranges=series.get("sourceRange",{}).get("sources",[])
    require(len(ranges)==1, "Read one vertical range for each CUSTOM label vector.")
    r=ranges[0]; col=r.get("startColumnIndex",0)+1; end=r.get("endRowIndex",0)
    require(r.get("endColumnIndex")==col and end-r.get("startRowIndex",0) in (count,count+1),
            "A native label vector must cover the complete plotted series.")
    tab=workbook[titles[r.get("sheetId",0)]]
    return [tab.cell(row,col) for row in range(end-count+1,end+1)]


def custom_labels(config, data, titles, values, formulas):
    count=len(data["values"])
    source=cell_vector(config["series"],titles,values,count)
    labels=cell_vector(config["dataLabel"]["customLabelData"],titles,values,count)
    expressions=cell_vector(config["dataLabel"]["customLabelData"],titles,formulas,count)
    expected={row["point"]:row["text"] for row in data["labels"]}
    for i,(src,cell,expression) in enumerate(zip(source,labels,expressions)):
        value=cell.value
        if i not in expected:
            require(value is None or value=="","The native chart adds an unrequested data label.")
            continue
        text=expected[i].strip()
        if isinstance(value,(float,int)):
            pct=text.endswith("%")
            token=text.replace(",","").rstrip("%")
            digits=len(token.rsplit(".",1)[1]) if "." in token else 0
            match=math.isclose(value*(100 if pct else 1),float(token),rel_tol=0,abs_tol=.5*10**(-digits)+1e-10)
        else:
            match=chart_text.normalize(str(value))==chart_text.normalize(text)
        require(match,"A CUSTOM label disagrees with its original data point.")
        if cell.coordinate==src.coordinate and cell.parent.title==src.parent.title:
            continue
        require(expression.data_type=="f","A CUSTOM label must refer to live values rather than fixed text.")
        from openpyxl.formula.tokenizer import Tokenizer
        referenced=False
        for token in Tokenizer(expression.value).items:
            if token.subtype!="RANGE":continue
            parts=token.value.rsplit("!",1)
            sheet=parts[0].strip("'").replace("''","'") if len(parts)==2 else cell.parent.title
            if sheet==src.parent.title and parts[-1].replace("$","").upper()==src.coordinate:
                referenced=True
        require(referenced,"Bind the CUSTOM label formula to the corresponding live data cell.")


def native_labels(args, native, element, chart, meta, sources, page):
    '''Inspect the actual linked source. Never replace live data with text on Slides.'''
    book_id=element["sheetsChart"]["spreadsheetId"]
    basic,series=chart_text.chart_spec(chart)
    prefix="pst52_"+hashlib.sha256(element["objectId"].encode()).hexdigest()[:10]+"_"
    overlays=[e["objectId"] for e in native["slides"][page-1]["pageElements"] if e.get("objectId","").startswith(prefix)]
    base={"page":page,"chart_id":chart["chartId"],"spreadsheet_id":book_id,
          "presentation_id":native["presentationId"],"native_object_id":element["objectId"]}
    if not meta.get("sheets") or meta.get("spreadsheetId")!=book_id:
        return {**base,"stage":"read_sheet_metadata","next":"Read tab titles and sheet IDs from the linked spreadsheet."}
    try:
        titles=axis_fallback["sheet_titles"](meta,book_id)
        values=load_workbook(args.xlsx,read_only=False,data_only=True)
        formulas=None
        try:
            names,_=match_sheet_ranges(values,chart,sources,titles)
            source={row["name"]:row for row in sources}
            for c,name in zip(series,names):
                data=source[name]; kind=c.get("dataLabel",{}).get("type","NONE")
                if not data["labels"]:
                    require(kind in ("NONE","DATA_LABEL_TYPE_UNSPECIFIED"),"Preserve series whose labels were hidden in the PowerPoint.")
                elif kind=="CUSTOM":
                    if formulas is None:formulas=load_workbook(args.xlsx,read_only=False,data_only=False)
                    custom_labels(c,data,titles,values,formulas)
                else:
                    require(kind=="DATA" and len(data["labels"])==len(data["values"]),
                            "Use live Sheets DATA labels or a source-linked CUSTOM vector for "+name+".")
            require(basic.get("legendPosition")!="NO_LEGEND","Keep the source legend in the native chart.")
        finally:
            values.close()
            if formulas:formulas.close()
    except (ValueError,KeyError,IndexError,TypeError) as error:
        return {**base,"stage":"reimport_native_combo","reason":str(error),"previous_studio_labels":overlays,
                "next":"Build the chart with native-combo-workbook.py FINAL.pptx POWERPOINT.pdf CHARTS.xlsx --page PAGE. Import it as the delivery Sheet, relink its actual chartId, remove the previous studio labels when replacing this chart, refresh and check the native PDF."}
    if overlays:
        return {**base,"stage":"remove_legacy_chart_text","write_control":{"requiredRevisionId":native["revisionId"]},
                "slides_requests":[{"deleteObject":{"objectId":oid}} for oid in overlays],
                "next":"Remove only this chart's identified studio overlays on this working revision, refresh and verify the native PDF."}
    return {**base,"stage":"native_labels_live","labels":sum(len(r["labels"]) for r in sources),
            "next":"Keep this linked chart. Check the two axes, actual labels, legend and font sizes in the native PDF."}


def run(args):
    present=unwrap(read_json(args.native))
    chart_doc=unwrap(read_json(args.chart))
    metadata_path=getattr(args,"sheet_meta",None)
    meta=unwrap(read_json(metadata_path)) if metadata_path else chart_doc.get("updatedSpreadsheet",chart_doc)
    preflight=slot_preflight(args,present,chart_doc,meta)
    if preflight and preflight["stage"]!="linked":
        return preflight
    element_id=preflight.get("element_id") if preflight else None
    page,element,chart=get_chart(chart_doc,present,args.page,meta.get("spreadsheetId"),getattr(args,"chart_id",None),element_id)
    chart=deepcopy(chart);chart_id=chart["chartId"];ref=element["sheetsChart"]
    bookid=ref["spreadsheetId"]
    region,cats,src,axes,ws,hs=chart_text.chart_reference(args.pptx,args.pptx_pdf,page,args.chart_index)
    source_id={"pptx":sha(args.pptx),"pptx_pdf":sha(args.pptx_pdf),"presentation_id":present["presentationId"],
               "spreadsheet_id":bookid,"chart_id":chart_id,"element_id":element["objectId"],"page":page}
    if not getattr(args,"static_annotation_mode",False):
        return native_labels(args,present,element,chart,meta,src,page)
    prior=read_json(args.state) if args.state.is_file() else None
    if prior:
        require(prior.get("source")==source_id,"Use a new state file for a different slide deck, source, job or chart.")
    base={"source":source_id,"page":page,"source_size":[ws,hs],"region":[region.x0/ws,region.y0/hs,region.x1/ws,region.y1/hs]}
    if "spreadsheetId" not in meta or not meta.get("sheets"):
        meta=None
    contract=prior.get("formula_axis") if prior else None
    if contract:
        base["formula_axis"]=contract
    book=load_workbook(args.xlsx,read_only=False,data_only=True)
    try:
        source_chart=contract["original_chart"] if contract else chart
        titles=axis_fallback["sheet_titles"](meta,bookid) if meta else None
        if contract and not meta:
            return {"stage":"read_sheet_metadata","spreadsheet_id":bookid,"next":"Read sheet IDs and titles with --sheet-meta, retaining this state."}
        names,tab=match_sheet_ranges(book,source_chart,src,titles)
        if contract:
            if contract["id"] not in titles:
                require(prior["stage"]=="formula_axis","The existing calibrated worksheet disappeared.")
                return prior["packet"]
            formulas=load_workbook(args.xlsx,read_only=False,data_only=False)
            try:
                actual_basic = chart["spec"]["basicChart"]
                if prior.get("stage") in ("formula_axis","restore_formula_series") and not actual_basic.get("series"):
                    # Some Sheets exports remove every series while moving a chart to
                    # another tab. Retry only its saved spec on that same, verified tab.
                    saved = next(r for r in prior["packet"]["sheets_requests"] if "updateChartSpec" in r)
                    requested = saved["updateChartSpec"]
                    require(requested["chartId"]==chart_id and actual_basic.get("domains") and
                            chart["position"]["overlayPosition"]["anchorCell"]["sheetId"]==contract["id"],
                            "Read back the relocated chart and target calibration tab before restoring its series.")
                    domain = axis_fallback["single_range"](actual_basic["domains"][0]["domain"],contract["rows"])
                    require(domain.get("sheetId",0)==contract["id"] and domain.get("startColumnIndex",0)==0
                            and domain.get("startRowIndex",0)==0,"The relocated chart no longer points to the expected domain.")
                    axis_fallback["verify"](contract,{**chart,"spec":requested["spec"]},book,formulas,meta,bookid)
                    packet={"stage":"restore_formula_series","spreadsheet_id":bookid,"sheets_requests":[saved],
                            "presentation_id":present["presentationId"],"refresh_requests":prior["packet"]["refresh_requests"],
                            "next":"Restore the saved spec in place, read back its real series, refresh and export again."}
                    return packet,{**base,"stage":"restore_formula_series","packet":packet}
                chart=axis_fallback["verify"](contract,chart,book,formulas,meta,bookid)
            finally:
                formulas.close()
        else:
            actual_color_styles(tab,chart,names)
        def check_registration():
            report=axis_fallback["measure_current"](chart_text,args.google_pdf,present,element,chart,names,src,axes,page,ws,hs)
            if report["fits"]:
                return None
            if contract:
                return {"stage":"needs_review","axis_registration":report,
                        "next":"The recalculated chart still fails its measured source scale; inspect this same chart."}
            if not meta:
                return {"stage":"read_sheet_metadata","spreadsheet_id":bookid,"axis_registration":report,
                        "next":"Read this spreadsheet's complete sheetId/title list and rerun with --sheet-meta."}
            record,requests=axis_fallback["prepare"](chart,book,meta,bookid,names,src,report,source_id["element_id"])
            packet={"stage":"formula_axis","spreadsheet_id":bookid,"sheets_requests":requests,
                    "presentation_id":present["presentationId"],"refresh_requests":[{"refreshSheetsChart":{"objectId":element["objectId"]}}],
                    "axis_registration":report,"next":"Apply as one Sheets batch, refresh the same chart, read new metadata and exports, then rerun."}
            return packet,{**base,"stage":"formula_axis","formula_axis":record,"packet":packet}
        if prior and "expected" in prior and sha(args.google_pdf)!=prior["project_pdf_sha256"]:
            checked,issues=final_check(prior,args.google_pdf)
            pending=check_registration()
            if pending:
                return pending
            if not issues:
                return {"stage":"verified","page":page,"chart_id":chart_id,"references":source_id,
                        "google_pdf_sha256":sha(args.google_pdf),"measured":checked}
            if len(issues) == 1 and issues[0]["role"] == "layout":
                shift = issues[0]["shift_pt"]
                if shift is None or prior.get("stage") == "reposition":
                    return {"stage":"needs_review","issues":issues,"next":"Make room around this chart, then re-export."}
                requests = layout["reposition"](present,page,element["objectId"],ws,shift)
                packet = {"stage":"reposition","presentation_id":present["presentationId"],
                          "write_control":{"requiredRevisionId":present["revisionId"]},"slides_requests":requests,
                          "issues":issues,"next":"Move the linked chart and its labels together, re-export, then verify."}
                state = {**prior,"stage":"reposition","project_pdf_sha256":sha(args.google_pdf),
                         "expected":deepcopy(prior["expected"]),"packet":packet}
                for label in state["expected"]:
                    label["center"][0] += shift[0]/ws
                    label["center"][1] += shift[1]/hs
                return packet,state
        if prior and prior.get("stage") == "reposition" and sha(args.google_pdf) == prior["project_pdf_sha256"]:
            return prior["packet"]
        basic,series=chart_text.chart_spec(chart)
        bare=basic.get("legendPosition")=="NO_LEGEND" and all(r.get("dataLabel",{}).get("type")=="NONE" for r in series)
        preparing = prior and prior.get("stage") == "prepare"
        same_pdf = preparing and sha(args.google_pdf) == prior.get("before_pdf_sha256")
        if preparing and args.applied_prepare:
            # Tool contracts may return only the chart ID on later reads. Reuse own exact accepted
            # request after a real Sheets acknowledgement and confirm its cells in the fresh XLSX.
            chart=deepcopy(prior["prepared_chart"]);basic,series=chart_text.chart_spec(chart);bare=True
        aux, needs_scale = (None,False) if contract else right_axis_calibration(chart, tab, axes["RIGHT_AXIS"])
        if preparing and (not bare or needs_scale) and same_pdf:
            return prior["packet"]
        if preparing and bare and not needs_scale and same_pdf and prior.get("before_slides_revision") == present["revisionId"]:
            return {"stage":"refresh","presentation_id":present["presentationId"],
                    "refresh_requests":prior["packet"]["refresh_requests"],
                    "next":"Refresh this linked chart, read back the presentation and export a fresh native PDF."}
        if not bare or needs_scale:
            prepared=deepcopy(chart)
            set_right_window(prepared, axes["RIGHT_AXIS"])
            req=chart_text.prepare(prepared,aux,530)
            packet={"stage":"prepare","spreadsheet_id":bookid,"sheets_requests":req,"presentation_id":present["presentationId"],
                    "right_axis_ticks":[t["text"] for t in axes["RIGHT_AXIS"]],
                    "refresh_requests":[{"refreshSheetsChart":{"objectId":element["objectId"]}}],
                    "next":"After Sheets accepts, refresh the linked chart, export this page's current native Google Slides PDF, read its metadata and the accepted chart. Run the same command on the new PDF."}
            return packet,{**base,"stage":"prepare","before_pdf_sha256":sha(args.google_pdf),
                           "before_slides_revision":present["revisionId"],"prepared_chart":prepared,"packet":packet}
        pending=check_registration()
        if pending:
            return pending
        plan=chart_text.make_plan(args.pptx,args.pptx_pdf,args.google_pdf,present,chart,names,page,element["objectId"],args.chart_index,args.legacy_label)
        packet={"stage":"project","presentation_id":plan["presentation_id"],"write_control":plan["write_control"],
                "slides_requests":plan["requests"],"summary":plan["summary"],
                "next":"Apply all Slides requests to the returned revision, export the updated presentation PDF, then rerun with that PDF and latest metadata for real measurement."}
        state={**base,"stage":"project","project_pdf_sha256":sha(args.google_pdf),"expected":plan["expected"]}
        if prior and prior.get("stage")=="project" and sha(args.google_pdf)!=prior["project_pdf_sha256"]:
            state["prior_issues"]=issues
            if prior.get("prior_issues")==issues:
                return {"stage":"needs_review","issues":issues,"message":"The same rendered defects persisted after correction; inspect this version."}
        return packet,state
    finally:
        book.close()


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    for name in ("pptx","pptx_pdf","google_pdf","native","chart","xlsx","state"):
        cli.add_argument(name,type=Path)
    cli.add_argument("--page",type=int);cli.add_argument("--chart-index",type=int,default=0)
    cli.add_argument("--chart-id",type=int,help="Select the working Sheets chart if the workbook has several charts.")
    cli.add_argument("--static-image",help="Converted chart image object visually verified against this PowerPoint chart, when it lacks a Sheets hyperlink.")
    cli.add_argument("--sheet-meta",type=Path,help="The same spreadsheet's latest metadata, including all sheet IDs and titles.")
    cli.add_argument("--legacy-label",action="append",default=[]);cli.add_argument("--applied-prepare",action="store_true")
    cli.add_argument("--static-annotation-mode",action="store_true",help="Use only for a separately requested static annotated illustration; editable Work never enables this option.")
    a=cli.parse_args();result=run(a)
    if isinstance(result,tuple):
        result,state=result
        tmp=a.state.with_suffix(a.state.suffix+".tmp");tmp.write_text(json.dumps(state,ensure_ascii=False));tmp.replace(a.state)
    print(json.dumps(result,ensure_ascii=False,separators=(",",":")))
