#!/usr/bin/env python3
"""Make recoverable chart data portable in the PowerPoint delivered alongside Google Slides."""
import argparse
import hashlib
import io
import json
import math
import os
import re
import sys
from datetime import date, time, timedelta
import tempfile
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree
from openpyxl import Workbook, load_workbook
from openpyxl.utils.cell import range_boundaries
from openpyxl.utils.datetime import to_excel
from pptx import Presentation
from pptx.oxml.ns import qn
from pptx.parts.chart import ChartPart
from pptx.enum.shapes import MSO_SHAPE_TYPE
from slide_numbers import strip_slide_numbers

XLS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
A1 = re.compile(r"\$?[A-Za-z]{1,3}\$?[1-9][0-9]*(?::\$?[A-Za-z]{1,3}\$?[1-9][0-9]*)?$")

def numeric_cell(value, epoch):
    if isinstance(value, (date, time, timedelta)):
        return to_excel(value, epoch)
    return value


def reject(condition, message):
    if condition:
        raise ValueError(message)

def cached_workbook(chart):
    workbook=Workbook()
    workbook.remove(workbook.active)
    literal_values={}
    cells={}
    series=chart._element.xpath(".//c:ser")
    reject(not series, "This chart does not expose standard series.")
    for ser in series:
        refs=ser.xpath(".//c:numRef|.//c:strRef")
        reject(not refs or ser.xpath(".//c:multiLvlStrRef|.//c:externalData"), "Chart series needs its original workbook.")
        for ref in refs:
            formula=ref.find(qn("c:f")); cache=ref.find(qn("c:numCache")) if ref.tag==qn("c:numRef") else ref.find(qn("c:strCache"))
            reject(formula is None or not formula.text or cache is None, "Missing chart reference or cached values.")
            tab,bang,address=formula.text.rpartition("!")
            reject(not bang or not A1.fullmatch(address) or "[" in tab or "]" in tab, "Unsupported chart cell reference.")
            if tab.startswith("'") and tab.endswith("'"):tab=tab[1:-1].replace("''","'")
            reject(not tab,"Missing source sheet name.")
            ws=workbook[tab] if tab in workbook.sheetnames else workbook.create_sheet(tab)
            left,top,right,bottom=range_boundaries(address.replace("$",""))
            reject(left!=right and top!=bottom, "Chart reference is not one-dimensional.")
            count=cache.find(qn("c:ptCount")); length=max(right-left,bottom-top)+1
            reject(count is None or int(count.get("val"))!=length,"Chart cache range length mismatch.")
            points=cache.findall(qn("c:pt")); indices=set()
            for pt in points:
                index=int(pt.get("idx")); node=pt.find(qn("c:v"))
                reject(not 0<=index<length or index in indices or node is None,"Invalid cached chart cell.")
                indices.add(index)
                cell=ws.cell(top+(index if bottom!=top else 0),left+(index if right!=left else 0))
                raw=node.text or ""; numeric=ref.tag==qn("c:numRef")
                value=float(raw) if numeric else raw
                if numeric:reject(not math.isfinite(value),"Non-finite chart value.")
                key=(tab,cell.coordinate)
                reject(key in cells and cells[key]!=(numeric,value),"Conflicting cached values.")
                cells[key]=(numeric,value)
                cell.value=value
                if numeric:
                    literal_values[key]=raw
                    fmt=cache.find(qn("c:formatCode"))
                    if fmt is not None and fmt.text:cell.number_format=fmt.text
                else:cell.data_type="s"
    reject(not cells,"No data to embed.")
    buf=io.BytesIO();workbook.save(buf);output=io.BytesIO()
    # openpyxl rounds numeric literals when serializing. Restore their actual source precision.
    with ZipFile(buf) as src, ZipFile(output,"w",ZIP_DEFLATED) as dst:
        sheet_files={f"xl/worksheets/sheet{i}.xml":name for i,name in enumerate(workbook.sheetnames,1)}
        for info in src.infolist():
            blob=src.read(info)
            if info.filename in sheet_files:
                root=etree.fromstring(blob);sheet=sheet_files[info.filename]
                for el in root.iter(XLS+"c"):
                    key=(sheet,el.get("r"))
                    if key in literal_values:el.find(XLS+"v").text=literal_values[key]
                blob=etree.tostring(root)
            dst.writestr(info,blob)
    blob=output.getvalue();checked=load_workbook(io.BytesIO(blob),data_only=True)
    for (sheet,coord),(numeric,value) in cells.items():
        actual=checked[sheet][coord].value
        if numeric:actual = numeric_cell(actual, checked.epoch)
        reject(actual!=value and not (value=="" and actual is None),"Embedded workbook differs from the chart.")
    return blob

def chart_shapes(shapes):
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from chart_shapes(shape.shapes)
        elif shape.has_chart:
            yield shape


def inspect_workbook(part):
    nodes = part._element.xpath("./c:externalData")
    reject(len(nodes) != 1, "Chart needs one embedded workbook.")
    rel = part.rels[nodes[0].get(qn("r:id"))]
    reject(rel.is_external, "Chart data points outside the PPTX.")
    blob = rel.target_part.blob
    with ZipFile(io.BytesIO(blob)) as package:
        reject(any(name.startswith("xl/externalLinks/") for name in package.namelist()),
               "Workbook uses an external source; verify local values before delivery.")
    refs = part._element.xpath(".//c:ser//c:numRef|.//c:ser//c:strRef")
    reject(not refs, "No cell references available to verify.")
    actual = load_workbook(io.BytesIO(blob), data_only=True)
    try:
        verified = 0
        for ref in refs:
            formula = ref.findtext(qn("c:f")) or ""
            tab, bang, address = formula.rpartition("!")
            reject(not bang or not A1.fullmatch(address), "Unsupported chart cell reference.")
            tab = tab.removeprefix("'").removesuffix("'").replace("''", "'")
            reject(tab not in actual.sheetnames, "Referenced worksheet is missing.")
            numeric = ref.tag == qn("c:numRef")
            cache = ref.find(qn("c:numCache") if numeric else qn("c:strCache"))
            left, top, right, bottom = range_boundaries(address.replace("$",""))
            reject(left != right and top != bottom, "Unsupported two-dimensional chart range.")
            reject(cache is None, "Chart cannot be compared with cached source values.")
            length = max(right-left, bottom-top) + 1
            count = cache.find(qn("c:ptCount"))
            reject(count is None or int(count.get("val")) != length, "Chart range count mismatch.")
            seen = set()
            for pt in cache.findall(qn("c:pt")):
                idx = int(pt.get("idx"))
                reject(idx in seen or not 0 <= idx < length, "Invalid cached chart index.")
                seen.add(idx)
                expected = pt.findtext(qn("c:v")) or ""
                value = actual[tab].cell(top + (idx if bottom != top else 0),
                                         left + (idx if right != left else 0)).value
                if numeric:
                    value = numeric_cell(value, actual.epoch)
                    agree = not isinstance(value,bool) and isinstance(value, (float,int)) and math.isclose(value,float(expected),rel_tol=1e-14,abs_tol=0)
                else:
                    agree = (value == expected or (expected == "" and value is None))
                reject(not agree, "Stored cell differs from the chart cache: " + formula)
                verified += 1
        reject(not verified, "No source cells were verified.")
        return verified
    finally:
        actual.close()


def audit(path):
    deck = Presentation(path)
    charts, issues = [], []
    for page, slide in enumerate(deck.slides, 1):
        for shape in chart_shapes(slide.shapes):
            part = shape.chart.part
            row = {"page":page, "part":str(part.partname), "shape_id":shape.shape_id}
            try:
                row["verified_cells"] = inspect_workbook(part)
            except Exception as exc:
                row["issue"] = str(exc)
                issues.append({"page":page, "part":row["part"], "issue":str(exc)})
            charts.append(row)
    return {"pptx_sha256":hashlib.sha256(path.read_bytes()).hexdigest(), "charts":charts, "issues":issues}


def prepare(source,dest):
    reject(dest.resolve()==source.resolve() or dest.exists(), "Use a fresh output distinct from the source.")
    deck=Presentation(source); repaired=[];unresolved=[]
    folios_removed = strip_slide_numbers(deck)
    for part in deck.part.package.iter_parts():
        if not isinstance(part,ChartPart):continue
        nodes=part._element.xpath("./c:externalData")
        if len(nodes)>1:
            unresolved.append({"part":str(part.partname),"issue":"Ambiguous workbook relationships."})
            continue
        node = nodes[0] if nodes else None
        rid = node.get(qn("r:id")) if node is not None else None
        rel = part.rels.get(rid)
        if rel is not None and not rel.is_external:
            continue
        try:blob=cached_workbook(part)
        except (ValueError,TypeError,KeyError) as e:
            unresolved.append({"part":str(part.partname),"issue":str(e)});continue
        if node is not None:
            part._element.remove(node)
        if rel is not None:
            part.drop_rel(rid)
        part.chart_workbook.update_from_xlsx_blob(blob);repaired.append(str(part.partname))
    with tempfile.NamedTemporaryFile(dir=dest.parent,suffix=".pptx",delete=False) as f:
        tmp=Path(f.name)
    try:
        if repaired or folios_removed:deck.save(tmp)
        else:
            import shutil
            shutil.copyfile(source,tmp)
        probe=Presentation(tmp)
        reject(len(probe.slides)!=len(deck.slides),"Slide count changed.")
        for part in probe.part.package.iter_parts():
            if str(part.partname) in repaired:
                rid=part._element.xpath("./c:externalData")[0].get(qn("r:id"))
                reject(part.rels[rid].is_external,"Chart workbook was not embedded.")
                load_workbook(io.BytesIO(part.related_part(rid).blob),read_only=True).close()
        os.link(tmp,dest)
    finally:tmp.unlink(missing_ok=True)
    return {"pages":len(deck.slides),"embedded":repaired,"unresolved":unresolved}

if __name__=="__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--audit", action="store_true", help="Check the exact PowerPoint supplied for download.")
    cli.add_argument("source", type=Path)
    cli.add_argument("output", nargs="?", type=Path)
    args = cli.parse_args()
    if args.audit == (args.output is not None):
        cli.error("Provide a fresh output path to repair, or a single PPTX with --audit.")
    try:
        result = {} if args.audit else prepare(args.source,args.output)
        result.update(audit(args.source if args.audit else args.output))
        print(json.dumps(result,ensure_ascii=False))
        sys.exit(1 if result["issues"] or result.get("unresolved") else 0)
    except Exception as e:
        sys.exit(str(e))
