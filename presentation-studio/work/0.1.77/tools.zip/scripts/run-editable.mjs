// Call from a host that can invoke Slides, image generation and private file tools.
// The host owns durable state and resolves file and operation references.
import { assetPrompt, assessGenerated, prepareAssetCall, rejectedCard, requiresCutout, inspectCutoutOriginal } from "./generated-asset.mjs";
import { inspectVisible } from "./visible-release.mjs";
import { applyImageAdjustments } from "./image-adjustments.mjs";
import { refinedPages, verifyEditableResult } from "./refined-design.mjs";
import { chartArtifactIssues, chartWorkbookDelivery } from "./chart-workbooks.mjs";

function check(condition, reason) {
  if (!condition) throw new Error(reason);
}

function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object")
    return Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])]));
  return value;
}

function validReference(value) {
  return typeof value === "string" && value.trim().length > 0;
}

async function boundedImageCall(call, timeoutMs) {
  let timer;
  try {
    return await Promise.race([
      Promise.resolve().then(call),
      new Promise(resolve => {
        timer = setTimeout(() => resolve({status: "unknown", reason: "No receipt before deadline"}), timeoutMs);
      })
    ]);
  } catch (error) {
    // A transport exception does not prove that the service never received the request.
    return {status: "unknown", reason: String(error?.message ?? error)};
  } finally {
    clearTimeout(timer);
  }
}

function recordReceipt(task, receipt) {
  if (task.pending?.generation_ref && receipt?.generation_ref &&
      task.pending.generation_ref !== receipt.generation_ref) {
    task.reason = "Retrieved result does not match the observed generation.";
    return;
  }
  if (receipt?.status === "ready" && validReference(receipt.file) && validReference(receipt.generation_ref)) {
    // The adapter must have decoded the actual image, checked its brief and saved it privately.
    task.result = {file: receipt.file, generation_ref: receipt.generation_ref};
    if (receipt.visual_review) task.result.visual_review = receipt.visual_review;
    delete task.pending;
    delete task.reason;
  } else if (receipt?.status === "generated" && validReference(receipt.generation_ref)) {
    task.pending.generation_ref = receipt.generation_ref;
    if (validReference(receipt.operation_ref)) task.pending.operation_ref = receipt.operation_ref;
    task.reason = "Image generated; retrieve its original file before delivery.";
  } else if (!task.pending?.generation_ref && (receipt?.status === "not_started" || receipt?.status === "failed")) {
    task.reason = receipt.reason || receipt.status;
    delete task.pending;
  } else {
    if (validReference(receipt?.operation_ref)) task.pending.operation_ref = receipt.operation_ref;
    task.reason = receipt?.reason || "Awaiting a verifiable result";
  }
}

function nativeSlides(ref, id) {
  try {
    const target = new URL(ref);
    return target.origin === "https://docs.google.com" && validReference(id) &&
      target.pathname.split("/").slice(1,4).join("/") === "presentation/d/" + id;
  } catch { return false; }
}

export async function runEditable(job, host, {timeoutMs = 240000} = {}) {
  // This runs before loading a job, writing a draft, or dispatching an image.
  // A legacy card or a free-text confirmation does not identify the current host.
  if (host?.surface !== "work" && host?.surface !== "codex") {
    return {
      status: "handoff_to_work",
      action: "save_handoff_for_work",
      next_step: "保存本件設定並讀回私人交接文件，顯示完整可複製的 Work 啟動指令與操作步驟。"
    };
  }
  job = applyImageAdjustments(job);
  check(job && validReference(job.id) && validReference(job.revision), "Bind a job and content revision.");
  check(validReference(job.source_key) && job.settings && typeof job.settings === "object",
        "Bind the source version and confirmed settings.");
  check(Number.isSafeInteger(job.pages) && job.pages > 0 && Array.isArray(job.assets), "Invalid page plan.");
  check(Number.isFinite(timeoutMs) && timeoutMs > 0, "Invalid tool timeout.");
  const selectedProfile = job.settings.editable_profile ?? job.editable_profile;
  check(selectedProfile == null || ["quick","refined"].includes(selectedProfile), "Unknown editable profile.");
  check(!(job.settings.editable_profile && job.editable_profile && job.settings.editable_profile !== job.editable_profile),
        "Recover the confirmed profile before producing conflicting settings.");
  check(job.layout_change_pages == null || (Array.isArray(job.layout_change_pages) &&
        job.layout_change_pages.every(n => Number.isInteger(n) && n >= 1 && n <= job.pages)), "Invalid layout-change scope.");
  if (job.page_profiles != null) {
    check(typeof job.page_profiles === "object" && !Array.isArray(job.page_profiles) &&
      Object.entries(job.page_profiles).every(([page, profile]) => /^[1-9]\d*$/.test(page) &&
        Number(page) <= job.pages && ["quick","refined"].includes(profile)), "Invalid page-specific profile.");
  }
  if (job.editable_charts != null) {
    check(Array.isArray(job.editable_charts) && job.editable_charts.every(row => row &&
      Number.isInteger(row.page) && row.page >= 1 && row.page <= job.pages &&
      Number.isInteger(row.count) && row.count > 0 && (row.formats == null ||
        (Array.isArray(row.formats) && row.formats.length && row.formats.every(f => ["pptx","slides"].includes(f))))) &&
      new Set(job.editable_charts.map(row => row.page)).size === job.editable_charts.length,
      "Supply the per-page native chart requirements from the approved source.");
  }
  if (job.intentionally_blank_pages != null) {
    check(Array.isArray(job.intentionally_blank_pages) && job.intentionally_blank_pages.every(n =>
      Number.isInteger(n) && n > 0 && n <= job.pages), "Validate deliberately blank source pages.");
  }
  const seen = new Set();
  for (const asset of job.assets) {
    const key = JSON.stringify([asset.page, asset.name]);
    check(Number.isInteger(asset.page) && asset.page >= 1 && asset.page <= job.pages &&
      validReference(asset.name) && validReference(asset.brief) && !seen.has(key), "Invalid or duplicate image layer.");
    check(asset.action === "add" || (asset.action === "redraw" && validReference(asset.reference)),
          "A redraw requires its approved source.");
    seen.add(key);
  }
  const retryTest = job.retry_test;
  if (retryTest != null) {
    check(seen.has(JSON.stringify([retryTest.page, retryTest.name])),
          "Select an approved image slot for the requested retry test.");
  }
  const freshOnly = job.settings.fresh_images_only === true;
  const signature = JSON.stringify(stable(job));
  const nativeProvider = value => value == null || /^(native|openai|chatgpt|chatgpt[_ -]?images|openai[_ -]?images)$/i.test(value);
  const single = typeof host.singleImage?.generate === "function" && nativeProvider(host.singleImage.provider ?? host.imageProvider) ?
    host.singleImage : null;
  const fallbackNative = nativeProvider(host.imageProvider) && (host.imageProvider != null || nativeProvider(host.singleImage?.provider));
  const returningGenerator = single ? single.returnsFiles === true : fallbackNative && typeof host.generateReturning === "function";
  const generate = single?.generate ?? (fallbackNative ?
    (returningGenerator ? host.generateReturning : host.generate) : null);
  const terminalRisk = !returningGenerator && host.imageContinuation === "may_end_turn";
  const formats = job.deliverables ?? ["pptx","slides"];
  check(Array.isArray(formats) && formats.length && formats.every(x => x === "slides" || x === "pptx"),
        "Unknown output format.");
  const saved = await host.load(job.id);
  const state = saved ?? {signature, version: 0, tasks: job.assets.map(() => ({attempts: 0}))};
  check(state.signature === signature, "Source, revision, settings or asset list changed; use a separate job.");
  async function commit() {
    const before = state.version;
    state.version++;
    // Compare-and-swap. Concurrent or superseded callers must stop before dispatch.
    await host.save(job.id, structuredClone(state), before);
  }
  if (!saved) await commit();
  // Never dispatch an image until the host has written and read back all independent slide work.
  // prepare and apply upsert by job, revision and layer identity, including after interrupted writes.
  // Do not make deck montages the generator's latest visual context during production.
  const beforeImages = {phase:"before_images", render:"private_files", display:"none"};
  const base = await host.prepare(job, state.base, beforeImages);
  check(validReference(base?.ref) && Array.isArray(base.page_refs) && base.page_refs.length === job.pages &&
        base.page_refs.every(validReference) && new Set(base.page_refs).size === job.pages,
        "Incomplete editable baseline; read every page back first.");
  check(!state.base || state.base.ref === base.ref, "Resume the existing baseline.");
  state.base = base;
  await commit();

  function assetKey(index) {
    return JSON.stringify(stable([job.id, job.source_key, job.revision, job.settings, job.assets[index]]));
  }
  function logTest(index, status, reference) {
    if (!retryTest) return;
    const {page, name} = job.assets[index];
    (state.image_events ??= []).push({page, name, attempt:state.tasks[index].attempts, status, reference});
  }
  const refined = new Set(refinedPages(job));
  function cutoutSlot(asset) {
    return (refined.has(asset.page) || asset.transparent_cutout === true) && requiresCutout(asset);
  }
  async function finishAttempt(index, reply) {
    const task = state.tasks[index];
    const reference = task.pending?.key;
    if ((reply?.request_key != null && reply.request_key !== reference) ||
        (reply?.asset_key != null && reply.asset_key !== task.pending?.asset_key)) {
      task.reason = "生成結果的請求或圖位與本工作不符，待查回正確素材";
      return;
    }
    const asset = job.assets[index];
    if (task.pending?.generation_ref && reply?.generation_ref && task.pending.generation_ref !== reply.generation_ref) return;
    if (refined.has(asset.page) || cutoutSlot(asset)) {
      const card=rejectedCard(reply,task.pending);
      if (card) {
        (task.rejections ??= []).push(card);
        task.reason=card.reason;
        delete task.pending;
        logTest(index,"rejected",card.generation_ref);
        return;
      }
    }
    if ((refined.has(asset.page) || cutoutSlot(asset)) && ["ready","rejected"].includes(reply?.status) &&
        validReference(reply.file) && validReference(reply.generation_ref)) {
      if (task.rejections?.some(row => row.generation_ref === reply.generation_ref)) {
        // An old operation is not the outcome of a later retry. Keep querying the current key.
        if (reply.request_key !== reference) return;
      }
      let decision = assessGenerated(reply, asset.placement_px);
      if (decision.status === "unverified" && typeof host.reviewGenerated === "function") {
        const visual = await boundedImageCall(() => host.reviewGenerated(asset, reply, {...task.pending}), timeoutMs);
        reply = {...reply, visual_review:visual};
        decision = assessGenerated(reply, asset.placement_px);
      }
      if (decision.status === "ready" && cutoutSlot(asset)) {
        reply = await inspectCutoutOriginal(reply, host);
        decision = assessGenerated(reply, asset.placement_px, true);
      }
      const review = reply.visual_review;
      if (decision.status === "ready" && task.pending.input_sha256 && review.sha256 === task.pending.input_sha256)
        decision = {status:"rejected", reason:"工具原樣回傳輸入參照，尚未生成授權素材"};
      const old = task.rejections?.some(row => row.generation_ref === reply.generation_ref ||
        (review?.sha256 && row.sha256 === review.sha256));
      const reused = freshOnly && review?.sha256 && state.tasks.some((other,i) =>
        i !== index && other.result?.visual_review?.sha256 === review.sha256);
      if (decision.status === "rejected" || (decision.status === "ready" && (old || reused))) {
        const reason = old || reused ? "重複取得已用或已排除的素材" : decision.reason;
        (task.rejections ??= []).push({request_key:reference, generation_ref:reply.generation_ref,
          sha256:review.sha256, reason});
        task.reason = reason;
        delete task.pending;
        logTest(index, "rejected", reply.generation_ref);
        return;
      }
      if (decision.status !== "ready") {
        // No visual evidence yet. Preserve this generation; missing evidence is not a failed photo.
        task.pending.candidate_file = reply.file;
        recordReceipt(task, {...reply, status:"generated"});
        task.reason = "尚待核對這次生圖的完整原檔、實際畫面與圖位尺寸";
        return;
      }
      reply = {...reply, status:"ready"};
    }
    recordReceipt(task, reply);
    if (!task.pending) logTest(index, task.result ? "ready" : reply.status, task.result?.generation_ref ?? reference);
  }
  async function findGenerated(index) {
    if (typeof host.findGenerated !== "function") return;
    const task = state.tasks[index];
    if ((freshOnly || retryTest || task.rejections?.length) && !task.pending) return;
    const asset_key = assetKey(index);
    const reply = await boundedImageCall(() => host.findGenerated(job, job.assets[index],
      {...task.pending, asset_key}), timeoutMs);
    if (reply?.asset_key !== asset_key || !validReference(reply.generation_ref) ||
        !["ready","generated","rejected","rejected_preview"].includes(reply.status)) return;
    if ((freshOnly || retryTest) && reply.request_key !== task.pending.key) return;
    task.pending ??= {key:JSON.stringify([job.id,job.revision,index,task.attempts]), asset_key};
    await finishAttempt(index, validReference(reply.file) || reply.preview_review ? reply : {...reply, status:"generated"});
    await commit();
  }
  async function reconcile(index) {
    const task = state.tasks[index];
    if (task.pending.candidate_file && task.pending.generation_ref && typeof host.reviewGenerated === "function") {
      await finishAttempt(index, {status:"ready", file:task.pending.candidate_file,
        generation_ref:task.pending.generation_ref});
      if (!task.pending) { await commit(); return; }
    }
    const reply = await boundedImageCall(() => host.lookup(job.assets[index], {...task.pending}), timeoutMs);
    await finishAttempt(index, reply);
    await commit();
  }
  async function draftBeforeImage() {
    if (!terminalRisk) return true;
    const recovered = state.tasks.flatMap((task,index) => task.result ?
      [{page:job.assets[index].page,name:job.assets[index].name,...task.result}] : []);
    const key = JSON.stringify(recovered);
    if (recovered.length && state.applied_before_image !== key) {
      await host.apply(base, recovered, beforeImages);
      state.applied_before_image = key;
      await commit();
    }
    if (state.draft) return true;
    // Never use a publishing action to discover whether a private candidate is blank.
    let preview = await host.verify(base, job, recovered, beforeImages);
    let gaps = await inspectVisible(job, host, preview, formats, beforeImages);
    if (gaps.length && typeof host.repairVisible === "function") {
      const allowed = gaps.filter(i => !i.page || !job.layout_change_pages || job.layout_change_pages.includes(i.page));
      if (allowed.length) {
        const before = preview.native_id;
        try { await host.repairVisible(base, job, preview, allowed, beforeImages); } catch { return false; }
        preview = await host.verify(base, job, recovered, beforeImages);
        if (before !== preview.native_id) return false;
        gaps = await inspectVisible(job, host, preview, formats, beforeImages);
      }
    }
    if (gaps.length) return false;
    check(typeof host.publishDraft === "function", "Expose the verified editable draft links before terminal image generation.");
    const draft = await host.publishDraft(base, job, preview);
    check(draft?.output_revision === preview.output_revision &&
          (!formats.includes("pptx") || draft.pptx_ref === preview.pptx_ref) &&
          (!formats.includes("slides") || draft.native_id === preview.native_id) && draft?.pages === job.pages && validReference(draft.message_ref) &&
          (!formats.includes("slides") || nativeSlides(draft.url, draft.native_id)) &&
          (!formats.includes("pptx") || (validReference(draft.pptx_ref) && draft.pptx_ref !== draft.url)),
          "Show the verified requested-format drafts in this Chat before image generation.");
    state.draft = draft;
    await commit();
    return true;
  }
  async function dispatch(index) {
    const task = state.tasks[index];
    if (!(await draftBeforeImage())) {
      task.reason = "此版工作稿仍有未通過的畫面，已轉入組裝及修復。";
      blockedSlots.add(task);
      return;
    }
    const asset = job.assets[index];
    const prompt = assetPrompt(asset, job.settings, cutoutSlot(asset));
    if (!prompt) {
      task.reason = "尚未從逐頁定稿取得可用的獨立素材主體";
      blockedSlots.add(task);
      return;
    }
    task.attempts++;
    task.pending = {key: JSON.stringify([job.id, job.revision, index, task.attempts]), asset_key:assetKey(index)};
    if (task.attempts === 1 && retryTest?.page === asset.page && retryTest.name === asset.name) {
      logTest(index, "injected_not_started", task.pending.key);
      recordReceipt(task, {status:"not_started", reason:"Controlled retry test: skipped provider dispatch once."});
      await commit();
      return;
    }
    const refinedAsset = refined.has(asset.page);
    let call;
    try {
      call = refinedAsset || cutoutSlot(asset) || single ? await prepareAssetCall(asset, job.settings, task.pending.key, !!task.rejections?.length, host, single, refinedAsset, cutoutSlot(asset)) :
        {provider_input:{prompt},reference_kind:"none"};
    } catch (error) {
      // No provider call occurred. Other slots can still be produced while this reference is unavailable.
      task.attempts--;
      delete task.pending;
      task.reason = String(error?.message ?? error);
      blockedSlots.add(task);
      await commit();
      return;
    }
    if (call.reference) task.pending.input_reference = call.reference;
    if (call.reference_sha256) task.pending.input_sha256 = call.reference_sha256;
    task.pending.reference_kind = call.reference_kind;
    logTest(index, "dispatch", task.pending.key);
    await commit();
    // Opaque job/request IDs travel to the adapter as local operation metadata only.
    const args = {...task.pending,prompt:call.provider_input.prompt,provider_input:call.provider_input};
    const imageAsset = call.reference ? {...asset,reference:call.reference} : asset;
    const reply = await boundedImageCall(() => single ? single.generate(call.provider_input, {key:task.pending.key}) :
      generate.call(host,imageAsset,args), timeoutMs);
    await finishAttempt(index, reply);
    await commit();
  }

  // Round robin after first attempts. Reconcile an ambiguous write once per invocation.
  const probed = new Set();
  const checkedSaved = new Set();
  const blockedSlots = new Set();
  let continuationChecked = false;
  let continuationActive = false;
  let dispatchedInThisRun = false;
  // A turn-ending generator may have shown a complete gallery without returning any files.
  // Reconcile the whole gallery before sending a new request. Legacy states may lack request keys.
  for (let index=0; index < state.tasks.length; index++) {
    const task = state.tasks[index];
    // Recheck older refined receipts before trusting their previous placement.
    if (task.result && (refined.has(job.assets[index].page) || cutoutSlot(job.assets[index])) &&
        assessGenerated(task.result, job.assets[index].placement_px, cutoutSlot(job.assets[index])).status !== "ready") {
      const previous = task.result;
      delete task.result;
      task.pending = {key:JSON.stringify([job.id,job.revision,index,task.attempts]),asset_key:assetKey(index),
        generation_ref:previous.generation_ref,candidate_file:previous.file};
      await finishAttempt(index, {...previous, status:"ready"});
      await commit();
    }
    if (task.result) continue;
    await findGenerated(index);
    if (task.pending) {
      probed.add(task.pending.key);
      await reconcile(index);
    }
  }
  for (;;) {
    const eligible = state.tasks.map((task, index) => ({task, index})).filter(({task}) =>
      !task.result && !task.pending && !blockedSlots.has(task) && task.attempts < 3);
    eligible.sort((a, b) => a.task.attempts - b.task.attempts ||
      job.assets[a.index].page - job.assets[b.index].page);
    if (eligible.length) {
      const {task, index} = eligible[0];
      if (dispatchedInThisRun && !task.attempts) {
        // One provider operation may have returned several distinct, approved assets.
        await findGenerated(index);
        if (task.result || task.pending) continue;
      }
      if (!freshOnly && !retryTest && (task.attempts || terminalRisk) && host.recover && !checkedSaved.has(index)) {
        checkedSaved.add(index);
        // Recovery is read-only. A missing repository must not prevent a fresh attempt.
        const recovered = await boundedImageCall(() => host.recover(job, job.assets[index]), timeoutMs);
        if (recovered?.status === "ready" && validReference(recovered.file) && validReference(recovered.generation_ref)) {
          task.pending = {key:JSON.stringify([job.id,job.revision,index,task.attempts]), asset_key:assetKey(index)};
          await finishAttempt(index, recovered);
          if (task.result) task.recovered = true;
          await commit();
          continue;
        }
      }
      if (typeof generate !== "function") {
        task.reason = "目前沒有可呼叫的圖像生成工具";
        blockedSlots.add(task);
        continue;
      }
      if (terminalRisk) {
        // A saved draft cannot wake a dead Chat turn. Verify an independently running
        // continuation before invoking a tool that can terminate this turn.
        if (!continuationChecked) {
          continuationChecked = true;
          const receipt = typeof host.ensureContinuation === "function" ?
            await boundedImageCall(() => host.ensureContinuation(job, base, state.continuation), timeoutMs) : null;
          continuationActive = receipt?.active === true && receipt.job_id === job.id &&
            receipt.revision === job.revision && validReference(receipt.worker_ref);
          if (continuationActive) { state.continuation = receipt; await commit(); }
        }
        if (!continuationActive) {
          task.reason = "生圖介面會結束對話，未取得可回傳檔案的工具或可自動接續的服務";
          blockedSlots.add(task);
          continue;
        }
      }
      await dispatch(index);
      dispatchedInThisRun = true;
      continue;
    }
    const idx = state.tasks.findIndex(task => task.pending && !probed.has(task.pending.key));
    if (idx < 0) break;
    probed.add(state.tasks[idx].pending.key);
    await findGenerated(idx);
    if (state.tasks[idx].pending) await reconcile(idx);
  }

  const ready = [], missing = [], restore = [];
  state.tasks.forEach((task, index) => {
    const {page, name} = job.assets[index];
    if (task.result) ready.push({page, name, ...task.result, recovered: task.recovered === true});
    else {
      missing.push({page, name, attempts:task.attempts, reason:task.reason});
      if (task.rejections?.length) restore.push({page,name});
    }
  });
  await host.apply(base, ready, {restore_slots:restore});
  let {verified, issues} = await verifyEditableResult(job, host, base, ready);
  const checkBooks = formats.includes("slides") && (terminalRisk || job.require_chart_workbooks === true ||
    verified.chart_delivery != null || verified.presentation != null || typeof host.prepareChartDelivery === "function");
  // Apply current delivery checks even when resuming an earlier job signature.
  const chartJob = {...job, chart_fidelity_version:1};
  function finalCharts() {
    if (checkBooks) check(nativeSlides(verified.url, verified.native_id), "Read back the link to the actual delivered Slides.");
    const result = checkBooks ? chartWorkbookDelivery(job, base, verified, formats) : {books:[], issues:[]};
    result.issues.push(...chartArtifactIssues(chartJob, verified, formats));
    return result;
  }
  let charts = finalCharts();
  async function repairCharts() {
    if (!charts.issues.length || typeof host.prepareChartDelivery !== "function") return;
    const nativeId = verified.native_id;
    let repairError;
    try { await host.prepareChartDelivery(base, chartJob, verified, charts.issues); }
    catch (error) { repairError = String(error?.message ?? error); }
    ({verified, issues} = await verifyEditableResult(job, host, base, ready));
    check(verified.native_id === nativeId, "Verify the original working Slides after chart repair.");
    charts = finalCharts();
    if (charts.issues.length && repairError) charts.issues.push(repairError);
  }
  await repairCharts();
  if (state.draft?.native_id) check(state.draft.native_id === verified.native_id, "Update the same working Slides file.");
  if (state.image_baseline?.native_id) check(state.image_baseline.native_id === verified.native_id, "Deliver the same working Slides used by the image job.");
  const requiresReceipt = terminalRisk;
  let visibility = await inspectVisible(job, host, verified, formats);
  // A first export, a draft, and a partial delivery are all publication boundaries.
  for (let attempt = 0; visibility.length && attempt < 2 && typeof host.repairVisible === "function"; attempt++) {
    const allowed = visibility.filter(i => !i.page || !job.layout_change_pages || job.layout_change_pages.includes(i.page));
    if (!allowed.length) break;
    const previous = verified;
    try { await host.repairVisible(base, job, previous, allowed); } catch { break; }
    ({verified, issues} = await verifyEditableResult(job, host, base, ready));
    check(verified.native_id === previous.native_id, "Verify the same Slides after visibility repair.");
    charts = finalCharts();
    await repairCharts();
    visibility = await inspectVisible(job, host, verified, formats);
  }
  if (visibility.length) {
    // Keep the editable draft and its receipts private. Do not publish a blank file as a partial.
    state.delivery = {status:"withheld", pages:verified.pages, visibility_issues:visibility};
    await commit();
    return {...state.delivery, missing, differences:verified.differences ?? []};
  }
  const pptxReady = validReference(verified.pptx_ref) && verified.pptx_ref !== verified.url;
  const readyToDeliver = !missing.length && !issues.length && !charts.issues.length && verified.content_ok === true &&
    (!requiresReceipt || !formats.includes("pptx") || pptxReady);
  const status = readyToDeliver ? "complete" : "partial";
  state.delivery = {status:requiresReceipt && readyToDeliver ? "awaiting_delivery" : status,
                    native_id: verified.native_id, url: verified.url, pages: verified.pages};
  if (pptxReady) state.delivery.pptx_ref = verified.pptx_ref;
  if (checkBooks) state.delivery.chart_workbooks = charts.books;
  if (charts.issues.length) state.delivery.chart_workbook_issues = charts.issues;
  if (refinedPages(job).length) {
    state.delivery.editable_profile = selectedProfile ?? null;
    state.delivery.design_issues = issues;
    state.delivery.design_review = verified.design_review ?? null;
  }
  await commit();
  if (requiresReceipt) {
    // Idempotent by job/revision, output revision and actual delivered references, including after a lost response.
    const packet = {...state.delivery, status, missing, differences:verified.differences ?? []};
    check(typeof host.publishDelivery === "function", "Publish the verified presentation files to the same Chat.");
    const publicationKey = JSON.stringify(stable([verified.output_revision, packet]));
    const prior = state.publication;
    const receipt = validReference(verified.output_revision) && prior?.key === publicationKey ?
      prior : await host.publishDelivery(job, packet, verified.output_revision);
    check(validReference(receipt?.message_ref), "Read back the user-visible delivery message.");
    state.publication = {key:publicationKey, message_ref:receipt.message_ref};
    state.delivery.status = status;
    state.delivery.message_ref = receipt.message_ref;
    await commit();
  }
  return {...state.delivery, missing, differences: verified.differences ?? []};
}
