"""Check the measured chart ink against the canvas and the surrounding caption."""
import hashlib

import fitz


def clearance(checked, remaining, width, height, gap=2.0):
    def bounds(row):
        x0, y0, x1, y1 = row["rect"]
        return fitz.Rect(x0*width, y0*height, x1*width, y1*height)

    labels = [(row["key"], bounds(row)) for row in checked]
    if not labels:
        return []
    ink = fitz.Rect(labels[0][1])
    for _, box in labels[1:]:
        ink |= box
    dx = max(0, gap-ink.x0) - max(0, ink.x1+gap-width)
    dy = max(0, gap-ink.y0) - max(0, ink.y1+gap-height)
    outside = [(row["text"], bounds(row)) for row in remaining]
    reasons = []
    if abs(dx) > 0.05 or abs(dy) > 0.05:
        reasons.append("chart text touches the page edge")
    for key, legend in labels:
        if not key.startswith("legend"):
            continue
        for _, box in outside:
            if (legend.x0 < box.x1 and box.x0 < legend.x1
                    and legend.y0 < box.y0 < legend.y1 + gap):
                reasons.append("legend and text below the chart lack clearance")
                dy = min(dy, box.y0-legend.y1-gap)
    if not reasons:
        return []
    shift = fitz.Rect(dx, dy, dx, dy)
    moved = ink + shift
    safe = (abs(dx) <= width*.025 and abs(dy) <= height*.025 and moved.x0 >= gap-.05
            and moved.y0 >= gap-.05 and moved.x1 <= width-gap+.05 and moved.y1 <= height-gap+.05)
    for _, box in outside:
        old_area = (ink & box).get_area()
        if (moved & box).get_area() > old_area + .05:
            safe = False
    return [{"role":"layout","issue":", ".join(dict.fromkeys(reasons)),
             "shift_pt":[dx,dy] if safe else None}]


def reposition(presentation, page, element_id, source_width, shift):
    page_width = presentation["pageSize"]["width"]
    scale = page_width["magnitude"] / (12700 if page_width["unit"] == "EMU" else 1) / source_width
    prefix = "pst52_" + hashlib.sha256(element_id.encode()).hexdigest()[:10] + "_"
    requests = []
    for el in presentation["slides"][page-1]["pageElements"]:
        if el["objectId"] != element_id and not el["objectId"].startswith(prefix):
            continue
        transform = dict(el["transform"])
        units = 12700 if transform.get("unit", "EMU") == "EMU" else 1
        for axis, delta in zip(("translateX","translateY"),shift):
            transform[axis] = transform.get(axis, 0) + delta*scale*units
        requests.append({"updatePageElementTransform":{"objectId":el["objectId"],"applyMode":"ABSOLUTE",
                                                       "transform":transform}})
    if len(requests) < 2:
        raise ValueError("Read the current linked chart and its editable chart labels before adjusting clearance.")
    return requests
