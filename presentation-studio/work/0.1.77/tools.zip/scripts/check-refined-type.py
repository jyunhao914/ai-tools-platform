"""Find fused title and explanation treatments in the actual editable slide and its PDF."""
import argparse
import json
import re
import unicodedata
from pathlib import Path

import fitz
from pptx import Presentation
from pptx.enum.shapes import PP_PLACEHOLDER


def compact(text):
    return "".join(unicodedata.normalize("NFKC", text).casefold().split())


def combined_heading(slide):
    # A heading plus substantive prose in one title placeholder is a reliable
    # role pairing. A wrapped name or two balanced lines of a title is not.
    title = slide.shapes.title
    if title is None or not title.has_text_frame or title.placeholder_format.type not in (
            PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE, PP_PLACEHOLDER.VERTICAL_TITLE):
        return None
    raw_lines = title.text.splitlines()
    lines = [line.strip() for line in raw_lines if line.strip()]
    if len(lines) < 2:
        return None
    heading, body = lines[0], " ".join(lines[1:])
    if len(compact(body)) < max(26, len(compact(heading)) * 2):
        return None
    if not (any(not line.strip() for line in raw_lines[1:-1]) or
            re.search(r"[，。！？；：,;.!?]", body) or len(lines) >= 3):
        return None
    return heading, lines[1]


def visible_lines(page):
    rows = []
    for block in page.get_text("dict", flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)["blocks"]:
        for line in block.get("lines", []):
            spans = [s for s in line["spans"] if compact(s["text"])]
            if not spans:
                continue
            primary = max(spans, key=lambda s: len(compact(s["text"])))
            rows.append((compact("".join(s["text"] for s in spans)), primary, line["bbox"]))
    return rows


def measure(pdf_page, pair):
    lines = visible_lines(pdf_page)
    title, lead = map(compact, pair)
    heads = [r for r in lines if r[0] == title]
    bodies = [r for r in lines if len(r[0]) >= 4 and
              (r[0].startswith(lead[:min(9,len(lead))]) or lead.startswith(r[0]))]
    if len(heads) != 1 or len(bodies) != 1:
        return None
    _, h, hb = heads[0]
    _, b, bb = bodies[0]
    # Weight, face, colour, size and column are independent ways to show a role.
    return (h["font"] == b["font"] and h["flags"] == b["flags"] and h["color"] == b["color"]
            and abs(h["size"] - b["size"]) <= max(.4, .035*h["size"])
            and abs(hb[0]-bb[0]) < pdf_page.rect.width*.018 and bb[1] > hb[1])


def check(pptx, pdf, selected):
    deck = Presentation(pptx)
    issues = []
    with fitz.open(pdf) as rendered:
        if len(deck.slides) != len(rendered):
            raise ValueError("Slide count differs between the PowerPoint and its rendered output.")
        for n in sorted(selected):
            if not 1 <= n <= len(rendered):
                raise ValueError("Requested page is outside the rendered deck.")
            pair = combined_heading(deck.slides[n-1])
            if pair and measure(rendered[n-1], pair):
                issues.append({"page": n, "heading": pair[0],
                    "reason": "標題和解釋同在標題欄，成品上同字級、字重、顏色及對齊。請依兩者關係重排，保留原文後重新匯出。"})
    return {"status": "repair_layout" if issues else "no_findings", "issues": issues}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx", type=Path)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--pages", help="Comma-separated one-based editable refined pages")
    args = parser.parse_args()
    selected = ({int(n) for n in args.pages.split(",")} if args.pages else
                set(range(1, len(Presentation(args.pptx).slides)+1)))
    print(json.dumps(check(args.pptx, args.pdf, selected), ensure_ascii=False))


if __name__ == "__main__":
    main()
