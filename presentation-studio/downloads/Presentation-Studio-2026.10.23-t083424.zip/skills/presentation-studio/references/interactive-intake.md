# 同包互動表單

表單模板、選項與預覽已隨安裝包提供，正式路徑是對話內的互動內容，不是 MCP App。不要呼叫舊的同名 `studio_open_intake`、新增 MCP 或要求使用者補裝另一個外掛。

## 產生與顯示

1. 先辨識本次來源並建立 job；PPTX／PDF 用 `source_kind="slides"`，大綱用 `"outline"`。只將使用者明確指定的值放進 selected；未知留空，不預選風格。
2. 依 drive-styles.md 從目前使用者的 Google Drive 完整讀回風格、名稱、UUID 與九頁預覽。用 `style_library.catalog` 及 `form_group` 驗證；不要用其他帳號、舊工作目錄或開發者快照。`intake_data.arguments(source_kind, menu=..., selected=...)` 會產出輸入資料。未連接時用真實的 not_connected 與簡短 library_message；空庫只能來自實際完整讀回。內建風格仍可使用。
3. 保存輸入 JSON；執行本版 `python <本技能>/scripts/packaged_intake.py <input.json> <絕對路徑/form.html> --job-id <本次job> --config-output <同job/config.json>`。唯一 request_id、job_id、來源與 catalog_snapshot 必須一起保存；不在重試時換來源或重新生成 ID。內建預覽由渲染器帶入，不讓模型逐項重畫或複製 base64。
4. 讀回片段確認沒有生成錯誤且小於 1 MB。在同一回合最後回覆加入 `visualize{"path":"<實際表單絕對路徑>"}` 顯示可操作表單；不能只給路徑、下載附件或聲稱已開啟。使用本包模板，不另造表單。所有待選項同張顯示，兩個風格清單在各自選項正下方，展開直接顯示完整預覽。
5. 等使用者送出。平台可能顯示「有個應用程式想傳送這則提示詞」視窗；由使用者按傳送或取消，不能繞過。成功須以同一對話收到匹配 request_id／job_id 的完整選值為準，不把產檔或按鈕文字當成功。

生成片段或傳送失敗時保留原本來源、選擇與 request_id，查實際錯誤；暫時連線錯誤依 [恢復流程](cloud.md#暫時連線錯誤的恢復) 在同一回合處理，恢復就接續，不要求回覆「繼續」。已有 config／HTML 時讀回並重用，不因重試重新產生 ID；不能回去呼叫私人 MCP、隱藏個人風格或用文字清單替代。未送出設定的重新整理暫存依主機能力；已收到的設定以對話與 job 恢復，不重問。

## 送出直接製作

表單送出的完整值要先對照已保存 config 與 job；未知值、錯誤 request_id／job_id 或陳舊的風格 snapshot 不執行。已有使用者要求製作與本次來源時，設定齊全就直接製作並交付，不再要求回覆「開始製作」或確認摘要，也不把 JSON 重貼給使用者。僅開設定的測試不製作。表單回傳不擴大原任務範圍。

本次來源與工作紀錄預設留在平台工作目錄；不要先把來源與紀錄備份 Drive，造成額外授權關卡。依使用者的原任務建立與交付簡報；保存私人風格另依明確選擇。

## 保存風格

自動／自訂風格完成交付後，用同一個渲染器 `--mode save --job-id <已完成job>`；輸入 `suggested_style_name` 為實際配色、材質與構圖的描述性名稱。提供儲存／略過、可修改名稱，不預選答案，也不阻擋成品交付。

收到匹配 job_id 與 request_id 的 SAVE、style_name，才依 drive-styles.md 寫入使用者自己的 Drive 並讀回；SKIP 不寫入、不重做簡報。表單送出成功不等於 Drive 保存成功。
