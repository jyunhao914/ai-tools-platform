"""Render the packaged form. No network, MCP registration or Drive writes."""
import argparse
import copy
import json
from pathlib import Path
import uuid
import intake_form

VERSION = "2026.10.23-t181824"


def prepare(data, *, job_id, mode="intake"):
    if not isinstance(job_id, str) or not job_id.strip() or len(job_id) > 300:
        raise ValueError("A current presentation job_id is required")
    config = {"request_id": str(uuid.uuid4()), "job_id": job_id, "version": VERSION}
    if mode == "save":
        name = data.get("suggested_style_name", "").strip()
        if not name or len(name) > 120:
            raise ValueError("Suggest a descriptive style name from the completed design")
        config.update(suggested_style_name=name, groups=[{
            "id": "save_style", "title": "是否存入我的風格庫？", "options": [
                {"id": "SAVE", "label": "存入我的風格庫"},
                {"id": "SKIP", "label": "這次不儲存"}]}])
        return config
    if mode != "intake" or data.get("source_kind") not in {"outline", "slides"}:
        raise ValueError("Use intake with source_kind outline/slides, or save")
    status = data.get("library_status")
    if status not in {"ready", "empty", "not_connected", "error"}:
        raise ValueError("Read the current user's Drive library and supply its actual status")
    personal = data.get("personal_styles") or []
    if status == "ready" and not personal:
        raise ValueError("A ready library must include its real styles and previews")
    if personal and status != "ready":
        raise ValueError("Personal styles require a verified ready library")
    catalog = json.loads((Path(__file__).parent.parent / "references/intake-options.json").read_text())
    ids = (["operation", "source_format", "image_policy", "content", "style"]
           if data["source_kind"] == "slides" else ["outline_format", "content", "style"])
    groups = [copy.deepcopy(next(g for g in catalog["groups"] if g["id"] == gid)) for gid in ids]
    selected = data.get("selected") or {}
    for group in groups:
        for option in group["options"]:
            option.pop("aliases", None)
        if group["id"] in selected:
            value = selected[group["id"]]
            if value not in {o["id"] for o in group["options"]}:
                raise ValueError("Invalid selected option: " + group["id"])
            group["selected"] = value
    if personal:
        if len(personal) > 50 or not data.get("catalog_snapshot"):
            raise ValueError("Personal styles require a current catalog snapshot and at most 50 entries")
        group = {"id": "personal_style", "title": "我的風格庫", "options": copy.deepcopy(personal)}
        if "personal_style" in selected:
            group["selected"] = selected["personal_style"]
        groups.append(group)
        config["catalog_snapshot"] = data["catalog_snapshot"]
    config.update(groups=groups, library_status=status)
    if "settings_only" in data:
        if not isinstance(data["settings_only"], bool):
            raise ValueError("settings_only must be a boolean")
        config["settings_only"] = data["settings_only"]
    if data.get("library_message"):
        config["library_message"] = str(data["library_message"])[:1000]
    if "target_pages" in data:
        pages = data["target_pages"]
        if isinstance(pages, bool) or not isinstance(pages, int) or pages < 1:
            raise ValueError("target_pages must be a positive integer")
        config["target_pages"] = pages
    if "custom_style" in data:
        config["custom_style"] = str(data["custom_style"])[:3000]
    for key, limit in (("audience", 200), ("outline_input", 20000), ("source_revision", 200)):
        if key in data:
            value = data[key]
            if not isinstance(value, str) or len(value) > limit:
                raise ValueError(f"Invalid or oversized {key}")
            config[key] = value
    action = data.get("next_action", "produce")
    if action not in {"produce", "edit_outline"}:
        raise ValueError("next_action must be produce or edit_outline")
    config["next_action"] = action
    return config


def render(data, *, job_id, mode="intake"):
    config = prepare(data, job_id=job_id, mode=mode)
    return config, intake_form.render(config)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--mode", choices=["intake", "save"], default="intake")
    parser.add_argument("--config-output", type=Path, required=True)
    args = parser.parse_args()
    config, fragment = render(json.loads(args.input.read_text()), job_id=args.job_id, mode=args.mode)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.config_output.parent.mkdir(parents=True, exist_ok=True)
    args.config_output.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n")
    args.output.write_text(fragment)
    print(json.dumps({"html": str(args.output.resolve()), "config": str(args.config_output.resolve()),
                      "request_id": config["request_id"], "job_id": config["job_id"],
                      "version": VERSION, "bytes": len(fragment.encode())}))
