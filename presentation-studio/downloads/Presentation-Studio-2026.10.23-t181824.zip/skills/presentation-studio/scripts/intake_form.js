/* Shared deterministic form and submission contract. No network calls. */
function studioSelection(config, values) {
  const saving = config.groups.some(g => g.id === "save_style");
  const action = saving ? undefined : (values.next_action || config.next_action || "produce");
  if (action && !["produce", "edit_outline"].includes(action)) throw new Error("請選擇接下來要製作或修改大綱。");
  const drafting = action === "edit_outline";
  const analysisOnly = config.groups.some(g => g.id === "operation") && ["O4", "O5"].includes(values.operation);
  if (!drafting && !analysisOnly && values.style === "SM" && !config.groups.some(g => g.id === "personal_style" && g.options.length))
    throw new Error(config.library_message || (config.library_status === "empty" ? "你的風格庫尚未儲存款式，請先選擇內建、自動或自訂風格。" : "尚未取得可用的個人風格；請先連接自己的 Google Drive 並讀取風格庫。"));
  const choices = {};
  for (const group of config.groups) {
    if (analysisOnly && group.id !== "operation") continue;
    if (group.id === "personal_style" && config.groups.some(g => g.id === "style") && values.style !== "SM") continue;
    const option = group.options.find(o => o.id === values[group.id]);
    if (!option) {
      if (drafting && !values[group.id]) continue;
      throw new Error("請選擇「" + group.title + "」。");
    }
    choices[group.id] = option.id;
  }
  const result = {schema: 1, request_id: config.request_id, choices};
  if (!saving) {
    result.next_action = action;
    for (const [key, limit] of [["audience", 200], ["outline_input", 20000]]) {
      const text = String(values[key] || "").trim();
      if (text.length > limit) throw new Error(key === "audience" ? "適用對象請控制在 200 字內。" : "大綱過長，請改在對話附加文件或貼上網址。");
      if (text) result[key] = text;
    }
  }
  const hasPages = values.target_pages != null && String(values.target_pages).trim() !== "";
  if (!saving && !analysisOnly && ((!drafting && ["O2", "O3"].includes(choices.operation)) || hasPages)) {
    const pages = Number(values.target_pages);
    if (!Number.isSafeInteger(pages) || pages < 1)
      throw new Error("請填入大於零的目標頁數。");
    result.target_pages = pages;
  }
  if (choices.style === "SC" && (!drafting || values.custom_style)) {
    const description = (values.custom_style || "").trim();
    if (!description) throw new Error("請填入自訂風格描述。");
    result.custom_style = description;
  }
  if (choices.save_style === "SAVE") {
    const name = (values.style_name || "").trim();
    if (!name) throw new Error("請填入風格名稱。");
    result.style_name = name;
  }
  if (config.catalog_snapshot) result.catalog_snapshot = config.catalog_snapshot;
  if (config.job_id) result.job_id = config.job_id;
  if (config.source_revision) result.source_revision = config.source_revision;
  if (config.settings_only === true) result.settings_only = true;
  return result;
}

function studioPrompt(config, selection) {
  if (config.settings_only === true) {
    return "Presentation Studio 設定：本次僅收集並保存這次選值，不製作簡報、不生圖、不寫入 Drive；等待人類後續要求。\n" + JSON.stringify({...selection, settings_only: true});
  }
  if (selection.next_action === "edit_outline" && !selection.choices.save_style) {
    return "Presentation Studio 設定：請先依本次補充內容及已選操作修改大綱，交付可繼續討論的草稿；暫不製作投影片或生圖，不要求先完成製作形式與風格。\n" + JSON.stringify(selection);
  }
  const labels = config.groups.filter(g => g.id in selection.choices).map(g => {
    const code = selection.choices[g.id];
    const label = g.options.find(o => o.id === code).label;
    return g.title + " " + (["SA","SC","SM","SAVE","SKIP"].includes(code) ? label : code + "（" + label + "）");
  });
  if (selection.target_pages) labels.push("預計頁數 " + selection.target_pages);
  if (selection.audience) labels.push("適用對象 " + selection.audience);
  return "Presentation Studio 設定：" + labels.join("；") + "。\n" +
    (selection.choices.save_style ? "這是我的風格保存選擇，請只依本次選擇保存或略過，不重複製作。\n" : selection.choices.operation === "O4" ? "請還原來源的完整逐頁大綱，接著可繼續修改；本次不製作投影片，不要求製作形式或風格。\n" : selection.choices.operation === "O5" ? "請偵測來源風格並提供預覽與保存選擇；本次不重製簡報，不要求製作形式或選另一種風格。\n" : ["O2", "O3"].includes(selection.choices.operation) ? "請先依目標頁數整理縮減或擴增後的逐頁大綱供修改與確認，保留本次製作設定；確認大綱後直接製作，不再另問開始。若人類已明確確認此修訂稿並要求製作，就沿用已確認稿直接執行。\n" : selection.next_action === "edit_outline" ? "請先依本次補充內容修改大綱並交付可繼續討論的草稿；暫不製作投影片或生圖，不要求先完成製作形式與風格。\n" : "請依這次設定直接製作並交付本次來源的簡報；設定齊全時不再詢問是否開始。若在此表單之後已有新的來源或修改要求，先以對話中的最新要求核對，不用舊表單覆蓋新內容。\n") +
    JSON.stringify(selection);
}

function studioStateSaver(getBridge, reportFailure) {
  let latest = 0;
  return async snapshot => {
    const revision = ++latest;
    try {
      const bridge = getBridge();
      if (typeof bridge?.setWidgetState !== "function") throw new Error("State storage unavailable");
      await bridge.setWidgetState(snapshot);
      if (revision === latest) reportFailure(false);
    } catch {
      if (revision === latest) reportFailure(true);
    }
  };
}

async function studioSend(bridge, message, timers) {
  let timer;
  try {
    return await Promise.race([
      Promise.resolve().then(() => bridge.sendFollowUpMessage(message)),
      new Promise((_, reject) => {
        timer = timers.setTimeout(() => reject(new Error("Submission acknowledgement timed out")), 45000);
      })
    ]);
  } finally { timers.clearTimeout(timer); }
}

function mountStudioIntake(root, config, host) {
  const form = root.querySelector("form");
  const area = root.querySelector("[data-groups]");
  const button = form.querySelector("[data-submit]");
  const error = root.querySelector("[data-error]");
  const status = root.querySelector("[data-status]");
  const persistence = root.querySelector("[data-persistence]");
  const fallback = root.querySelector("[data-fallback]");
  const fallbackText = root.querySelector("[data-fallback-text]");
  const copyButton = root.querySelector("[data-copy]");
  const copyStatus = root.querySelector("[data-copy-status]");
  const controls = {};
  const sections = {};
  const styleModes = [];
  const stylePanels = {};
  let sending = false;
  let accepted = null;
  const saveState = studioStateSaver(() => host.openai, failed => {
    persistence.textContent = failed
      ? "重新整理可能遺失未送出的選項。"
      : "";
  });
  function node(tag, text, cls) {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    if (cls) el.className = cls;
    return el;
  }
  function gallery(options, label, collapsed, groupId) {
    const wrapper = node(collapsed ? "details" : "div");
    if (collapsed) wrapper.append(node("summary", label));
    const grid = node("div", null, "studio-gallery");
    for (const option of options.filter(o => o.preview_data)) {
      const item = node("div", null, "studio-style");
      const image = node("img", null, "studio-preview");
      image.src = option.preview_data;
      image.alt = option.id + " " + option.label + " 九頁風格預覽";
      item.append(image, node("p", option.id + " " + option.label));
      grid.append(item);
    }
    wrapper.append(grid);
    return wrapper;
  }
  for (const [index, group] of config.groups.entries()) {
    if (index && !(group.id === "personal_style" && sections.style)) area.append(node("hr"));
    const section = node("section");
    sections[group.id] = section;
    section.setAttribute("aria-label", group.title);
    section.append(node("p", group.title));
    if (group.context) section.append(node("p", group.context, "text-small"));
    if (group.id === "style") {
      for (const [mode, title] of [
        ["auto", "自動"], ["builtin", "預設風格"],
        ["personal", "我的風格庫"], ["custom", "自訂風格"],
      ]) {
        const label = node("label", null, "form-check");
        const radio = node("input", null, "form-check-input");
        radio.type = "radio"; radio.name = "style_mode"; radio.value = mode;
        const code = group.selected;
        radio.checked = mode === (code === "SA" ? "auto" : code === "SM" ? "personal" :
          code === "SC" ? "custom" : /^\d{2}$/.test(code || "") ? "builtin" :
          "");
        label.append(radio, node("span", title, "form-check-label"));
        section.append(label);
        styleModes.push(radio);
      }
      for (const mode of ["builtin", "personal", "custom"]) {
        stylePanels[mode] = node("div");
        stylePanels[mode].hidden = true;
        section.append(stylePanels[mode]);
      }
      if (config.library_message || !config.groups.some(g => g.id === "personal_style")) {
        stylePanels.personal.append(node("p", config.library_message || (config.library_status === "empty" ? "你的風格庫目前尚未儲存款式。" : "尚未取得你的風格庫，請先連接自己的 Google Drive。")));
      }
    }
    const isSelect = group.id === "style" || group.id === "personal_style";
    controls[group.id] = [];
    if (isSelect) {
      const input = node("select", null, "form-select");
      input.name = group.id; input.setAttribute("aria-label", group.title);
      const blank = node("option", "請選擇"); blank.value = ""; input.append(blank);
      for (const option of group.options) {
        if (group.id === "style" && !/^\d{2}$/.test(option.id)) continue;
        const entry = node("option", ["SA","SC","SM"].includes(option.id) ? option.label : option.id + " " + option.label);
        entry.value = option.id; input.append(entry);
      }
      input.value = group.selected || "";
      controls[group.id].push(input);
      if (group.id === "style") {
        stylePanels.builtin.append(input, gallery(group.options, "展開內建 15 款風格", true, group.id));
      } else section.append(input, gallery(group.options, "展開我的風格預覽（" + group.options.length + " 款）", true, group.id));
    } else {
      const grid = group.id === "personal_style" ? node("div", null, "viz-grid") : section;
      if (grid !== section) section.append(grid);
      for (const option of group.options) {
        const item = node("div", null, "studio-style");
        if (group.id === "personal_style" && option.preview_data) {
          const preview = node("img", null, "studio-preview");
          preview.src = option.preview_data;
          preview.alt = option.id + " " + option.label + " 預覽";
          item.append(preview);
        }
        const label = node("label", null, "form-check");
        const input = node("input", null, "form-check-input");
        input.type = "radio"; input.name = group.id; input.value = option.id;
        input.checked = group.selected === option.id;
        label.append(input, node("span", ["SAVE","SKIP"].includes(option.id) ? option.label : option.id + " · " + option.label, "form-check-label"));
        controls[group.id].push(input); item.append(label); grid.append(item);
      }
    }
    if (group.id === "personal_style" && stylePanels.personal) stylePanels.personal.append(section);
    else area.append(section);
  }
  const pages = form.elements.namedItem("target_pages");
  const pagesField = root.querySelector("[data-pages]");
  if (sections.operation) {
    sections.operation.append(pagesField);
  } else if (!sections.save_style) {
    const goal = node("section");
    goal.setAttribute("aria-label", "製作目標");
    goal.append(node("p", "製作目標"), pagesField);
    area.prepend(goal, node("hr"));
  }
  const custom = form.elements.namedItem("custom_style");
  const styleName = form.elements.namedItem("style_name");
  const audience = form.elements.namedItem("audience");
  const outlineInput = form.elements.namedItem("outline_input");
  const nextAction = form.elements.namedItem("next_action");
  root.querySelector("[data-planning]").hidden = !!sections.save_style;
  if (stylePanels.custom) stylePanels.custom.append(root.querySelector("[data-custom]"));
  pages.value = config.target_pages || "";
  custom.value = config.custom_style || "";
  styleName.value = config.suggested_style_name || "";
  audience.value = config.audience || "";
  outlineInput.value = config.outline_input || "";
  nextAction.value = config.next_action || "produce";
  function values() {
    const state = {target_pages: pages.value, custom_style: custom.value, style_name: styleName.value,
      audience: audience.value, outline_input: outlineInput.value, next_action: nextAction.value};
    for (const group of config.groups) {
      const inputs = controls[group.id];
      state[group.id] = inputs[0].tagName === "SELECT" ? inputs[0].value :
        (inputs.find(input => input.checked)?.value || "");
    }
    if (styleModes.length) {
      state.style_mode = styleModes.find(input => input.checked)?.value || "";
      state.style = {auto: "SA", personal: "SM", custom: "SC"}[state.style_mode] ||
        (state.style_mode === "builtin" ? state.style : "");
    }
    return state;
  }
  function refresh() {
    const v = values();
    const analysisOnly = !!sections.operation && ["O4", "O5"].includes(v.operation);
    for (const id of ["source_format", "image_policy", "content", "style", "personal_style"]) {
      if (sections[id]) sections[id].hidden = analysisOnly;
    }
    root.querySelector("[data-pages]").hidden = !!sections.save_style || analysisOnly;
    root.querySelector("[data-custom]").hidden = analysisOnly || v.style !== "SC";
    root.querySelector("[data-style-name]").hidden = !sections.save_style || v.save_style === "SKIP";
    styleName.disabled = v.save_style === "SKIP";
    if (sections.personal_style && sections.style) sections.personal_style.hidden = analysisOnly || v.style !== "SM";
    for (const [mode, panel] of Object.entries(stylePanels)) panel.hidden = v.style_mode !== mode;
    const same = accepted === JSON.stringify(v);
    button.disabled = sending || same;
    button.textContent = sending ? "送出中…" : same ? "設定已送出" :
      sections.save_style ? (v.save_style === "SKIP" ? "略過儲存" : "確認儲存風格") :
      v.operation === "O4" ? "還原逐頁大綱 →" : v.operation === "O5" ? "偵測風格 →" :
      v.next_action === "edit_outline" ? "送出並修改大綱 →" : "套用設定並繼續 →";
    if (!fallback.hidden) {
      try { fallbackText.value = studioPrompt(config, studioSelection(config, v)); copyButton.disabled = false; }
      catch { fallbackText.value = ""; copyButton.disabled = true; }
    }
  }
  function restore(snapshot) {
    const state = snapshot?.modelContent;
    if (!state || state.request_id !== config.request_id || state.form_id !== root.id) return;
    for (const group of config.groups) {
      const code = state.values?.[group.id];
      if (!group.options.some(o => o.id === code)) continue;
      for (const input of controls[group.id]) {
        if (input.tagName === "SELECT") input.value = code;
        else input.checked = input.value === code;
      }
    }
    if (styleModes.length) {
      const v = state.values || {};
      const mode = v.style === "SA" ? "auto" : v.style === "SM" ? "personal" :
        v.style === "SC" ? "custom" : /^\d{2}$/.test(v.style || "") ? "builtin" : v.style_mode;
      for (const input of styleModes) input.checked = input.value === mode;
    }
    pages.value = state.values?.target_pages || "";
    custom.value = state.values?.custom_style || "";
    styleName.value = state.values?.style_name ?? config.suggested_style_name ?? "";
    audience.value = state.values?.audience ?? config.audience ?? "";
    // Large pasted outlines remain in this live form; don't truncate or rely on host state storage.
    if (state.values?.outline_input !== undefined) outlineInput.value = state.values.outline_input;
    nextAction.value = state.values?.next_action || config.next_action || "produce";
    refresh();
  }
  restore(host.openai?.widgetState);
  host.addEventListener("openai:set_globals", e => {
    if (!sending) restore(e.detail?.globals?.widgetState);
  });
  form.addEventListener("input", () => {
    error.textContent = ""; status.textContent = ""; copyStatus.textContent = ""; refresh();
    const saved = values();
    if (JSON.stringify(saved).length > 3000) delete saved.outline_input;
    const snapshot = {modelContent: {request_id: config.request_id, form_id: root.id, values: saved}};
    void saveState(snapshot);
  });
  async function submit(event) {
    event.preventDefault();
    if (sending || button.disabled) return;
    error.textContent = "";
    const v = values();
    let selection;
    try { selection = studioSelection(config, v); }
    catch (e) { error.textContent = e.message; return; }
    if (typeof host.openai?.sendFollowUpMessage !== "function") {
      showFallback(selection, "此畫面不支援直接送出。請複製下方完整設定，貼到此對話並送出即可接續，不用重選。");
      return;
    }
    sending = true; refresh();
    // Freeze controls until the exact clicked selection is acknowledged.
    for (const input of form.querySelectorAll("input,select,textarea")) input.disabled = true;
    try {
      await studioSend(host.openai, {
        prompt: studioPrompt(config, selection), title: "套用簡報製作設定"
      }, {setTimeout: (fn, ms) => (host.setTimeout || setTimeout)(fn, ms),
          clearTimeout: id => (host.clearTimeout || clearTimeout)(id)});
      accepted = JSON.stringify(v);
      status.textContent = "設定已送交對話；請在對話中查看接續結果。";
    } catch {
      showFallback(selection, "尚未確認送出。若對話未收到設定，請複製下方內容貼回此對話；已收到就不必重送。");
    } finally {
      sending = false;
      for (const input of form.querySelectorAll("input,select,textarea")) input.disabled = false;
      refresh();
    }
  }
  function showFallback(selection, message) {
    error.textContent = message;
    fallback.hidden = false;
    fallbackText.value = studioPrompt(config, selection);
    copyStatus.textContent = "";
  }
  copyButton.addEventListener("click", async () => {
    try {
      await host.navigator.clipboard.writeText(fallbackText.value);
      copyStatus.textContent = "已複製。貼到此對話並送出，才會開始處理。";
    } catch {
      fallbackText.focus(); fallbackText.select();
      copyStatus.textContent = "請長按上方文字全選並複製，再貼到此對話送出。";
    }
  });
  button.addEventListener("click", submit);
  form.addEventListener("submit", submit);
  refresh();
}

if (typeof module !== "undefined") module.exports = {studioSelection, studioPrompt, studioStateSaver, studioSend, mountStudioIntake};
