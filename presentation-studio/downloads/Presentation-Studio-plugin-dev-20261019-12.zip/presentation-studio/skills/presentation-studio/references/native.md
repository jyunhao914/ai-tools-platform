# 原生簡報適配

平台只授權修改使用者指定目標；開發驗收建立專用 Page，不能修改參考原件。

第一筆寫入先儲存封面的原生文字並讀回，確認確實能新增物件後才呼叫 ImageGen；僅能讀取空白頁或改背景不算通過。第一筆寫入建立封面後完成呼叫，讓檢視器能開啟；後續每次一至三頁，小批次保存。新建文件已有空白頁時使用它；不能多留一頁。

API 使用平台 Presentations 技能和當次工具 schema。典型原生文字：

```javascript
const shape = slide.shapes.add({geometry:'textbox',position:{left:72,top:60,width:1136,height:80},fill:'none',line:{fill:'none',width:0}});
shape.text = exactSourceTitle;
shape.text.style = {fontSize:44,typeface:'Noto Sans CJK TC',color:profile.titleColor,bold:true};
```

獨立配圖：先記錄 slot 的位置比例，再上傳生成 PNG。雲端使用返回的持久 reference：

```javascript
slide.images.add({path:reference,fit:'contain',position:slot,alt:assetDescription});
```

雲端 execute_artifact_code 的 image_references 列出本次插入或需要讀取的持久圖片參照；渲染已有圖像時 hydrate_images=true，並包含背景及繼承圖片。不要把本機磁碟路徑傳給雲端圖片上傳工具。桌面 Artifact Session 才可用 path:<本機 PNG>。

圖像式：同尺寸整頁 PNG 插入 {left:0,top:0,width:1280,height:720}，來源比例相同時 fit:'contain'；不得自動裁切文字。更新一頁先定位其原生 slide id 與 image id，再 replace 圖片；保留來源與舊版。

可編輯式表格／圖表／流程圖保留原生物件。插畫不使用大量幾何圖形假裝 ImageGen 結果。對應資料內的文字都從來源讀，不手打近似內容。自寫排版可在已確認內容與圖片 slot 範圍內調整，不硬鎖單一模板。

驗收資料包括原生物件 inspect、逐頁 PNG 的實際視覺確認、來源文字對照、每個 PNG 與 slide/image id 的映射、寫入收據。只保存暫存檔／預覽／前幾頁不能當成成品。


## 桌面 Artifact Session 相容入口

桌面必須先載入本技能的 `scripts/native_compat.mjs`，每次寫入都用它的 `runNativeSession` 包住完整呼叫（含圖片持久化與提交），不能只包住 callback。把下例的 `<技能目錄>` 替換為本次實際技能位置；不能保存開發者路徑。Web 雲端 execute_artifact_code 不套用此桌面入口。

```javascript
var nativeCompat = await import('<技能目錄>/scripts/native_compat.mjs');
var deck = await nativeCompat.runNativeSession(artifactSession, async ({presentation}) => {
  // 只使用此 callback 的 prebound presentation，讀回現有內容後修改。
  const slide = presentation.slides.getItem(0);
  const shape = slide.shapes.add({geometry:'textbox', position:{left:72,top:60,width:1136,height:80}});
  shape.text = exactSourceTitle;
}, {artifactRef: connectedArtifactRef});
nodeRepl.write(deck);
```

根因：部分桌面原生套件的 plain-object 檢查使用相同 realm 的 prototype 身分比較；host structuredClone 產生另一 realm 的普通物件，新增文字／圖形／圖片時被誤判為 `Invalid native record owner`。這個錯誤不等於使用者沒有文件權限。相容入口先偵測實際 clone 行為，只在需要時將複製出的普通物件 prototype 正規化；原始 clone 的值、循環參照、二進位資料及錯誤仍保留，結束或失敗後以 finally 還原。它不改套件檔、不改權限，不是繞過文件存取檢查。

已經失敗時：先讀回相同 Page 的現有物件，使用本入口繼續尚未儲存部分，避免重複插入。保留既有生成圖片，找回原檔，不因寫入失敗重生圖片。若連線失效，對同一 Page 重新 connect 後再讀回；若套用相容入口仍失敗，保存實際錯誤，不能無限重試、默默更換文件或指示使用者重開就保證修好。
