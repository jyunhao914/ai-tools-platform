---
name: studio-resume
description: "Presentation Studio暫停、取消、中斷接續及修改已確認簡報時使用。"
---

# 接續
先讀 ../studio-flow/SKILL.md。沿用原對話需求、來源、採用修訂、設定與成果，只接未完成步驟。
大綱採用修訂僅適用①②；③沿用原稿來源、頁面讀取進度及形式／圖片／風格，文字固定保留原文。③沒有adopted_revision不算缺項；舊進度若帶允許潤飾不得沿用或要求採用潤飾稿。原稿讀完且三項有效就接續製作。
③也保留 ../studio-content/references/redesign-image-policy.md 的逐頁素材角色、實際引用、擷取狀態及已授權圖片例外；只重做受影響頁。不能因接續或換風格，就把沿用／重繪改成重新生成，或把資訊圖表當裝飾刪除。
來源臨時路徑失效時，保留已驗證Library/Drive檔案引用，依 ../studio-content/SKILL.md 重新取得；單一路徑失效不等於附件遺失。已知檔名但引用不足時依其來源的正式搜尋方式查找，不能直接陷入重傳循環。
有Drive寫入能力時在本工作目錄保存progress.json：schema_version、job_id、mode、stage、revision、requirements、sources、pages、adopted_revision、settings、style_snapshot、folder_ids、page_results、delivery。保存必要正文與已驗證檔案ID，不含憑證、大量base64或短效帶簽章網址。
原對話不足時從使用者提供的本工作資料夾/進度檔讀回；跨對話不能憑記憶猜ID，不能保證恢復未持久保存的資料。只有失效臨時路徑就說明缺失。
暫停/取消停止新操作，只有明確恢復才續行；不假裝背景仍製作。晚到舊結果只屬舊修訂。
修改建立新修訂保留前版，只讓受影響的採用/設定失效，未變頁成果可沿用。用戶發起修改不等於自動QA。
分開記錄未開始/成功/失敗/未知；未知先查回原操作。無工具就停在具體缺項，不部署服務或不斷輪詢不存在的工作。

