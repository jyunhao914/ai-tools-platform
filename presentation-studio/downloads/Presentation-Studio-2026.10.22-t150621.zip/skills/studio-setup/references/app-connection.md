# 連接簡報設定介面

首次安裝需要兩部分：本 ZIP 的製作技能，以及目前使用者自己建立的「Presentation Studio｜製作簡報」App 連接。ZIP 不含任何人的私人 App ID。不要把 ZIP 裡的直接 HTTP 工具呼叫當成可顯示的 MCP App。

1. 先發現目前可用的已連接 App 工具，尋找 `studio_open_intake` 和 `studio_open_style_save`。名稱可能帶平台命名空間；用實際發現的工具，不猜 App ID。
2. 已有該 App 就沿用，不建立重複連接；舊名稱「Presentation Studio｜簡報設定」且提供相同工具也可沿用。若缺少，提供以下一次性設定：在電腦瀏覽器登入使用者自己的 ChatGPT → 外掛程式 → 新增 → 新增自訂 MCP 伺服器。
3. 名稱填「Presentation Studio｜製作簡報」；伺服器 URL 填 `https://presentation-studio-mcp.zxc80057.chatgpt.site/api/forms-mcp`；身分驗證選「無需身分驗證」。使用者閱讀風險提示後選「我已瞭解並希望繼續」→「建立為外掛程式」→「連接」。這個端點只產生設定表單，沒有 Google 帳號或 Drive 存取權限。
4. 返回新的工作對話，選取「Presentation Studio｜簡報工作室」與「Presentation Studio｜製作簡報」。若平台尚未把 App 工具提供給對話，請使用者加入已連接的 App；不要反覆用 shell、curl、Python 直接呼叫 URL 來假裝選單已顯示。
5. 呼叫真實 App 工具並等候實際表單或回傳設定。只有收到 JSON 不代表表單出現；若使用者說看不到，核對是否選到自己的 App 連接，不要叫他點不存在的表單。

這是下載安裝與個人連接流程，不是外掛目錄上架。不要引導至 OpenAI Platform 的付款、API 額度或發布者身份驗證。不宣稱 ZIP 安裝可替使用者完成 Google 授權，也不承諾平台未提供的安裝入口。若沒有「新增自訂 MCP 伺服器」，如實指出該帳號未顯示必要入口，不以另一人的 App ID 取代。

Google Drive 仍須由使用者在官方 Google Drive 外掛完成自己的帳號授權。已連接就沿用。不得使用外掛作者的 Drive、資料夾 ID、token 或私人風格。換裝置沿用同一 ChatGPT 帳號的已連接 App；每個新的 ChatGPT 帳號各自完成一次連接。

