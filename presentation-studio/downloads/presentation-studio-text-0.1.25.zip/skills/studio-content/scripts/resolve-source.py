#!/usr/bin/env python3
"""Resolve Library metadata without downloading files or guessing recency.

Read one JSON object from stdin with source_result, observed_names (optional),
and confirmed_library_file_id (optional). The original source_result must be
retained by the caller for the official Library download helper. This program
does not turn search results into direct attachment references.
"""

import json
import sys


class LookupFailure(ValueError):
    pass


def unwrap(value):
    """Follow only documented structured/result wrappers or JSON text blocks."""
    for _ in range(20):
        if not isinstance(value, dict):
            raise LookupFailure("result_is_not_an_object")
        if value.get("isError") is True or value.get("ok") is False:
            raise LookupFailure("source_tool_failed")
        if value.get("error"):
            raise LookupFailure("source_tool_failed")
        if isinstance(value.get("structuredContent"), dict):
            value = value["structuredContent"]
            continue
        if isinstance(value.get("result"), dict):
            value = value["result"]
            continue
        if "items" in value or "results" in value or "retrieval_title_results" in value:
            return value
        blocks = value.get("content")
        if isinstance(blocks, list):
            parsed = []
            for block in blocks:
                if not isinstance(block, dict) or block.get("type") != "text":
                    continue
                try:
                    item = json.loads(block.get("text", ""))
                except (ValueError, TypeError):
                    continue
                if isinstance(item, dict):
                    parsed.append(item)
            if len(parsed) == 1:
                value = parsed[0]
                continue
        raise LookupFailure("unrecognized_result_structure")
    raise LookupFailure("too_many_result_wrappers")


def nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())


def resolve(request):
    if not isinstance(request, dict) or "source_result" not in request:
        raise LookupFailure("source_result_required")
    observed = request.get("observed_names", [])
    if not isinstance(observed, list) or any(not nonempty_string(n) for n in observed):
        raise LookupFailure("observed_names_must_be_strings")
    confirmed = request.get("confirmed_library_file_id")
    if confirmed is not None and not nonempty_string(confirmed):
        raise LookupFailure("confirmed_library_file_id_must_be_a_string")
    data = unwrap(request["source_result"])
    if "items" in data and ("results" in data or "retrieval_title_results" in data):
        raise LookupFailure("ambiguous_result_structure")
    sections = ["items"] if "items" in data else ["results", "retrieval_title_results"]
    candidates = []
    by_identity = {}
    offset = 0
    for section in sections:
        items = data.get(section, [])
        if not isinstance(items, list):
            raise LookupFailure("result_collection_is_not_an_array")
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                raise LookupFailure("malformed_file_metadata")
            nested = item.get("metadata", {})
            if not isinstance(nested, dict):
                raise LookupFailure("malformed_file_metadata")
            # Top-level returned fields are authoritative; metadata fills gaps.
            metadata = dict(nested)
            metadata.update({k: v for k, v in item.items() if v is not None})
            if metadata.get("kind") == "folder":
                # Keep download indices unambiguous. Request include_folders=false.
                raise LookupFailure("file_only_result_required")
            library_id = metadata.get("library_file_id")
            file_id = metadata.get("file_id")
            name = metadata.get("name") or metadata.get("file_name")
            if not nonempty_string(name) or not (nonempty_string(library_id) or nonempty_string(file_id)):
                raise LookupFailure("file_identity_or_name_missing")
            identity = ("library", library_id) if nonempty_string(library_id) else ("file", file_id)
            position = {"section": section, "index": index, "download_index": offset + index}
            if identity in by_identity:
                candidate = by_identity[identity]
                candidate["source_positions"].append(position)
                if name not in candidate["observed_result_names"]:
                    candidate["observed_result_names"].append(name)
                continue
            candidate = {
                "name": name,
                "library_file_id": library_id if nonempty_string(library_id) else None,
                "file_id": file_id if nonempty_string(file_id) else None,
                "source_positions": [position],
                "observed_result_names": [name],
            }
            for key in ("path", "mime_type", "size_bytes", "created_at", "modified_at", "version_id"):
                if key in metadata:
                    candidate[key] = metadata[key]
            candidates.append(candidate)
            by_identity[identity] = candidate
        offset += len(items)

    output = {
        "metadata_only": True,
        "download_route": "original_result_with_official_download_helper",
        "has_more": bool(data.get("next_cursor")),
        "candidate_count": len(candidates),
        "candidates": candidates,
    }
    if not candidates:
        if output["has_more"]:
            output.update(status="needs_selection", reason="incomplete_result")
        else:
            output.update(status="not_found", reason="no_candidates_in_returned_result")
        return output

    if confirmed is not None:
        matches = [c for c in candidates if c["library_file_id"] == confirmed]
        reason = "confirmed_library_file_id"
    else:
        # Literal exact matching only: do not strip suffixes, normalize names,
        # pick the first observed name, or use creation time/ranking as evidence.
        matches = [c for c in candidates if c["name"] in observed]
        reason = "unique_exact_filename"
    if matches and confirmed is None and output["has_more"]:
        output.update(status="needs_selection", reason="incomplete_name_uniqueness")
    elif len(matches) == 1:
        selected = matches[0]
        index = selected["source_positions"][0]["download_index"]
        if index > 999:
            raise LookupFailure("download_index_exceeds_three_digits")
        output.update(status="identified", reason=reason, selected=selected,
                      download_selection=f"{index:03d}")
    else:
        output.update(status="needs_selection", reason=(
            "confirmed_reference_not_in_result" if confirmed is not None
            else "multiple_exact_matches" if matches
            else "no_exact_source_evidence"))
    return output


def main():
    try:
        result = resolve(json.load(sys.stdin))
    except (LookupFailure, ValueError, TypeError) as exc:
        result = {"status": "lookup_failed", "metadata_only": True,
                  "reason": str(exc) if isinstance(exc, LookupFailure) else "invalid_json_input"}
    json.dump(result, sys.stdout, ensure_ascii=False)
    sys.stdout.write("\n")
    return 1 if result["status"] == "lookup_failed" else 0


if __name__ == "__main__":
    sys.exit(main())
