#!/usr/bin/env python3
"""Read ordered PPTX structure and extract referenced images; never claim visual reading."""
import argparse
import hashlib
import json
import posixpath
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
REL = '{http://schemas.openxmlformats.org/package/2006/relationships}'


def inspect(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    assets = output / 'images'
    assets.mkdir(exist_ok=True)
    with zipfile.ZipFile(source) as z:
        if sum(i.file_size for i in z.infolist()) > 1024 ** 3:
            raise ValueError('UNCOMPRESSED_PACKAGE_TOO_LARGE')
        bad = z.testzip()
        if bad:
            raise ValueError('ZIP_CRC_FAILED: ' + bad)
        names = set(z.namelist())

        def xml(part):
            return ET.fromstring(z.read(part))

        def rels(part):
            folder, name = posixpath.split(part)
            rp = posixpath.join(folder, '_rels', name + '.rels')
            if rp not in names:
                return {}
            result = {}
            for el in xml(rp).findall(REL + 'Relationship'):
                target = el.get('Target', '')
                external = el.get('TargetMode') == 'External'
                resolved = None if external else posixpath.normpath(
                    target.lstrip('/') if target.startswith('/') else posixpath.join(folder, target))
                result[el.get('Id')] = {'type': el.get('Type', '').rsplit('/', 1)[-1],
                                       'part': resolved, 'external': external}
            return result

        presentation = xml('ppt/presentation.xml')
        pr = rels('ppt/presentation.xml')
        page_size = presentation.find('p:sldSz', NS)
        pages = []
        for index, entry in enumerate(presentation.findall('p:sldIdLst/p:sldId', NS), 1):
            rid = entry.get('{' + NS['r'] + '}id')
            slide = pr.get(rid, {}).get('part')
            if not slide or slide not in names:
                raise ValueError('MISSING_SLIDE_RELATIONSHIP: ' + str(rid))
            root = xml(slide)
            texts = [el.text for el in root.findall('.//a:t', NS) if el.text]
            images, missing, seen = [], [], set()

            def collect(part, inherited=False):
                if part in seen:
                    return
                seen.add(part)
                relationships = rels(part)
                for blip in xml(part).findall('.//a:blip', NS):
                    ref = blip.get('{' + NS['r'] + '}embed') or blip.get('{' + NS['r'] + '}link')
                    rel = relationships.get(ref)
                    if not rel or rel['external'] or rel['part'] not in names:
                        missing.append({'part': part, 'relationship': ref,
                                        'reason': 'external' if rel and rel['external'] else 'missing'})
                        continue
                    data = z.read(rel['part'])
                    digest = hashlib.sha256(data).hexdigest()
                    suffix = Path(rel['part']).suffix.lower()
                    dest = assets / (digest + suffix)
                    if not dest.exists():
                        dest.write_bytes(data)
                    images.append({'package_part': rel['part'], 'path': str(dest),
                                   'bytes': len(data), 'sha256': digest,
                                   'inherited': inherited, 'referenced_from': part})
                for rel in relationships.values():
                    if rel['type'] in ('slideLayout', 'slideMaster') and not rel['external']:
                        if rel['part'] in names:
                            collect(rel['part'], True)
                        else:
                            missing.append({'part': part, 'reason': 'missing_layout_or_master'})

            collect(slide)
            # Only a single, uncropped, unrotated full-slide picture is a safe
            # substitute for a rendered page. Mixed pages must be rendered.
            tree = root.find('p:cSld/p:spTree', NS)
            objects = [] if tree is None else [e for e in tree if e.tag.rsplit('}', 1)[-1] not in ('nvGrpSpPr', 'grpSpPr', 'extLst')]
            full_image = None
            if len(objects) == 1 and objects[0].tag == '{' + NS['p'] + '}pic' and not missing:
                pic = objects[0]
                transform = pic.find('p:spPr/a:xfrm', NS)
                crop = pic.find('p:blipFill/a:srcRect', NS)
                direct = [im for im in images if not im['inherited']]
                if transform is not None and page_size is not None and len(direct) == 1:
                    off, ext = transform.find('a:off', NS), transform.find('a:ext', NS)
                    if (off is not None and ext is not None
                            and all(abs(int(off.get(k, '0'))) <= int(page_size.get(dim)) * 0.005 for k, dim in (('x', 'cx'), ('y', 'cy')))
                            and all(abs(int(ext.get(k, '0')) - int(page_size.get(k))) <= int(page_size.get(k)) * 0.005 for k in ('cx', 'cy'))
                            and all(transform.get(k, '0') in ('0', 'false') for k in ('rot', 'flipH', 'flipV'))
                            and (crop is None or all(int(v) == 0 for v in crop.attrib.values()))):
                        full_image = direct[0]['path']
            pages.append({'number': index, 'part': slide, 'texts': texts,
                          'pictures': len(root.findall('.//p:pic', NS)),
                          'shapes': len(root.findall('.//p:sp', NS)),
                          'graphic_frames': len(root.findall('.//p:graphicFrame', NS)),
                          'images': images, 'unresolved_images': missing,
                          'text_extraction_empty': not texts,
                          'reading_action': 'read_image' if full_image else 'render_then_read',
                          'page_image_path': full_image,
                          'visual_read_required': True})
        if not pages:
            raise ValueError('NO_SLIDES_IN_PRESENTATION_ORDER')
    report = {'ok': True, 'source': str(source), 'size_bytes': source.stat().st_size,
              'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'page_count': len(pages),
              'page_size_emu': dict(page_size.attrib) if page_size is not None else None,
              'pages': pages, 'content_read_complete': False,
              'note': 'Structure only. Read actual page images/rendered pages before redesign. Empty extracted text does not mean an empty slide.'}
    manifest = output / 'manifest.json'
    manifest.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    queue = [{'page': p['number'], 'action': p['reading_action'],
              'image_path': p['page_image_path'], 'status': 'pending'} for p in pages]
    queue_file = output / 'reading-queue.json'
    queue_file.write_text(json.dumps({'source': str(source), 'pages': queue}, ensure_ascii=False, indent=2), encoding='utf-8')
    return {'ok': True, 'manifest': str(manifest), 'page_count': len(pages),
            'next_action': 'execute_reading_queue', 'reading_queue': str(queue_file),
            'direct_image_pages': [p['number'] for p in pages if p['page_image_path']],
            'empty_text_pages': [p['number'] for p in pages if p['text_extraction_empty']],
            'image_references': sum(len(p['images']) for p in pages),
            'unresolved_images': sum(len(p['unresolved_images']) for p in pages),
            'content_read_complete': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', help='Actual local PPTX path')
    parser.add_argument('output', help='Inspection output directory')
    args = parser.parse_args()
    try:
        print(json.dumps(inspect(args.source, args.output), ensure_ascii=False))
    except (OSError, ValueError, KeyError, ET.ParseError, zipfile.BadZipFile) as exc:
        print(json.dumps({'ok': False, 'error': str(exc)}, ensure_ascii=False))
        sys.exit(1)
