import { spawn } from 'node:child_process';
import { isAbsolute, dirname } from 'node:path';
import { stat, mkdir } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';

const pythonLauncher = [
  'import os,sys,runpy',
  'try:',
  ' import certifi',
  ' if not os.environ.get("SSL_CERT_FILE"): os.environ["SSL_CERT_FILE"]=certifi.where()',
  'except ImportError: pass',
  'sys.argv=sys.argv[1:]',
  'sys.path.insert(0,os.path.dirname(sys.argv[0]))',
  'runpy.run_path(sys.argv[0],run_name="__main__")',
].join('\n');

async function runOfficial({ helperPath, args, input, pythonExecutable, cwd }) {
  return new Promise((resolve) => {
    const child = spawn(pythonExecutable, ['-c', pythonLauncher, helperPath, ...args], { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', chunk => { stdout += chunk.toString(); });
    child.stderr.on('data', chunk => { stderr = (stderr + chunk.toString()).slice(-4000); });
    child.on('error', error => resolve({ ok: false, stage: 'spawn', code: error.code || 'SPAWN_FAILED' }));
    child.stdin.on('error', () => {});
    child.on('close', exitCode => {
      const http = stderr.match(/HTTP status (\d{3})/);
      const code = /Library prepare_materialize is not available/.test(stderr)
        ? 'LIBRARY_BRIDGE_UNAVAILABLE'
        : /certificate verify failed|CERTIFICATE_VERIFY_FAILED/i.test(stderr)
          ? 'CERTIFICATE_VERIFICATION_FAILED'
          : /download failed/i.test(stderr) ? 'DOWNLOAD_FAILED' : undefined;
      resolve({ ok: exitCode === 0, stage: 'transfer', exitCode, stdout, ...(code ? { code } : {}), ...(http ? { httpStatus: Number(http[1]) } : {}) });
    });
    child.stdin.end(JSON.stringify(input));
  });
}

// Search/list results must use the official download helper's complete-result route.
export async function downloadLibrarySearch({ helperPath, workspace, result, selection, destination, pythonExecutable = 'python3' }) {
  if (!isAbsolute(helperPath) || !isAbsolute(workspace)) throw new Error('Absolute helper and workspace paths required');
  if (typeof destination !== 'string' || isAbsolute(destination) || destination.split(/[\\/]/).includes('..')) throw new Error('Contained relative destination required');
  if (!/^(ALL|(?:\d{3})+)$/.test(selection)) throw new Error('Official selection format required');
  await stat(helperPath);
  const run = await runOfficial({ helperPath, args: [], input: { result, selection, destination }, pythonExecutable, cwd: workspace });
  if (!run.ok) { delete run.stdout; return run; }
  try { return { ok: true, result: JSON.parse(run.stdout) }; }
  catch { return { ok: false, stage: 'result', code: 'INVALID_HELPER_RESULT' }; }
}

// Run the current, unchanged official Library helper. Never download directly.
export async function materializeLibrary({ helperPath, destination, transfer, pythonExecutable = 'python3' }) {
  if (!isAbsolute(helperPath) || !isAbsolute(destination)) throw new Error('Absolute helper and destination paths required');
  if (!transfer || typeof transfer !== 'object' || typeof transfer.download_url !== 'string') throw new Error('Complete official signed-URL transfer required');
  await stat(helperPath);
  await mkdir(dirname(destination), { recursive: true });
  const result = await runOfficial({ helperPath, args: ['materialize', destination], input: transfer, pythonExecutable });
  delete result.stdout;
  if (!result.ok) return result;
  const info = await stat(destination);
  if (typeof transfer.size_bytes === 'number' && info.size !== transfer.size_bytes) return { ok: false, stage: 'size', expected: transfer.size_bytes, actual: info.size };
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(destination)) hash.update(chunk);
  return { ok: true, path: destination, sizeBytes: info.size, sha256: hash.digest('hex') };
}
