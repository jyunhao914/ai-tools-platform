// Load the packaged preset image from the current skill's actual /bundle URL.
// The import API is memory-only; the optional CLI writes one verified PNG.
import https from 'node:https';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { Buffer } from 'node:buffer';
import { mkdir, writeFile } from 'node:fs/promises';
import { isAbsolute, join, resolve } from 'node:path';
import { URL, pathToFileURL } from 'node:url';
import { setTimeout, clearTimeout } from 'node:timers';

const MAX_DOWNLOAD = 8 * 1024 * 1024;
const MAX_TAR = 16 * 1024 * 1024;
const MAX_PNG = 6 * 1024 * 1024;
const MAX_JSON = 1024 * 1024;
const TIMEOUT_MS = 30000;
const PNG_PATH = 'assets/presets-01-15.png';
const JSON_PATH = 'references/presets.json';
const PNG_SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

function fail(code) { throw new Error(code); }
function safeUrl(value, base) {
  let url;
  try { url = new URL(value, base); } catch { fail('PREVIEW_URL_INVALID'); }
  if (url.protocol !== 'https:' || url.username || url.password || !url.hostname) {
    fail('PREVIEW_URL_INVALID');
  }
  return url;
}

function requestBytes(url, deadline) {
  return new Promise((resolve, reject) => {
    let settled = false;
    let req;
    let res;
    const finish = (error, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error || result?.location) { res?.destroy(); req?.destroy(); }
      if (error) reject(new Error(error)); else resolve(result);
    };
    const remaining = deadline - Date.now();
    const timer = setTimeout(() => finish('PREVIEW_DOWNLOAD_TIMEOUT'), Math.max(0, remaining));
    if (remaining <= 0) { finish('PREVIEW_DOWNLOAD_TIMEOUT'); return; }
    try {
      req = https.get(url, response => {
        res = response;
        if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
          if (typeof res.headers.location !== 'string') finish('PREVIEW_REDIRECT_INVALID');
          else finish(null, { location: res.headers.location });
          return;
        }
        if (res.statusCode !== 200) { finish('PREVIEW_DOWNLOAD_HTTP_ERROR'); return; }
        const length = Number(res.headers['content-length']);
        if (Number.isFinite(length) && length > MAX_DOWNLOAD) {
          finish('PREVIEW_BUNDLE_TOO_LARGE'); return;
        }
        let size = 0;
        const chunks = [];
        res.on('data', chunk => {
          size += chunk.length;
          if (size > MAX_DOWNLOAD) finish('PREVIEW_BUNDLE_TOO_LARGE');
          else chunks.push(chunk);
        });
        res.on('end', () => finish(null, { bytes: Buffer.concat(chunks) }));
        res.on('aborted', () => finish('PREVIEW_DOWNLOAD_FAILED'));
        res.on('error', () => finish('PREVIEW_DOWNLOAD_FAILED'));
      });
      req.on('error', () => finish('PREVIEW_DOWNLOAD_FAILED'));
    } catch { finish('PREVIEW_DOWNLOAD_FAILED'); }
  });
}

function tarString(header, start, length) {
  return header.subarray(start, start + length).toString('utf8').split('\0', 1)[0];
}
function tarNumber(header, start, length) {
  const value = tarString(header, start, length).trim();
  if (!/^[0-7]+$/.test(value)) fail('PREVIEW_TAR_INVALID');
  const parsed = Number.parseInt(value, 8);
  if (!Number.isSafeInteger(parsed) || parsed < 0) fail('PREVIEW_TAR_INVALID');
  return parsed;
}
function parsePax(bytes) {
  const values = Object.create(null);
  let offset = 0;
  while (offset < bytes.length) {
    const space = bytes.indexOf(32, offset);
    if (space < offset || space - offset > 10) fail('PREVIEW_TAR_INVALID');
    const count = bytes.subarray(offset, space).toString('ascii');
    if (!/^[1-9][0-9]*$/.test(count)) fail('PREVIEW_TAR_INVALID');
    const end = offset + Number(count);
    if (end > bytes.length || end <= space + 2 || bytes[end - 1] !== 10) fail('PREVIEW_TAR_INVALID');
    const record = bytes.subarray(space + 1, end - 1).toString('utf8');
    const equals = record.indexOf('=');
    if (equals < 1) fail('PREVIEW_TAR_INVALID');
    values[record.slice(0, equals)] = record.slice(equals + 1);
    offset = end;
  }
  return values;
}

// Pure parser for the observed skill-bundle format: gzip-compressed tar.
// Only these two exact regular-file entries are ever retained; nothing is extracted.
export function parseBundle(input) {
  // instanceof fails for typed arrays crossing the node_repl execution realm.
  if (!Buffer.isBuffer(input) && !(ArrayBuffer.isView(input) && input.BYTES_PER_ELEMENT === 1)) {
    fail('PREVIEW_BUNDLE_INPUT_INVALID');
  }
  if (input.byteLength > MAX_DOWNLOAD) fail('PREVIEW_BUNDLE_TOO_LARGE');
  const compressed = Buffer.from(input);
  if (compressed[0] !== 0x1f || compressed[1] !== 0x8b) fail('PREVIEW_BUNDLE_NOT_TAR_GZIP');
  let tar;
  try { tar = gunzipSync(compressed, { maxOutputLength: MAX_TAR }); }
  catch { fail('PREVIEW_BUNDLE_INVALID_OR_TOO_LARGE'); }
  let offset = 0;
  let count = 0;
  let pax = {};
  let globalPax = {};
  const files = new Map();
  let ended = false;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(value => value === 0)) { ended = true; break; }
    if (++count > 256) fail('PREVIEW_TAR_TOO_MANY_ENTRIES');
    const checksum = tarNumber(header, 148, 8);
    let actual = 0;
    for (let i = 0; i < 512; i++) actual += i >= 148 && i < 156 ? 32 : header[i];
    if (checksum !== actual) fail('PREVIEW_TAR_CHECKSUM_FAILED');
    const size = tarNumber(header, 124, 12);
    const dataStart = offset + 512;
    const next = dataStart + Math.ceil(size / 512) * 512;
    if (next > tar.length) fail('PREVIEW_TAR_TRUNCATED');
    const body = tar.subarray(dataStart, dataStart + size);
    const type = header[156];
    if (type === 120 || type === 103) { // POSIX per-file/global extended metadata
      if (size > 65536) fail('PREVIEW_TAR_INVALID');
      const attrs = parsePax(body);
      if (type === 103) globalPax = { ...globalPax, ...attrs };
      else pax = attrs;
      offset = next;
      continue;
    }
    const prefix = tarString(header, 345, 155);
    const rawName = tarString(header, 0, 100);
    const name = (pax.path ?? globalPax.path ?? (prefix ? `${prefix}/${rawName}` : rawName)).replace(/^\.\//, '');
    if (pax.size !== undefined || globalPax.size !== undefined) fail('PREVIEW_TAR_UNSUPPORTED_SIZE');
    pax = {};
    if (name === PNG_PATH || name === JSON_PATH) {
      if (type !== 0 && type !== 48) fail('PREVIEW_ASSET_NOT_REGULAR_FILE');
      if (files.has(name)) fail('PREVIEW_ASSET_DUPLICATED');
      if (size > (name === PNG_PATH ? MAX_PNG : MAX_JSON)) fail('PREVIEW_ASSET_TOO_LARGE');
      files.set(name, body);
    }
    offset = next;
  }
  if (!ended) fail('PREVIEW_TAR_TRUNCATED');
  if (!files.has(PNG_PATH) || !files.has(JSON_PATH)) fail('PREVIEW_ASSET_MISSING');
  const bytes = files.get(PNG_PATH);
  if (bytes.length < 33 || !bytes.subarray(0, 8).equals(PNG_SIGNATURE)
      || bytes.readUInt32BE(8) !== 13 || bytes.toString('ascii', 12, 16) !== 'IHDR') {
    fail('PREVIEW_PNG_INVALID');
  }
  const width = bytes.readUInt32BE(16);
  const height = bytes.readUInt32BE(20);
  if (!width || !height || width > 8192 || height > 8192 || width * height > 32 * 1024 * 1024) {
    fail('PREVIEW_PNG_DIMENSIONS_INVALID');
  }
  let metadata;
  try { metadata = JSON.parse(files.get(JSON_PATH).toString('utf8')); }
  catch { fail('PREVIEW_METADATA_INVALID'); }
  const sheet = metadata?.preview_sheet;
  if (!sheet || sheet.asset_path !== PNG_PATH || !/^[0-9a-f]{64}$/.test(sheet.sha256 ?? '')) {
    fail('PREVIEW_METADATA_INVALID');
  }
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  if (sha256 !== sheet.sha256) fail('PREVIEW_HASH_MISMATCH');
  return { bytes: Buffer.from(bytes), mimeType: 'image/png', width, height, sha256 };
}

export async function loadPresetPreview({ bundleUrl } = {}) {
  let url = safeUrl(bundleUrl);
  const deadline = Date.now() + TIMEOUT_MS;
  for (let redirects = 0; redirects <= 3; redirects++) {
    const result = await requestBytes(url, deadline);
    if (result.bytes) return parseBundle(result.bytes);
    if (redirects === 3) fail('PREVIEW_TOO_MANY_REDIRECTS');
    url = safeUrl(result.location, url);
  }
  fail('PREVIEW_DOWNLOAD_FAILED');
}

async function main() {
  const chunks = [];
  let length = 0;
  for await (const chunk of process.stdin) {
    length += chunk.length;
    if (length > 32768) fail('PREVIEW_CLI_INPUT_TOO_LARGE');
    chunks.push(chunk);
  }
  let options;
  try { options = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { fail('PREVIEW_CLI_INPUT_INVALID'); }
  const directory = options?.outputDirectory;
  if (typeof directory !== 'string' || !isAbsolute(directory) || directory.includes('\0')) {
    fail('PREVIEW_OUTPUT_DIRECTORY_INVALID');
  }
  const preview = await loadPresetPreview({ bundleUrl: options.bundleUrl });
  const path = join(directory, 'presets-01-15.png');
  await mkdir(directory, { recursive: true });
  // wx avoids silently replacing any existing file or following a symlink.
  await writeFile(path, preview.bytes, { flag: 'wx', mode: 0o600 });
  process.stdout.write(JSON.stringify({
    path, mimeType: preview.mimeType, sha256: preview.sha256,
    size: preview.bytes.length, width: preview.width, height: preview.height,
  }) + '\n');
}

if (typeof process !== 'undefined' && process.argv?.[1]
    && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main().catch(error => {
    const code = /^PREVIEW_[A-Z_]+$/.test(error?.message ?? '') ? error.message : 'PREVIEW_CLI_FAILED';
    process.stderr.write(code + '\n');
    process.exitCode = 1;
  });
}
