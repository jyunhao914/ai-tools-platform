import { isAbsolute, dirname } from 'node:path';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

// Pass the actual image_url returned by the image tool through structured calls.
// This saves unchanged bytes; it does not render, edit, crop, or regenerate images.
export async function saveGeneratedImage({ imageUrl, destination }) {
  if (typeof destination !== 'string' || !isAbsolute(destination)) throw new Error('ABSOLUTE_DESTINATION_REQUIRED');
  if (typeof imageUrl !== 'string') throw new Error('IMAGE_DATA_URI_REQUIRED');
  const match = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(imageUrl);
  if (!match || match[2].length % 4 !== 0) throw new Error('VALID_IMAGE_DATA_URI_REQUIRED');
  const bytes = Buffer.from(match[2], 'base64');
  if (!bytes.length || bytes.length > 100 * 1024 * 1024) throw new Error('IMAGE_SIZE_INVALID');
  if (bytes.toString('base64') !== match[2]) throw new Error('INVALID_BASE64');
  const kind = match[1];
  const signatureOK = kind === 'png'
    ? bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))
    : kind === 'jpeg'
      ? bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255
      : bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
  if (!signatureOK) throw new Error('IMAGE_TYPE_MISMATCH');
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  await mkdir(dirname(destination), { recursive: true });
  let reused = false;
  try { await writeFile(destination, bytes, { flag: 'wx' }); }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    const existing = await readFile(destination);
    if (!existing.equals(bytes)) throw new Error('DESTINATION_HAS_DIFFERENT_IMAGE');
    reused = true;
  }
  return { path: destination, mimeType: `image/${kind}`, sizeBytes: bytes.length, sha256, reused };
}
