#!/usr/bin/env python3
"""Read-only image-mode PPTX gate (Python standard library only).

Usage: python3 validate-image-deck.py MANIFEST_JSON DECK_PPTX
Manifest: {"schema_version":1,"expected_pages":9,"content_revision":"r1",
 "pages":[{"page_number":1,"image_path":"page-01.png","image_sha256":"...",
 "content_revision":"r1","source_kind":"generated_full_page",
 "generation_ref":"actual generation result reference"}, ...]}
For an explicitly authorized unchanged original page, source_kind is
"approved_original_page" and a nonempty "authorization" replaces generation_ref.
Relative image paths are relative to the manifest. Output is JSON; only exit 0
means pass. This verifies bytes, page mapping and PPTX structure, not OCR, medical
accuracy, image aesthetics, or the truth of supplied generation/approval records.
"""

import binascii
import hashlib
import json
import posixpath
import re
import struct
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
import zlib
from pathlib import Path


P = "http://schemas.openxmlformats.org/presentationml/2006/main"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PR = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"
PRESENTATION_MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"
SLIDE_MIME = "application/vnd.openxmlformats-officedocument.presentationml.slide+xml"
MAX_IMAGE_BYTES = 256 * 1024 * 1024
REL_TYPES = {
    "slide": {R + "/slide", "http://purl.oclc.org/ooxml/officeDocument/relationships/slide"},
    "image": {R + "/image", "http://purl.oclc.org/ooxml/officeDocument/relationships/image"},
    "officeDocument": {R + "/officeDocument", "http://purl.oclc.org/ooxml/officeDocument/relationships/officeDocument"},
}


class GateError(Exception):
    def __init__(self, code, message, page=None):
        super().__init__(message)
        self.code, self.message, self.page = code, message, page

    def as_dict(self):
        result = {"code": self.code, "message": self.message}
        if self.page is not None:
            result["page_number"] = self.page
        return result


def require(condition, code, message, page=None):
    if not condition:
        raise GateError(code, message, page)


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def positive_int(value):
    return type(value) is int and value > 0


def strict_json(text):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, "duplicate_json_key", "Manifest has duplicate JSON keys.")
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=pairs)


def png_dimensions(data):
    require(data.startswith(b"\x89PNG\r\n\x1a\n"), "invalid_image", "Invalid PNG signature.")
    offset, chunks, compressed, ended = 8, [], bytearray(), False
    width = height = depth = color = interlace = None
    while offset < len(data):
        require(offset + 12 <= len(data), "invalid_image", "Truncated PNG chunk.")
        length = struct.unpack_from(">I", data, offset)[0]
        kind = data[offset + 4:offset + 8]
        stop = offset + 12 + length
        require(stop <= len(data), "invalid_image", "Truncated PNG chunk payload.")
        payload = data[offset + 8:offset + 8 + length]
        crc = struct.unpack_from(">I", data, offset + 8 + length)[0]
        require(binascii.crc32(kind + payload) & 0xffffffff == crc,
                "invalid_image", "PNG chunk CRC mismatch.")
        require(chunks or kind == b"IHDR", "invalid_image", "PNG must start with IHDR.")
        if kind == b"IHDR":
            require(not chunks and length == 13, "invalid_image", "Invalid PNG IHDR.")
            width, height, depth, color, compression, filtering, interlace = struct.unpack(">IIBBBBB", payload)
            depths = {0: {1, 2, 4, 8, 16}, 2: {8, 16}, 3: {1, 2, 4, 8}, 4: {8, 16}, 6: {8, 16}}
            require(width > 0 and height > 0 and color in depths and depth in depths[color]
                    and compression == 0 and filtering == 0 and interlace in (0, 1),
                    "invalid_image", "Unsupported or invalid PNG dimensions/encoding.")
        elif kind == b"IDAT":
            require(b"IDAT" not in chunks or chunks[-1] == b"IDAT",
                    "invalid_image", "PNG IDAT chunks must be consecutive.")
            compressed.extend(payload)
        elif kind == b"IEND":
            require(length == 0 and stop == len(data), "invalid_image", "Invalid PNG ending.")
            ended = True
        elif kind[:1].isupper() and kind != b"PLTE":
            raise GateError("invalid_image", "Unrecognized critical PNG chunk.")
        chunks.append(kind)
        offset = stop
        if ended:
            break
    require(ended and compressed, "invalid_image", "PNG is missing image data or IEND.")
    require(color != 3 or b"PLTE" in chunks, "invalid_image", "Indexed PNG has no palette.")
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[color]
    passes = [(0, 0, 1, 1)] if not interlace else [
        (0, 0, 8, 8), (4, 0, 8, 8), (0, 4, 4, 8), (2, 0, 4, 4),
        (0, 2, 2, 4), (1, 0, 2, 2), (0, 1, 1, 2)]
    rows, expected = [], 0
    for x, y, dx, dy in passes:
        w, h = max(0, (width - x + dx - 1) // dx), max(0, (height - y + dy - 1) // dy)
        if w and h:
            stride = 1 + (w * channels * depth + 7) // 8
            rows.append((h, stride))
            expected += h * stride
    require(expected <= MAX_IMAGE_BYTES, "image_too_large", "Decoded PNG exceeds the validation memory limit.")
    decoder = zlib.decompressobj()
    decoded = decoder.decompress(bytes(compressed), expected + 1)
    require(len(decoded) == expected and decoder.eof and not decoder.unused_data
            and not decoder.unconsumed_tail, "invalid_image", "Invalid PNG compressed pixels.")
    cursor = 0
    for count, stride in rows:
        for _ in range(count):
            require(decoded[cursor] <= 4, "invalid_image", "Invalid PNG scanline filter.")
            cursor += stride
    return width, height


def jpeg_dimensions(data):
    require(data[:2] == b"\xff\xd8", "invalid_image", "Invalid JPEG signature.")
    offset, width, height, saw_scan, entropy = 2, None, None, False, 0
    sof_markers = {0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf}
    while offset < len(data):
        require(data[offset] == 0xff, "invalid_image", "Invalid JPEG marker boundary.")
        while offset < len(data) and data[offset] == 0xff:
            offset += 1
        require(offset < len(data), "invalid_image", "Truncated JPEG marker.")
        marker = data[offset]
        offset += 1
        if marker == 0xd9:
            require(offset == len(data) and width and height and saw_scan and entropy,
                    "invalid_image", "Incomplete JPEG image.")
            return width, height
        require(marker not in {0, 0xd8, 0x01, *range(0xd0, 0xd8)},
                "invalid_image", "Unexpected standalone JPEG marker.")
        require(offset + 2 <= len(data), "invalid_image", "Truncated JPEG segment.")
        size = struct.unpack_from(">H", data, offset)[0]
        require(size >= 2 and offset + size <= len(data), "invalid_image", "Invalid JPEG segment length.")
        payload = data[offset + 2:offset + size]
        offset += size
        if marker in sof_markers:
            require(width is None and len(payload) >= 6, "invalid_image", "Invalid JPEG frame.")
            height, width = struct.unpack_from(">HH", payload, 1)
            components = payload[5]
            require(width > 0 and height > 0 and components > 0 and len(payload) == 6 + 3 * components,
                    "invalid_image", "Invalid JPEG frame dimensions/components.")
        if marker == 0xda:
            require(width and height and payload and len(payload) == 4 + 2 * payload[0],
                    "invalid_image", "Invalid JPEG scan header.")
            saw_scan = True
            while offset < len(data):
                if data[offset] != 0xff:
                    entropy += 1
                    offset += 1
                    continue
                next_offset = offset + 1
                while next_offset < len(data) and data[next_offset] == 0xff:
                    next_offset += 1
                require(next_offset < len(data), "invalid_image", "Truncated JPEG scan.")
                if data[next_offset] == 0 or 0xd0 <= data[next_offset] <= 0xd7:
                    entropy += 1
                    offset = next_offset + 1
                else:
                    break
    raise GateError("invalid_image", "JPEG has no complete end marker.")


def image_dimensions(data):
    require(0 < len(data) <= MAX_IMAGE_BYTES, "invalid_image", "Image is empty or exceeds the validation size limit.")
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return png_dimensions(data)
    if data.startswith(b"\xff\xd8"):
        return jpeg_dimensions(data)
    raise GateError("invalid_image", "Image bytes must be PNG or JPEG; a filename alone is not evidence.")


def validate_manifest(path):
    manifest = strict_json(path.read_text(encoding="utf-8"))
    require(isinstance(manifest, dict), "invalid_manifest", "Manifest must be a JSON object.")
    require(type(manifest.get("schema_version")) is int and manifest["schema_version"] == 1,
            "invalid_manifest", "schema_version must be 1.")
    count, revision, pages = manifest.get("expected_pages"), manifest.get("content_revision"), manifest.get("pages")
    require(positive_int(count) and nonempty(revision), "invalid_manifest", "Expected page count and content revision are required.")
    require(isinstance(pages, list) and len(pages) == count,
            "missing_pages", "Manifest must contain exactly the confirmed number of pages.")
    seen_refs, seen_hashes, records = set(), {}, []
    for number, page in enumerate(pages, 1):
        require(isinstance(page, dict) and type(page.get("page_number")) is int and page["page_number"] == number,
                "page_order", "Manifest page numbers must be contiguous and in original order.", number)
        require(page.get("content_revision") == revision, "stale_revision", "Page image belongs to a different content revision.", number)
        kind = page.get("source_kind")
        require(kind in {"generated_full_page", "approved_original_page"}, "invalid_source", "Page has no valid full-page source kind.", number)
        if kind == "generated_full_page":
            ref = page.get("generation_ref")
            require(nonempty(ref), "missing_generation", "Generated page needs an actual generation result reference.", number)
            require(ref.strip() not in seen_refs, "reused_generation", "The same generation result was assigned to multiple pages.", number)
            seen_refs.add(ref.strip())
        else:
            require(nonempty(page.get("authorization")), "missing_authorization", "Original-page reuse needs explicit page-specific authorization.", number)
        image_path, digest = page.get("image_path"), page.get("image_sha256")
        require(nonempty(image_path) and isinstance(digest, str) and re.fullmatch(r"[0-9a-fA-F]{64}", digest),
                "invalid_image_record", "Image path and SHA256 are required.", number)
        source = Path(image_path)
        if not source.is_absolute():
            source = path.parent / source
        require(source.is_file(), "missing_image", "Recorded page image file is not available.", number)
        data = source.read_bytes()
        try:
            dimensions = image_dimensions(data)
        except GateError as error:
            error.page = number
            raise
        actual = hashlib.sha256(data).hexdigest()
        require(actual == digest.lower(), "image_hash_mismatch", "Image bytes differ from the recorded SHA256.", number)
        require(actual not in seen_hashes or (kind == "approved_original_page" and seen_hashes[actual] == kind),
                "reused_image", "Generated full-page image bytes were reused for another page.", number)
        seen_hashes[actual] = kind
        records.append({"page_number": number, "image_sha256": actual, "dimensions": dimensions})
    return count, revision, records


def xml_bytes(data):
    require(b"<!DOCTYPE" not in data.upper() and b"<!ENTITY" not in data.upper(),
            "invalid_xml", "DTD/entity declarations are not allowed in package XML.")
    return ET.fromstring(data)


def rel_path(part):
    folder, name = posixpath.split(part)
    return posixpath.join(folder, "_rels", name + ".rels")


def resolve_part(source, target):
    require(nonempty(target), "invalid_relationship", "Relationship target is missing.")
    parsed = urllib.parse.urlsplit(target)
    require(not parsed.scheme and not parsed.netloc and not parsed.query and not parsed.fragment,
            "invalid_relationship", "Internal relationship must target a package part.")
    decoded = urllib.parse.unquote(parsed.path)
    require("\\" not in decoded and "\x00" not in decoded, "invalid_relationship", "Invalid relationship target path.")
    result = posixpath.normpath(decoded.lstrip("/") if decoded.startswith("/") else posixpath.join(posixpath.dirname(source), decoded))
    require(result not in {".", ".."} and not result.startswith("../"), "invalid_relationship", "Relationship escapes package root.")
    return result


def bool_true(value):
    return value in {"1", "true"}


def numeric(value, label):
    require(isinstance(value, str) and re.fullmatch(r"-?\d+", value), "invalid_geometry", "Invalid " + label + ".")
    return int(value)


def no_transform_effects(node):
    require(node.get("rot", "0") == "0" and node.get("flipH", "0") in {"0", "false"}
            and node.get("flipV", "0") in {"0", "false"}, "image_transform", "Page image is rotated or flipped.")


def zero_rect(node):
    return all(numeric(node.get(key, "0"), "crop/fill rectangle") == 0 for key in ("l", "t", "r", "b"))


def check_picture(pic, width, height, ns):
    p, a, r = ns
    require(all(not bool_true(node.get("hidden")) for node in pic.iter()), "hidden_image", "Page image is hidden.")
    require(len(pic) == 3 and len(pic.findall("{%s}nvPicPr" % p)) == 1
            and all(node.tag in {"{%s}nvPicPr" % p, "{%s}blipFill" % p, "{%s}spPr" % p} for node in pic),
            "image_effect", "Page picture contains unsupported styling or rendering extensions.")
    props = pic.findall("{%s}spPr" % p)
    fills = pic.findall("{%s}blipFill" % p)
    require(len(props) == 1 and len(fills) == 1, "invalid_picture", "Page picture needs one shape and one image fill.")
    allowed = {"xfrm", "prstGeom", "noFill", "ln", "effectLst"}
    for child in props[0]:
        require(child.tag in {"{%s}%s" % (a, name) for name in allowed}, "image_effect", "Unsupported picture geometry or visual effect.")
        if child.tag == "{%s}prstGeom" % a:
            require(child.get("prst") == "rect" and all(not list(node) for node in child), "image_effect", "Full-page picture must use unadjusted rectangle geometry.")
        elif child.tag == "{%s}ln" % a:
            require(child.find("{%s}noFill" % a) is not None and all(node.tag == "{%s}noFill" % a for node in child), "image_effect", "Page picture has a visible border or line effect.")
        elif child.tag == "{%s}effectLst" % a:
            require(not list(child), "image_effect", "Page picture has visual effects.")
    transforms = props[0].findall("{%s}xfrm" % a)
    require(len(transforms) == 1, "invalid_geometry", "Page picture requires explicit geometry.")
    xfrm = transforms[0]
    no_transform_effects(xfrm)
    require(len(xfrm.findall("{%s}off" % a)) == 1 and len(xfrm.findall("{%s}ext" % a)) == 1 and len(xfrm) == 2,
            "invalid_geometry", "Page picture requires one offset and one extent.")
    off, ext = xfrm.find("{%s}off" % a), xfrm.find("{%s}ext" % a)
    x, y = numeric(off.get("x"), "image x"), numeric(off.get("y"), "image y")
    cx, cy = numeric(ext.get("cx"), "image width"), numeric(ext.get("cy"), "image height")
    require(cx > 0 and cy > 0 and abs(x) <= width * .001 and abs(y) <= height * .001
            and abs(cx - width) <= width * .001 and abs(cy - height) <= height * .001,
            "not_full_page", "Picture does not cover the entire slide without repositioning.")
    fill = fills[0]
    require(all(child.tag in {"{%s}blip" % a, "{%s}srcRect" % a, "{%s}stretch" % a} for child in fill),
            "image_effect", "Picture has an unsupported or tiled fill.")
    blips, stretches = fill.findall("{%s}blip" % a), fill.findall("{%s}stretch" % a)
    require(len(blips) == 1 and len(stretches) == 1, "invalid_picture", "Picture must stretch one embedded image to its full frame.")
    for crop in fill.findall("{%s}srcRect" % a):
        require(zero_rect(crop), "cropped_image", "Full-page image cannot crop away content.")
    stretch = stretches[0]
    require(len(stretch) == 1 and stretch[0].tag == "{%s}fillRect" % a and zero_rect(stretch[0]),
            "cropped_image", "Image fill cannot crop or offset page content.")
    blip = blips[0]
    require(not blip.get("{%s}link" % r), "external_image", "Page image must be embedded, not externally linked.")
    # The harmless DPI extension is commonly emitted by Office; no rendering effects.
    for child in blip:
        require(child.tag == "{%s}extLst" % a, "image_effect", "Image color/opacity/rendering effects are not allowed.")
        for ext_node in child:
            require(ext_node.tag == "{%s}ext" % a and all(node.tag == "{http://schemas.microsoft.com/office/drawing/2010/main}useLocalDpi" for node in ext_node),
                    "image_effect", "Unsupported image rendering extension.")
    embedded = blip.get("{%s}embed" % r)
    require(nonempty(embedded), "missing_embedded_image", "Page has no embedded image reference.")
    return embedded


def validate_pptx(path, count, records):
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        names = [item.filename for item in infos]
        require(len(names) == len(set(names)), "duplicate_zip_member", "PPTX contains duplicate ZIP member names.")
        for name in names:
            parts = name.rstrip("/").split("/")
            require(name and not name.startswith("/") and "\\" not in name and "\x00" not in name
                    and all(part not in {"", ".", ".."} for part in parts), "invalid_zip_path", "PPTX contains an unsafe ZIP member path.")
        require(archive.testzip() is None, "zip_crc", "PPTX ZIP integrity check failed.")
        require("[Content_Types].xml" in names and "_rels/.rels" in names,
                "invalid_pptx", "PPTX is missing required package content types or root relationships.")
        types_root = xml_bytes(archive.read("[Content_Types].xml"))
        require(types_root.tag == "{%s}Types" % CT, "invalid_content_types", "Invalid package content-types document.")
        defaults, overrides = {}, {}
        for node in types_root:
            mime = node.get("ContentType")
            require(nonempty(mime), "invalid_content_types", "Package content type is missing.")
            if node.tag == "{%s}Default" % CT:
                extension = node.get("Extension")
                require(nonempty(extension) and not any(char in extension for char in "/\\.")
                        and extension.lower() not in defaults, "invalid_content_types", "Invalid or duplicate extension content type.")
                defaults[extension.lower()] = mime
            elif node.tag == "{%s}Override" % CT:
                part_name = node.get("PartName")
                require(nonempty(part_name) and part_name.startswith("/"), "invalid_content_types", "Invalid content-type part name.")
                part_name = resolve_part("", part_name)
                require(part_name not in overrides, "invalid_content_types", "Duplicate part content type.")
                overrides[part_name] = mime
            else:
                raise GateError("invalid_content_types", "Unknown package content-type element.")

        def content_type(part):
            return overrides.get(part, defaults.get(posixpath.splitext(part)[1][1:].lower()))

        relationships = {}
        for name in names:
            if name.endswith(".rels"):
                tree = xml_bytes(archive.read(name))
                require(tree.tag == "{%s}Relationships" % PR, "invalid_relationship", "Invalid relationships document.")
                rels = {}
                for node in tree:
                    require(node.tag == "{%s}Relationship" % PR, "invalid_relationship", "Unknown relationship element.")
                    key = node.get("Id")
                    require(nonempty(key) and key not in rels and nonempty(node.get("Type")) and nonempty(node.get("Target")),
                            "duplicate_relationship", "Relationship ID is duplicate or metadata is missing.")
                    require(node.get("TargetMode", "Internal") in {"Internal", "External"}, "invalid_relationship", "Unknown relationship target mode.")
                    rels[key] = node.attrib
                relationships[name] = rels
        office_documents = [rel for rel in relationships.get("_rels/.rels", {}).values()
                            if rel.get("Type") in REL_TYPES["officeDocument"]]
        require(len(office_documents) == 1 and office_documents[0].get("TargetMode", "Internal") == "Internal"
                and resolve_part("", office_documents[0].get("Target")) == "ppt/presentation.xml",
                "invalid_pptx", "Root officeDocument relationship must identify this presentation.")
        require("ppt/presentation.xml" in names, "invalid_pptx", "PPTX presentation part is missing.")
        require(content_type("ppt/presentation.xml") == PRESENTATION_MIME,
                "invalid_content_types", "Presentation part is not declared as a PPTX presentation.")
        root = xml_bytes(archive.read("ppt/presentation.xml"))
        ns = (P, A, R)
        if root.tag == "{http://purl.oclc.org/ooxml/presentationml/main}presentation":
            ns = ("http://purl.oclc.org/ooxml/presentationml/main", "http://purl.oclc.org/ooxml/drawingml/main", "http://purl.oclc.org/ooxml/officeDocument/relationships")
        p, a, r = ns
        require(root.tag == "{%s}presentation" % p, "invalid_pptx", "Invalid presentation root.")
        sizes, lists = root.findall("{%s}sldSz" % p), root.findall("{%s}sldIdLst" % p)
        require(len(sizes) == 1 and len(lists) == 1, "invalid_pptx", "Presentation needs one slide size and one ordered slide list.")
        width, height = numeric(sizes[0].get("cx"), "slide width"), numeric(sizes[0].get("cy"), "slide height")
        require(width > 0 and height > 0 and abs(width / height / (16 / 9) - 1) <= .001,
                "slide_aspect", "Image-mode deck must use 16:9 slides.")
        slides = list(lists[0])
        require(len(slides) == count and all(node.tag == "{%s}sldId" % p for node in slides),
                "slide_count", "PPTX slide count differs from confirmed page count.")
        presentation_rels = relationships.get(rel_path("ppt/presentation.xml"), {})
        seen_ids, seen_parts, errors, verified = set(), set(), [], 0
        for number, slide_id in enumerate(slides, 1):
            try:
                identifier = slide_id.get("id")
                require(nonempty(identifier) and identifier not in seen_ids, "duplicate_slide", "Slide ID is missing or reused.")
                seen_ids.add(identifier)
                relation = presentation_rels.get(slide_id.get("{%s}id" % r), {})
                require(relation.get("Type") in REL_TYPES["slide"] and relation.get("TargetMode", "Internal") == "Internal",
                        "invalid_relationship", "Slide relation is missing, external or not a slide.")
                part = resolve_part("ppt/presentation.xml", relation.get("Target"))
                require(part in names and part not in seen_parts, "duplicate_slide", "Slide part is missing or reused.")
                require(content_type(part) == SLIDE_MIME, "invalid_content_types", "Slide part is not declared as a presentation slide.")
                seen_parts.add(part)
                slide = xml_bytes(archive.read(part))
                require(slide.tag == "{%s}sld" % p and slide.get("show", "1") in {"1", "true"},
                        "hidden_slide", "Slide is hidden or has an invalid root.")
                trees = slide.findall("{%s}cSld/{%s}spTree" % (p, p))
                require(len(trees) == 1, "invalid_slide", "Slide needs exactly one shape tree.")
                tree = trees[0]
                require(all(not bool_true(node.get("hidden")) for node in tree.iter()),
                        "hidden_image", "Slide group or page image is hidden.")
                pictures = tree.findall("{%s}pic" % p)
                require(len(pictures) == 1, "image_count", "Each slide must contain exactly one full-page image.")
                require(all(node.tag in {"{%s}nvGrpSpPr" % p, "{%s}grpSpPr" % p, "{%s}pic" % p} for node in tree),
                        "native_objects", "Text, shapes, groups, tables or other drawable objects cannot replace or overlay a full-page image.")
                for group in tree.findall("{%s}grpSpPr" % p):
                    require(all(node.tag == "{%s}xfrm" % a for node in group), "image_effect", "Slide group has rendering effects.")
                    for transform in group:
                        no_transform_effects(transform)
                        require(len(transform) == 4, "invalid_geometry", "Invalid slide group transform.")
                        for first, second, keys in [("off", "chOff", ("x", "y")), ("ext", "chExt", ("cx", "cy"))]:
                            left, right = transform.findall("{%s}%s" % (a, first)), transform.findall("{%s}%s" % (a, second))
                            require(len(left) == len(right) == 1 and all(numeric(left[0].get(key), "group transform") == numeric(right[0].get(key), "group transform") for key in keys),
                                    "image_transform", "Slide group transform changes picture geometry.")
                image_id = check_picture(pictures[0], width, height, ns)
                image_rel = relationships.get(rel_path(part), {}).get(image_id, {})
                require(image_rel.get("Type") in REL_TYPES["image"] and image_rel.get("TargetMode", "Internal") == "Internal",
                        "external_image", "Image relationship is missing, external or not an image.")
                media = resolve_part(part, image_rel.get("Target"))
                require(media in names, "missing_media", "Embedded image part is missing.")
                data = archive.read(media)
                expected_mime = "image/png" if data.startswith(b"\x89PNG\r\n\x1a\n") else "image/jpeg"
                require(content_type(media) == expected_mime, "invalid_content_types", "Embedded image content type does not match its image bytes.")
                require(hashlib.sha256(data).hexdigest() == records[number - 1]["image_sha256"],
                        "embedded_image_mismatch", "Slide image does not match its recorded page image and order.")
                verified += 1
            except GateError as error:
                error.page = number
                errors.append(error.as_dict())
        return verified, errors


def main():
    result = {"passed": False, "expected_pages": None, "verified_pages": 0, "errors": []}
    try:
        require(len(sys.argv) == 3, "usage", "Usage: validate-image-deck.py MANIFEST_JSON DECK_PPTX")
        manifest_path, deck_path = Path(sys.argv[1]), Path(sys.argv[2])
        count, revision, records = validate_manifest(manifest_path)
        result["expected_pages"] = count
        result["verified_pages"], result["errors"] = validate_pptx(deck_path, count, records)
        result["passed"] = not result["errors"] and result["verified_pages"] == count
        if result["passed"]:
            result["content_revision"] = revision
            result["pages"] = count
            result["pptx_sha256"] = hashlib.sha256(deck_path.read_bytes()).hexdigest()
            result["manifest_sha256"] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    except GateError as error:
        result["errors"].append(error.as_dict())
    except (OSError, ValueError, TypeError, KeyError, ET.ParseError, zipfile.BadZipFile, zlib.error, struct.error, RuntimeError) as error:
        result["errors"].append({"code": "unreadable_or_malformed_input", "message": type(error).__name__ + ": unable to validate the supplied files."})
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    sys.exit(main())
