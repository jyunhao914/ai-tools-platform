# 圖像式完整頁面與交付檢查

本文件的逐頁佇列與結構檢查只適用③保留內容重新設計的圖像式輸出；①②與可編輯式的製作路徑不變，三模式均遵守工作模式入口。這是製作內部步驟，不新增使用者設定或確認選單，也不要求使用者操作程式。Google Drive上傳與匯入參數完全沿用studio-production的PPTX交接規則。

## 生圖前準備

先依 ../../studio-flow/references/work-handoff.md 確認已在工作模式，再依studio-production的能力查找，確認本回合正式生圖、實際圖片傳遞、PPTX組裝、Python檢查及Drive交接可用，才開始生圖。這是製作前的入口與能力核對，不能假定進入工作模式就取得所有工具。沒有必要工具時回報實際缺項，不要求使用者連回電腦或安裝環境，也不回到對話模式繞過入口。

從本版正式技能資源取得scripts/image-page-queue.py與scripts/validate-image-deck.py，原樣放入同一個已核對可用的執行環境、同一目錄。已有正式掛載就沿用；skill://是資源識別而非本機路徑。只按實際工具簽章執行，不硬編某個執行工具名稱或作者電腦路徑。腳本只處理任務與檔案，並不提供生圖／雲端工具，也不會自行呼叫它們。

依已確認正文建立內部JOB_JSON。以下只展示欄位；實際pages須完整列出原稿1至N頁，逐頁text保存全部原文或已採用潤稿，不重新摘要、不變更頁數／頁序：

```json
{
  "schema_version": 1,
  "content_revision": "本次已確認內容與風格修訂",
  "style_prompt": "共用配色、字體與視覺規則，不含整份簡報正文或多頁總覽要求",
  "image_policy": "本次已選的頁內圖片政策",
  "expected_pages": 1,
  "pages": [
    {
      "page_number": 1,
      "text": "本頁完整已確認正文",
      "references": [],
      "source_kind": "generated_full_page"
    }
  ]
}
```

references只放本頁真實素材引用，不放整份原稿的多頁畫面。原稿無文字的頁面明確保留text為空字串，不補造標題或說明、不刪頁。共用風格只含視覺規則；資訊圖表及其他必要參考沿用既有逐頁素材政策。使用者明確授權某頁原樣保留時才填source_kind=approved_original_page及authorization，不將一般「沿用原圖」當成整頁保留授權。

在上述執行環境先執行以下命令；scripts路徑以實際取得腳本的位置為準：

```text
python3 scripts/image-page-queue.py init JOB_JSON STATE_JSON
python3 scripts/image-page-queue.py next JOB_JSON STATE_JSON
```

init保存工作雜湊且拒絕覆寫不同任務；next只傳回第一個未完成頁的page_number、request_id、prompt及本頁references。頁數等進度欄位留在內部紀錄，不追加進生圖提示。prompt只含目前一頁的正文與共用設定；不得將完整JOB_JSON、其他頁正文或全份頁面總覽要求送給生圖。原稿文字即使包含「九宮格」等字樣也須完整保留，不以關鍵字刪除正文。

## 單頁派送與接續

1. action=generate_page時，實際呼叫正式ChatGPT Images，只使用目前頁prompt及必要的本頁素材。action=reuse_original_page僅按明確授權取用原頁，不能當成新生成。只產生一張獨立16:9投影片；不將一次九宮格生成或裁切總覽算作N頁。
2. 將當次真實圖片取得到相同執行環境；依實際結果記錄RECEIPT_JSON，包含page_number、next回傳的request_id、實際image_path、正式generation_ref及layout。只有實際結果是單張投影片時才填layout=single_slide；已知是overview、contact_sheet、multi_slide或純配圖時不填single_slide。原樣保留頁不假造generation_ref。
3. 執行`python3 scripts/image-page-queue.py record JOB_JSON STATE_JSON RECEIPT_JSON`。須退出碼0及ok=true才接下一次next；圖片未取得、內容／風格修訂不符、頁碼錯置、生成引用重複或已知總覽不得推進。相同成功紀錄重送為冪等，不重複生圖。失敗保存具體原因與既有結果，不捏造完成狀態。
4. 重複next／實際生圖或已授權沿用／record，直到action=assemble。不在第一張預覽或部分頁完成時結束回合再詢問是否繼續。一般執行已有全部頁製作授權；依工作模式接續規則修復已知未完成頁，只有使用者取消／暫停、必要授權未完成、工具實際失敗、執行限制或限定修復仍失敗才停止並記錄未完成頁。
5. 執行`python3 scripts/image-page-queue.py export JOB_JSON STATE_JSON MANIFEST_JSON`。未取得全部頁面圖不得匯出；export重查實檔與雜湊，產生下方驗證器使用的manifest。不得手動補寫缺頁以繞過佇列。腳本不能證明生圖工具曾被呼叫，也不自動辨識像素中的九宮格；layout是根據真實結果的觀察紀錄，不能當成程式視覺驗證。

接續沿用同一JOB_JSON與STATE_JSON，不清空成功頁。已有真實page_results但尚無佇列時，按頁序在輪到該頁時記錄已核對、未變的既有結果，不假稱重新生成，也不重生已有成功頁。若中間缺頁，先完成該缺頁，再沿用後續既有頁。正文或風格修訂改變時建立新工作狀態，保留舊版；只沿用核對後未受影響的頁面，修改頁按新正文製作。跨環境只保存／取回正式檔案與引用，臨時路徑不可直接冒充新環境可讀檔案。

## 逐頁完成

按已確認頁數與頁序保留page_results，每頁記錄目前內容／風格修訂、完整生圖提示、正式生成結果引用、實際取得的頁面圖路徑與SHA256。提示須含該頁完整已確認正文，不能只生成配圖。引用及路徑都必須來自本次真實結果，不以檔名、口頭宣稱或編造ID充數，不保存憑證、短效網址或大量base64。

完成頁＝完整頁面圖已取得並對應本頁；純文字、結論、參考資料與署名頁同樣計入。只有配圖、空白圖、待生成占位、文字物件或未經授權挪用其他頁圖片均不算完成。一般每頁由ChatGPT Images直接生成；只有使用者明確要求該頁原樣保留，才沿用該頁已取得的完整原頁圖並記錄授權。此例外不允許在圖像式上另疊文字或物件。

既有授權下接續全部未完成頁，不因已完成部分生圖而提前結束。全部所需頁面圖到齊才組裝完整PPTX。若工具明確失敗或無法接續，保存既有結果與未完成頁碼，如實說明停點；不得用文字補位，不默默改形式、減頁或把半成品交付後要求使用者自行完成。只有使用者明確要求查看部分成果時才提供且標明未完成，不將其記為正式交付。已知缺字或內容錯置的頁面亦不得冒稱完成；依 ../../studio-flow/references/work-handoff.md 只修復該頁，同一已知問題最多自動修正兩次，未受影響頁沿用。已寫入不可覆寫receipt時保留舊attempt，建立新的接續狀態並沿用其他成功頁，不竄改舊紀錄。這不另加例行評分、逐字OCR或已完成頁的自動重生流程。

## 結構檢查

組裝時只把對應頁面圖放入對應投影片，鋪滿16:9頁面，不裁切內容、不重排文字。使用上述export成功產生的內部manifest.json；以下為輸出欄位結構，不得依範例手填完成紀錄：

```json
{
  "schema_version": 1,
  "content_revision": "本次已確認內容與風格修訂",
  "expected_pages": 1,
  "pages": [
    {
      "page_number": 1,
      "content_revision": "與上方相同的修訂",
      "image_path": "實際頁面圖路徑",
      "image_sha256": "從實檔計算的SHA256",
      "source_kind": "generated_full_page",
      "generation_ref": "正式生成結果實際回傳的引用"
    }
  ]
}
```

pages必須按1到expected_pages完整列出。相對image_path以manifest所在資料夾為準。原樣保留的例外頁用source_kind=approved_original_page及authorization欄記錄使用者對該頁的明確授權，不假造generation_ref；一般生成頁不使用此例外。content_revision是本次已確認內容與風格的工作修訂，不覆寫原稿或改變潤稿採用規則。

在本回合已用來組裝PPTX的執行環境執行：

```text
python3 scripts/validate-image-deck.py MANIFEST_JSON DECK_PPTX
```

scripts路徑以本技能目錄為準；雲端沒有掛載時，從正式技能資源取得本版腳本，原樣保存到同一執行環境。不得把skill://當本機路徑，不要求連回使用者電腦，不部署新服務。腳本僅用Python標準函式庫；缺少可用執行能力或驗證失敗就保留進度與具體缺項，不能跳過檢查宣稱完成。

只有退出碼0及passed=true才允許正式匯入：預期頁數、頁序、修訂一致；每頁圖實檔非空、PNG/JPEG有效、SHA256相符；PPTX內每頁恰有一張對應的完整頁面圖，圖片鋪滿頁面、沒有裁切／旋轉或額外文字與物件。錯頁圖片、重複生成結果或不足頁面均須阻擋；使用者明確原樣保留的重複原稿頁不因圖片SHA256相同而排除。它檢查檔案與物件結構，不能證明圖片中的文字零誤差或醫療正確，也不能把程式畫的圖偽報成ChatGPT Images結果。

保留檢查結果與PPTX SHA256；驗證後修改PPTX或manifest，原檢查即失效，須重新執行。檔案封裝問題修正封裝即可，不重生既有圖片；未完成生圖則接續缺頁。完成後沿用原PPTX交接流程，並讀回原生Slides，確認頁數／頁序／尺寸與每頁完整圖片物件；不能只靠檔案ID或上傳成功結案。
