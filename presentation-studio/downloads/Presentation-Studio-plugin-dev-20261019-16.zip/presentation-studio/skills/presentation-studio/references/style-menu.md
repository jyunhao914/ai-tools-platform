# 網頁版風格縮圖

雲端 skills.read 可讀文字，但本次網頁驗收無法讀取 JPG 資源。不要用它反覆讀二進位圖片，也不要把讀取失敗說成使用者未安裝。以下是已公開且逐一比對與包內完全一致的內建預覽；使用者的私人風格不能上傳公開網站。

首次選風格，讀取 [固定預覽對應](preview-manifest.json) 與 `scripts/style_preview.py`，在雲端執行環境保存這兩份文字資源。指定可用的中文字型，使用該程式下載及組合總覽：`python style_preview.py --manifest preview-manifest.json --font <中文字型路徑> --output styles.png`。程式按明確編號配對、核對每張 SHA-256，不能按下載完成順序或目錄排序重配標籤。下載或校驗失敗保留實際錯誤，不補別張圖。它會合成帶 01–15 編號與中文名稱的總覽 PNG，使用平台支援的圖片附件呈現，並附上可開啟的總覽檔案。網頁實測已發現外部 Markdown 圖片顯示空白，不先走這個已失敗的呈現方法。下列網址是下載來源，不是要直接複製成外部圖片回覆。可重用已下載且完整的總覽，不必每次重抓。只下載與合成既有圖，不呼叫 ImageGen 重造預覽。沒有展示成功不能宣稱縮圖已顯示；工具不可用時說明實際錯誤並提供既有公開風格頁連結 https://jyunhao914.github.io/ai-tools-platform/gpt-slides/ 。

01｜明亮暖色

![01 明亮暖色](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s01.jpg)

02｜藍色醫療

![02 藍色醫療](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s02.jpg)

03｜粉紅醫療

![03 粉紅醫療](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s03.jpg)

04｜白底深藍

![04 白底深藍](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s04.jpg)

05｜高科技

![05 高科技](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s05.jpg)

06｜極簡黑白

![06 極簡黑白](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s06.jpg)

07｜企業提案

![07 企業提案](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s07.jpg)

08｜手繪溫暖

![08 手繪溫暖](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s08.jpg)

09｜雜誌編輯

![09 雜誌編輯](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s09.jpg)

10｜日系極簡

![10 日系極簡](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s10.jpg)

11｜兒童繪本

![11 兒童繪本](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s11.jpg)

12｜黑板粉筆

![12 黑板粉筆](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s12.jpg)

13｜漫畫分鏡

![13 漫畫分鏡](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s13.jpg)

14｜復古台味

![14 復古台味](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s14.jpg)

15｜自然療癒

![15 自然療癒](https://jyunhao914.github.io/ai-tools-platform/gpt-slides/thumbs/s15.jpg)

同時提供：0 自動（依內容與受眾設計）、自訂（使用者描述）、我的風格（從已保存的 Studio 設定找到私人風格庫，重新讀取名稱與預覽）。僅推薦幾個風格不能取代完整選單。
