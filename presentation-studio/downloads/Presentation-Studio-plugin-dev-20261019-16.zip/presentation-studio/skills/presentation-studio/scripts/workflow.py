"""Portable intake, write recovery and delivery checks. No network or credentials.

Run outside the artifact callback: a viewer flush error can be returned by the
host after that callback has succeeded. Pass actual tool receipts/readbacks,
not a guessed success flag. The caller performs each returned next action.
"""
import argparse
import copy
import hashlib
import json
import re
import unicodedata
import zipfile
from pathlib import Path
import xml.etree.ElementTree as ET


def intake(groups):
    """Only missing choices; one option per line, suitable for narrow chats."""
    blocks = []
    for group in groups:
        if group.get('selected') is not None:
            continue
        title = group['title'].strip()
        options = group['options']
        if not title or not options:
            raise ValueError('Missing question or options')
        lines = [f'**{title}**', '']
        if group.get('context'):
            lines.extend([group['context'].strip(), ''])
        for option in options:
            label = option['label'].strip()
            if not label or '\n' in label:
                raise ValueError('An option must be one short label')
            lines.append(f"- {option['id']}．{label}")
        blocks.append('\n'.join(lines))
    return '\n\n'.join(blocks)


def resolve_choices(groups, reply):
    """Resolve codes and explicit meaning aliases without guessing an ambiguous choice.

    The host may interpret other paraphrases, then validate against the same
    option IDs. This parser never changes content permissions via fuzzy spelling.
    """
    normalize=lambda s: unicodedata.normalize('NFKC',s).casefold().strip()
    text=normalize(reply)
    hits=[]; denials=[]
    def negated(start):
        return bool(re.search(r'(不要|不用|不想|不需要|別|不)\s*$',text[max(0,start-5):start]))
    for group in groups:
        for option in group['options']:
            code=normalize(str(option['id']))
            for found in re.finditer(r'(?<![\w])'+re.escape(code)+r'(?![\w])',text):
                (denials if negated(found.start()) else hits).append((found.start(),found.end(),group['id'],option['id']))
            for phrase in [option['label'],*option.get('aliases',[])]:
                phrase=normalize(phrase)
                if not phrase:continue
                for found in re.finditer(re.escape(phrase),text):
                    (denials if negated(found.start()) else hits).append((found.start(),found.end(),group['id'],option['id']))
    # A full phrase such as "不要微調" takes precedence over the word "微調".
    hits=[h for h in hits if not any(k[0]<=h[0] and k[1]>=h[1] and k[1]-k[0]>h[1]-h[0] for k in hits)]
    denials=[h for h in denials if not any(k[0]<=h[0] and k[1]>=h[1] and k[1]-k[0]>h[1]-h[0] for k in hits)]
    selected,ambiguous,missing={}, {}, []
    for group in groups:
        choices={h[3] for h in hits if h[2]==group['id']}
        denied={h[3] for h in denials if h[2]==group['id']}
        if choices & denied:ambiguous[group['id']]=sorted(choices)
        elif len(choices)==1:selected[group['id']]=next(iter(choices))
        elif len(choices)>1:ambiguous[group['id']]=sorted(choices)
        elif group.get('selected') is not None and group['selected'] not in denied:selected[group['id']]=group['selected']
        else:missing.append(group['id'])
    return {'selected':selected,'ambiguous':ambiguous,'missing':missing}


def begin_write(document_id, operation_id, expected, before):
    """Bind one write to its destination and selected content before dispatch."""
    if not document_id or not operation_id or not expected or not before:
        raise ValueError('Missing write identity, content fingerprint or baseline')
    return {'document_id': document_id, 'operation_id': operation_id,
            'expected': copy.deepcopy(expected), 'before': copy.deepcopy(before),
            'attempts': 1, 'phase': 'WRITING', 'history': []}


def classify_error(message):
    text = message.casefold()
    # Hard failures take precedence even if another line also says timeout.
    if re.search(r'permission denied|access denied|forbidden|unauthorized|安全拒絕|safety refusal|quota|rate.limit|額度|權限拒絕', text):
        return 'BLOCKED'
    if 'external document is no longer open' in text or 'connection expired' in text:
        return 'RECONNECT'
    if re.search(r'viewer flush failed|timed out|timeout|逾時', text):
        return 'READ_BACK'
    return 'INSPECT_ERROR'


def recover_write(state, evidence):
    """A bounded state machine. A readback never authorizes a blind replay.

    Evidence events: failure, transaction, readback, dispatched. For readback,
    comparison is MATCH (expected write present), ABSENT (baseline unchanged),
    or CONFLICT. It must be derived by inspecting the actual objects/content.
    """
    out = copy.deepcopy(state)
    if evidence.get('document_id') != out['document_id'] or evidence.get('operation_id') != out['operation_id']:
        raise ValueError('Evidence belongs to a different document or operation')
    kind = evidence.get('kind')
    phase = out['phase']
    if phase in {'COMPLETE', 'BLOCKED', 'CONFLICT'}:
        raise ValueError('This recovery is already terminal')
    if kind == 'failure':
        if phase != 'WRITING':
            raise ValueError('No write is awaiting a result')
        if not evidence.get('message') or not evidence.get('receipt_id'):
            raise ValueError('Keep the actual failed tool receipt')
        action = classify_error(evidence['message'])
        out['phase'] = action
        # Resolve any in-flight transaction before considering a new write.
        if action not in {'BLOCKED', 'INSPECT_ERROR'} and evidence.get('transaction_id'):
            out['transaction_id'] = evidence['transaction_id']
            out['phase'] = 'CHECK_TRANSACTION'
    elif kind == 'transaction':
        if phase != 'CHECK_TRANSACTION' or evidence.get('transaction_id') != out.get('transaction_id'):
            raise ValueError('Resolve the original transaction')
        if evidence.get('status') not in {'committed', 'not_committed', 'pending', 'unknown'}:
            raise ValueError('Unknown transaction status')
        if evidence['status'] in {'pending', 'unknown'}:
            out['phase'] = 'CHECK_TRANSACTION'
        else:
            out['transaction_status'] = evidence['status']
            out['phase'] = 'READ_BACK'
    elif kind == 'readback':
        if phase not in {'WRITING', 'READ_BACK', 'RECONNECT'}:
            raise ValueError('Resolve the transaction or error before readback')
        if not evidence.get('receipt_id') or not evidence.get('settled'):
            raise ValueError('Readback must follow completion of the prior operation')
        if evidence.get('expected') != out['expected']:
            raise ValueError('Do not change selected content during recovery')
        comparison = evidence.get('comparison')
        if comparison == 'MATCH':
            out['phase'] = 'COMPLETE'
        elif comparison == 'ABSENT':
            if evidence.get('observed') != out['before']:
                raise ValueError('A missing object alone does not prove an unchanged baseline')
            if out.get('transaction_status') == 'committed':
                out['phase'] = 'CONFLICT'
            else:
                out['phase'] = 'RETRY_SAME_WRITE' if out['attempts'] == 1 else 'BLOCKED'
        elif comparison == 'CONFLICT':
            out['phase'] = 'CONFLICT'
        else:
            raise ValueError('Compare actual saved objects with the expected write')
    elif kind == 'dispatched':
        if phase != 'RETRY_SAME_WRITE' or evidence.get('expected') != out['expected']:
            raise ValueError('Retry only the same verified missing write')
        out['attempts'] += 1
        out['phase'] = 'WRITING'
    else:
        raise ValueError('Unknown recovery evidence')
    out['history'].append(copy.deepcopy(evidence))
    return out


def verify_delivery(document, pptx_path, expected_pages):
    """Require a named, read-back document AND a real complete PPTX package.

    Caller must inspect the linked native deck and its viewer, then render and
    review the exported file. This checker does not pretend to open a browser.
    """
    title = document.get('title', '').strip()
    if not title or title.casefold() in {'untitled', 'untitled presentation', '未命名投影片', '未命名簡報'}:
        raise ValueError('Name the actual document; cover text is not its metadata title')
    if not document.get('id') or not document.get('url') or not document.get('readback_receipt'):
        raise ValueError('Missing persistent native entry or readback')
    if document.get('pages') != expected_pages or expected_pages < 1:
        raise ValueError('Native page count is incomplete')
    if document.get('opened') is not True or not document.get('open_evidence'):
        raise ValueError('Native entry has not been opened and verified')
    path = Path(pptx_path)
    if not path.is_file():
        raise ValueError('No actual PPTX download')
    try:
        with zipfile.ZipFile(path) as archive:
            if archive.testzip():
                raise ValueError('Corrupt PPTX')
            root = ET.fromstring(archive.read('ppt/presentation.xml'))
            ns = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
            slides = root.findall('p:sldIdLst/p:sldId', ns)
            if len(slides) != expected_pages:
                raise ValueError('Exported PPTX page count differs')
            rels = ET.fromstring(archive.read('ppt/_rels/presentation.xml.rels'))
            by_id = {x.attrib['Id']: x.attrib['Target'] for x in rels}
            import posixpath
            for slide in slides:
                target = by_id[slide.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
                part = target.lstrip('/') if target.startswith('/') else posixpath.normpath('ppt/' + target)
                ET.fromstring(archive.read(part))
    except (zipfile.BadZipFile, KeyError, ET.ParseError) as exc:
        raise ValueError('Not a complete readable PPTX package') from exc
    return {'status': 'VERIFIED_PACKAGE', 'document_id': document['id'], 'title': title,
            'native_url': document['url'], 'pages': expected_pages,
            'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def complete_delivery(job, document, pptx_path):
    """Mark delivery only after finish and an actual named/opened export.

    Revalidate legacy DELIVERABLE jobs with studio.finish first; do not accept
    their former status as proof of a completed download.
    """
    if job.get('status') != 'READY_FOR_EXPORT':
        raise ValueError('Run studio.finish before verifying delivery')
    if any(op.get('phase') != 'COMPLETE' for op in job.get('write_operations', {}).values()):
        raise ValueError('Unresolved native write; delivery cannot be completed')
    receipt = verify_delivery(document, pptx_path, len(job['plan']))
    out = copy.deepcopy(job)
    out['delivery'] = receipt
    out['status'] = 'DELIVERED'
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['intake', 'resolve', 'recover', 'delivery', 'complete'])
    parser.add_argument('input', type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8'))
    if args.command == 'intake':
        print(intake(data['groups']))
    elif args.command == 'resolve':
        print(json.dumps(resolve_choices(data['groups'],data['reply']),ensure_ascii=False))
    elif args.command == 'recover':
        print(json.dumps(recover_write(data['state'], data['evidence']), ensure_ascii=False))
    elif args.command == 'complete':
        print(json.dumps(complete_delivery(data['job'], data['document'], data['pptx_path']), ensure_ascii=False))
    else:
        print(json.dumps(verify_delivery(data['document'], data['pptx_path'], data['expected_pages']), ensure_ascii=False))


if __name__ == '__main__':
    main()
