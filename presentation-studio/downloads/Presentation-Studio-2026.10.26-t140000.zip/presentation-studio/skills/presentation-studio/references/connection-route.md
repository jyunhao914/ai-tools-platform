# 依本回合實際連接選擇表單（私人未驗證候選）

本包沒有 MCP／App 宣告，不會替帳號建立連接，也不保證手機已能送出。只使用宿主當回合正式提供的能力；封裝、工具交接、畫面可見、同對話收件及跨裝置驗收分開記錄。原 pure-portable 實驗另行保留。

所有路徑都只呈現同版 canonical 選單。助理不能自行撰寫 HTML／JavaScript、傳入自訂 groups／options，或把 4＋2 縮成「重製／還原／分析／換其他模式」。只收到檔案且目的不明時，完整原輸入明寫 phase=entry 並保留真實來源，不依 PPTX／PDF 種類代選操作；目的已知則直接帶入對應階段與模式。正式表單失敗後的對話備援是文字接續，不是製作另一份互動 UI。

## 選一次路徑，不做無關前置盤點

先使用本回合已提供的工具描述及 schema，必要時才用正式工具發現功能。只選目前連接的 Presentation Studio 正式工具；保存工具完整識別及實際描述／schema 來源。名稱相同不是同一連接或同版契約的證據，不混用另一安裝、帳號、舊快取或來源不明的工具。多個候選無法確認哪個屬於目前連接時，不猜測，進隨包路徑。不能把本地 JSON、自填能力旗標、網站 HTTP 成功或安裝成功當成宿主提供工具的證據。

新版工作流程契約版本為 **2026.10.24-t222500**。所有原生結果仍須以完整原始輸入核對；工具名稱、部署紀錄與成功回應都不能取代核對。

1. 優先使用本回合實際連接且明示支援 2026.10.24-t222500、完整輸入 schema 相符的 studio_open_workflow_v3。
2. 其次使用同一實際連接明示支援同版本的 studio_open_workflow_v2；只支援 t094000 的直接 v2 必須略過。
3. 直接入口不可用時，若本回合正式提供目前 Presentation Studio 連接的 studio_open_intake，且 schema 接受 source_kind=outline 及 selected 的字串值，可使用本版明確定義的版本化相容請求。這也適用於宿主快取了舊 intake 工具描述的情況；不要求先刷新工具或改用隨包表單。必須先確認實際連接身分，不能對另一個同名工具猜測。請求格式為：

```json
{"source_kind":"outline","selected":{"workflow_v2_config":"<JSON.stringify({contract_version: \"2026.10.24-t222500\", input: 完整原始工作流程輸入})>"}}
```

實作時將 `{ "contract_version": "2026.10.24-t222500", "input": <完整原始 input 物件> }` 序列化為 selected.workflow_v2_config 的字串值。外層 outline 僅供相容封套分派，內層保留真實來源、mode、phase、需求、修訂與接續欄位。只能使用既有 workflow_v2_config 鍵，不創造 workflow_v3_config，不混入 legacy 選值。新服務會依內層版本完整驗證；舊服務會拒絕這個版本化框架，不得改成未加框架的舊請求重試。發出請求不代表版本已受支援；只有下方完整結果核對成功才可接續。拒絕、錯版或內容不符時保留停點，不能假稱表單已開啟。

save 同樣使用此順序與完整核對，不改用舊 studio_open_style_save。本包沒有連接宣告，沒有實際 intake 工具的帳號不會因本規則獲得連接。
4. 沒有以上契約匹配工具時，依 [隨包路徑](portable-route.md) 單次執行 portable_intake.py，再交接正式 visualize 參照。Visualize 是正式技能，不要求工具清單有同名函式；未驗收也不代表能力不存在。先查實際技能與執行能力，不猜測瀏覽器或手機支援情況。

工具名稱中的 v3 不改變回傳種類：合法結果仍須是 kind="studio-workflow-v2"，且 version 與 config.version 都是 2026.10.24-t222500。不得改成 studio-workflow-v3、接受 t094000 或重寫回傳版本來通過驗證。以下 verify_connected_result.mjs 全量核對對所有入口都不可省略。

初次 entry／requirements 不預查 Python／Node 版本、Pillow、Drive、圖片生成或簡報編輯器；直接執行當前選中路徑。已讀且版本未變的規則及同一 source_revision 已確認資料直接沿用。只有實際錯誤才針對該步診斷。製作設定需要預覽時仍完整讀取及驗證預覽，不能為速度刪除安全檢查。

## 正式工具回傳必須與原輸入完全相符

新 job 第一次表單前，從宿主正式技能來源取得當前 skill_root，將可信同版最小 runtime 保存到固定 job 目錄，避免下回合暫時 plugin mount 消失後找不到收件器。正式工具路徑先執行一次：

```sh
python3 <當前可信skill_root>/scripts/stage_form_runtime.py <固定job目錄>
```

保存實際回傳的 runtime_id、runtime_root、runtime_manifest、runtime_record 與 runtime_paths；後續準備／收件／回傳核對優先用 runtime_paths.prepare、runtime_paths.accept、runtime_paths.verify_connected_result 的絕對路徑，不自行拼舊 mount。正式工具路徑必須已取得 verify_connected_result 路徑才能呼叫；不存在就先處理該缺檔，不聲稱可在之後補驗證。隨包 portable_intake.py 會自動做同一 staging，明確帶入 `--job-directory <固定job目錄>`；接續依同版 pin 驗證，不能以重建另一目錄繞過失效或缺少紀錄。只解析需要的同版檔案，不做全磁碟、Plugin Management／Plugin Creator 掃描；失效時由當前正式技能清單重新定位，不能信任另一執行環境留下的絕對路徑。

呼叫前保存本階段完整 input.json；建立一次 request_id 並保存，工具重試沿用該 ID 與原輸入。新 job 第一次表單前建立固定 receipts 目錄並記入 intake-state.receipts_directory；既有工作沿用實際收件目錄。正常下一階段先取得前一 request 的真正 accepted 收件；previous／replacement、來源更新和內容確認依 [互動契約](interactive-intake.md)，不可先改 active request 掩蓋未收件。

在組裝並保存 input.json 的同一次執行請求內，先以已驗證 runtime_root 中固定的 `scripts/portable_prepare.mjs` 對這份原輸入做無網路預檢；不新增 helper、不重新搬移既有 runtime、不先呼叫正式表單試錯：

```sh
node <已驗證runtime_root>/scripts/portable_prepare.mjs < <input.json> > <preflight-config.private.json> 2> <preflight-diagnostic.private.txt>
```

由同一執行器檢查退出碼並解析成功的私人 config，只向模型回傳固定狀態、job_id／request_id／source_revision／contract version、input SHA256 與私人 config SHA256。失敗時保留原診斷並只回既有固定錯誤分類；非零退出、逾時或輸出無法解析都不能發正式 UI 請求，不能把錯誤物件當 config。完整 input、config、預覽及 stderr 不回傳對話，也不為修正本地輸入錯誤重新下載風格。原欄位 `selected.content="K"` 是原文保留，`selected.content="T"` 是潤飾文字；不得寫 `selected.text` 或新增相容別名。修正代理填錯鍵名後仍核對人類原選擇及原內容確認，不能藉此改變選值或補製作授權。

通過後，正式工具必須從剛通過的同一份 input.json 讀取完整資料，不另手抄一份參數；不把預檢 config 當 input，也不先寫成正式 config.json／改 active_request_id。input bytes 或可信 runtime 改變就重新預檢；同 request 重試時，原 input bytes、runtime_id 與私人預檢檔雜湊全相同才沿用已通過結果。這是純本地前檢，不需另一輪模型規劃；隨包 portable_intake.py 本來已呼叫同一 canonical 準備器，不另外重跑預檢。正式結果取得後，下面的 verify_connected_result 全量核對仍必須執行。

同一 job 接收後續選值時，優先使用已保存 runtime_paths.receive，以單次執行完成原 stage 與 accept；舊 pin 缺此入口則在一次執行內依序使用原 stage／accept。保持原 pin、receipt 與來源版本，不重新探索路由或取得另一版資源。先收件再進行下一階段所需讀取；需要大綱才產生大綱、進 settings 才讀風格、真正 produce 才讀製作工具。相互獨立的正式資料讀取與執行器內驗證可在同一編排請求依序／平行完成，只向對話輸出必要摘要，不回傳 HTML 或圖片 base64；不能因此省略正式工具結果與原 input 的全量核對。

將**實際工具結果**保存為 result.json，執行本包只讀核對器：

```sh
node <已驗證的runtime_paths.verify_connected_result> <input.json> <result.json>
```

核對器拒絕 isError、legacy kind、錯版，以及任何與原輸入的 canonical config 不符的來源、job、request、階段、選項、頁數、確認或 replacement。它使用本包未修改的 prepareWorkflow／config-validator，不能以服務回傳任意 config 自我驗證。私人預覽使用原輸入已驗證資料核對；這不證明宿主已收到或顯示預覽。

僅成功輸出 `status=validated` 後，將**工具回傳原樣 structuredContent.config** 保存為 config.json，再把其 request_id 記入 active_request_id。核對器輸出只是準備驗證，不是 selection、receipt、畫面可見或製作授權。不能重建 config 取代工具結果、改欄位迎合錯誤，或把核對器結果當成人類回覆。

正式工具結果由宿主呈現註冊的 MCP App；正常交接不另外產生 visualize 副本。UI 以官方 App.connect／message.text 能力及 App.sendMessage 提交；它不是在隨包 HTML 注入 window.openai。隨包路徑仍使用宿主真正提供的 sendFollowUpMessage。兩者都保留宿主傳送確認，不猜測 postMessage、不操控聊天輸入欄、不偽造 bridge、不安排背景補送。

## 失敗接續與重試

- 回傳核對失敗、宿主拒絕或明確載入／傳送失敗時保存真實停點，不宣稱表單可用或成功。已交接但可見性未知不等於失敗，不反覆另開表單。可用原 config 的未顯示案件只依 interactive-intake.md「原生表單未顯示時的同設定重顯示」完整檢查及 recover_display.py CLI 恢復，不繞過 receipts 檢查或重建新 request。
- 已有畫面但送出能力缺少時，不以換路徑保證恢復；同畫面保留欄位、顯示未送出並可重試。逾時結果不明先查同對話與同 job 收件，不直接自動再送。當前正式能力無法完成時，在同一對話用簡短問答只補缺少的欄位，沿用**實際已收到**的資料。不得聲稱自動取得另一畫面未送出的選值、草稿或已保存未知資料；不要求手動複製轉貼。
- 人類在對話實際回答的資料另記錄真實原話，依既有對話接續與授權流程處理，不能偽造成表單 selection／SDK ack。備援成功不等於原表單已修復。缺少製作授權時只補該項；已授權且仍對應最新來源時不重複詢問。
- 真正同對話收到 selection 後，依原 config、最新 intake-state 與固定 receipts 目錄執行未修改的 accept_intake.cjs；只有 accepted 才執行對應動作，resume 讀回原工作。入口、需求、內容確認不授權製作；還原大綱／分析風格只完成對應工作。頁數、圖片處理、來源修訂與最新內容確認規則不因選路徑而改變。

此候選僅修正路由與回傳核對；尚未取得有效 App binding 的帳號不會因安裝本包而獲得該連接。正式服務註冊、手機實際顯示／送出、改頁數、間隔操作與壓力穩定驗收仍須各自完成，未驗證不發布或更換網站下載。
