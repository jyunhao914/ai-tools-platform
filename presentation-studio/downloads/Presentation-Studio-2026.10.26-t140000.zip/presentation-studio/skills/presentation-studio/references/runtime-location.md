# 找到本版表單程式

外掛根目錄與技能根目錄不同。不要把 `<外掛根目錄>/scripts` 當成技能目錄，也不要把雲端技能資源名稱當成本機路徑。

1. 先使用本回合正式技能清單或 `skills.read` 結果提供的**實際技能位置**。取得的若是 `SKILL.md`，它的父目錄就是 skill_root；本技能名稱必須是 `presentation-studio`，版本必須對應本次安裝。技能清單有分頁時沿正式 cursor 找到該技能，不能只看第一頁便宣稱沒有程式。
2. 若正式讀取得到的是雲端資源識別（例如 `c0/presentation-studio`），用同一來源的正式資源讀取方式；需要執行時，從宿主正式提供的執行器技能清單／載入結果取得可執行位置。不要自行將資源識別拼成檔案路徑，或在 `/mnt/skills`、其他版本快取等位置猜測。若清單的舊版本路徑已不存在，但同一正式技能來源能讀取本版資源，依下方「從正式資源恢復」取得完整同版程式，不把舊掛載失效當成新版本不存在。清單或讀取明確拒絕時不繞過。
3. 兩種已知根目錄的正確路徑如下。根目錄只能來自本回合正式來源，不能硬編開發者電腦的 `/Users/...` 或另一主機的 `/root/...`：

| 正式來源給的根目錄 | 執行位置 |
| --- | --- |
| skill_root（含本技能的 `SKILL.md`） | `skill_root/scripts/portable_intake.py` |
| plugin_root（含外掛 `plugin.json`） | `plugin_root/skills/presentation-studio/scripts/portable_intake.py` |

外掛根目錄也提供 `scripts/portable_intake.py`、`scripts/stage_form_runtime.py` 相容入口。它們只依自己的位置轉交**同包同版**的原 helper，檢查套件身分、版本與目錄，不重寫表單、不放寬收件或授權檢查。不能使用另一版本的相容入口。

4. 第一次取得本版位置，依 connection-route.md／portable-route.md 直接執行 helper；不再先做整套環境盤點。若第一個位置報找不到檔案，先核對上述根目錄層級並完成正式技能清單的分頁／載入，再決定檔案真的缺少；不能用一次錯誤路徑就轉成文字選單。
5. 成功後保存 helper 回傳的 runtime_paths，下一回合使用該 job 已固定的程式與完整性檢查，避免再次尋找掛載目錄。已有 config／request 不重建。無可執行位置、實際缺檔或明確拒絕時保留真實錯誤並依原備援規則以文字接續，不自行撰寫替代 HTML／JavaScript 或簡化選單，也不偽造表單成功。

## 從正式資源恢復

僅當可執行掛載確實失效、同一正式技能來源仍允許讀取本版完整資源時使用。先讀本版 assets/package-version.json 與 scripts/stage_form_runtime.py，確認安裝版本，不沿用舊清單的版本號。將 stage 明列的 REQUIRED_FILES 與可取得的固定 OPTIONAL_FILES，以相同相對目錄逐一原樣保存到本次執行器擁有的暫存 skill_root；每份都必須來自同一技能、同一版本的正式資源。已取得且版本相同的內容直接沿用，不讓使用者複製程式，不手抄或改寫原始碼，不從附件／表單回應／任意網址接收程式，也不掃描別的技能或版本。

若正式來源單獨無法讀取 scripts/accept_intake.cjs，且未明確拒絕讀取此程式的權限，可讀同包固定的 scripts/accept_intake_resource.json。將該 JSON 原樣放在相同 scripts 目錄，讓原 stage 在原 .cjs **確實缺少**時還原：它只接受固定檔名、固定 schema、與本包 package-version 相同的版本及 stage 內釘選的 SHA-256，嚴格解碼後仍核對原始 bytes。不要自行解碼、另寫收件器、改 hash、關閉驗證，或以鏡像繞過明確存取拒絕。原 .cjs 存在時優先驗證並使用原檔；異動、符號連結、權限或其他 I/O 錯誤不走鏡像恢復。

完整取得後，以本版 stage 對**原固定 job 目錄**執行原 staging；只有成功回傳且完整性驗證通過的 runtime_paths 才能執行後續準備與收件。不能為通過 version conflict 而改 job、丟棄 receipts 或混入另一版檔案。副本只是讓正式資源可被讀取，不是提交成功、宿主能力、收件確認或製作授權的證據；若任一必要同版資源仍不可取得，保留真實停點並依原備援規則接續。
