#!/usr/bin/env python3
"""Stage trusted sibling code and receive one real submission in one local call.

All five paths and the optional Node executable come from the executor's saved
job, never from form fields. The unchanged receiver owns validation, publication
and deduplication. This helper neither advances state nor authorizes production.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
from stage_form_runtime import RuntimeStageError, stage_runtime

NODE_TIMEOUT_SECONDS = 30
MAX_SUMMARY_BYTES = 8192
REJECTED = {
    'Job or request does not match the saved form': 'RECEIVE_JOB_OR_REQUEST_MISMATCH',
    'Stale source revision: retain current content': 'RECEIVE_SOURCE_REVISION_MISMATCH',
    'A newer form is active: retain current requirements': 'RECEIVE_REQUEST_SUPERSEDED',
    'Received selection does not match the saved form contract': 'RECEIVE_SELECTION_MISMATCH',
    'Latest content has not been confirmed': 'RECEIVE_CONTENT_UNCONFIRMED',
    'Receipt is incomplete: inspect this job before retrying any side effect': 'RECEIVE_RECEIPT_INCOMPLETE',
    'Production already claimed: inspect the existing job, then create a revision for changed settings': 'RECEIVE_PRODUCTION_ALREADY_CLAIMED',
}


class ReceiveIntakeError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _encode(value):
    return json.dumps(value, ensure_ascii=True, separators=(',', ':')) + '\n'


def _data_path(value):
    """Use executor-selected absolute real data paths, including separate stores."""
    path = Path(value)
    if not path.is_absolute() or '..' in path.parts:
        raise ReceiveIntakeError('RECEIVE_PATH_INVALID')
    if path.is_symlink():
        raise ReceiveIntakeError('RECEIVE_PATH_INVALID')
    # Match stage_runtime: reject a directly selected symlink, then resolve
    # ancestor OS aliases (macOS /tmp and /var) before checking real paths.
    path = path.resolve()
    for item in (path, *path.parents):
        if item.is_symlink():
            raise ReceiveIntakeError('RECEIVE_PATH_INVALID')
    return path


def _timings(started, stage_elapsed, accept_elapsed):
    # Local executor timings only; no display, mobile or end-to-end measurement.
    return {'stage': round(stage_elapsed * 1000, 3),
            'accept': round(accept_elapsed * 1000, 3),
            'total': round((time.perf_counter() - started) * 1000, 3)}


def _summary(result, config_path, runtime, receipts):
    """Return allowlisted scalar metadata, never the receiver's full selection."""
    try:
        receipt = result['receipt']
        selection = receipt['selection']
        receipt_path = Path(result['receipt_path'])
        if (result['action'] not in ('accepted', 'resume') or
                not isinstance(receipt, dict) or not isinstance(selection, dict) or
                not receipt_path.is_absolute() or receipt_path.parent != receipts or
                not isinstance(receipt['id'], str) or len(receipt['id']) != 64 or
                any(character not in '0123456789abcdef' for character in receipt['id'])):
            raise ValueError()
        # Read only version metadata. Contract and installed package versions
        # have different meanings and must remain separate in the summary.
        config = json.loads(config_path.read_bytes())
        package = json.loads((Path(runtime['runtime_root']) / 'assets/package-version.json').read_bytes())
        summary = {'action': result['action'], 'confirmation_status': 'confirmed',
                   'receipt_path': str(receipt_path),
                   'receipt_summary': {'id': receipt['id'], 'job_id': receipt['job_id'],
                       'request_id': receipt['request_id'],
                       'source_revision': receipt.get('source_revision'),
                       'next_action': selection.get('next_action'),
                       'settings_only': selection.get('settings_only') is True},
                   'package_version': package['version'], 'contract_version': config['version'],
                   'runtime_id': runtime['runtime_id']}
        scalars = [summary['receipt_path'], summary['package_version'], summary['contract_version'],
                   summary['runtime_id'], *summary['receipt_summary'].values()]
        if any(value is not None and not isinstance(value, (str, bool)) for value in scalars):
            raise ValueError()
        # Canonical IDs already have contract limits. This final bound also
        # protects stdout if unexpected saved metadata exceeds those limits.
        if len(_encode(summary).encode('utf-8')) > MAX_SUMMARY_BYTES - 256:
            raise ValueError()
        return summary
    except (KeyError, TypeError, ValueError, OSError, UnicodeError):
        raise ReceiveIntakeError('RECEIVE_SUMMARY_UNCONFIRMED') from None


def receive(job_directory, config_path, selection_path, state_path, receipts_directory, *, node='node'):
    """One stage then one unchanged CJS invocation; never retry or mutate state."""
    started = time.perf_counter()
    stage_elapsed = accept_elapsed = 0
    try:
        # stage_runtime retains all original source/hash/cache/version checks.
        # Its output alone chooses executable code; no JSON supplies a script.
        stage_started = time.perf_counter()
        try:
            runtime = stage_runtime(job_directory)
        finally:
            stage_elapsed = time.perf_counter() - stage_started
        config, selection, state, receipts = (
            _data_path(value) for value in
            (config_path, selection_path, state_path, receipts_directory))
        # The original CLI prints its complete receipt. Keep that private output
        # off the tool channel and on a temporary stream until it is summarized.
        with tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as diagnostics:
            accept_started = time.perf_counter()
            try:
                result = subprocess.run([node, runtime['runtime_paths']['accept'],
                    str(config), str(selection), str(state), str(receipts)],
                    stdout=output, stderr=diagnostics, timeout=NODE_TIMEOUT_SECONDS)
            except FileNotFoundError:
                raise ReceiveIntakeError('RECEIVE_NODE_NOT_FOUND') from None
            except subprocess.TimeoutExpired:
                raise ReceiveIntakeError('RECEIVE_TIMEOUT_UNCONFIRMED') from None
            except OSError:
                raise ReceiveIntakeError('RECEIVE_NODE_START_FAILED') from None
            finally:
                accept_elapsed = time.perf_counter() - accept_started
            if result.returncode:
                diagnostics.seek(0)
                # Only exact, fixed original diagnostics may be classified.
                # Arbitrary Node stderr or JSON source is never returned.
                diagnostic = diagnostics.read(1024).decode('utf-8', errors='replace')
                code = REJECTED.get(diagnostic.removesuffix('\n'), 'RECEIVE_REJECTED_UNCONFIRMED')
                raise ReceiveIntakeError(code)
            output.seek(0)
            try:
                accepted = json.load(output)
            except (ValueError, TypeError, UnicodeError):
                raise ReceiveIntakeError('RECEIVE_SUMMARY_UNCONFIRMED') from None
        packet = _summary(accepted, config, runtime, receipts)
        packet['timings_ms'] = _timings(started, stage_elapsed, accept_elapsed)
        return packet, 0
    except RuntimeStageError:
        code = 'RECEIVE_STAGE_UNCONFIRMED'
    except ReceiveIntakeError as error:
        code = error.code
    except Exception:
        code = 'RECEIVE_INTERNAL_UNCONFIRMED'
    return {'action': None, 'confirmation_status': 'unconfirmed', 'error': code,
            'receipt_may_exist': True,
            'instruction': 'Inspect the existing job and original receipts before any resubmission. Do not retry automatically.',
            'timings_ms': _timings(started, stage_elapsed, accept_elapsed)}, 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('job_directory', 'config', 'selection', 'state', 'receipts_directory'):
        parser.add_argument(name, type=Path)
    parser.add_argument('--node', default='node', help='Node executable supplied only by the executor, never a form field.')
    args = parser.parse_args()
    packet, status = receive(args.job_directory, args.config, args.selection, args.state,
                             args.receipts_directory, node=args.node)
    print(_encode(packet), end='')
    return status


if __name__ == '__main__':
    sys.exit(main())
