"""Portable content and asset ledger for a hosted skill sandbox.

The caller persists job JSON and assets in the chosen Drive or current-environment
file-only workflow. This module stores no credentials, calls no private platform
endpoints, and requires no local daemon.
Ledger operations are stdlib-only; deterministic page composition loads Pillow.
"""
import argparse
import copy
import hashlib
import json
import posixpath
from pathlib import Path, PurePosixPath
import re
import struct
import zlib
import uuid
import unicodedata
import zipfile
import xml.etree.ElementTree as ET

POLICIES = {'NONE', 'REUSE', 'REDRAW', 'GENERATE'}
OPERATIONS = {'PRESERVE', 'CONDENSE', 'EXPAND'}
NS = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}


def digest(value):
    if not isinstance(value, bytes):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(value).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + str(uuid.uuid4()))
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def outline(text):
    """Only standalone headings define pages; inline page citations remain text."""
    slides, current = [], None
    for line in text.splitlines():
        match = re.fullmatch(r'\s*#{0,6}\s*第\s*(\d+)\s*頁\s*[｜|:：]\s*(.+?)\s*', line)
        if match:
            current = {'id': str(uuid.uuid4()), 'label': match[1], 'texts': [match[2]], 'instructions': [], 'images': []}
            slides.append(current)
        elif line.strip():
            if current is None:
                raise ValueError('來源缺少獨立行的頁標題，先確認分頁，不默認頁數')
            value = re.sub(r'^\s*[-*•]\s+', '', line)
            value = value.replace('**', '')
            if value.startswith('視覺建議：'):
                current['instructions'].append(value)
            else:
                current['texts'].append(value)
    if not slides:
        raise ValueError('沒有可確認的頁面')
    return slides


def paragraph_text(paragraph):
    # Soft line breaks are not a:t runs; joining only text nodes loses content structure.
    return ''.join('\n' if n.tag == '{' + NS['a'] + '}br' else (n.text or '')
                   for n in paragraph.iter() if n.tag in {'{' + NS['a'] + '}br', '{' + NS['a'] + '}t'})


def slide_text_and_tables(node, include_paragraphs=False):
    texts, cell_indices, paragraphs = [], {}, []

    def walk(n):
        if n.tag == '{' + NS['a'] + '}tc':
            cell_indices[id(n)] = len(texts)
            parts = [paragraph_text(p) for p in n.findall('.//a:p', NS)]
            texts.append('\n'.join(parts))
            paragraphs.append(parts)
        elif n.tag == '{' + NS['p'] + '}txBody':
            parts = [paragraph_text(p) for p in n.findall('a:p', NS)]
            value = '\n'.join(parts)
            if value:
                texts.append(value)
                paragraphs.append(parts)
        elif n.tag == '{' + NS['a'] + '}p':
            value = paragraph_text(n)
            if value:
                texts.append(value)
                paragraphs.append([value])
        else:
            for child in n:
                walk(child)
    walk(node)
    tables = []
    for table in node.findall('.//a:tbl', NS):
        rows, merges = [], []
        for ri, row in enumerate(table.findall('a:tr', NS)):
            cells = row.findall('a:tc', NS)
            rows.append([cell_indices[id(c)] for c in cells])
            for ci, cell in enumerate(cells):
                attrs = {k: cell.attrib[k] for k in ('gridSpan', 'rowSpan', 'hMerge', 'vMerge') if k in cell.attrib}
                if attrs:
                    merges.append({'row': ri, 'column': ci, **attrs})
        tables.append({'text_indices': rows, 'merges': merges,
                       'column_widths_emu': [int(c.attrib['w']) for c in table.findall('a:tblGrid/a:gridCol', NS)]})
    return (texts, tables, paragraphs) if include_paragraphs else (texts, tables)


def pptx(path):
    """Keep exact text runs per paragraph, table cell order and source images."""
    slides = []
    with zipfile.ZipFile(path) as archive:
        presentation = ET.fromstring(archive.read('ppt/presentation.xml'))
        rels = ET.fromstring(archive.read('ppt/_rels/presentation.xml.rels'))
        relationships = {r.attrib['Id']: r.attrib['Target'] for r in rels}
        for index, item in enumerate(presentation.findall('p:sldIdLst/p:sldId', NS), 1):
            target = relationships[item.attrib['{' + NS['r'] + '}id']]
            name = target.lstrip('/') if target.startswith('/') else posixpath.normpath('ppt/' + target)
            xml_bytes = archive.read(name)
            node = ET.fromstring(xml_bytes)
            texts, tables, paragraphs = slide_text_and_tables(node, include_paragraphs=True)
            images = []
            relpath = str(PurePosixPath(name).parent / '_rels' / (PurePosixPath(name).name + '.rels'))
            if relpath in archive.namelist():
                mappings = {r.attrib['Id']: r.attrib for r in ET.fromstring(archive.read(relpath))}
                for pic in node.findall('.//p:pic', NS):
                    blip = pic.find('.//a:blip', NS)
                    key = None if blip is None else blip.attrib.get('{' + NS['r'] + '}embed')
                    rel = mappings.get(key, {})
                    image = {'relationship_id': key, 'target': rel.get('Target'), 'external': rel.get('TargetMode') == 'External'}
                    if image['target'] and not image['external']:
                        part = image['target'].lstrip('/') if image['target'].startswith('/') else posixpath.normpath(posixpath.dirname(name) + '/' + image['target'])
                        image.update(source_part=part, sha256=digest(archive.read(part)))
                    images.append(image)
            slides.append({'id': str(uuid.uuid4()), 'label': str(index), 'texts': texts, 'images': images, 'tables': tables, 'source_part': name,
                           'paragraph_evidence': {'kind': 'pptx_xml_paragraphs', 'source_part': name,
                                                  'xml_sha256': digest(xml_bytes), 'paragraphs': paragraphs}})
    return slides


def production_options(choices, confirmed_operation):
    """Map already validated choices; this is not a receipt or authorization.

    The caller supplies the explicit operation confirmed in the prior stage.
    No page-count inference, aliases, job creation or external reads occur here.
    """
    formats = {'E': 'EDITABLE', 'I': 'IMAGE'}
    policies = {'P0': 'NONE', 'P1': 'REUSE', 'P2': 'REDRAW', 'P3': 'GENERATE'}
    operations = {'O1': 'PRESERVE', 'O2': 'CONDENSE', 'O3': 'EXPAND'}
    if not isinstance(choices, dict):
        raise ValueError('Production options require validated choices')
    if not isinstance(confirmed_operation, str) or confirmed_operation not in operations:
        raise ValueError('Production requires an explicit confirmed O1, O2 or O3 operation')
    if ('workflow_mode' in choices and
            choices['workflow_mode'] not in ('TOPIC', 'OUTLINE', 'MATERIAL', 'REDESIGN')):
        raise ValueError('Auxiliary or unknown workflows cannot become production options')
    if 'operation' in choices and choices['operation'] != confirmed_operation:
        raise ValueError('Confirmed operation does not match validated choices')
    output, policy, text = (choices.get(key) for key in ('source_format', 'image_policy', 'content'))
    if (not isinstance(output, str) or output not in formats or
            not isinstance(policy, str) or policy not in policies or
            text not in ('K', 'T')):
        raise ValueError('Production requires exact source_format, image_policy and content choices')
    return {'mode': formats[output], 'policy': policies[policy],
            'operation': operations[confirmed_operation], 'text_mode': text}


def new_job(slides, mode, policy, style, operation='PRESERVE', target_pages=None, text_mode='K', asset_storage='drive'):
    if not isinstance(style, dict) or not style.get('selection') or not style.get('user_choice'):
        raise ValueError('請先取得風格選擇，並保存 selection 與使用者原話 user_choice；未選不能默認自動')
    if re.fullmatch(r'M\d+', str(style['selection']).upper()) or str(style['selection']).upper() in {'SM', 'MY', 'MY_STYLES', '我的風格', '我的風格庫'}:
        raise ValueError('我的風格庫只是入口，請先列出預覽並選擇個別風格')
    if str(style['selection']).upper() == 'PERSONAL':
        if not all(style.get(key) for key in ('style_id', 'folder_id', 'profile', 'preview_sha256', 'catalog_snapshot')):
            raise ValueError('個人風格未完整讀取與選定；請使用 style_library.select')
    if mode not in {'EDITABLE', 'IMAGE'} or policy not in POLICIES or operation not in OPERATIONS:
        raise ValueError('Invalid mode, image policy or operation')
    if text_mode not in {'K', 'T'}:
        raise ValueError('文字處理須明確選擇 K 或 T')
    if not isinstance(asset_storage, str) or asset_storage not in {'drive', 'file_only'}:
        raise ValueError('資產保存方式須明確為 drive 或 file_only')
    if target_pages is not None and (type(target_pages) is not int or target_pages < 1):
        raise ValueError('目標頁數必須為正整數')
    if operation != 'PRESERVE' and target_pages is None:
        raise ValueError('縮減／擴增必須先確認目標頁數')
    if not slides or any(not s.get('id') or not isinstance(s.get('texts'), list) for s in slides):
        raise ValueError('逐頁來源不完整')
    if len({s['id'] for s in slides}) != len(slides):
        raise ValueError('Duplicate source slide IDs')
    return {'schema_version': 1, 'id': str(uuid.uuid4()), 'mode': mode, 'policy': policy,
            'operation': operation, 'target_pages': target_pages, 'text_mode': text_mode, 'style': style,
            'source': slides, 'source_hash': digest(slides), 'plan': [], 'requests': {},
            'bindings': {}, 'status': 'PLANNING', 'asset_storage': asset_storage,
            'cloud': {'provider': 'google-drive' if asset_storage == 'drive' else 'file_only'}}


def _text_snapshot(pages):
    if not isinstance(pages, list) or not pages:
        raise ValueError('文字確認快照須為非空頁面清單')
    snapshot = []
    for page in pages:
        if (not isinstance(page, dict) or not isinstance(page.get('id'), str) or not page['id'] or
            not isinstance(page.get('source_ids'), list) or not page['source_ids'] or
            any(not isinstance(s, str) for s in page['source_ids']) or
            not isinstance(page.get('texts'), list) or any(not isinstance(t, str) for t in page['texts'])):
            raise ValueError('文字確認快照須包含頁 ID、來源對應與完整文字')
        snapshot.append({key: json.loads(json.dumps(page[key])) for key in ('id', 'source_ids', 'texts')})
    return snapshot


def confirm_text_revision(job, pages, confirmation_quote):
    """Bind an explicitly approved T snapshot to the unchanged original source."""
    if job.get('text_mode', 'K') != 'T' or job['operation'] != 'PRESERVE':
        raise ValueError('此確認僅適用保留內容且已選擇 T 微調文字的工作')
    if digest(job['source']) != job['source_hash']:
        raise ValueError('來源已變動，請建立新 job 並重新確認文字')
    if job.get('plan') or job.get('requests'):
        raise ValueError('製作計畫已建立；修改已確認文字須建立新 job，保留既有成果紀錄')
    if not isinstance(confirmation_quote, str) or not confirmation_quote.strip():
        raise ValueError('微調文字須保存使用者確認原話')
    snapshot = _text_snapshot(pages)
    if len(snapshot) != (job.get('target_pages') or len(job['source'])) or len({p['id'] for p in snapshot}) != len(snapshot):
        raise ValueError('文字快照的頁數或頁 ID 與確認目標不符')
    source_ids = [source['id'] for source in job['source']]
    mapped = []
    for page in snapshot:
        if len(set(page['source_ids'])) != len(page['source_ids']) or any(s not in source_ids for s in page['source_ids']):
            raise ValueError('文字快照含錯誤的來源對應')
        for source_id in page['source_ids']:
            if not mapped or mapped[-1] != source_id:
                mapped.append(source_id)
    if mapped != source_ids:
        raise ValueError('微調文字不得遺漏或重排來源；請先選擇相應處理方式')
    value = {'source_hash': job['source_hash'], 'pages': snapshot, 'confirmation_quote': confirmation_quote.strip()}
    job['text_revision'] = {**value, 'sha256': digest(value)}
    return job['text_revision']


def _check_text_revision(job, pages):
    if job['operation'] != 'PRESERVE' or job.get('text_mode', 'K') != 'T':
        return
    revision = job.get('text_revision', {})
    value = {key: revision.get(key) for key in ('source_hash', 'pages', 'confirmation_quote')}
    if (not isinstance(value['confirmation_quote'], str) or not value['confirmation_quote'].strip() or
        value['source_hash'] != job['source_hash'] or revision.get('sha256') != digest(value) or
        value['pages'] != _text_snapshot(pages)):
        raise ValueError('T 微調文字尚未確認，或與已確認的文字快照不一致')


def _check_plan(job):
    if digest(job['source']) != job['source_hash'] or digest(job['plan']) != job['plan_hash']:
        raise ValueError('來源或計畫已修改，必須重新確認後保存')
    _check_text_revision(job, job['plan'])
    if (job['operation'] == 'PRESERVE' and job.get('text_mode', 'K') == 'T' and
        job.get('plan_text_revision_sha256') != job['text_revision']['sha256']):
        raise ValueError('文字確認版本已變動，必須重新建立計畫')
    contract = {'mode': job['mode'], 'policy': job['policy']}
    if 'plan_image_contract' in job and job['plan_image_contract'] != contract:
        raise ValueError('製作形式或圖片政策已變動，必須重新確認並建立計畫')
    storage = _asset_storage(job)
    if 'plan_asset_storage' in job and job['plan_asset_storage'] != storage:
        raise ValueError('資產保存方式已變動，必須明確建立製作修訂')
    # Resumed old jobs have no contract snapshot, but must still obey the same
    # image rules before dispatch, registration, binding or delivery.
    for page in job['plan']:
        _check_image_policy(job, page)


def _check_source_asset(job, page, slot):
    asset = slot.get('source_asset')
    if (not isinstance(asset, dict) or not isinstance(asset.get('source_id'), str) or
        not isinstance(asset.get('sha256'), str) or not re.fullmatch(r'[a-f0-9]{64}', asset['sha256'])):
        raise ValueError('沿用／重繪必須指定原資產的 source_id 與實際 SHA256')
    source = next((s for s in job['source'] if s['id'] == asset['source_id']), None)
    if (not source or source['id'] not in page['source_ids'] or
        not any(image.get('sha256') == asset['sha256'] for image in source.get('images', []))):
        raise ValueError('沿用／重繪素材來源不屬於此頁對應的原始資產')


def _check_image_policy(job, page):
    # These are raster slots only: native text, charts and shapes are not slots.
    allowed = {
        ('EDITABLE', 'NONE'): set(),
        ('EDITABLE', 'REUSE'): {'REUSE'},
        ('EDITABLE', 'REDRAW'): {'REDRAW'},
        ('EDITABLE', 'GENERATE'): {'GENERATE'},
        ('IMAGE', 'NONE'): {'GENERATE'},  # full-page text/charts, no illustration
        ('IMAGE', 'REUSE'): {'COMPOSE_REUSE'},
        ('IMAGE', 'REDRAW'): {'REDRAW'},
        ('IMAGE', 'GENERATE'): {'GENERATE'},
    }
    contract = (job['mode'], job['policy'])
    if contract not in allowed:
        raise ValueError('Invalid mode or image policy')
    if job['mode'] == 'IMAGE' and len(page['slots']) != 1:
        raise ValueError('圖像式每頁須有一個整頁圖片實例')
    if contract == ('EDITABLE', 'NONE') and page['slots']:
        raise ValueError('不用圖片不得新增一般配圖')
    for slot in page['slots']:
        action = slot.get('action')
        if contract == ('IMAGE', 'REUSE') and action == 'REUSE':
            raise ValueError('整頁沿用原圖須以 COMPOSE_REUSE 組版，不能將單張素材冒充完整頁面')
        if action not in allowed[contract]:
            if job['policy'] == 'REUSE':
                raise ValueError('直接沿用原圖不得生成新配圖或替換為其他處理方式')
            raise ValueError('圖片實例處理方式不符合已確認的製作形式與圖片政策')
        if action in {'REUSE', 'REDRAW'}:
            _check_source_asset(job, page, slot)
        elif 'source_asset' in slot:
            raise ValueError('生成或整頁組版不得使用單張 source_asset 冒充沿用／重繪')
        if action == 'COMPOSE_REUSE':
            import reuse_composition
            reuse_composition.validate(page, job['source'], slot.get('composition'))
        elif 'composition' in slot:
            raise ValueError('只有 COMPOSE_REUSE 可以帶入原圖組版設定')


def series_requirements(slides):
    """Extract explicit arrow sequences and caller-identified visual series.

    General bullets are not automatically illustrations. Non-arrow comparisons
    and steps can be recorded in source.visual_series after reading the source.
    """
    groups = []
    for source in slides:
        candidates = list(source.get('visual_series', []))
        for text in source['texts']:
            if '→' not in text:
                continue
            value = re.split(r'[:：]', text, maxsplit=1)[-1].strip()
            members = [v.strip() for v in value.split('→')]
            if len(members) >= 2 and all(members):
                candidates.append({'kind': 'sequence', 'members': members})
        seen = set()
        for item in candidates:
            members = item.get('members', [])
            if len(members) < 2 or any(not isinstance(x, str) or not x.strip() for x in members):
                raise ValueError('系列圖必須包含至少兩個明確項目')
            key = tuple(members)
            if key in seen:
                continue
            seen.add(key)
            groups.append({'id': source['id'] + '-series-' + str(len(seen)),
                           'source_id': source['id'], 'kind': item.get('kind', 'sequence'), 'members': members})
    return groups


def _text_units(item):
    """Only explicit XML paragraphs make a newline a layout boundary.

    Raw texts remain immutable. Missing metadata keeps embedded newlines exact;
    never infer paragraph/soft-break semantics from a legacy string.
    """
    texts = item['texts']
    if not isinstance(texts, list) or any(not isinstance(text, str) for text in texts):
        raise ValueError('重新分頁的來源與計畫文字必須為字串')
    evidence = item.get('paragraph_evidence')
    if evidence is None:
        return texts
    if (not isinstance(evidence, dict) or evidence.get('kind') != 'pptx_xml_paragraphs'
        or not isinstance(item.get('source_part'), str)
        or evidence.get('source_part') != item['source_part']
        or not isinstance(evidence.get('xml_sha256'), str)
        or not re.fullmatch(r'[a-f0-9]{64}', evidence['xml_sha256'])):
        raise ValueError('段落證據缺少實際 PPTX XML 來源')
    paragraphs = evidence.get('paragraphs')
    if not isinstance(paragraphs, list) or len(paragraphs) != len(texts):
        raise ValueError('段落證據與原始文字不一致')
    units = []
    for text, parts in zip(texts, paragraphs):
        if (not isinstance(parts, list) or any(not isinstance(part, str) for part in parts)
            or '\n'.join(parts) != text):
            raise ValueError('段落證據與原始文字不一致')
        units.extend(parts)
    return units


def _text_stream(items):
    units = [unit for item in items for unit in _text_units(item)]
    boundaries, offset = set(), 0
    for unit in units:
        boundaries.add(offset)
        offset += len(unit)
    return ''.join(units), boundaries


def _word_character(character):
    return (character == '_' or character.isdigit() or
            (character.isalpha() and 'LATIN' in unicodedata.name(character, '')))


def _check_preserved_text(sources, pages):
    original, original_boundaries = _text_stream(sources)
    planned, planned_boundaries = _text_stream(pages)
    if planned != original:
        raise ValueError('保留內容重新分頁不得增減、改寫或重排原文')
    if any(item.get('paragraph_evidence') is not None for item in [*sources, *pages]):
        # Paragraph/box/page boundaries cannot silently merge or split English
        # words or numeric tokens. Ordinary spaces and soft breaks were never
        # removed and already participated in exact equality above.
        for offset in original_boundaries ^ planned_boundaries:
            if (0 < offset < len(original) and
                _word_character(original[offset-1]) and _word_character(original[offset])):
                raise ValueError('重新排版不得合併或拆開英文單詞與數字')
    return original


def _preserved_page_ranges(job, pages):
    """Verify repagination against exact source spans, including image-only pages."""
    sources = job['source']
    _check_preserved_text(sources, pages)
    spans, offset = [], 0
    for source in sources:
        end = offset + len(''.join(_text_units(source)))
        spans.append((source, offset, end))
        offset = end
    result, mapped, offset = [], [], 0
    for page in pages:
        text = ''.join(_text_units(page))
        end = offset + len(text)
        ranges = {source['id']: (max(offset, start) - start, min(end, stop) - start)
                  for source, start, stop in spans if start < end and stop > offset}
        # An empty text page must contain a real source image. An unbound
        # GENERATE slot is not evidence that a filler page preserves content.
        image_sources = set()
        for slot in page['slots']:
            assets = ([item.get('source_asset') for item in slot.get('composition', {}).get('images', [])]
                      if slot.get('action') == 'COMPOSE_REUSE' else
                      [slot.get('source_asset')] if slot.get('action') in {'REUSE', 'REDRAW'} else [])
            for asset in assets:
                if not isinstance(asset, dict):
                    continue
                for source in sources:
                    if (asset.get('source_id') == source['id'] and asset.get('sha256')
                        and any(image.get('sha256') == asset['sha256'] for image in source.get('images', []))):
                        image_sources.add(source['id'])
        if not text.strip() and not image_sources:
            raise ValueError('保留內容重新分頁不得新增空白填充頁；純圖片頁須對應實際來源圖片')
        expected = [source['id'] for source in sources if source['id'] in ranges or source['id'] in image_sources]
        if page['source_ids'] != expected:
            raise ValueError('重新分頁的來源對應必須符合該頁實際文字與圖片')
        for source_id in expected:
            if not mapped or mapped[-1] != source_id:
                mapped.append(source_id)
        result.append(ranges)
        offset = end
    if mapped != [source['id'] for source in sources]:
        raise ValueError('重新分頁不得遺漏或重排來源順序')
    return result


def _series_member_ranges(source, members):
    """Locate original labels, preferring exact arrow-sequence occurrences."""
    ranges = [[] for _ in members]
    offset = 0
    for text in _text_units(source):
        colon = re.search(r'[:：]', text)
        start = colon.end() if colon else 0
        parts = text[start:].split('→')
        if len(parts) > 1 and [part.strip() for part in parts] == members:
            for index, part in enumerate(parts):
                label_start = offset + start + len(part) - len(part.lstrip())
                ranges[index].append((label_start, label_start + len(members[index])))
                start += len(part) + 1
        offset += len(text)
    if any(ranges):
        return ranges
    # Caller-identified comparisons need not contain arrows. Match longer
    # labels first so a shorter label cannot also claim the same occurrence.
    text = ''.join(_text_units(source))
    occupied = []
    for index in sorted(range(len(members)), key=lambda i: len(members[i]), reverse=True):
        for match in re.finditer(re.escape(members[index]), text):
            start, end = match.span()
            if any(start < stop and end > begin for begin, stop in occupied):
                continue
            ranges[index].append((start, end))
            occupied.append((start, end))
    return ranges


def validate_series(job, page, source_ranges=None):
    if job['mode'] != 'EDITABLE' or job['policy'] != 'GENERATE':
        return
    # Preserve mode retains the source's actual series; rewritten jobs use their
    # approved page text/visual_series, not a sequence that may have been removed.
    sources = ([s for s in job['source'] if s['id'] in page['source_ids']]
               if job['operation'] == 'PRESERVE' and job.get('text_mode', 'K') == 'K' else [page])
    required = series_requirements(sources)
    if source_ranges is not None:
        visible = []
        source_by_id = {source['id']: source for source in sources}
        for group in required:
            bounds = source_ranges.get(group['source_id'])
            members = []
            for member, occurrences in zip(group['members'], _series_member_ranges(source_by_id[group['source_id']], group['members'])):
                if not occurrences:
                    # Non-textual visual-series metadata stays required; do not
                    # silently omit it because no literal label can be found.
                    members.append(member)
                    continue
                is_visible = False
                for start, end in occurrences:
                    if bounds is None or start >= bounds[1] or end <= bounds[0]:
                        continue
                    if start < bounds[0] or end > bounds[1]:
                        raise ValueError('重新分頁不能將系列圖的同一成員文字拆到不同頁')
                    is_visible = True
                if is_visible:
                    members.append(member)
            if members:
                visible.append({**group, 'members': members})
        required = visible
    mappings = page.get('series_bindings', [])
    slots = {s['id']: s for s in page['slots']}
    used = set()
    for group in required:
        matches = [m for m in mappings if m.get('members') == group['members']]
        if source_ranges is not None:
            matches = [m for m in matches
                       if m.get('series_id', group['id']) == group['id']
                       and m.get('source_id', group['source_id']) == group['source_id']]
            if (sum(other['members'] == group['members'] for other in required) > 1
                and any(not m.get('series_id') and not m.get('source_id') for m in matches)):
                raise ValueError('相同成員的系列圖須以 series_id 或 source_id 區分來源')
        if len(matches) != 1:
            raise ValueError('系列圖缺少逐項配圖計畫，不能以流程框或單張圖片代替')
        ids = matches[0].get('slot_ids', [])
        if len(ids) != len(group['members']) or len(set(ids)) != len(ids):
            raise ValueError('系列圖每個項目必須有不同的獨立圖片實例')
        if any(s not in slots or slots[s]['action'] != 'GENERATE' or s in used for s in ids):
            raise ValueError('系列圖實例缺少、重複或不符合生成配圖政策')
        used.update(ids)


def plan(job, pages):
    if digest(job['source']) != job['source_hash']:
        raise ValueError('來源已變動，請建立新 job')
    page_ranges = None
    if job['operation'] == 'PRESERVE' and job.get('text_mode', 'K') == 'T':
        _check_text_revision(job, pages)
    elif job['operation'] == 'PRESERVE':
        expected_pages = job.get('target_pages') or len(job['source'])
        if len(pages) != expected_pages:
            raise ValueError('重新分頁須符合已確認的目標頁數；未指定時保留原頁數')
        if expected_pages == len(job['source']):
            for source, page in zip(job['source'], pages):
                if page['source_ids'] != [source['id']]:
                    raise ValueError('保留模式不得增減或改寫文字；重新分頁須先確認目標頁數')
                if source.get('paragraph_evidence') is not None or page.get('paragraph_evidence') is not None:
                    _check_preserved_text([source], [page])
                elif page['texts'] != source['texts']:
                    raise ValueError('保留模式不得增減或改寫文字；重新分頁須先確認目標頁數')
        else:
            # A page count change is a layout choice, not content expansion.
            page_ranges = _preserved_page_ranges(job, pages)
    elif len(pages) != job['target_pages']:
        raise ValueError('修訂頁數與使用者確認不符')
    source_ids = {s['id'] for s in job['source']}
    ids = set()
    for index, page in enumerate(pages):
        if page['id'] in ids or not set(page['source_ids']) <= source_ids:
            raise ValueError('計畫頁 ID 重複或來源對應錯誤')
        ids.add(page['id'])
        if len({s['id'] for s in page['slots']}) != len(page['slots']):
            raise ValueError('同頁圖片實例 ID 不得重複')
        _check_image_policy(job, page)
        validate_series(job, page, None if page_ranges is None else page_ranges[index])
    job['plan'] = pages
    job['plan_hash'] = digest(pages)
    job['plan_image_contract'] = {'mode': job['mode'], 'policy': job['policy']}
    job['plan_asset_storage'] = _asset_storage(job)
    if job['operation'] == 'PRESERVE' and job.get('text_mode', 'K') == 'T':
        job['plan_text_revision_sha256'] = job['text_revision']['sha256']
    job['status'] = 'PRODUCING'
    return job


def dispatch(job, page_id, slot_id, prompt, revision=None, retry_of=None):
    _check_plan(job)
    page = next(p for p in job['plan'] if p['id'] == page_id)
    slot = next(s for s in page['slots'] if s['id'] == slot_id)
    if slot['action'] in {'REUSE', 'COMPOSE_REUSE'} or job['policy'] == 'REUSE':
        raise ValueError('沿用原圖不應呼叫 ImageGen')
    previous = [r for r in job['requests'].values() if r['page_id'] == page_id and r['slot_id'] == slot_id]
    if any(r['status'] == 'DISPATCHED' for r in previous):
        raise ValueError('同一實例仍有未知結果，先恢復，不可換提示詞重送')
    if revision is not None and (not revision.get('id') or not revision.get('reason', '').strip()):
        raise ValueError('修改須有已保存的使用者修改請求 ID 與原因')
    if retry_of:
        old = job['requests'].get(retry_of, {})
        if old not in previous or old.get('status') != 'REFUSED' or old.get('retry_of') or old.get('safe_retry_id'):
            raise ValueError('合規調整必須對應實際拒絕且不可重複')
    elif previous and previous[-1]['status'] == 'REFUSED':
        raise ValueError('拒絕後必須走 safe_retry 或局部素材組版，不能換提示詞直接重送')
    if any(r['status'] == 'READY' for r in previous) and revision is None and not retry_of:
        raise ValueError('已有可用圖片；只有明確修改請求才建立新版本')
    identity = {'job': job['id'], 'page': page_id, 'slot': slot_id, 'prompt': prompt}
    if revision is not None:
        identity['revision_id'] = revision['id']
    key = digest(identity)
    if key in job['requests']:
        raise ValueError('已有相同請求，先恢復結果或查看錯誤，不重複生圖')
    job['requests'][key] = {'id': key, 'page_id': page_id, 'slot_id': slot_id, 'prompt': prompt,
                            'status': 'DISPATCHED', 'versions': []}
    if slot['action'] == 'REDRAW':
        job['requests'][key]['source_asset'] = dict(slot['source_asset'])
    if revision is not None:
        job['requests'][key]['revision'] = revision
    job['status'] = 'PRODUCING'
    return key


def _asset_storage(job):
    # No ID-based fallback: old jobs remain Drive jobs unless explicitly set.
    mode = job.get('asset_storage', 'drive')
    if not isinstance(mode, str) or mode not in {'drive', 'file_only'}:
        raise ValueError('資產保存方式須明確為 drive 或 file_only')
    return mode


def _asset_version(job, file_path, data, drive_file_id, library_reference=None):
    version = {'sha256': digest(data), 'library_reference': library_reference}
    if _asset_storage(job) == 'drive':
        if not drive_file_id:
            raise ValueError('完全雲端模式須先上傳 Drive 取得持久 file ID')
        version['drive_file_id'] = drive_file_id
    else:
        if drive_file_id is not None:
            raise ValueError('file_only 不得填入 Drive ID 冒充雲端保存')
        path = Path(file_path)
        if not path.is_absolute() or not path.is_file():
            raise ValueError('file_only 資產須為實際存在的絕對檔案路徑')
        path = path.resolve()
        if path.read_bytes() != data:
            raise ValueError('登記期間資產檔案已變更')
        version['storage'] = {'mode': 'file_only', 'path': str(path),
                              'bytes': len(data), 'persistence': 'current_environment'}
    return version


def _check_asset_storage(job, asset):
    """Re-read selected local bytes at use time; a receipt cannot pin a file."""
    if _asset_storage(job) == 'drive':
        if not asset.get('drive_file_id') or asset.get('storage'):
            raise ValueError('Drive 資產缺少真實持久 ID，不能混用本機保存紀錄')
        return
    storage = asset.get('storage', {})
    if ('drive_file_id' in asset or not isinstance(storage, dict) or
        storage.get('mode') != 'file_only' or storage.get('persistence') != 'current_environment'):
        raise ValueError('本機資產保存紀錄不完整，不能冒充 Drive 資產')
    path = storage.get('path')
    if not isinstance(path, str) or not Path(path).is_absolute() or not Path(path).is_file():
        raise ValueError('本機資產已遺失或不是有效絕對路徑')
    data = Path(path).read_bytes()
    if type(storage.get('bytes')) is not int or len(data) != storage['bytes'] or digest(data) != asset.get('sha256'):
        raise ValueError('本機資產已被替換或內容與登記證據不一致')


def register(job, request_id, file_path, drive_file_id=None, library_reference=None):
    _check_plan(job)
    request = job['requests'][request_id]
    if request['status'] != 'DISPATCHED':
        raise ValueError('只有待回傳的生成請求可以登記；拒絕或已結案不能冒充成功')
    data = Path(file_path).read_bytes()
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('生成結果必須是真正 PNG')
    # Inspect all chunk boundaries and CRCs before registering a durable success.
    offset, kinds = 8, []
    while offset < len(data):
        if len(data)-offset < 12:
            raise ValueError('生成 PNG 不完整')
        length=struct.unpack('>I',data[offset:offset+4])[0]
        end=offset+length+12
        if end>len(data):
            raise ValueError('生成 PNG 不完整')
        kind=data[offset+4:offset+8]
        if zlib.crc32(data[offset+4:end-4])&0xffffffff != struct.unpack('>I',data[end-4:end])[0]:
            raise ValueError('生成 PNG 校驗失敗')
        if not kinds and (kind!=b'IHDR' or length!=13):
            raise ValueError('生成 PNG 缺少標頭')
        kinds.append(kind); offset=end
        if kind==b'IEND':
            if length or offset!=len(data):
                raise ValueError('生成 PNG 結尾錯誤')
            break
    if not kinds or kinds[-1]!=b'IEND' or b'IDAT' not in kinds:
        raise ValueError('生成 PNG 不完整')
    sha = digest(data)
    if any(v['sha256'] == sha for v in request['versions']):
        raise ValueError('同一結果已登記，不重複保存')
    version = _asset_version(job, file_path, data, drive_file_id, library_reference)
    request['versions'].append(version)
    request['selected'] = len(request['versions']) - 1
    request['status'] = 'READY'
    job.setdefault('selections', {})[request['page_id'] + ':' + request['slot_id']] = {'request_id': request_id, 'version': request['selected']}
    job['status'] = 'PRODUCING'
    return version


def register_reuse(job, page_id, slot_id, file_path, drive_file_id=None):
    """Retain original bytes without calling image generation."""
    _check_plan(job)
    page = next(p for p in job['plan'] if p['id'] == page_id)
    slot = next(s for s in page['slots'] if s['id'] == slot_id)
    source = slot.get('source_asset', {})
    if slot['action'] != 'REUSE' or not isinstance(source, dict):
        raise ValueError('此實例未指定沿用原素材')
    source_page = next((p for p in job['source'] if p['id'] == source.get('source_id')), None)
    if not source_page or source_page['id'] not in page['source_ids']:
        raise ValueError('素材來源不屬於此頁對應來源')
    data = Path(file_path).read_bytes()
    sha = digest(data)
    if sha != source.get('sha256') or not any(a.get('sha256') == sha for a in source_page['images']):
        raise ValueError('沿用素材與原始來源不一致')
    if _asset_storage(job) == 'drive' and not drive_file_id:
        raise ValueError('沿用素材須保存持久 Drive ID')
    version = _asset_version(job, file_path, data, drive_file_id)
    key = digest({'job': job['id'], 'page': page_id, 'slot': slot_id, 'source': sha})
    if key in job['requests']:
        _check_asset_storage(job, job['requests'][key]['versions'][0])
        return key
    job['requests'][key] = {'id': key, 'page_id': page_id, 'slot_id': slot_id, 'status': 'READY', 'kind': 'REUSE',
                            'selected': 0, 'versions': [version]}
    job.setdefault('selections', {})[page_id + ':' + slot_id] = {'request_id': key, 'version': 0}
    job['status'] = 'PRODUCING'
    return key


def _composition(job, page_id, slot_id, source_files, font_files):
    _check_plan(job)
    page = next(p for p in job['plan'] if p['id'] == page_id)
    slot = next(s for s in page['slots'] if s['id'] == slot_id)
    if (job['mode'], job['policy'], slot['action']) != ('IMAGE', 'REUSE', 'COMPOSE_REUSE'):
        raise ValueError('此圖片實例未確認為原圖整頁組版')
    import reuse_composition
    data, evidence = reuse_composition.render(page, job['source'], slot['composition'], source_files, font_files)
    evidence.update(source_hash=job['source_hash'], plan_hash=job['plan_hash'])
    return data, evidence


def compose_reuse(job, page_id, slot_id, source_files, font_files, output_path):
    """Render exact original assets plus approved text; no READY receipt yet."""
    output = Path(output_path)
    inputs = [*source_files.values(), *font_files.values()]
    if any(output.resolve() == Path(path).resolve() for path in inputs):
        raise ValueError('組版輸出不得覆寫來源圖片或字型')
    data, evidence = _composition(job, page_id, slot_id, source_files, font_files)
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_name('.'+output.name+'.'+str(uuid.uuid4()))
    temp.write_bytes(data)
    temp.replace(output)
    return evidence


def register_composition(job, page_id, slot_id, file_path, source_files, font_files, drive_file_id=None):
    """Re-render and compare bytes; arbitrary/generated PNGs cannot claim REUSE."""
    if _asset_storage(job) == 'drive' and not drive_file_id:
        raise ValueError('組版成果須先保存持久 Drive ID')
    expected, evidence = _composition(job, page_id, slot_id, source_files, font_files)
    data = Path(file_path).read_bytes()
    if data != expected:
        raise ValueError('整頁成果與原圖組版不一致，不能冒充沿用或重繪')
    sha = digest(data)
    version = _asset_version(job, file_path, data, drive_file_id)
    version['composition_evidence'] = evidence
    key = digest({'job': job['id'], 'page': page_id, 'slot': slot_id,
                  'composition': sha, 'plan_hash': job['plan_hash']})
    if key in job['requests']:
        _check_asset_storage(job, job['requests'][key]['versions'][0])
        return key
    job['requests'][key] = {'id': key, 'page_id': page_id, 'slot_id': slot_id, 'status': 'READY',
                            'kind': 'COMPOSE_REUSE', 'selected': 0, 'versions': [version]}
    job.setdefault('selections', {})[page_id+':'+slot_id] = {'request_id': key, 'version': 0}
    job['status'] = 'PRODUCING'
    return key


def _check_composition_request(job, page, slot, request):
    if slot['action'] != 'COMPOSE_REUSE':
        return
    asset = request['versions'][request['selected']]
    evidence = asset.get('composition_evidence', {})
    if (request.get('kind') != 'COMPOSE_REUSE' or evidence.get('source_hash') != job['source_hash'] or
        evidence.get('plan_hash') != job['plan_hash'] or evidence.get('layout_sha256') != digest(slot['composition']) or
        evidence.get('texts_sha256') != digest(page['texts']) or evidence.get('output_sha256') != asset['sha256']):
        raise ValueError('組版證據與目前來源、文字或版面不一致，不能綁定舊成果')


def select_version(job, page_id, slot_id, request_id, version=0):
    _check_plan(job)
    request = job['requests'][request_id]
    if request['status'] != 'READY' or (request['page_id'], request['slot_id']) != (page_id, slot_id):
        raise ValueError('不能選擇其他頁或未完成圖片')
    if type(version) is not int or not 0 <= version < len(request['versions']):
        raise ValueError('找不到指定版本')
    _check_asset_storage(job, request['versions'][version])
    request['selected'] = version
    job.setdefault('selections', {})[page_id + ':' + slot_id] = {'request_id': request_id, 'version': version}
    job['status'] = 'PRODUCING'


def bind(job, page_id, slot_id, request_id, slide_id, image_id):
    _check_plan(job)
    request = job['requests'][request_id]
    if request['page_id'] != page_id or request['slot_id'] != slot_id or request['status'] != 'READY':
        raise ValueError('資產跨頁、跨實例或尚未完成')
    selected = job.get('selections', {}).get(page_id + ':' + slot_id)
    if selected and selected != {'request_id': request_id, 'version': request['selected']}:
        raise ValueError('此圖片不是目前選定版本；指定舊版請先 select_version')
    page = next(p for p in job['plan'] if p['id'] == page_id)
    slot = next(s for s in page['slots'] if s['id'] == slot_id)
    _check_composition_request(job, page, slot, request)
    _check_asset_storage(job, request['versions'][request['selected']])
    job['bindings'][page_id + ':' + slot_id] = {'request_id': request_id, 'slide_id': slide_id, 'image_id': image_id,
                                               'asset': copy.deepcopy(request['versions'][request['selected']])}


def refusal(job, request_id, evidence):
    if not evidence or not evidence.get('tool_call_id') or evidence.get('category') != 'safety_refusal':
        raise ValueError('只有實際安全拒絕可進入合規調整')
    request = job['requests'][request_id]
    if request['status'] != 'DISPATCHED':
        raise ValueError('此請求不可重複結案')
    request['status'] = 'REFUSED'
    request['error'] = evidence


def safe_retry(job, refused_id, revised_prompt, change_reason):
    request = job['requests'][refused_id]
    if request['status'] != 'REFUSED' or request.get('safe_retry_id') or request.get('retry_of'):
        raise ValueError('僅可一次實質合規調整')
    if not change_reason.strip() or revised_prompt == request['prompt']:
        raise ValueError('不得重送原遭拒內容')
    key = dispatch(job, request['page_id'], request['slot_id'], revised_prompt, retry_of=refused_id)
    request['safe_retry_id'] = key
    job['requests'][key]['retry_of'] = refused_id
    job['requests'][key]['change_reason'] = change_reason
    return key


def finish(job, observed_texts, page_ids, committed, visual_reviewed):
    _check_plan(job)
    if not committed or not visual_reviewed or len(page_ids) != len(job['plan']) or len(set(page_ids)) != len(page_ids):
        raise ValueError('尚未完成雲端保存、全部頁面或實際視覺驗收')
    if job['mode'] == 'EDITABLE' and observed_texts != [p['texts'] for p in job['plan']]:
        raise ValueError('原生文字讀回不一致')
    if any(r['status'] == 'DISPATCHED' for r in job['requests'].values()):
        raise ValueError('仍有未知結果的生成請求，不能交付舊版本')
    for index, page in enumerate(job['plan']):
        for slot in page['slots']:
            binding = job['bindings'].get(page['id'] + ':' + slot['id'])
            if not binding or binding['slide_id'] != page_ids[index]:
                raise ValueError('仍有未綁定圖片或錯頁')
            request = job['requests'][binding['request_id']]
            _check_composition_request(job, page, slot, request)
            _check_asset_storage(job, request['versions'][request['selected']])
            selected = job.get('selections', {}).get(page['id'] + ':' + slot['id'], {'request_id': request['id'], 'version': request['selected']})
            if binding['request_id'] != selected['request_id'] or binding['asset'] != job['requests'][selected['request_id']]['versions'][selected['version']]:
                raise ValueError('原生簡報仍綁定舊版本，必須更新圖片後再驗收')
    job['status'] = 'READY_FOR_EXPORT'
    return job


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    source = sub.add_parser('source')
    source.add_argument('input', type=Path)
    source.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.command == 'source':
        slides = pptx(args.input) if args.input.suffix.lower() == '.pptx' else outline(args.input.read_text())
        write_json(args.output, {'slides': slides, 'source_sha256': digest(args.input.read_bytes())})


if __name__ == '__main__':
    main()
