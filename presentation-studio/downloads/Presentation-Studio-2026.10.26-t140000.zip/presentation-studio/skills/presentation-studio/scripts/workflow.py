"""Portable intake, write recovery and delivery checks. No network or credentials.

Run outside the artifact callback: a viewer flush error can be returned by the
host after that callback has succeeded. Pass actual tool receipts/readbacks,
not a guessed success flag. The caller performs each returned next action.
"""
import argparse
import copy
import hashlib
import io
import json
import re
import unicodedata
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET


def intake_transcript(groups):
    """Accessible transcript only; never the user-facing selection interface."""
    blocks = []
    for group in groups:
        if group.get('selected') is not None:
            continue
        title = group['title'].strip()
        options = group['options']
        if not title or not options:
            raise ValueError('Missing question or options')
        lines = [f'**{title}**', '']
        if group.get('context'):
            lines.extend([group['context'].strip(), ''])
        for option in options:
            label = option['label'].strip()
            if not label or '\n' in label:
                raise ValueError('An option must be one short label')
            lines.append(f"- {option['id']}．{label}")
        blocks.append('\n'.join(lines))
    return '\n\n'.join(blocks)


def resolve_choices(groups, reply):
    """Resolve codes and explicit meaning aliases without guessing an ambiguous choice.

    The host may interpret other paraphrases, then validate against the same
    option IDs. This parser never changes content permissions via fuzzy spelling.
    """
    normalize=lambda s: unicodedata.normalize('NFKC',s).casefold().strip()
    text=normalize(reply)
    hits=[]; denials=[]
    def negated(start):
        return bool(re.search(r'(不要|不用|不想|不需要|別|不)\s*$',text[max(0,start-5):start]))
    for group in groups:
        for option in group['options']:
            code=normalize(str(option['id']))
            for found in re.finditer(r'(?<![\w])'+re.escape(code)+r'(?![\w])',text):
                (denials if negated(found.start()) else hits).append((found.start(),found.end(),group['id'],option['id']))
            for phrase in [option['label'],*option.get('aliases',[])]:
                phrase=normalize(phrase)
                if not phrase:continue
                for found in re.finditer(re.escape(phrase),text):
                    (denials if negated(found.start()) else hits).append((found.start(),found.end(),group['id'],option['id']))
    # A full phrase such as "不要微調" takes precedence over the word "微調".
    hits=[h for h in hits if not any(k[0]<=h[0] and k[1]>=h[1] and k[1]-k[0]>h[1]-h[0] for k in hits)]
    denials=[h for h in denials if not any(k[0]<=h[0] and k[1]>=h[1] and k[1]-k[0]>h[1]-h[0] for k in hits)]
    selected,ambiguous,missing={}, {}, []
    for group in groups:
        choices={h[3] for h in hits if h[2]==group['id']}
        denied={h[3] for h in denials if h[2]==group['id']}
        if choices & denied:ambiguous[group['id']]=sorted(choices)
        elif len(choices)==1:selected[group['id']]=next(iter(choices))
        elif len(choices)>1:ambiguous[group['id']]=sorted(choices)
        elif group.get('selected') is not None and group['selected'] not in denied:selected[group['id']]=group['selected']
        else:missing.append(group['id'])
    return {'selected':selected,'ambiguous':ambiguous,'missing':missing}


def begin_write(document_id, operation_id, expected, before):
    """Bind one write to its destination and selected content before dispatch."""
    if not document_id or not operation_id or not expected or not before:
        raise ValueError('Missing write identity, content fingerprint or baseline')
    return {'document_id': document_id, 'operation_id': operation_id,
            'expected': copy.deepcopy(expected), 'before': copy.deepcopy(before),
            'attempts': 1, 'phase': 'WRITING', 'history': []}


def classify_error(message):
    text = message.casefold()
    # Hard failures take precedence even if another line also says timeout.
    if re.search(r'permission denied|access denied|forbidden|unauthorized|安全拒絕|safety refusal|quota|rate.limit|額度|權限拒絕', text):
        return 'BLOCKED'
    if 'external document is no longer open' in text or 'connection expired' in text:
        return 'RECONNECT'
    if re.search(r'viewer flush failed|timed out|timeout|逾時', text):
        return 'READ_BACK'
    return 'INSPECT_ERROR'


def recover_write(state, evidence):
    """A bounded state machine. A readback never authorizes a blind replay.

    Evidence events: failure, transaction, readback, dispatched. For readback,
    comparison is MATCH (expected write present), ABSENT (baseline unchanged),
    or CONFLICT. It must be derived by inspecting the actual objects/content.
    """
    out = copy.deepcopy(state)
    if evidence.get('document_id') != out['document_id'] or evidence.get('operation_id') != out['operation_id']:
        raise ValueError('Evidence belongs to a different document or operation')
    kind = evidence.get('kind')
    phase = out['phase']
    if phase in {'COMPLETE', 'BLOCKED', 'CONFLICT'}:
        raise ValueError('This recovery is already terminal')
    if kind == 'failure':
        if phase != 'WRITING':
            raise ValueError('No write is awaiting a result')
        if not evidence.get('message') or not evidence.get('receipt_id'):
            raise ValueError('Keep the actual failed tool receipt')
        action = classify_error(evidence['message'])
        out['phase'] = action
        # Resolve any in-flight transaction before considering a new write.
        if action not in {'BLOCKED', 'INSPECT_ERROR'} and evidence.get('transaction_id'):
            out['transaction_id'] = evidence['transaction_id']
            out['phase'] = 'CHECK_TRANSACTION'
    elif kind == 'transaction':
        if phase != 'CHECK_TRANSACTION' or evidence.get('transaction_id') != out.get('transaction_id'):
            raise ValueError('Resolve the original transaction')
        if evidence.get('status') not in {'committed', 'not_committed', 'pending', 'unknown'}:
            raise ValueError('Unknown transaction status')
        if evidence['status'] in {'pending', 'unknown'}:
            out['phase'] = 'CHECK_TRANSACTION'
        else:
            out['transaction_status'] = evidence['status']
            out['phase'] = 'READ_BACK'
    elif kind == 'readback':
        if phase not in {'WRITING', 'READ_BACK', 'RECONNECT'}:
            raise ValueError('Resolve the transaction or error before readback')
        if not evidence.get('receipt_id') or not evidence.get('settled'):
            raise ValueError('Readback must follow completion of the prior operation')
        if evidence.get('expected') != out['expected']:
            raise ValueError('Do not change selected content during recovery')
        comparison = evidence.get('comparison')
        if comparison == 'MATCH':
            out['phase'] = 'COMPLETE'
        elif comparison == 'ABSENT':
            if evidence.get('observed') != out['before']:
                raise ValueError('A missing object alone does not prove an unchanged baseline')
            if out.get('transaction_status') == 'committed':
                out['phase'] = 'CONFLICT'
            else:
                out['phase'] = 'RETRY_SAME_WRITE' if out['attempts'] == 1 else 'BLOCKED'
        elif comparison == 'CONFLICT':
            out['phase'] = 'CONFLICT'
        else:
            raise ValueError('Compare actual saved objects with the expected write')
    elif kind == 'dispatched':
        if phase != 'RETRY_SAME_WRITE' or evidence.get('expected') != out['expected']:
            raise ValueError('Retry only the same verified missing write')
        out['attempts'] += 1
        out['phase'] = 'WRITING'
    else:
        raise ValueError('Unknown recovery evidence')
    out['history'].append(copy.deepcopy(evidence))
    return out


def _has_evidence(value):
    # Evidence is a real tool/readback record, never a success boolean.
    return (isinstance(value, str) and bool(value.strip())) or (isinstance(value, dict) and bool(value))


def _https_url(value):
    if not isinstance(value, str) or not value.strip() or any(ord(c) < 32 for c in value):
        raise ValueError('A real HTTPS URL is required')
    try:
        parsed = urlsplit(value)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError('A real HTTPS URL is required')
        parsed.port  # Reject malformed ports as well as malformed hosts.
    except ValueError as exc:
        raise ValueError('A real HTTPS URL is required') from exc
    return parsed


def _read_pptx(pptx_path, expected_pages):
    """Inspect the same bytes used by the returned hash; no network access."""
    path = Path(pptx_path)
    if not path.is_file():
        raise ValueError('No actual PPTX download')
    payload = path.read_bytes()
    try:
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            if archive.testzip():
                raise ValueError('Corrupt PPTX')
            root = ET.fromstring(archive.read('ppt/presentation.xml'))
            ns = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
            slides = root.findall('p:sldIdLst/p:sldId', ns)
            if len(slides) != expected_pages:
                raise ValueError('Exported PPTX page count differs')
            rels = ET.fromstring(archive.read('ppt/_rels/presentation.xml.rels'))
            by_id = {x.attrib['Id']: x.attrib['Target'] for x in rels}
            import posixpath
            for slide in slides:
                target = by_id[slide.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
                part = target.lstrip('/') if target.startswith('/') else posixpath.normpath('ppt/' + target)
                ET.fromstring(archive.read(part))
    except (zipfile.BadZipFile, KeyError, ET.ParseError) as exc:
        raise ValueError('Not a complete readable PPTX package') from exc
    return {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}


def _verify_pptx_delivery(document, path, expected_pages, package):
    """Check the reviewed PPTX and its download entry in either delivery mode."""
    artifact = document.get('artifact')
    download = document.get('download')
    if not isinstance(artifact, dict) or not isinstance(download, dict):
        kind = 'File-only' if document.get('delivery_mode') == 'file_only' else 'Native'
        raise ValueError(f'{kind} delivery requires artifact and download evidence')
    recorded_path = artifact.get('path')
    if not isinstance(recorded_path, str) or not Path(recorded_path).is_absolute() or Path(recorded_path).resolve() != path:
        raise ValueError('Artifact evidence must identify the actual PPTX path')
    if (artifact.get('sha256') != package['sha256'] or type(artifact.get('bytes')) is not int
            or artifact['bytes'] != package['bytes'] or type(artifact.get('pages')) is not int
            or artifact['pages'] != expected_pages):
        raise ValueError('Artifact hash, size or page evidence differs from the actual PPTX')
    if artifact.get('opened') is not True or not _has_evidence(artifact.get('open_evidence')):
        raise ValueError('The actual PPTX has not been opened and verified')
    if download.get('verified') is not True or not _has_evidence(download.get('evidence')):
        raise ValueError('The download entry has not been verified')
    if download.get('sha256') != package['sha256']:
        raise ValueError('Download evidence belongs to different PPTX bytes')
    local_path = download.get('local_path')
    if not isinstance(local_path, str) or not Path(local_path).is_absolute():
        raise ValueError('Download evidence must identify its actual local readback')
    downloaded = _read_pptx(local_path, expected_pages)
    if downloaded != package:
        raise ValueError('Downloaded PPTX differs from the reviewed artifact')
    url = download.get('url')
    if not isinstance(url, str) or not url.strip() or any(ord(c) < 32 for c in url):
        raise ValueError('Missing usable download entry')
    if url.startswith('/'):
        if Path(url).resolve() != path:
            raise ValueError('Local download link does not identify the reviewed artifact')
        persistence = 'current_environment'
    elif url.startswith('sandbox:'):
        parsed = urlsplit(url)
        if parsed.netloc or parsed.query or parsed.fragment or not parsed.path.startswith('/') or Path(unquote(parsed.path)).resolve() != path:
            raise ValueError('Sandbox download link does not identify the reviewed artifact')
        persistence = 'current_environment'
    else:
        parsed = _https_url(url)
        if parsed.hostname == 'docs.google.com' and parsed.path.startswith('/presentation/'):
            kind = 'file-only' if document.get('delivery_mode') == 'file_only' else 'PPTX'
            raise ValueError(f'A native presentation URL is not a {kind} download entry')
        if url == document.get('url'):
            raise ValueError('A native presentation URL is not a PPTX download entry')
        persistence = 'provider_defined'
    return {'artifact_path': str(path), 'download_url': url, 'download_persistence': persistence,
            'artifact_evidence': copy.deepcopy(artifact), 'download_evidence': copy.deepcopy(download)}


def _verify_file_only(document, path, expected_pages, package):
    if any(document.get(key) is not None for key in ('id', 'url', 'native_url', 'document_id')):
        raise ValueError('File-only delivery must not claim a native document entry')
    return _verify_pptx_delivery(document, path, expected_pages, package)


def verify_delivery(document, pptx_path, expected_pages):
    """Check an actual native export or explicitly declared file-only delivery.

    The caller performs real viewer/render and download checks and supplies their
    evidence. This local checker validates package bytes and evidence identity;
    it cannot authenticate a remote receipt or open a host download UI itself.
    """
    if not isinstance(document, dict):
        raise ValueError('Actual delivery metadata is required')
    mode = document.get('delivery_mode', 'native')
    if not isinstance(mode, str) or mode not in {'native', 'file_only'}:
        raise ValueError('Unknown delivery_mode')
    title = document.get('title', '')
    if not isinstance(title, str) or not title.strip() or title.strip().casefold() in {'untitled', 'untitled presentation', '未命名投影片', '未命名簡報'}:
        raise ValueError('Name the actual document; cover text is not its metadata title')
    title = title.strip()
    if type(expected_pages) is not int or expected_pages < 1 or type(document.get('pages')) is not int or document['pages'] != expected_pages:
        raise ValueError('Delivered page count is incomplete')
    if mode == 'native':
        if not isinstance(document.get('id'), str) or not document['id'].strip() or not _has_evidence(document.get('readback_receipt')):
            raise ValueError('Missing persistent native entry or readback')
        parsed = _https_url(document.get('url'))
        if parsed.hostname == 'docs.google.com':
            match = re.match(r'^/presentation/d/([^/]+)(?:/|$)', parsed.path)
            if not match or unquote(match.group(1)) != document['id']:
                raise ValueError('Native presentation URL and read-back ID differ')
        if document.get('opened') is not True or not _has_evidence(document.get('open_evidence')):
            raise ValueError('Native entry has not been opened and verified')
    package = _read_pptx(pptx_path, expected_pages)
    receipt = {'status': 'VERIFIED_PACKAGE', 'delivery_mode': mode, 'title': title,
               'pages': expected_pages, **package}
    if mode == 'native':
        receipt.update({'document_id': document['id'], 'native_url': document['url'],
                        'readback_receipt': copy.deepcopy(document['readback_receipt']),
                        'open_evidence': copy.deepcopy(document['open_evidence'])})
        receipt.update(_verify_pptx_delivery(document, Path(pptx_path).resolve(), expected_pages, package))
    else:
        receipt.update(_verify_file_only(document, Path(pptx_path).resolve(), expected_pages, package))
    return receipt


def complete_delivery(job, document, pptx_path):
    """Mark delivery only after finish and an actual named/opened export.

    Revalidate legacy DELIVERABLE jobs with studio.finish first; do not accept
    their former status as proof of a completed download.
    """
    if job.get('status') != 'READY_FOR_EXPORT':
        raise ValueError('Run studio.finish before verifying delivery')
    if any(op.get('phase') != 'COMPLETE' for op in job.get('write_operations', {}).values()):
        raise ValueError('Unresolved native write; delivery cannot be completed')
    receipt = verify_delivery(document, pptx_path, len(job['plan']))
    out = copy.deepcopy(job)
    out['delivery'] = receipt
    out['status'] = 'DELIVERED'
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['intake', 'resolve', 'recover', 'delivery', 'complete'])
    parser.add_argument('input', type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8'))
    if args.command == 'intake':
        import intake_form
        print(intake_form.render(data))
    elif args.command == 'resolve':
        print(json.dumps(resolve_choices(data['groups'],data['reply']),ensure_ascii=False))
    elif args.command == 'recover':
        print(json.dumps(recover_write(data['state'], data['evidence']), ensure_ascii=False))
    elif args.command == 'complete':
        print(json.dumps(complete_delivery(data['job'], data['document'], data['pptx_path']), ensure_ascii=False))
    else:
        print(json.dumps(verify_delivery(data['document'], data['pptx_path'], data['expected_pages']), ensure_ascii=False))


if __name__ == '__main__':
    main()
