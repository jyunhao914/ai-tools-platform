#!/usr/bin/env python3
"""Prepare the unchanged form via its canonical contract, without any MCP call.

Private candidate only. Prepared files are not UI or submission evidence.
The host must supply execution, formal visualization and a supported send bridge.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

# The pinned runtime is immutable job evidence, not a Python bytecode cache.
sys.dont_write_bytecode = True
from intake_form import render
from stage_form_runtime import RuntimeStageError, stage_runtime

ROOT = Path(__file__).resolve().parent
NODE_TIMEOUT_SECONDS = 30
ERROR_MESSAGES = {
    'PORTABLE_NODE_NOT_FOUND': 'Node executable was not found; use the current host execution environment.',
    'PORTABLE_NODE_START_FAILED': 'Node could not be started; inspect the current host execution environment.',
    'PORTABLE_NODE_TIMEOUT': 'Node preparation timed out; retain the existing job before retrying.',
    'PORTABLE_MODULE_LOAD_FAILED': 'The canonical modules could not be loaded; check the packaged files and Node compatibility.',
    'PORTABLE_INPUT_READ_FAILED': 'The preparation input could not be read.',
    'PORTABLE_INPUT_INVALID': 'Input validation failed; inspect WORKFLOW_SCHEMA and retain the existing job.',
    'PORTABLE_NODE_FAILED': 'Node preparation failed without a recognized diagnostic; retain the existing job.',
    'PORTABLE_PREPARE_OUTPUT_INVALID': 'Node did not return a valid configuration; no form was prepared.',
    'PORTABLE_RENDER_FAILED': 'Form rendering or preview validation failed; retain the existing input and all validation checks.',
    'PORTABLE_OUTPUT_TOO_LARGE': 'Form exceeds the supported size; no output was written.',
    'PORTABLE_PATH_INVALID': 'Use distinct absolute output paths; input and existing job records are read-only.',
    'PORTABLE_OUTPUT_EXISTS': 'Output already exists; reuse the saved form and request instead of replacing them.',
    'PORTABLE_INPUT_TOO_LARGE': 'Input exceeds the supported size; no output was written.',
    'PORTABLE_INPUT_CHANGED': 'Input changed during preparation; inspect the job before retrying.',
    'PORTABLE_FILE_IO_FAILED': 'A required file operation failed; retain the existing job and inspect file access.',
    'PORTABLE_INTERNAL_FAILED': 'Preparation failed; retain the existing job. No successful display or submission is implied.',
}
# Only a known helper exit code AND its exact fixed diagnostic classify a failure.
# Use stdout for this fixed packet so Node warnings do not hide the classification.
# Arbitrary stderr, including runtime stack traces, is never printed or inspected.
NODE_DIAGNOSTICS = {
    64: 'PORTABLE_INPUT_INVALID',
    65: 'PORTABLE_MODULE_LOAD_FAILED',
    66: 'PORTABLE_INPUT_READ_FAILED',
    70: 'PORTABLE_NODE_FAILED',
}


class PortableIntakeError(ValueError):
    def __init__(self, code):
        self.code = code if code in ERROR_MESSAGES else 'PORTABLE_INTERNAL_FAILED'
        super().__init__(f'{self.code}: {ERROR_MESSAGES[self.code]}')


def prepare(data, *, node='node'):
    try:
        result = subprocess.run([node, str(ROOT / 'portable_prepare.mjs')],
            input=json.dumps(data), capture_output=True, text=True,
            encoding='utf-8', errors='replace', timeout=NODE_TIMEOUT_SECONDS)
    except FileNotFoundError:
        raise PortableIntakeError('PORTABLE_NODE_NOT_FOUND') from None
    except subprocess.TimeoutExpired:
        raise PortableIntakeError('PORTABLE_NODE_TIMEOUT') from None
    except OSError:
        raise PortableIntakeError('PORTABLE_NODE_START_FAILED') from None
    if result.returncode:
        code = NODE_DIAGNOSTICS.get(result.returncode)
        if code is None or result.stdout != json.dumps({'error': code}, separators=(',', ':')) + '\n':
            code = 'PORTABLE_NODE_FAILED'
        raise PortableIntakeError(code)
    try:
        config = json.loads(result.stdout)
    except (ValueError, TypeError):
        raise PortableIntakeError('PORTABLE_PREPARE_OUTPUT_INVALID') from None
    if not isinstance(config, dict):
        raise PortableIntakeError('PORTABLE_PREPARE_OUTPUT_INVALID')
    try:
        html = render(config)  # Original renderer: image decoding and all preview validation stay intact.
    except Exception:
        raise PortableIntakeError('PORTABLE_RENDER_FAILED') from None
    if len(html.encode('utf-8')) >= 960000:
        raise PortableIntakeError('PORTABLE_OUTPUT_TOO_LARGE')
    return config, html


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--config-output', type=Path, required=True)
    parser.add_argument('--node', default='node')
    parser.add_argument('--job-directory', type=Path,
                        help='Fixed persistent job directory; defaults to config-output parent for compatibility.')
    args = parser.parse_args()
    outputs = (args.config_output, args.output)
    if any(not p.is_absolute() for p in outputs) or len({p.resolve() for p in (args.input, *outputs)}) != 3:
        raise PortableIntakeError('PORTABLE_PATH_INVALID')
    if any(p.exists() or p.is_symlink() for p in outputs):
        raise PortableIntakeError('PORTABLE_OUTPUT_EXISTS')
    original = args.input.read_bytes()
    if len(original) > 2000000:
        raise PortableIntakeError('PORTABLE_INPUT_TOO_LARGE')
    try:
        data = json.loads(original)
    except (ValueError, UnicodeError):
        raise PortableIntakeError('PORTABLE_INPUT_INVALID') from None
    config, html = prepare(data, node=args.node)
    if args.input.read_bytes() != original:
        raise PortableIntakeError('PORTABLE_INPUT_CHANGED')
    # Before publishing the first form, pin trusted sibling code while the mount
    # is available. Form input never chooses the source or executable.
    runtime = stage_runtime(args.job_directory or args.config_output.parent)
    created = []
    try:
        for destination, payload in ((args.config_output, json.dumps(config, ensure_ascii=False, indent=2) + '\n'),
                                     (args.output, html)):
            destination.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            created.append(destination)
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
    except BaseException:
        for path in created:
            path.unlink()
        raise
    print(json.dumps({
        'route': 'portable-form-private-candidate', 'verification_status': 'unverified',
        'display_status': 'prepared',
        'display_reference': 'visualize' + json.dumps({'path': str(args.output.resolve())}) + '',
        'display_instruction': 'Read and follow the formal visualize skill provided in this turn before handing off this reference in the final response. If it is not provided, use supported skill discovery; unknown availability is not a host rejection. Do not invent a display interface or bypass an explicit host rejection. A send bridge that is not yet available does not establish that initial display is unsupported. Prepared is not visible or submitted. Preserve config and current job state; validate an actual human submission with accept_intake.cjs.',
        'config_path': str(args.config_output.resolve()),
        'request_id': config['request_id'], 'job_id': config['job_id'],
        'source_revision': config['source_revision'], 'version': config['version'],
        'bytes': len(html.encode('utf-8')),
        'html_sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
        'canonical_sha256': hashlib.sha256(args.config_output.read_bytes()).hexdigest(),
        **runtime,
    }, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except PortableIntakeError as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
    except RuntimeStageError as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
    except OSError:
        print(str(PortableIntakeError('PORTABLE_FILE_IO_FAILED')), file=sys.stderr)
        sys.exit(1)
    except Exception:
        print(str(PortableIntakeError('PORTABLE_INTERNAL_FAILED')), file=sys.stderr)
        sys.exit(1)
