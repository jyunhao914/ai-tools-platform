#!/usr/bin/env python3
"""Package-root compatibility entry; delegates to this package's canonical helper."""
import json
from pathlib import Path
import subprocess
import sys

EXPECTED_VERSION = "2026.10.26-t140000"
ALLOWED = {"portable_intake.py", "stage_form_runtime.py"}


def main():
    entry = Path(__file__).absolute()
    root = entry.parent.parent.resolve()
    try:
        if entry.name not in ALLOWED or entry.is_symlink():
            raise ValueError()
        for relative in ("plugin.json", ".codex-plugin/plugin.json"):
            path = root / relative
            if path.resolve().parent != (root / relative).parent or path.is_symlink():
                raise ValueError()
            manifest = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(manifest, dict) or manifest.get("name") != "presentation-studio" or manifest.get("version") != EXPECTED_VERSION:
                raise ValueError()
        skill = root / "skills/presentation-studio"
        target = skill / "scripts" / entry.name
        # A wrapper never searches the filesystem or follows another installed package.
        if skill.resolve() != skill or target.resolve() != target or not target.is_file():
            raise ValueError()
        if not (skill / "SKILL.md").is_file():
            raise ValueError()
    except (OSError, ValueError, TypeError, UnicodeError):
        print(json.dumps({"error": "FORM_PACKAGE_ENTRY_INVALID"}), file=sys.stderr)
        return 64
    return subprocess.call([sys.executable, "-B", str(target), *sys.argv[1:]])


if __name__ == "__main__":
    sys.exit(main())
