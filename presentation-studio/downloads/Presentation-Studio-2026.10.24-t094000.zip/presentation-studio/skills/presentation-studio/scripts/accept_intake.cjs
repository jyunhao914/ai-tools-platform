/* Validate against the saved form and claim one receipt before any side effect.
 * No network. Receipts are local progress records, never evidence of delivery.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {studioSelection} = require('./intake_form.js');

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(
    Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}
const encode = value => JSON.stringify(canonical(value));
const digest = value => crypto.createHash('sha256').update(encode(value)).digest('hex');

function validate(config, received, current) {
  if (!config.job_id || current.job_id !== config.job_id || received.job_id !== config.job_id ||
      received.request_id !== config.request_id) throw Error('Job or request does not match the saved form');
  if ((config.source_revision || '') !== (current.source_revision || '') ||
      (received.source_revision || '') !== (config.source_revision || '')) throw Error('Stale source revision: retain current content');
  if (current.active_request_id && current.active_request_id !== config.request_id)
    throw Error('A newer form is active: retain current requirements');
  const values = {...received, ...received.choices, next_action: received.requested_action};
  const selection = studioSelection(config, values);
  if (encode(selection) !== encode(received)) throw Error('Received selection does not match the saved form contract');
  if (selection.next_action === 'produce' && !selection.settings_only &&
      (!config.source_revision || !current.confirmation_quote || current.outline_revision == null ||
       current.confirmed_outline_revision !== current.outline_revision))
    throw Error('Latest content has not been confirmed');
  return selection;
}

function accept(config, received, current, directory) {
  const selection = validate(config, received, current);
  const id = digest(selection);
  const receipt = {id, job_id: config.job_id, request_id: config.request_id,
    source_revision: config.source_revision, selection, status: 'received'};
  fs.mkdirSync(directory, {recursive: true});
  // All production submissions for this content revision share a claim. Changed
  // settings cannot silently launch a second deck while the first is unresolved.
  const producing = selection.next_action === 'produce' && !selection.settings_only;
  const key = producing ? digest({job: config.job_id, revision: config.source_revision, action: 'produce'}) : id;
  const destination = path.join(directory, key + '.json');
  const temporary = path.join(directory, '.' + crypto.randomUUID() + '.tmp');
  const descriptor = fs.openSync(temporary, 'wx');
  try {
    fs.writeFileSync(descriptor, JSON.stringify(receipt, null, 2) + '\n');
    fs.fsyncSync(descriptor);
  } finally { fs.closeSync(descriptor); }
  try {
    // Publish a complete file exclusively: no reader can observe a half-written
    // receipt, and concurrent submissions cannot both acquire this claim.
    try { fs.linkSync(temporary, destination); }
    catch (error) {
      if (error.code !== 'EEXIST') throw error;
      let existing;
      try { existing = JSON.parse(fs.readFileSync(destination, 'utf8')); }
      catch { throw Error('Receipt is incomplete: inspect this job before retrying any side effect'); }
      if (existing.id !== id) throw Error('Production already claimed: inspect the existing job, then create a revision for changed settings');
      return {action: 'resume', receipt_path: destination, receipt: existing};
    }
    return {action: 'accepted', receipt_path: destination, receipt};
  } finally { fs.unlinkSync(temporary); }
}

if (require.main === module) {
  const [configPath, receivedPath, currentPath, directory] = process.argv.slice(2);
  try {
    if (!directory) throw Error('Usage: node accept_intake.cjs config.json received.json intake-state.json receipts-directory');
    const read = filename => JSON.parse(fs.readFileSync(filename, 'utf8'));
    console.log(JSON.stringify(accept(read(configPath), read(receivedPath), read(currentPath), directory)));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = {validate, accept};
