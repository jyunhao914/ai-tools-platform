"""Prepare packaged form input from a fresh validated Drive catalog; no cloud writes."""
from style_library import form_group


def arguments(source_kind, *, menu=None, selected=None, library_status=None,
              library_message=None, target_pages=None, custom_style=None,
              audience=None, outline_input=None, next_action=None, source_revision=None,
              settings_only=False, phase=None, source_has_images=None, source_layout=None, **flow):
    file_kinds = {'pdf', 'pptx', 'slides', 'image', 'document'}
    if source_kind not in {'unknown', 'topic', 'outline'} | file_kinds:
        raise ValueError('source_kind must be unknown, topic, outline, PDF, slides, image or document')
    if source_layout is not None and (source_layout not in {'slides', 'document'} or source_kind not in file_kinds):
        raise ValueError('File source_layout must be slides or document')
    if source_layout is None and source_kind in file_kinds:
        source_layout = 'document' if source_kind in {'image', 'document'} else 'slides'
    if phase is None:
        phase = "entry" if source_kind == "unknown" else "settings" if flow.get("content_confirmed") else "requirements" if source_kind == "topic" or source_layout == 'document' else "outline_review" if source_kind == "outline" else "operation"
    if phase not in ("entry", "requirements", "outline_review", "operation", "settings"):
        raise ValueError("Invalid intake phase")
    if source_kind == "unknown" and phase != "entry":
        raise ValueError("Unknown source_kind is allowed only in entry phase")
    if phase == "entry" and flow.get("content_confirmed"):
        raise ValueError("Entry only selects a workflow; it cannot confirm content")
    result = {'source_kind': source_kind, 'selected': dict(selected or {}), 'phase': phase, **flow}
    if source_layout is not None:
        result['source_layout'] = source_layout
    if source_has_images is not None:
        if not isinstance(source_has_images, bool):
            raise ValueError('source_has_images must be a verified boolean')
        result['source_has_images'] = source_has_images
    if phase in ("entry", "requirements", "outline_review", "operation"):
        pass
    elif menu is not None:
        issues = [f"{item['name']}：{item['preview_upgrade_reason']}"
                  for item in menu.get('preview_upgrades', [])]
        issues += [f"{item.get('name', '未命名風格')}：{item['error']}"
                   for item in menu.get('warnings', [])]
        message = '暫不可選的款式：' + '；'.join(issues) if issues else None
        available = [item for item in menu.get('items', [])
                     if not item.get('preview_upgrade_reason')]
        if menu.get('state') == 'READY' and available:
            options = form_group(menu)['options']
            result.update(library_status='ready', catalog_snapshot=menu['snapshot'],
                          personal_styles=[{key: item[key] for key in
                            ('id', 'label', 'preview_data', 'preview_metadata')}
                            for item in options])
            if message:
                result['library_message'] = message
        elif menu.get('state') == 'EMPTY' and not menu.get('items') and not issues:
            result.update(library_status='empty', catalog_snapshot=menu['snapshot'])
        elif menu.get('state') in ('READY', 'UNAVAILABLE') and message:
            result.update(library_status='error', library_message=message,
                          catalog_snapshot=menu['snapshot'])
        else:
            raise ValueError('風格庫狀態不可用；不得偽稱為空庫')
    elif library_status in ('error', 'not_connected') and library_message:
        result.update(library_status=library_status, library_message=library_message)
    else:
        raise ValueError('需要完整雲端清單或實際連接錯誤；不可省略風格庫')
    if target_pages is not None:
        if type(target_pages) is not int or target_pages < 1:
            raise ValueError('目標頁數必須是正整數')
        result['target_pages'] = target_pages
    if custom_style is not None:
        result['custom_style'] = custom_style
    for key, value, limit in (("audience", audience, 200), ("outline_input", outline_input, 20000),
                              ("source_revision", source_revision, 200)):
        if value is not None:
            if not isinstance(value, str) or len(value) > limit:
                raise ValueError(f'Invalid or oversized {key}')
            result[key] = value
    if next_action is None:
        next_action = "select_mode" if phase == "entry" else "produce"
    if phase == "entry":
        if next_action != "select_mode":
            raise ValueError('Entry next_action must be select_mode')
    elif next_action not in ("produce", "edit_outline"):
        raise ValueError('next_action must be produce or edit_outline outside entry')
    result['next_action'] = next_action
    if not isinstance(settings_only, bool):
        raise ValueError('settings_only must be a boolean')
    if settings_only:
        result['settings_only'] = True
    return result
