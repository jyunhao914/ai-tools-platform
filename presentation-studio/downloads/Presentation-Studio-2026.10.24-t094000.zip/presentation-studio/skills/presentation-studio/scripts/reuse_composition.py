"""Deterministic IMAGE+REUSE page composition; no image generation or redraw.

Only the confirmed page text, verified original images, a solid background and
hash-identified fonts can enter a render. Pillow is loaded only for rendering.
"""
import hashlib
import io
import json
from pathlib import Path
import re

WIDTH, HEIGHT = 1280, 720


def digest(value):
    if not isinstance(value, bytes):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(value).hexdigest()


def _keys(value, required, optional=()):
    if not isinstance(value, dict) or not set(required) <= value.keys() or set(value) - set(required) - set(optional):
        raise ValueError('組版欄位不完整或包含不支援的內容')


def _color(value):
    if not isinstance(value, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', value):
        raise ValueError('組版顏色須為不透明六位色碼')


def _frame(value):
    _keys(value, ('left', 'top', 'width', 'height'))
    x, y, w, h = (value[k] for k in ('left', 'top', 'width', 'height'))
    if any(type(n) is not int for n in (x, y, w, h)) or min(x, y) < 0 or min(w, h) <= 0 or x+w > WIDTH or y+h > HEIGHT:
        raise ValueError('組版位置須在 1280×720 畫布內')
    return x, y, w, h


def validate(page, sources, layout):
    _keys(layout, ('background', 'images', 'texts'))
    _color(layout['background'])
    if not isinstance(layout['images'], list) or not isinstance(layout['texts'], list):
        raise ValueError('組版圖片與文字須為清單')
    if not layout['images'] and not page['texts']:
        raise ValueError('不能建立空白整頁圖片')
    if [item.get('text_index') for item in layout['texts'] if isinstance(item, dict)] != list(range(len(page['texts']))):
        raise ValueError('組版必須依序包含每一段已確認文字，不能增刪或重複')
    frames = []
    for item in layout['images']:
        _keys(item, ('source_asset', 'position'))
        asset = item['source_asset']
        _keys(asset, ('source_id', 'sha256'))
        source = next((s for s in sources if s['id'] == asset['source_id']), None)
        if (not source or source['id'] not in page['source_ids'] or
            not re.fullmatch(r'[a-f0-9]{64}', str(asset['sha256'])) or
            not any(image.get('sha256') == asset['sha256'] for image in source.get('images', []))):
            raise ValueError('組版原圖須對應本頁已驗證的來源 SHA')
        frames.append(_frame(item['position']))
    for item in layout['texts']:
        _keys(item, ('text_index', 'position', 'font_size', 'font_sha256', 'color'))
        if type(item['text_index']) is not int or not re.fullmatch(r'[a-f0-9]{64}', str(item['font_sha256'])):
            raise ValueError('組版文字索引或字型 SHA 不正確')
        if type(item['font_size']) is not int or not 12 <= item['font_size'] <= 120:
            raise ValueError('組版字級須介於 12 與 120 像素')
        _color(item['color'])
        frames.append(_frame(item['position']))
    for i, (x, y, w, h) in enumerate(frames):
        if any(x < a+c and x+w > a and y < b+d and y+h > b for a, b, c, d in frames[:i]):
            raise ValueError('原圖與文字區塊不能互相遮擋；請調整版面')


def _bytes(files, sha, label):
    if not isinstance(files, dict) or sha not in files:
        raise ValueError(label+'缺少實際檔案')
    try:
        data = Path(files[sha]).read_bytes()
    except (OSError, TypeError) as exc:
        raise ValueError(label+'檔案無法讀取，請提供目前環境的實際檔案') from exc
    if digest(data) != sha:
        raise ValueError(label+'檔案與原始 SHA 不一致')
    return data


def _glyph_signature(font, char):
    mask = font.getmask(char)
    return mask.size, bytes(mask), font.getbbox(char), font.getlength(char)


def _wrap_text(text, width, measure):
    lines, line = [], ''
    closing, opening = '，。；：！？、）】》〉」』〕％%', '（【《〈「『〔'
    for char in text:
        if char == '\n':
            lines.append(line); line = ''; continue
        if measure(char) > width:
            raise ValueError('文字欄太窄，不能裁切已確認文字')
        if line and measure(line+char) > width:
            carry = ''
            if char in closing and len(line) > 1:
                cut = len(line)-1
                while cut > 0 and line[cut] in closing:
                    cut -= 1
                line, carry = line[:cut], line[cut:]
            elif line[-1] in opening:
                cut = len(line)-1
                while cut > 0 and line[cut-1] in opening:
                    cut -= 1
                line, carry = line[:cut], line[cut:]
            if not line or measure(carry+char) > width:
                raise ValueError('文字欄太窄，不能將中文標點孤立在行首或裁切文字')
            lines.append(line); line = carry
        line += char
    lines.append(line)
    return lines


def render(page, sources, layout, source_files, font_files):
    """Return PNG bytes plus measured evidence, never a caller-supplied receipt."""
    validate(page, sources, layout)
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageOps, __version__
    except ImportError as exc:
        raise ValueError('整頁原圖組版需要 Pillow；尚未生成或登記成果') from exc
    canvas = Image.new('RGBA', (WIDTH, HEIGHT), layout['background'])
    image_evidence, font_evidence = [], {}
    for item in layout['images']:
        asset = item['source_asset']
        data = _bytes(source_files, asset['sha256'], '來源圖片')
        with Image.open(io.BytesIO(data)) as original:
            if original.format not in {'PNG', 'JPEG', 'WEBP'} or getattr(original, 'n_frames', 1) != 1:
                raise ValueError('組版只支援靜態 PNG、JPEG 或 WebP 原圖')
            if original.width * original.height > 40_000_000:
                raise ValueError('來源圖片尺寸過大，請先確認可用素材')
            original.load()
            oriented = ImageOps.exif_transpose(original)
            x, y, w, h = _frame(item['position'])
            ratio = min(w/oriented.width, h/oriented.height)
            size = (max(1, round(oriented.width*ratio)), max(1, round(oriented.height*ratio)))
            placed = oriented.convert('RGBA').resize(size, Image.Resampling.LANCZOS)
            canvas.alpha_composite(placed, (x+(w-size[0])//2, y+(h-size[1])//2))
            image_evidence.append({**asset, 'original_size': list(original.size),
                                   'exif_orientation': original.getexif().get(274, 1),
                                   'placed_size': list(size), 'position': dict(item['position']), 'transform': 'contain'})
    draw = ImageDraw.Draw(canvas)
    for item in layout['texts']:
        text = page['texts'][item['text_index']]
        if not isinstance(text, str):
            raise ValueError('已確認文字須為字串')
        sha = item['font_sha256']
        try:
            font = ImageFont.truetype(io.BytesIO(_bytes(font_files, sha, '字型')), item['font_size'])
        except OSError as exc:
            raise ValueError('字型無法載入，請提供目前環境可用且支援本文的字型') from exc
        missing = _glyph_signature(font, chr(0x10ffff))
        for char in set(text)-{'\n', ' '}:
            if _glyph_signature(font, char) == missing:
                raise ValueError('字型缺少字元 U+'+format(ord(char), '04X')+'；請使用支援本文的實際字型，不能以缺字方框交付')
        font_evidence[sha] = {'sha256': sha, 'family': font.getname()[0], 'style': font.getname()[1]}
        x, y, w, h = _frame(item['position'])
        # Character wrapping preserves CJK and whitespace without rewriting.
        lines = _wrap_text(text, w, lambda line: draw.textlength(line, font=font))
        ascent, descent = font.getmetrics()
        line_height = ascent+descent+max(2, item['font_size']//5)
        if len(lines)*line_height > h:
            raise ValueError('文字超出版面，請重新排版；不能省略或裁切')
        for index, line in enumerate(lines):
            if line:
                box = draw.textbbox((x, y+index*line_height), line, font=font, anchor='lt')
                if box[0] < x or box[2] > x+w or box[3] > y+h:
                    raise ValueError('文字實際字形超出欄位，請重新排版')
                draw.text((x, y+index*line_height), line, font=font, fill=item['color'], anchor='lt')
    output = io.BytesIO()
    canvas.convert('RGB').save(output, format='PNG', compress_level=9)
    data = output.getvalue()
    evidence = {'renderer': 'original-image-composition-v1', 'pillow_version': __version__,
                'output_sha256': digest(data), 'output_size': [WIDTH, HEIGHT],
                'layout_sha256': digest(layout), 'texts_sha256': digest(page['texts']),
                'source_assets': image_evidence, 'fonts': list(font_evidence.values())}
    return data, evidence
