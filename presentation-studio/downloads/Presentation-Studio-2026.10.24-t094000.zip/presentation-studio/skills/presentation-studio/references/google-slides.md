# Google Slides 雲端路徑

此路徑透過使用者已連接的 Google Drive 工具，在 Google 伺服器建立、編輯、匯出。不要求使用者安裝桌面軟體，也不把本機生成 PPTX 再上傳當成雲端組版。提示詞、排版計畫及程式可在平台託管沙箱暫存。使用者明確要求 Spaces 時不得自行切換。

## 建立與保存

- create_file 的 MIME 為 application/vnd.google-apps.presentation。OAuth 連線建立時不傳 parent_folder_id；取得真實 ID 後讀 parents，再用 update_file 移入使用者指定的製作紀錄資料夾。
- 建立成功後 get_presentation 讀 pageSize、revisionId、slides。新檔可能已有一頁含空白標題框。只可在確認是本次新檔、文字和素材皆空白後使用它，或在新增完成後刪除這一張；不能刪除其他檔案的原頁。
- 使用 batch_update_presentation 寫入原生物件。每批使用剛讀回或前一批成功返回的 requiredRevisionId，遇到衝突讀取新狀態再決定，不蓋過使用者修改。
- scripts/google_slides.py 的 compile_page 以 1280×720 計畫產生 16:9 的原生文字、矩形表格及圖片請求，tool_batches 拆為每次最多一個圖片上傳。它是常見版型的適配器，不限制自行設計排版；特殊表格及圖表可自行使用 Google 原生 API。
- 保留內容時 K 文字取自保存的原始來源；T 取自綁定原 source_hash 且已通過 confirm_text_revision 的文字快照，依同版計畫寫入，不自行再次潤飾。物件 ID 由 job 與頁面產生，逾時後保留同一 ID 查回，不能改 ID 再做。工具成功返回後仍核對實際讀回內容。

## 獨立 PNG 與圖像式

目前 batch_update_presentation 的 image_uris 是單一檔案路徑字串，不能傳 JSON 陣列或把多個路徑串起來。一次傳一張平台沙箱 PNG，createImage.url 使用同一佔位路徑，由連接器上傳處理。不要公開使用者的 Drive 圖片權限來湊公開 URL。不同環境若工具 schema 改變，依其正式 schema 適配。

一頁多張配圖分批插入同一 slide，不重複 createSlide 或文字。圖像式每頁放入該頁完整 PNG。Google 按原始比例置入圖片框，不要用不等比變形；表格和解剖示意圖不能裁切資訊。為每個 image object 記錄 SHA256、來源持久 file ID 和當頁 slot。詮釋資料的 hash 只是追蹤線索，還須查看實際圖片，匯出時比對內嵌 PNG 才能證實沒有替換。

## 可編輯表格與換行

來源 `texts` 以文字框或儲存格為單位，內部換行保留為 `\n`；空白儲存格也保留。`tables[].text_indices` 是每列、每欄對應到 `texts` 的索引，不能重新摘要儲存格內容。

排版計畫可沿用來源表格的 text_indices，加入 `position`、`size` 和 `header_rows`。`textBoxes` 與 texts 等長，屬於表格的項目填 null，避免同一內容又畫成文字框。compile_page 產生真正原生表格；verify_page 按物件 ID 與儲存格位置讀回，不能只確認所有文字有出現就認定對應正確。

空白儲存格不插入空格，也不發送 updateTextStyle，因為 Google 會拒絕對無文字儲存格設定文字樣式。一般段落的換行可能在 PPTX 匯出後成為另一種段落表示，仍以同一文字框內的完整文字核對。

來源合併儲存格資訊保留在 merges。簡易編譯器不自動展平成未合併表格；此類來源須依資料關係設計原生合併操作並另外檢查，不能刪掉 merges 就冒充完整還原。表格可能受最小列高影響，全部內容讀回後仍須查看實際版面，不能只相信要求的外框尺寸。

## 驗收與匯出

修改既有圖片使用 `replace_asset`，傳入最新讀回頁面與原 binding。它會核對上傳檔案實際 SHA256、目標頁／圖片與舊版本；輸出經 `tool_batches` 後以同次 revisionId 提交。替換後保留原 object ID，`CENTER_INSIDE` 避免裁切。重新讀回確認再更新工作紀錄。超時後發現目標已是選定版本，不再次替換；不可因工具回覆未知而重生圖片。詳見 [工作紀錄](job-ledger.md)。

全部物件插入後一次讀回原生文字、圖片 ID、頁數和順序。新製頁面備忘稿預設空白；內部 JSON、檢查資料及來源清單另存 job，不寫入 notes。匯出後再核對全部備忘稿，只有明確要求的講稿可以保留。Google 文字框會有一個結構性結尾換行，核對時只移除該換行，不刪掉來源中的有意換行。verify_page 用於文字及綁定讀回，不能取代視覺驗收。

透過 Google Slides 技能正式 PDF 匯出／渲染輔助檢查所有頁面。若當前沙箱沒有工具返回的 materialized workspace_path，保存實際錯誤；可用工具返回的授權下載參照取得同份 PDF，或使用正式縮圖工具檢查。不能聲稱沒有看過的頁面已通過。

正文不能貼齊頁面底緣。一般文字至少保留頁高 3% 的底部留白，並將字型實際行高、段落間距及文字框內距算入可用高度；文字框外框未超出頁面不代表文字不會被裁切。內容多時先重新分配區塊、縮短區塊間距，再調整字級，不得為塞入版面刪掉應保留的原文。下載 PPTX 後逐頁檢查實際匯出成品，尤其最後一行；修正時保留同一文件及物件 ID，重新匯出整份檔案，不能再交付已下載的舊檔。

使用 Drive export_file 匯出 application/vnd.openxmlformats-officedocument.presentationml.presentation。10 MB 限制失敗時使用 fetch(download_raw_file=true, include_base64=false, raw_export_mime_type=同 MIME)，不要交付截斷檔案。私密下載網址會過期，工作紀錄保留原生文件 ID，不存簽名網址。需要持久 PPTX 時另存至同一 job 的 Drive 資料夾。

這些 Google API 呼叫可以證明雲端製作；只有在電腦網頁版完成安裝與實際操作，才能另外宣稱網頁版端到端驗收通過。

若原生匯出與官方下載路徑均失敗，保留兩次實際錯誤，不直接把 403 推斷成使用者無權限。可在平台雲端沙箱以已確認的版面計畫、原生文字與原始 PNG 另行組裝可編輯 PPTX；重新讀取核對文字、物件、圖片並看各頁後交付，明說是另行封裝而非 Google 直接匯出成功。不得使用使用者電腦上的軟體作為必要步驟，不重生圖；複雜原生效果無法等價還原時揭露差異。

文字框可指定 `color`、`fill` 與 `alignment`；編譯器應保留這些設定，不能全部覆寫為風格的共同文字色。對齊接受 left/start、center、right/end、justify/justified；不支援的值在送出前報錯。匯出後核對實際顏色、底色及對齊，不能只核對正文。
