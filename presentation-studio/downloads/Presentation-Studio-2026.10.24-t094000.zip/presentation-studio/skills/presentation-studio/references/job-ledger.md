# 來源、圖片版本與恢復紀錄

`scripts/studio.py` 是平台沙箱可載入的標準 Python 模組，不需使用者安裝 Python。由呼叫端先在平台託管工作目錄保存 JSON；它本身不會上傳。每次修改後呼叫 `write_json`。只有使用者明確要求備份本次來源與紀錄到指定 Drive 位置時才上傳，成功後登記真實 file ID。未備份不可宣稱雲端保存或跨對話可恢復；備份不是製作成品的前置條件。

## 一次新製作

1. `pptx(path)` 或 `outline(text)` 取得來源。PPTX 的 `images` 保留來源檔案內的 `source_part` 與實際位元組 SHA256；texts 保留文字框／儲存格內換行，tables 保存儲存格索引與合併資訊。PDF 必須使用平台閱讀／渲染工具逐頁取得內容，不能交給大綱解析器假裝成功。
2. `new_job(slides, mode, policy, style, operation, target_pages, text_mode="K", asset_storage="drive")`。style 至少包含 `selection` 與 `user_choice`，例如 `{"selection":"02","user_choice":"選藍色醫療"}`；原話需來自實際回答，未選先顯示風格並詢問，不補成自動。來源設定後保留不可變的原始快照；縮減／擴增改製作計畫並保留來源對應。明確的另一份獨立任務才新建 job。同一任務一次多檔或後續補充／替換來源，沿用 intake-state.json 的 job_id，保存新來源快照並遞增 source_revision，使舊表單與受影響的內容確認失效；保留仍適用的人類設定及舊修訂。已有製作紀錄時按 source-to-deck.md 建立修訂，不原地改寫已凍結的 studio.py 來源、計畫或雜湊，也不因附件數量拆成多份獨立任務。

   PRESERVE 也接受已確認的 target_pages，用於保留內容重新分頁；不傳時沿用原頁數。K 的不同頁數計畫逐字核對原稿全文與順序，並保留連續的 source_ids 對應；同一來源可分到相鄰目標頁，不能刪改正文、遺漏或重排來源。T 依下節的明確確認文字快照核對，原始來源仍不變；不得借潤飾增刪事實或跳過來源順序驗證。一頁既有投影片分成兩頁仍是 PRESERVE，不改為 EXPAND。海報／資料轉成新簡報時先規劃並確認新的逐頁稿，再用該稿建立製作計畫。目標頁數不等於已確認內容配置，仍須遵守前面的內容確認流程。

   重新分頁時，每頁的 source_ids 必須符合該頁文字在原稿中的實際位置；跨兩個來源的文字不能只標一個來源。不得新增空白填充頁。沒有文字的純圖片頁，須有 REUSE／REDRAW slot，或 IMAGE＋REUSE 的 COMPOSE_REUSE.composition.images，並以 source_asset={"source_id":"來源頁 ID","sha256":"原圖 SHA256"} 對應 source.images 中已讀取的原圖；憑空新增 GENERATE slot 不算保留來源內容。
3. `plan(job, pages)` 保存確認後的文字與每頁圖片位置。它核對頁數、來源對應、K 的原稿文字或 T 的已確認快照，以及同頁每張圖片的獨立 slot ID。排版仍可自行撰寫，不要求固定模板。可編輯＋生成配圖時，先呼叫 series_requirements(source)：明確箭頭序列自動識別；其他比較／步驟由閱讀來源後記錄 source.visual_series=[{"kind":"comparison","members":["調整前","調整後"]}]。先保存這份來源再 new_job，不修改已凍結來源。plan 的每頁附 series_bindings=[{"members":["調整前","調整後"],"slot_ids":["before","after"]}]，每個項目對應不同的 GENERATE slot。四階段缺一圖位、只規劃一張綜合圖或重用同一 slot 都不通過，須自行補完整計畫；NONE／REUSE 及整頁圖像式不套用逐項生成要求。縮減／擴增使用確認後的頁面 texts／visual_series，不強迫保留已刪除的來源序列。

   K 保留內容重新分頁時，系列成員依原文位置分配到新頁，同一成員的標籤不能拆成兩頁。若合併後出現成員名稱相同的不同系列，series_bindings 另加 series_id（使用 series_requirements 返回的 id），例如 {"series_id":"source-a-series-1","members":["調整前","調整後"],"slot_ids":["before-a","after-a"]}。不同來源可用 source_id 區分；同一來源仍有歧義時必須用 series_id。成員不重複時原有 members＋slot_ids 寫法仍可使用。T 使用已確認頁面 texts／visual_series 的實際成員，不拿已潤飾掉的舊標籤強迫配圖；新增的系列關係也須符合已確認內容。
4. 只有 GENERATE／REDRAW slot 呼叫 `dispatch(job, page_id, slot_id, prompt)`，先建立唯一生成請求並保存本次工作紀錄，再呼叫平台 ImageGen。REUSE 及 COMPOSE_REUSE 使用下節專用登記流程，不呼叫 dispatch。結果未知時，先找回原呼叫結果，不改提示詞重送。
5. 取得真正 PNG 後依已明確選定的資產保存方式登記。預設 Drive 先上傳並取得真實 ID，再 `register(job, request_id, sandbox_path, drive_file_id)`；`asset_storage="file_only"` 則以實際絕對路徑 `register(job, request_id, absolute_png_path)`，不填 Drive ID。最新結果自動選定。把同一資產寫入簡報並讀回後，才 `bind(job, page_id, slot_id, request_id, slide_id, image_id)`。

## 資產保存方式

預設 `asset_storage="drive"`，舊 job 沒有此欄位時仍按 Drive 驗證；缺少 ID 不會自動降級。Drive 不可用而依 cloud.md 製作檔案時，在 `new_job(..., asset_storage="file_only")` 明確選定本次工作環境保存。`plan` 固定此選擇；計畫後不能改成另一方式來繞過檢查，需依既有流程建立明確修訂。接續舊版、尚無保存方式快照的計畫時，只有已明確記錄 `asset_storage="file_only"` 的 job 可走本機分支，並須逐筆通過相同的資產驗證。

file_only 的 `register`、`register_reuse`、`register_composition` 均省略 drive_file_id，不填空字串或假 ID。必須傳入當前環境實際存在的絕對檔案路徑；登記保存標準化路徑、實際 SHA256、位元組數與 `persistence="current_environment"`。生成 PNG 結構／CRC、原圖 SHA／來源對應及組版重新渲染逐位元組比對仍照常執行。`select_version`、`bind`、`finish` 會重讀實體檔案，遺失或被替換就拒絕；保留紀錄並找回同一原始資產，不能用修改紀錄、假 ID 或重生圖片冒充恢復。

本機登記不是 Drive 存檔或跨裝置持久連結，也不代表簡報已完成。仍須用當前可用的簡報工具插入同一圖片，讀回 PPTX 內嵌圖片位元組、文字與頁數，完成視覺及 `complete_delivery` 驗證。資產保存在本機與成品是否有原生文件是兩個獨立事實；交付分支依實際文件證據選擇。

## 製作形式與圖片政策的固定對應

plan 的 slots 只表示點陣圖片，不包含原生文字、圖表或形狀。可編輯式各頁可以沒有 slots；圖像式每頁須有且只有一個整頁 slot。

| 製作形式 | 不用圖片 P0 | 沿用原圖 P1 | 超擬真重繪 P2 | 重新生成 P3 |
| --- | --- | --- | --- | --- |
| EDITABLE | 無圖片 slots | REUSE | REDRAW | GENERATE |
| IMAGE | GENERATE，僅排正文／圖表 | COMPOSE_REUSE | REDRAW | GENERATE |

IMAGE＋P0 的整頁 PNG 是輸出容器，不能加一般配圖或沿用原圖；提示詞與逐頁視覺驗收均須核對這點。原生文字／形狀不因 P0 被禁止。GENERATE 不接受 source_asset 或原圖 composition，不能用它冒充重繪；COMPOSE_REUSE 依下節驗證完整組版，不能帶單張 source_asset 假裝整頁。

REUSE／REDRAW 都須提供 `source_asset={"source_id":"來源 ID","sha256":"實際原圖 SHA256"}`，SHA 必須存在於對應來源的 images，而且來源 ID 在本頁 source_ids 中。來源一頁拆成多頁時，各頁可明確對應同一原來源 ID，不要求頁碼相等。IMAGE＋P2 沒有獨立原圖時，可使用**實際擷取並先登記於來源快照**的原頁影像，明示為原頁重繪；沒有原圖就保留待辦，不能改為 P3 或捏造 SHA。已凍結來源不可事後加圖改 hash，補充資產須按來源修訂流程重新確認。

REDRAW 的 dispatch 紀錄保留 source_asset；呼叫 ImageGen 時仍須提供對應的實際原圖作參照，不能只送文字提示。plan 保存已選 mode／policy，後續 dispatch、登記、綁定與 finish 都重新檢查；舊紀錄雖無此快照，也必須符合上述對應才可接續。

## 保留原文時的段落與文字框重排

新版 `pptx(path)` 保留原始 texts 不變，另保存每個文字框／儲存格的實際 XML 段落、來源 part 及 XML SHA256。O1＋K 重新排版可將這些有證據的段落分隔換成文字框或頁面邊界；普通空格、字詞、標點、順序及 `a:br` 軟換行仍逐字核對，英文單詞與數字不能因移除邊界而合併或拆開。來源對應與系列圖位置使用同一段落序列，不能因此漏頁、漏圖或漏系列。

舊 job 沒有 paragraph_evidence 時維持原有精確檢查，不猜測字串中的換行代表段落。需要此重排能力時，重新讀取同一實際原稿取得 XML 證據，依既有修訂流程保存，不手填證據或修改既有 source/hash。製作計畫保留預期的實際文字框內容；finish 仍核對真正讀回的文字與已保存計畫。

## K 原稿與 T 已確認文字快照

`text_mode` 必須採用人類實際選擇；省略時僅為舊 job 相容，依 K 處理。K 的製作計畫與正文維持原稿逐字檢查。O1＋T 使用 `new_job(..., operation="PRESERVE", text_mode="T")` 保留原始 source 與 source_hash；先完成潤飾內容的討論，再呼叫 `confirm_text_revision(job, pages, confirmation_quote)`，保存已確認的頁 id、source_ids、texts、原 source_hash 與實際確認原話。它不是用目前計畫冒充來源，也不是因選了 T 就自動假定任意新稿已獲確認。只展示需確認的變更，不重抄未變全文；已存在涵蓋該版內容的明確確認可直接使用。

完成快照後才 `plan(job, pages)`。快照須覆蓋目標頁數及全部來源，來源順序不變；計畫與 finish 都核對同一快照。未確認、文字／來源／確認原話／快照摘要被修改或計畫仍綁舊文字版本時拒絕。已有 plan 或 requests 後修改文字，建立同一邏輯任務下的新製作修訂 job 並保留舊紀錄，不原地改 hash 避開驗證。實際呼叫見 [製作範例](production_examples.md)。

## 獨立風格分析的紀錄

ANALYZE／analyze_style 先在同一工作紀錄保存實際來源、source_revision、分析結果與通過九頁預覽驗證的證據；不為儲存風格建立簡報、呼叫 finish／complete_delivery 或偽造 DELIVERED。結果交付後可用同一 job 與修訂的 mode=save，保存原 config 及 active_request_id，依 accept_intake.cjs 核對真實收到的 SAVE／SKIP。SAVE 只授權該次風格保存，SKIP 不寫入；兩者都不授權製作。只有 Drive 實際寫入並讀回才記為已保存，不能把收件紀錄當成保存證據。

## 直接沿用原圖

可編輯式沿用原圖的 slot `action` 設 `REUSE`，`source_asset` 為 `{"source_id": "來源頁 ID", "sha256": "來源素材 SHA256"}`。從 PPTX 指定的 source_part 取出原始素材，不重新截圖、不經 AI 重畫。Drive 模式上傳後 `register_reuse(job, page_id, slot_id, file_path, drive_file_id)`；明確 file_only 模式則以原圖絕對路徑呼叫並省略 drive_file_id。兩者都核對原素材實際位元組及來源頁，返回可綁定的 request ID。再次登記相同原素材不會重複產生紀錄。

## 整頁圖像式沿用原圖

IMAGE＋REUSE 每頁使用唯一 `COMPOSE_REUSE` slot；單張 REUSE 素材不能冒充含完整文字的整頁成品。slot.composition 包含 background（六位不透明色碼）、images（source_asset 與 position）、texts（text_index、position、font_size、font_sha256、color）。固定 1280×720，位置以整數像素表示。texts 依序引用該頁全部已確認段落，不另填一份文字；images 只能引用本頁 source_ids 對應的原圖 SHA，使用 contain 保持比例且不裁切。區塊不得重疊，文字超框須調整版面，不能刪字或裁切。images 可空，但整頁不能全空；來源純圖片頁亦可依有效來源對應併到其他頁。此路徑不接受新增配圖、任意背景圖片或 AI 重繪。

先取得實際原圖及字型檔，以 `{sha256: path}` 分別組成 source_files、font_files。字型由當前平台可用依賴或已授權檔案取得，應涵蓋本頁所用文字並實際看圖確認，不能硬編開發者的 macOS／Windows 路徑，也不能在缺中文字時默默替換成方框。Pillow 只在 `compose_reuse`／`register_composition` 實際渲染時載入；一般工作紀錄、來源解析與文字快照不需要它。缺依賴或字型時清楚保留待辦，不省略驗證或改呼叫 ImageGen。

呼叫 `compose_reuse(job, page_id, slot_id, source_files, font_files, output_path)` 產出真實 PNG 與計量證據；這一步不登記 READY、不代表保存或交付。雲端 Drive 路徑上傳後取得真實 drive_file_id，再 `register_composition(job, page_id, slot_id, file_path, source_files, font_files, drive_file_id)`。程式用相同原圖、字型及版面重新渲染並逐位元組比對，成功才登記；保留原圖 SHA、實際尺寸、contain 位置、字型 SHA、輸出 SHA 與來源／計畫／文字／版面摘要。渲染與登記使用相同檔案及執行環境，不能中途換字型或用外部 PNG 取代。實際插入簡報並讀回後才 bind，最後 finish／交付驗證依原流程。明確 file_only 模式則以組版輸出的絕對路徑呼叫同一 register_composition 並省略 drive_file_id，仍重渲染核對全部證據。Drive 不可用時按 cloud.md 的檔案交付流程處理，不能虛構 Drive ID。

完整可執行組版範例見 [製作呼叫範例](production_examples.md)。

## 修改、指定舊版與更新簡報

使用者明確修改才重新 `dispatch`，附 `revision={"id": "本次修改 ID", "reason": "已確認修改要求"}`；微小色差或 OCR 檢查不自動產生修改請求。保存所有版本，不覆寫原 PNG。

指定舊版用 `select_version(job, page_id, slot_id, request_id, version=0)`；選擇紀錄改變不代表投影片已更新。Google 路徑先讀當頁與 revisionId，再用 `google_slides.replace_asset(binding, asset, observed_slide)` 及 `tool_batches` 產生替換。binding 包含 slide_id、image_id、slot_id、目前圖片 sha256；asset 包含實際沙箱路徑與選定圖片 sha256。送出時使用同一讀回的 requiredRevisionId。

替換保持原 image object ID，完整置入圖片，不裁切內容。結果未知先讀回；已是所選 SHA256 時不再寫入，仍須核對實際圖片。物件消失、屬於別頁或中途被使用者修改時，先釐清，不直接蓋過。只有確認寫入後才更新 bind。匯出 PPTX 必須核對內嵌圖片的實際位元組，不只相信 SHA 標籤。

## 失敗與交付

安全拒絕需有實際工具證據才使用 `refusal`；最多一次 `safe_retry`，不能把拒絕結果登記為成功。仍無法生成時按主技能的局部素材組版處理，不能把整張原頁冒充生成頁。服務、權限或額度問題不能誤標為安全拒絕。Spaces 的寫入逾時或 viewer flush failed 必須依 workflow.md 的 recover_write 狀態機處理，再依 native.md 查交易並讀回：已保存的頁與 slot 重新綁定，未保存的單獨補寫；不能把工具逾時當作 Page 權限拒絕。

`finish(job, observed_texts, page_ids, committed, visual_reviewed)` 核對完整頁序、原生正文與目前選定圖片是否已綁定，未知生成結果或仍綁定舊版會阻擋交付。參數只能來自實際讀回與逐頁看圖，不能為了通過而填入計畫內容或猜測 true。它不取代實際工具操作與視覺驗收。

原生寫入收據的 state 存到 job.native_pages[page_id]，每次更新後保存到同一份平台工作目錄進度檔；只有已授權紀錄備份時才同步指定 Drive 位置；下一個 appendPage／appendAsset 傳入這份 input.state。pending transaction 也保存在同一處，用來核對逾時前後物件。備忘稿不作為任何工作紀錄儲存區。

`finish` 只返回 READY_FOR_EXPORT；接著依 workflow.md 呼叫 workflow.py.complete_delivery(job, document, pptx_path)。有原生文件時用 native 核對真實文件 ID／URL／讀回及開啟證據；沒有原生文件而採檔案製作時，明確用 file_only 提供實際 PPTX 的 path／SHA256／大小／頁數、開啟證據及可交付入口／下載讀回證據，不偽造雲端 ID 或連結。兩條路均檢查完整 PPTX 與已結束的寫入，再保存返回的 DELIVERED job。file_only 不跳過內容驗收、不清除未完成寫入、不表示 Drive 已保存。舊 DELIVERABLE 不能當作完成，先重新 finish。沒有真實檔案就不能回覆完成。

PNG 登記前核對區塊結構與 CRC，只有檔頭或遭截斷的檔案不能登記為已生成。此檢查不等於解碼或內容驗收，仍需開圖檢查。finish 重新核對已確認來源及計畫摘要；計畫被修改須依已授權變更重新確認版本，不能同步改 observed 便冒充原內容驗證通過。
