# 製作呼叫範例

以下片段載入當前外掛版本的 `scripts/studio.py`。輸入必須來自實際讀取的來源、已驗證收件及人類確認；示例函式不提供預設人類授權，也不代替平台檔案、Drive 或簡報工具。每次改動工作紀錄後以 `studio.write_json` 保存。路徑使用當前平台工作目錄與可用依賴，不能直接照抄開發者電腦路徑。

表單 `source_format` 的 E／I 對應 EDITABLE／IMAGE；`image_policy` 的 P0／P1／P2／P3 對應 NONE／REUSE／REDRAW／GENERATE。`content` K／T 原樣傳入 text_mode，不能因為操作為 O1 就忽略 T。

## O1＋T：原始來源與已確認潤飾稿分開保存

`original_sources` 是最初已讀取且保留圖片關聯的原稿；`approved_pages` 是經討論確認的逐頁潤飾稿，每頁含 id、source_ids、texts，不能拿它覆蓋原稿。`confirmation_quote` 必須是真實人類對這一版文字的確認原話；選擇「允許潤飾」本身不能冒充尚未呈現的新稿已獲確認。已存在適用於本版的確認就直接沿用，不重問；缺少時只呈現有變動的部分。

此例為可編輯、不用圖片。其他圖片政策仍依同一確認快照加入符合政策的 slots；本函式只建立受驗證計畫，尚未產生或交付簡報。

<!-- executable-example: confirmed-text -->
```python
import copy
import studio


def prepare_confirmed_text_example(original_sources, approved_pages,
                                   style, confirmation_quote):
    pages = copy.deepcopy(approved_pages)
    for page in pages:
        page["slots"] = []
    job = studio.new_job(
        copy.deepcopy(original_sources), "EDITABLE", "NONE", copy.deepcopy(style),
        operation="PRESERVE", target_pages=len(pages), text_mode="T",
    )
    studio.confirm_text_revision(job, pages, confirmation_quote)
    studio.plan(job, pages)
    return job
```

`text_revision` 保存精確頁文字、來源對應、原 source_hash、確認原話及摘要；plan 綁定這份快照，finish 再驗證。不能修改 source／snapshot／hash 來通過檢查。已有 plan 或 requests 後改文字，須在同一邏輯任務建立新的製作修訂 job 並保留原 job，不原地改寫既有成果。

## IMAGE＋P1：以原圖及正文組成完整頁面

此例適用於**已確認製作範圍的一頁**，包含一張已讀取的原圖與一至兩段原稿文字。它是具體排版例子，不能把多頁來源自動截成一頁；整份簡報應為所有確認頁面各建一份 plan。正式版面可修改位置及大小，但文字段落須完整、依序引用，不能為塞入範例版面而刪減。

`source_slide` 保留實際 `id/texts/images`；`original_image_path` 是從該來源取得且 SHA 已核對的原圖。`font_path` 必須是當前執行環境實際可讀、涵蓋正文所有字元的授權字型檔；先用平台提供的依賴或使用者素材找到它，不能假定 macOS／Windows 固定字型路徑。`style` 帶入真實選擇及 user_choice。

<!-- executable-example: compose-reuse -->
```python
import copy
from pathlib import Path
import studio


def compose_reuse_example(source_slide, original_image_path, font_path,
                          style, output_path, asset_storage="drive"):
    source = copy.deepcopy(source_slide)
    if not 1 <= len(source["texts"]) <= 2:
        raise ValueError("此範例版面供一至兩段文字；請為實際內容重新規劃完整文字框")
    image_path, font_path = Path(original_image_path), Path(font_path)
    image_sha = studio.digest(image_path.read_bytes())
    font_sha = studio.digest(font_path.read_bytes())
    if not any(item.get("sha256") == image_sha for item in source.get("images", [])):
        raise ValueError("原圖檔案不是這一頁已讀取的來源素材")
    source_files = {image_sha: str(image_path)}
    font_files = {font_sha: str(font_path)}
    page = {
        "id": "page-1", "source_ids": [source["id"]],
        "texts": list(source["texts"]),
        "slots": [{
            "id": "full", "action": "COMPOSE_REUSE",
            "composition": {
                "background": "#ffffff",
                "images": [{
                    "source_asset": {"source_id": source["id"], "sha256": image_sha},
                    "position": {"left": 700, "top": 100, "width": 500, "height": 500},
                }],
                "texts": [{
                    "text_index": index,
                    "position": {"left": 50, "top": 100 + index * 220,
                                 "width": 600, "height": 180},
                    "font_size": 32, "font_sha256": font_sha, "color": "#123456",
                } for index in range(len(source["texts"]))],
            },
        }],
    }
    job = studio.new_job([source], "IMAGE", "REUSE", copy.deepcopy(style),
                         operation="PRESERVE", target_pages=1, text_mode="K",
                         asset_storage=asset_storage)
    studio.plan(job, [page])
    evidence = studio.compose_reuse(
        job, page["id"], "full", source_files, font_files, output_path,
    )
    return job, page, source_files, font_files, evidence
```

`compose_reuse` 產出真實 1280×720 PNG，原圖以 contain 保持比例且不裁切，文字逐段取自 page.texts。圖片與文字區塊不得重疊，文字溢出、缺字、無效或不可讀字型會拒絕；保留內容並修正實際版面／字型，不能改用生成圖片蒙混通過。支援靜態 PNG、JPEG、WebP 原圖及純色背景，不接受任意新增圖片或 AI 生成背景。沒有圖片的個別頁可使用空 images，但頁面不可全空。

Pillow **只在實際組版渲染時**載入，普通 ledger／來源讀取／文字快照不需要它。缺少時會回報「整頁原圖組版需要 Pillow；尚未生成或登記成果」，不能將未產出登記成功。字型以 SHA 對應當前檔案傳入，不隨外掛發布私人／未授權字型。真正中文字體與排版仍須實際開圖驗收。

函式返回時 `job.requests` 尚未有 READY 紀錄。先保存 job 與 evidence，開啟實際 PNG 檢查；在採用 Drive 的雲端製作流程上傳這份 PNG 並取得真實 file ID，才登記如下。`uploaded_drive_file_id`、`native_slide_id`、`native_image_id` 都由實際工具回覆取得，不能以示例字串填入：

```python
request_id = studio.register_composition(
    job, page["id"], "full", output_path,
    source_files, font_files, uploaded_drive_file_id,
)
studio.write_json(job_path, job)
# 用正式簡報工具將同一 PNG 寫入該頁，讀回確認後才執行：
studio.bind(job, page["id"], "full", request_id,
            native_slide_id, native_image_id)
studio.write_json(job_path, job)
```

register_composition 使用相同來源、字型及計畫重新渲染，與實際輸出逐位元組比對；原圖 SHA 與整頁輸出 SHA 分別保存，不能拿生成頁或單張原圖假稱組版成功。登記與渲染使用相同依賴版本和字型檔，不能中途替換。之後仍須完成 finish、真實簡報讀回、PPTX 匯出與交付驗證；組版或 READY 不是交付成功。

IMAGE＋REUSE 不使用 dispatch／ImageGen／register_reuse。EDITABLE＋REUSE 才使用單素材的 register_reuse。Drive 不可用時遵循 [檔案交付流程](cloud.md#drive-不可用時仍交付成品)，不可虛構 Drive ID 讓雲端登記成功；也不因雲端不可用而更改人類已選圖片政策。

## Drive 不可用時：明確登記當前環境圖片

製作計畫前選定 `asset_storage="file_only"`，不因缺少 Drive ID 隱式切換。上方組版例子可傳入此參數；其餘新 job 也在 new_job 傳入同值。`output_path`／`original_image_path` 必須是實際存在的絕對路徑，不是虛構的雲端入口。各路徑只執行與已確認圖片政策相符的一種：

```python
# GENERATE／REDRAW：已實際 dispatch 並收到本次圖片生成工具的 PNG
asset = studio.register(job, request_id, generated_png_path)

# EDITABLE＋REUSE：已讀取並保留 SHA 的原圖
request_id = studio.register_reuse(job, page_id, slot_id, original_image_path)

# IMAGE＋REUSE：先依上方 compose_reuse_example 實際渲染並開圖檢查
request_id = studio.register_composition(
    job, page_id, slot_id, output_path, source_files, font_files,
)
```

以上皆不填 drive_file_id；程式保存實際標準化絕對路徑、SHA256、大小及 current_environment。生成 PNG 校驗、沿用原圖 SHA／來源對應、組版重新渲染比對全部保留。插入簡報並讀回實際圖片後才 bind；select_version、bind、finish 另重讀本機資產，遺失或被替換即拒絕。PPTX 交付仍須完成內容、內嵌圖片、可開啟與實際檔案入口的驗證，不能把本機素材登記當成雲端存檔或成品已交付。
