# 原生簡報適配

平台只授權修改使用者指定目標；開發驗收建立專用 Page，不能修改參考原件。

第一筆寫入先儲存封面的原生文字並讀回，確認確實能新增物件後才呼叫 ImageGen；僅能讀取空白頁或改背景不算通過。第一筆寫入建立封面後完成呼叫，讓檢視器能開啟；後續每次工具呼叫只保存一頁文字排版，或一張已生成的 PNG；不能把多張新 PNG 的上傳放在同一個工具呼叫。新建文件已有空白頁時使用它；不能多留一頁。

API 使用平台 Presentations 技能和當次工具 schema。典型原生文字：

```javascript
const shape = slide.shapes.add({geometry:'textbox',position:{left:72,top:60,width:1136,height:80},fill:'none',line:{fill:'none',width:0}});
shape.text = exactSourceTitle;
shape.text.style = {fontSize:44,typeface:'Noto Sans CJK TC',color:profile.titleColor,bold:true};
```

獨立配圖：先記錄 slot 的位置比例，再上傳生成 PNG。雲端使用返回的持久 reference：

```javascript
slide.images.add({path:reference,fit:'contain',position:slot,alt:assetDescription});
```

雲端 execute_artifact_code 的 image_references 列出本次插入或需要讀取的持久圖片參照；渲染已有圖像時 hydrate_images=true，並包含背景及繼承圖片。不要把本機磁碟路徑傳給雲端圖片上傳工具。桌面 Artifact Session 才可用 path:<本機 PNG>。

圖像式：同尺寸整頁 PNG 插入 {left:0,top:0,width:1280,height:720}，來源比例相同時 fit:'contain'；不得自動裁切文字。更新一頁先定位其原生 slide id 與 image id，再 replace 圖片；保留來源與舊版。

可編輯式表格／圖表／流程圖保留原生物件。插畫不使用大量幾何圖形假裝 ImageGen 結果。對應資料內的文字依已保存的製作快照讀取：K 使用原稿，T 使用已確認的潤飾稿，不手打近似內容或在寫入時再改字。自寫排版可在已確認內容與圖片 slot 範圍內調整，不硬鎖單一模板。

驗收資料包括原生物件 inspect、逐頁 PNG 的實際視覺確認、來源文字對照、每個 PNG 與 slide/image id 的映射、寫入收據。只保存暫存檔／預覽／前幾頁不能當成成品。


## 寫入期限與逾時恢復

所有寫入都先記錄 `workflow.py.begin_write`，並依 [外層保存錯誤](workflow.md) 處理工具回傳；特別是 `Artifact Session viewer flush failed`，可能在 callback 已返回物件 ID 後才由 host 回報。不可只根據 callback 成功或一次 flush 失敗宣稱完成／必須停止。操作 ID、嘗試次數及證據保存在 job.write_operations，跨回合不能重設。

桌面 `artifact_session.js` 省略 `timeout_ms` 時只有 30 秒。含圖片的寫入使用 `timeout_ms:60000`，一次只上傳一張新 PNG；每次工具呼叫等待儲存收據才進下一次。不能在同一工具呼叫以迴圈、Promise.all 或連續 await 包入多張新 PNG。這是每次寫入的大小限制，不是每頁圖片數量限制；同頁四張系列配圖仍逐張寫入同一頁。

`scripts/native.mjs` 的 `appendPage` 只保存一頁原生文字及版面，返回 `pending_slots`；逐一另開工具呼叫執行 `appendAsset` 保存一張 PNG。兩者必須包在下方 `runNativeSession` 中。回傳的 `state`（page/slot/image ID 與 SHA256）立即保存到獨立 job.json 的 native_pages，不寫進備忘稿、隱藏文字或替代文字。後續呼叫將該頁最新 state 放在 input.state。每次圖片寫入前，先把現有 image ID、slot 與選定資產保存為 pending operation。已確認的操作比對紀錄後返回 reused，不再新增。若遺失圖片寫入收據，先完成工具 transaction 查詢，再讀回該頁；比較 pending 前後 image ID，檢查新增圖與已保存 PNG，確認相同後補登 state.assets。未核對前 appendAsset 會阻止重複插入；這是內部恢復步驟，完成便繼續，不要求使用者回覆。文字寫入遺失收據可由原生文字物件名稱及完整文字恢復；仍須與 ledger 核對。不能把未知圖片視為未完成而再插一次。可以自寫版面，但須遵守相同的小步提交及恢復規則。

逾時／unknown 不是權限不足，也不是生圖失敗。若工具回傳 transaction，先依工具的 status／abort 指示查回；committed:true 不重送，accepted 仍須等確認，只有 committed:false 才重新執行未完成操作。未提供 transaction 時先重新讀同一 Page，核對已保存文字、頁與圖片綁定。確認上一操作已結束且未存入後，最多補做一次單頁或單張寫入；成功便繼續後續頁面。不重新生成 PNG、不改成原頁、不要求使用者重開、不在只完成封面時自行結束。真正權限拒絕、額度或持續服務中斷才按實際錯誤報告阻塞。

回傳資料保持精簡：只回頁／物件 ID、計數與摘要；大型 inspect 寫檔或逐頁讀回。不要在一次回傳傳出整份 `toSnapshot()`，外部文件的結果大小限制也可能導致 unknown；依同一交易恢復程序處理。

## 桌面 Artifact Session 相容入口

桌面必須先載入本技能的 `scripts/native_compat.mjs`，每次寫入都用它的 `runNativeSession` 包住完整呼叫（含圖片持久化與提交），不能只包住 callback。把下例的 `<技能目錄>` 替換為本次實際技能位置；不能保存開發者路徑。Web 雲端 execute_artifact_code 不套用此桌面入口。

```javascript
var nativeCompat = await import('<技能目錄>/scripts/native_compat.mjs');
var deck = await nativeCompat.runNativeSession(artifactSession, async ({presentation}) => {
  // 只使用此 callback 的 prebound presentation，讀回現有內容後修改。
  const slide = presentation.slides.getItem(0);
  const shape = slide.shapes.add({geometry:'textbox', position:{left:72,top:60,width:1136,height:80}});
  shape.text = exactSourceTitle;
}, {artifactRef: connectedArtifactRef});
nodeRepl.write(deck);
```

根因：部分桌面原生套件的 plain-object 檢查使用相同 realm 的 prototype 身分比較；host structuredClone 產生另一 realm 的普通物件，新增文字／圖形／圖片時被誤判為 `Invalid native record owner`。這個錯誤不等於使用者沒有文件權限。相容入口先偵測實際 clone 行為，只在需要時將複製出的普通物件 prototype 正規化；原始 clone 的值、循環參照、二進位資料及錯誤仍保留，結束或失敗後以 finally 還原。它不改套件檔、不改權限，不是繞過文件存取檢查。

已經失敗時：先讀回相同 Page 的現有物件，使用本入口繼續尚未儲存部分，避免重複插入。保留既有生成圖片，找回原檔，不因寫入失敗重生圖片。若連線失效，對同一 Page 重新 connect 後再讀回；若套用相容入口仍失敗，保存實際錯誤，不能無限重試、默默更換文件或指示使用者重開就保證修好。

## 備忘稿

新製簡報的備忘稿預設空白。只有使用者明確要求講稿時才使用 `notesPolicy:'REQUESTED'` 寫入已確認講稿。來源出處、檢查結果、JSON、page/slot/image ID、SHA256 與製作進度留在獨立工作紀錄；不放入備忘稿，也不移去隱藏文字或替代文字。既有使用者備忘稿不擅自刪除，使用者要求清空時才刪。舊版技術備忘稿先移存 ledger，確認保存後移除。驗收讀回所有 speaker notes；匯出 Google Slides 與 PPTX 後再檢查，未要求講稿的新增頁面應為空白。

## 返回修改版面

`appendPage` 是新增／核對原操作，不是修改入口。相同文字但位置或樣式不同，不能回報 reused 當成已修改。收到已確認的版面修改時，使用 `reviseLayout`，提供該頁最新 `state` 與 `revision:{id,reason}`，其餘 input 與原計畫相同。每次實際修改使用一個固定 revision ID；重送同次修改使用同一 ID，不能重複插圖或重生圖片。

此入口僅調整既有文字及圖位，保留所有文字、slot、圖片與原生 ID。改文字、增減圖位、改裝飾物清單需另行規劃及確認來源對照，不可混為單純重排。返回舊版面仍是一筆新 revision，沿用已保存 PNG。沒有對齊設定代表靠左，必須明確重設，不能殘留前次置中。改完保存新 state、讀回物件並渲染驗證。若使用者直接改過原生頁面，先核對差異，不能套過期 state 覆蓋。

寫入前會檢查所有文字框、圖位與裝飾物的完整計畫，拒絕越界、重複圖位及未列入來源的裝飾文字；不能等寫到一半才檢查後面的項目。這是計畫檢查，無法取代平台交易恢復或視覺驗收。
