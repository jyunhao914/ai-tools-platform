# 選單、寫入恢復與交付

`scripts/workflow.py` 是標準 Python 輔助程式，可在平台託管沙箱執行，不需要使用者安裝。不會呼叫模型、改權限、生成圖片或自動宣稱成功。呼叫端根據真實工具回覆提供證據並執行它返回的下一步。

## 互動選單（必要）

依 [互動表單](interactive-intake.md) 先確認當前正式工具能力。優先使用 schema／版本相符的 `studio_open_workflow_v2`；未提供時使用已部署的 `studio_open_intake` v2 封套相容入口，外層恰為 `source_kind="outline"` 與 `selected={workflow_v2_config: JSON.stringify(完整v2原輸入)}`，不混入其他外層欄位或 selected 選值。兩者均以完整 v2 schema 驗證、呈現同一 App SDK 表單，核對回傳 kind／version／config.version，再原樣保存 structuredContent.config 作為唯一收件快照。兩個正式入口都不可用或版本不符，才用同包 `packaged_intake.py` 產生片段，透過對話的正式 visualize 內容參照顯示。未帶封套的 legacy studio_open_intake 與舊 studio_open_style_save 仍不能代替新版階段與來源修訂契約；不可把解析失敗或舊結果當成新版成功。無須要求使用者另外建立連接。`intake_transcript` 僅供無障礙紀錄，不取代可操作表單。

新版工具已部署至既有表單服務，各宿主的載入、提交及接續仍須實測。技能 ZIP、文件與本機測試不是部署證據；實際工具回傳也不是人類提交。兩條路徑都必須保存原 config/request_id 為 active_request_id，再用匹配版本的 accept_intake.cjs 核對實際收到的選值、最新來源修訂與內容確認，才執行對應下一步。

工作方向不明時先用 entry：四個主要方向為從主題製作、依現成大綱製作、把資料整理成簡報、重製現有簡報；還原大綱與分析風格收在輔助功能，六項共用單選群組。入口回傳 select_mode，只選路徑，不產生內容或授權製作。只有啟用外掛而無來源時使用 source_kind=unknown；unknown 不能進其他階段。四個主模式或兩個輔助工作的目的已明確時直接略過入口，沿用已有來源；還原大綱／分析風格不接著要求製作設定。

每一階段只收當下尚缺資料：主題與非簡報素材先確認基本需求；已有大綱確認修改或沿用；已有簡報選處理方式；內容確認後才在同一張製作表單收齊設定與風格。PDF 依實際內容分辨資料或投影片。已指定設定保留，送出後依當次 job 與 request_id 接續原任務；只有最後的確認製作動作才啟動成品生成。

## 外層保存錯誤

`Artifact Session viewer flush failed` 可能出現在工具回傳外層，不在 callback 的 try/catch 內。必須檢查完整工具結果的 isError／content；callback 返回 image ID 不代表已保存。不能只修改 callback 然後聲稱處理了外層同步失敗。

每筆寫入前 `begin_write(document_id, operation_id, expected, before)`：記下真實文件 ID、固定操作 ID、預期文字或已選 PNG 的 SHA256／slot，以及讀回的頁與物件基線。保存至 job.write_operations。失敗、讀回與重送都使用同一個操作紀錄，不能重設 attempts 或改 key。

工具失敗後，將 message、receipt_id（實際呼叫識別）、必要時 transaction_id，連同 document_id／operation_id 送入 `recover_write(state, evidence)`；CLI 可用 `python workflow.py recover recovery-input.json`。保存返回 state，依 phase 執行：

| phase | 下一步 |
| --- | --- |
| CHECK_TRANSACTION | 用原交易查狀態，pending／unknown 不寫入；先依工具指示解決交易。 |
| RECONNECT | 對同一 Page 重新連接，再讀回；不另建文件。 |
| READ_BACK | 查原文件的真實內容，確認操作已結束，核對當頁文字、image ID、PNG 與基線。 |
| RETRY_SAME_WRITE | 上一筆已結束、確定未保存且基線未變：將 dispatched 事件登記後，補寫同一頁或同一張已生成 PNG 一次。 |
| COMPLETE | 本筆操作已核對保存，更新 native state／binding，直接處理下一筆，不結束整份任務。 |
| CONFLICT | 內容不符或有人修改：核對差異，不覆蓋、不重插。 |
| INSPECT_ERROR | 未知錯誤先查其真實原因，不把它當成可重試錯誤。 |
| BLOCKED | 真正權限／額度拒絕，或同筆補寫後仍未保存：保留實際證據，說明阻塞。 |

readback 事件的 comparison 必須來自實際讀回：MATCH＝指定內容已保存；ABSENT＝仍與 before 相同；CONFLICT＝內容異動或不吻合。帶上相同 expected、receipt_id、settled:true；ABSENT 另提供 observed 基線。只有確認前一操作結束才能 settled:true。committed 交易卻讀不到內容是衝突，不重送。重新寫入即使再次報錯，也要讀回確認，避免已保存卻被誤判失敗。

此程序只處理寫入，不能以寫入失敗重新呼叫 ImageGen。一次讀回可恢復不能宣稱平台底層不再發生錯誤。

## 文件名稱與可開啟交付

封面的文字和文件名稱是不同欄位。新建 Google／Spaces 文件傳入主題名稱；已有空白名稱時，用平台支援的文件命名工具或 UI 命名，再讀回 metadata。`artifactSession.run` 的 title 選項只在建立時使用，對既有文件忽略，不能用它假裝改名。不得為改名重建 Page、換 ID 或改正文；沒有支援的命名介面就明說名稱尚未修復。

內容完成後，先 `studio.finish` 核對正文、頁序、圖片綁定，再依實際目的地驗收。`verify_delivery(document, pptx_path, expected_pages)` 對下列兩種交付都實際讀取 PPTX、核對 ZIP／投影片關聯及頁數，並以同一份位元組計算 SHA256。它拒絕空名、未命名卡片、缺失或不完整檔案；`VERIFIED_PACKAGE` 不等於宿主下載測試、逐頁視覺驗收或雲端存檔成功。

- **原生文件交付**：`document.delivery_mode="native"`（舊呼叫未指定時仍使用 native）。實際開啟原生文件並讀回 title、完整頁數與圖像，取得 PPTX。document 包含真實 id、title、HTTPS url、pages、readback_receipt、opened=true、open_evidence；Google Slides URL 的文件 ID 須與讀回 ID 一致。不能填假的文件 ID、URL 或將計畫值當讀回值；已有原生文件時仍走此分支，不能用 file_only 省略其驗證。
- **僅交付檔案**：沒有原生文件、按 cloud.md 的檔案路徑製作時，必須明確指定 `document.delivery_mode="file_only"`，保留 title、pages，且不得填 id／url／native_url／document_id。`artifact` 包含實際本地 PPTX 絕對 path、sha256、bytes、pages、opened=true 與真實 open_evidence；先用當前平台工具開啟或渲染，核對內容與可編輯物件，再記錄該證據。`download` 包含要交付的 url、實際讀回的 local_path、同一份 sha256、verified=true 與真實 evidence。本機直接交付與 HTTPS 下載分開驗收：宿主明確支援絕對本機檔案連結時（例如 Codex 的絕對路徑 Markdown 檔案連結），local_path 可為 artifact.path；實際讀回該連結指向的同一檔案並核對 SHA、大小、頁數，即可記錄目前環境的本機入口驗證，不要求額外點擊下載 UI。evidence 必須標示 current_environment、實體檔案讀回、宿主支援的連結格式，以及未測下載 UI／HTTP 的範圍，不能把它稱為網路下載成功。HTTPS 入口則須實際下載，local_path 指向下載副本並核對相同檔案；宿主附件／沙箱入口須由宿主正式產生或確認可交付，不能自行編造參照。布林值不是開啟／入口驗證證據。程式會重讀 local_path 核對頁數與雜湊，拒絕與驗收檔不同的內容、缺證據或以原生簡報 URL 冒充檔案下載。

file_only 的本地絕對連結或 `sandbox:/...` 連結必須精確指向 artifact.path；`download_persistence=current_environment` 表示只保證當前宿主工作環境，不宣稱跨帳號、跨裝置或永久可用。HTTPS 入口期限由提供者決定。使用當前平台正式支援的附件／連結格式交付，保留原始開啟與下載工具證據；此離線驗證器不會自行操作下載 UI，也無法驗證遠端收據真偽。不得把單純 ZIP 讀取當成視覺開啟測試。

若 Spaces 的直接下載失敗，按正式工具／UI 使用 Google Slides 匯出副本（有已授權的 Drive 才可執行）並下載 PPTX，保留原 Page 與對應 ID。這是匯出副本，不將原件改成另一份作業。若已明確指定只留在 Spaces，或不允許 Google，不能默默轉移。沒有可用匯出路徑要報告「未取得 PPTX」，不可把圖片資料夾或殘缺卡片當成完成。

原生文件交付需要明確名稱、能開啟的原生入口及實際 PPTX 附件／可用下載入口；file_only 需要經上述驗證的 PPTX 附件／可用下載入口，並如實說明尚未存入 Drive。工作紀錄資料夾不能取代成品入口。

`studio.finish` 完成後狀態為 READY_FOR_EXPORT。呼叫 `complete_delivery(job, document, pptx_path)` 或 CLI `complete input.json`，由程式按 delivery_mode 實際檢查下載並拒絕未結束的寫入，再保存返回的 DELIVERED job。file_only 也不能跳過 finish、內容／圖片驗收，或清空尚未結束的原生寫入紀錄來通過檢查；先按真實狀態解決它。舊版 DELIVERABLE 需重新 finish，不直接升級為已交付。回傳 delivery 保留模式、檔案 SHA、頁數與證據；file_only 不產生 native_url／document_id，也不代表 Drive 已保存。

## 文字或代碼回答

可回「E、P3、02、K」，也可回「可編輯、生成配圖、藍色醫療、內容不要改」，兩者等效，並可混合回答。形式與圖片處理分開保存；舊 A／B／C 僅為既有選值相容，不再顯示為新版形式選單。大小寫、全形字母與標點自動正規化；正常畫面顯示名稱與說明，不要求記住或重打一遍代碼，保留使用者原話。

先用 `resolve_choices(groups, reply)` / CLI `resolve` 解析固定代碼、名稱與同義詞。其他相近說法由模型依語意對應到現有代碼並保存原話與理由，不要求使用者重打一遍代碼；不能只用字形相似度猜文字修改授權。只說「可編輯」而未決定是否配圖時，只補問配圖；「醫療」同時可能是藍色與粉紅時，只用互動表單詢問風格，其他設定保留。明確否定如「不要微調」必須解作保留，不得誤判允許微調。矛盾選項只用互動表單詢問衝突那一項。縮減／擴增仍需目標頁數；代碼不代替這項資訊。
