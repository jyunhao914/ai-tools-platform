"""Prepare packaged form input from a fresh validated Drive catalog; no cloud writes."""
from style_library import form_group


def arguments(source_kind, *, menu=None, selected=None, library_status=None,
              library_message=None, target_pages=None, custom_style=None):
    if source_kind not in ('slides', 'outline'):
        raise ValueError('source_kind must be slides or outline')
    result = {'source_kind': source_kind, 'selected': dict(selected or {})}
    if menu is not None:
        if menu.get('warnings'):
            raise ValueError('風格庫仍有讀取或驗證錯誤；先處理，不可冒充完整清單')
        if menu.get('state') == 'READY':
            options = form_group(menu)['options']
            result.update(library_status='ready', catalog_snapshot=menu['snapshot'],
                          personal_styles=[{key: item[key] for key in
                            ('id', 'label', 'preview_data', 'preview_metadata')}
                            for item in options])
        elif menu.get('state') == 'EMPTY' and not menu.get('items'):
            result.update(library_status='empty', catalog_snapshot=menu['snapshot'])
        else:
            raise ValueError('風格庫狀態不可用；不得偽稱為空庫')
    elif library_status in ('error', 'not_connected') and library_message:
        result.update(library_status=library_status, library_message=library_message)
    else:
        raise ValueError('需要完整雲端清單或實際連接錯誤；不可省略風格庫')
    if target_pages is not None:
        if type(target_pages) is not int or target_pages < 1:
            raise ValueError('目標頁數必須是正整數')
        result['target_pages'] = target_pages
    if custom_style is not None:
        result['custom_style'] = custom_style
    return result
