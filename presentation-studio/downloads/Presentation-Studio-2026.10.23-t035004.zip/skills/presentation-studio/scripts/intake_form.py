"""Render the packaged interactive intake; never silently return Markdown."""
import argparse
import base64
import copy
import hashlib
import json
import io
from PIL import Image, ImageOps
from pathlib import Path
import re


def resume_preview(data, reply):
    """Apply a preview-only request to the saved, validated source snapshot."""
    if (reply.get("schema") != "studio-preview-page-v1"
        or reply.get("request_id") != data.get("request_id")
        or reply.get("catalog_snapshot") != data.get("catalog_snapshot")):
        raise ValueError("Preview request does not match the current source/library snapshot")
    result = copy.deepcopy(data)
    values = reply.get("values") or {}
    for group in result["groups"]:
        code = values.get(group["id"])
        if code:
            if code not in {o["id"] for o in group["options"]}:
                raise ValueError("Unknown selected option in preview request")
            group["selected"] = code
        elif group["id"] in values:
            group.pop("selected", None)
    for key in ("target_pages", "custom_style"):
        if key in values:
            result[key] = values[key]
    if "style_name" in values and any(g["id"] == "save_style" for g in result["groups"]):
        result["suggested_style_name"] = values["style_name"]
    result["preview_request"] = reply["preview_request"]
    return result


def render(data):
    data = copy.deepcopy(data)
    if not isinstance(data.get("request_id"), str) or not data["request_id"].strip():
        raise ValueError("request_id must identify this source/intake")
    groups = data.get("groups")
    if not groups:
        raise ValueError("No choices remain: proceed without another confirmation")
    ids = set()
    for group in groups:
        gid = group["id"]
        if not re.fullmatch(r"[a-z][a-z0-9_]*", gid) or gid in ids:
            raise ValueError("Invalid or duplicate group")
        ids.add(gid)
        options = group["options"]
        if gid == "style":
            options.sort(key=lambda o: (o["id"] != "SA", o["id"] in {"SC", "SM"}, o["id"]))
            previews = json.loads((Path(__file__).parent.parent / "assets/builtin-previews.json").read_text())
            for option in options:
                if re.fullmatch(r"\d{2}", option["id"]):
                    if option["id"] not in previews:
                        raise ValueError("Unknown built-in style")
                    source = previews[option["id"]]
                    for key in ("preview_data", "preview_width", "preview_height"):
                        option[key] = source[key]
        codes = [str(o["id"]) for o in options]
        if not options or len(set(codes)) != len(codes) or not group["title"].strip():
            raise ValueError("Invalid options")
        if any(not str(o["label"]).strip() for o in options):
            raise ValueError("Missing label")
        if group.get("selected") is not None and group["selected"] not in codes:
            raise ValueError("Selected value is not an available option")
        if gid == "personal_style":
            if not data.get("catalog_snapshot"):
                raise ValueError("Personal choices require a current catalog snapshot")
            for option in options:
                metadata = option.get("preview_metadata") or {}
                pages = metadata.get("preview_pages") or []
                if (metadata.get("preview_layout") != "nine-slide-grid"
                    or metadata.get("preview_page_count") != 9
                    or not isinstance(pages, list) or len(pages) != 9
                    or any(not isinstance(p, dict) for p in pages)
                    or {p.get("slot") for p in pages} != set(range(9))
                    or len({p.get("render_sha256") for p in pages}) != 9
                    or any(not p.get("render_sha256") or p.get("kind") not in
                           {"source", "style_demo"} for p in pages)):
                    raise ValueError("Personal preview needs nine verified pages from the current library; upgrade and read back before rendering")
                image = option.get("preview_data", "")
                if not image.startswith(("data:image/png;base64,", "data:image/webp;base64,")):
                    raise ValueError("Each personal style requires an embedded preview")
                raw = base64.b64decode(image.split(",", 1)[1], validate=True)
                png = image.startswith("data:image/png;") and raw.startswith(b"\x89PNG\r\n\x1a\n")
                webp = image.startswith("data:image/webp;") and raw[:4] == b"RIFF" and raw[8:12] == b"WEBP"
                if not (png or webp) or len(raw) > 500000:
                    raise ValueError("Invalid or oversized personal thumbnail")
    if {"outline_format", "source_format"} <= ids:
        raise ValueError("Choose one source kind")
    if "save_style" in ids and not data.get("suggested_style_name", "").strip():
        raise ValueError("Suggest a descriptive style name from the actual design")
    config = {k: data[k] for k in ("request_id", "groups", "target_pages",
              "custom_style", "catalog_snapshot", "suggested_style_name",
              "job_id", "version", "library_status", "library_message") if k in data}
    # Both libraries ship together. Only the display copy is resized; Drive
    # originals and nine-page source metadata remain untouched.
    originals = [(option, option["preview_data"])
                 for group in groups for option in group["options"]
                 if option.get("preview_data")]
    for width, quality in ((640, 80), (480, 76), (360, 72), (240, 60), (240, 48)):
        for option, source in originals:
            image, size = _thumbnail(source, width, quality)
            option.update(preview_data=image, preview_width=size[0], preview_height=size[1])
        result = _fragment(config)
        if len(result.encode()) < 960_000:
            return result
    # Never silently remove images or ask for a second loading turn.
    raise ValueError("Complete thumbnail catalog exceeds the form budget; cannot show all previews")


def _thumbnail(source, width, quality):
    raw = base64.b64decode(source.split(",", 1)[1], validate=True)
    with Image.open(io.BytesIO(raw)) as decoded:
        image = ImageOps.exif_transpose(decoded).convert("RGBA")
        image.thumbnail((width, width), Image.Resampling.LANCZOS)
        output = io.BytesIO()
        image.save(output, "WEBP", quality=quality, method=6)
        return "data:image/webp;base64," + base64.b64encode(output.getvalue()).decode(), image.size


def _fragment(config):
    encoded = json.dumps(config, ensure_ascii=False, sort_keys=True)
    identity = hashlib.sha256(encoded.encode()).hexdigest()[:20]
    # JSON is data, including source titles and private style names.
    encoded = encoded.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    template = (Path(__file__).parent.parent / "assets/intake-form.html").read_text(encoding="utf-8")
    script = (Path(__file__).parent / "intake_form.js").read_text(encoding="utf-8")
    result = template.replace("__ROOT_ID__", "studio-intake-" + identity).replace(
        "__CONFIG__", encoded).replace("__SCRIPT__", script)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--resume", type=Path,
                        help="Preview-page reply JSON; preserves settings from the same snapshot")
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding="utf-8"))
    if args.resume:
        data = resume_preview(data, json.loads(args.resume.read_text(encoding="utf-8")))
    args.output.write_text(render(data), encoding="utf-8")
    print(str(args.output.resolve()))
