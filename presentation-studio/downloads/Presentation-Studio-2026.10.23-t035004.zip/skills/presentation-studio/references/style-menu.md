# 表單內風格預覽

內建 15 款預覽就在同包 `assets/builtin-previews.json`；`intake_form.py` 將完整預覽嵌入對話內表單。不需要主機資源代理、雲端表單、公開圖片網址或額外讀取回合。

自動排第一；預設風格、我的風格庫、自訂風格同階。兩組預覽在各自選項正下方，預設收合，展開立即顯示；不加載入、翻頁或放大按鈕。

私人風格先完整讀回目前使用者自己的 Google Drive，依 `style_library.catalog → form_group` 驗證九頁預覽。`intake_data.arguments` 將當次清單轉為 `personal_styles` 並保留 `catalog_snapshot`，交給包內渲染器，不呼叫 MCP。只在目前對話的工作檔與表單內使用私人縮圖，不上傳公開網站或包進外掛。缺檔、未連接、讀取錯誤不能偽稱空庫。
