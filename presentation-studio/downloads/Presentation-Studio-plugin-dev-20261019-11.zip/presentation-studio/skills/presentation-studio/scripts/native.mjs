// Portable callback: no filesystem, network, credentials or desktop API.
export async function appendPage({presentation, input}) {
  const {page, index, mode, colors, assets, expectedCount} = input;
  const current = presentation.slides.items.length;
  if (current !== expectedCount) throw new Error('Document changed; inspect before a new write');
  let slide;
  if (index === 0 && current === 1) {
    slide = presentation.slides.getItem(0);
    const inspected = await presentation.inspect({select:'$.slides[0].elements[*]',include:['id','kind']});
    if ((inspected.records ?? []).length) throw new Error('First page is not empty; preserve existing work');
  } else {
    if (index !== current) throw new Error('Do not skip or repeat a slide');
    slide = presentation.slides.add({width:1280,height:720});
  }
  slide.background.fill = colors.background;
  const elements = [], bindings = [];
  if (mode === 'EDITABLE') {
    if (page.textBoxes.length !== page.texts.length) throw new Error('Text plan is incomplete');
    for (let i=0;i<page.texts.length;i++) {
      const box = page.textBoxes[i];
      const shape = slide.shapes.add({geometry:'textbox',name:'source-text-'+i,position:box.position,fill:'none',line:{fill:'none',width:0}});
      shape.text = page.texts[i];
      shape.text.style = {fontSize:box.size,typeface:colors.font,color:i===0?colors.title:colors.text,bold:box.bold??i===0};
      elements.push(shape.toSnapshot().aid);
    }
  } else if (mode !== 'IMAGE') throw new Error('Unknown output mode');
  for (const slot of page.slots) {
    const asset = assets[slot.id];
    if ((!asset?.path && !asset?.blob) || !asset.sha256) throw new Error('Missing actual generated asset');
    const frame = mode==='IMAGE'?{left:0,top:0,width:1280,height:720}:slot.position;
    const source = asset.blob ? {blob:asset.blob,contentType:'image/png'} : {path:asset.path};
    const image = slide.images.add({...source,fit:'contain',position:frame,alt:slot.alt});
    bindings.push({slot_id:slot.id,image_id:image.toSnapshot().aid,sha256:asset.sha256});
  }
  return {page_id:page.id,slide_id:slide.toSnapshot().aid,elements,bindings};
}
