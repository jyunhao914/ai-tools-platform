# 來源、圖片版本與恢復紀錄

`scripts/studio.py` 是平台沙箱可載入的標準 Python 模組，不需使用者安裝 Python。由呼叫端透過 Google Drive 工具保存 JSON；它本身不會上傳。每次修改後呼叫 `write_json`，上傳成功後登記持久 file ID。不可只存沙箱路徑就宣稱雲端保存完成。

## 一次新製作

1. `pptx(path)` 或 `outline(text)` 取得來源。PPTX 的 `images` 保留來源檔案內的 `source_part` 與實際位元組 SHA256；texts 保留文字框／儲存格內換行，tables 保存儲存格索引與合併資訊。PDF 必須使用平台閱讀／渲染工具逐頁取得內容，不能交給大綱解析器假裝成功。
2. `new_job(slides, mode, policy, style, operation, target_pages)`。style 至少包含 `selection` 與 `user_choice`，例如 `{"selection":"02","user_choice":"選藍色醫療"}`；原話需來自實際回答，未選先顯示風格並詢問，不補成自動。來源設定後不可改原始紀錄；縮減／擴增改製作計畫並保留來源對應。新上傳必須新建 job。
3. `plan(job, pages)` 保存確認後的文字與每頁圖片位置。它核對頁數、來源對應、保留模式文字，以及同頁每張圖片的獨立 slot ID。排版仍可自行撰寫，不要求固定模板。
4. `dispatch(job, page_id, slot_id, prompt)` 先建立唯一生成請求並存 Drive，再呼叫平台 ImageGen。結果未知時，先找回原呼叫結果，不改提示詞重送。
5. 取得真正 PNG 後先上傳 Drive，再 `register(job, request_id, sandbox_path, drive_file_id)`。最新結果自動選定。把該資產寫入原生簡報並讀回後，才 `bind(job, page_id, slot_id, request_id, slide_id, image_id)`。

## 直接沿用原圖

圖片 slot 的 `action` 設 `REUSE`，`source_asset` 為 `{"source_id": "來源頁 ID", "sha256": "來源素材 SHA256"}`。從 PPTX 指定的 source_part 取出原始素材，不重新截圖、不經 AI 重畫。上傳 Drive 後 `register_reuse(job, page_id, slot_id, file_path, drive_file_id)` 會核對原素材實際位元組及來源頁，返回可綁定的 request ID。再次登記相同原素材不會重複產生紀錄。

## 修改、指定舊版與更新簡報

使用者明確修改才重新 `dispatch`，附 `revision={"id": "本次修改 ID", "reason": "已確認修改要求"}`；微小色差或 OCR 檢查不自動產生修改請求。保存所有版本，不覆寫原 PNG。

指定舊版用 `select_version(job, page_id, slot_id, request_id, version=0)`；選擇紀錄改變不代表投影片已更新。Google 路徑先讀當頁與 revisionId，再用 `google_slides.replace_asset(binding, asset, observed_slide)` 及 `tool_batches` 產生替換。binding 包含 slide_id、image_id、slot_id、目前圖片 sha256；asset 包含實際沙箱路徑與選定圖片 sha256。送出時使用同一讀回的 requiredRevisionId。

替換保持原 image object ID，完整置入圖片，不裁切內容。結果未知先讀回；已是所選 SHA256 時不再寫入，仍須核對實際圖片。物件消失、屬於別頁或中途被使用者修改時，先釐清，不直接蓋過。只有確認寫入後才更新 bind。匯出 PPTX 必須核對內嵌圖片的實際位元組，不只相信 SHA 標籤。

## 失敗與交付

安全拒絕需有實際工具證據才使用 `refusal`；最多一次 `safe_retry`，不能把拒絕結果登記為成功。仍無法生成時按主技能的局部素材組版處理，不能把整張原頁冒充生成頁。服務、權限或額度問題不能誤標為安全拒絕。

`finish(job, observed_texts, page_ids, committed, visual_reviewed)` 核對完整頁序、原生正文與目前選定圖片是否已綁定，未知生成結果或仍綁定舊版會阻擋交付。參數只能來自實際讀回與逐頁看圖，不能為了通過而填入計畫內容或猜測 true。它不取代實際工具操作與視覺驗收。
