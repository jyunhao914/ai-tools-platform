# 執行與保存

使用者指定：面向大量分享使用；預設 Google Drive，優先完全雲端及電腦網頁版。帳號登入及必要授權完成後，應由統一外掛連結安裝使用，不能綁定開發者單一電腦。本機快取不強制。iPad／iPhone 暫不列入驗收。只有確認雲端行不通，才啟用本機備案；暫時執行器失敗不代表雲端永久不可行。

必要能力：原生簡報建立／讀取／編輯／持久保存、圖片生成、原始檔案讀取與圖片上傳、Google Drive 搜尋／讀寫。不得以本機測試等同網頁測試。

完全雲端且未指定編輯器時，使用 Google create_file → get_presentation → batch_update_presentation → export_file；詳見 [Google Slides](google-slides.md)。若使用者指定 Spaces，使用 Pages create_presentation → inspect_artifact → execute_artifact_code；圖片以 upload_artifact_images 的實際雲端工作區路徑上傳。每次只對同一 Page 執行一個操作。

桌面若有 Artifact Session，可 connect_spaces_artifact 後使用返回的 artifactRef。它是當次連線，不保存到風格庫或當成跨對話永久參照。桌面僅有的能力不能標為網頁已驗證。

工作檔存在 Drive：來源、選定設定、原生 Page ID、修訂計畫、原圖與各次生成結果、逐頁資產映射、每次請求狀態與錯誤。網路／額度／服務中斷保存後回報；重開時由 Drive 找回，不依上一回合記憶猜測。

先驗證建立／寫入／圖片持久化／讀回，再接整份製作。artifact_executor_unavailable 依工具說明只重試一次；仍失敗記錄真正阻塞，不能宣稱雲端可用或靜默切成桌面。

公開說明須區分「工具文件支援」「本機實測」「雲端執行實測」「使用者網頁實測」。不得假裝掛上技能就能永遠連續生成或繞過帳號限制。
