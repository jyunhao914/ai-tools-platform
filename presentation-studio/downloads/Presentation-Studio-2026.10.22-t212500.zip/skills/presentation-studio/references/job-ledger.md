# 來源、圖片版本與恢復紀錄

`scripts/studio.py` 是平台沙箱可載入的標準 Python 模組，不需使用者安裝 Python。由呼叫端先在平台託管工作目錄保存 JSON；它本身不會上傳。每次修改後呼叫 `write_json`。只有使用者明確要求備份本次來源與紀錄到指定 Drive 位置時才上傳，成功後登記真實 file ID。未備份不可宣稱雲端保存或跨對話可恢復；備份不是製作成品的前置條件。

## 一次新製作

1. `pptx(path)` 或 `outline(text)` 取得來源。PPTX 的 `images` 保留來源檔案內的 `source_part` 與實際位元組 SHA256；texts 保留文字框／儲存格內換行，tables 保存儲存格索引與合併資訊。PDF 必須使用平台閱讀／渲染工具逐頁取得內容，不能交給大綱解析器假裝成功。
2. `new_job(slides, mode, policy, style, operation, target_pages)`。style 至少包含 `selection` 與 `user_choice`，例如 `{"selection":"02","user_choice":"選藍色醫療"}`；原話需來自實際回答，未選先顯示風格並詢問，不補成自動。來源設定後不可改原始紀錄；縮減／擴增改製作計畫並保留來源對應。新上傳必須新建 job。
3. `plan(job, pages)` 保存確認後的文字與每頁圖片位置。它核對頁數、來源對應、保留模式文字，以及同頁每張圖片的獨立 slot ID。排版仍可自行撰寫，不要求固定模板。可編輯＋生成配圖時，先呼叫 series_requirements(source)：明確箭頭序列自動識別；其他比較／步驟由閱讀來源後記錄 source.visual_series=[{"kind":"comparison","members":["調整前","調整後"]}]。先保存這份來源再 new_job，不修改已凍結來源。plan 的每頁附 series_bindings=[{"members":["調整前","調整後"],"slot_ids":["before","after"]}]，每個項目對應不同的 GENERATE slot。四階段缺一圖位、只規劃一張綜合圖或重用同一 slot 都不通過，須自行補完整計畫；NONE／REUSE 及整頁圖像式不套用逐項生成要求。縮減／擴增使用確認後的頁面 texts／visual_series，不強迫保留已刪除的來源序列。
4. `dispatch(job, page_id, slot_id, prompt)` 先建立唯一生成請求並保存本次工作紀錄，再呼叫平台 ImageGen。結果未知時，先找回原呼叫結果，不改提示詞重送。
5. 取得真正 PNG 後先上傳 Drive，再 `register(job, request_id, sandbox_path, drive_file_id)`。最新結果自動選定。把該資產寫入原生簡報並讀回後，才 `bind(job, page_id, slot_id, request_id, slide_id, image_id)`。

## 直接沿用原圖

圖片 slot 的 `action` 設 `REUSE`，`source_asset` 為 `{"source_id": "來源頁 ID", "sha256": "來源素材 SHA256"}`。從 PPTX 指定的 source_part 取出原始素材，不重新截圖、不經 AI 重畫。上傳 Drive 後 `register_reuse(job, page_id, slot_id, file_path, drive_file_id)` 會核對原素材實際位元組及來源頁，返回可綁定的 request ID。再次登記相同原素材不會重複產生紀錄。

## 修改、指定舊版與更新簡報

使用者明確修改才重新 `dispatch`，附 `revision={"id": "本次修改 ID", "reason": "已確認修改要求"}`；微小色差或 OCR 檢查不自動產生修改請求。保存所有版本，不覆寫原 PNG。

指定舊版用 `select_version(job, page_id, slot_id, request_id, version=0)`；選擇紀錄改變不代表投影片已更新。Google 路徑先讀當頁與 revisionId，再用 `google_slides.replace_asset(binding, asset, observed_slide)` 及 `tool_batches` 產生替換。binding 包含 slide_id、image_id、slot_id、目前圖片 sha256；asset 包含實際沙箱路徑與選定圖片 sha256。送出時使用同一讀回的 requiredRevisionId。

替換保持原 image object ID，完整置入圖片，不裁切內容。結果未知先讀回；已是所選 SHA256 時不再寫入，仍須核對實際圖片。物件消失、屬於別頁或中途被使用者修改時，先釐清，不直接蓋過。只有確認寫入後才更新 bind。匯出 PPTX 必須核對內嵌圖片的實際位元組，不只相信 SHA 標籤。

## 失敗與交付

安全拒絕需有實際工具證據才使用 `refusal`；最多一次 `safe_retry`，不能把拒絕結果登記為成功。仍無法生成時按主技能的局部素材組版處理，不能把整張原頁冒充生成頁。服務、權限或額度問題不能誤標為安全拒絕。Spaces 的寫入逾時或 viewer flush failed 必須依 workflow.md 的 recover_write 狀態機處理，再依 native.md 查交易並讀回：已保存的頁與 slot 重新綁定，未保存的單獨補寫；不能把工具逾時當作 Page 權限拒絕。

`finish(job, observed_texts, page_ids, committed, visual_reviewed)` 核對完整頁序、原生正文與目前選定圖片是否已綁定，未知生成結果或仍綁定舊版會阻擋交付。參數只能來自實際讀回與逐頁看圖，不能為了通過而填入計畫內容或猜測 true。它不取代實際工具操作與視覺驗收。

原生寫入收據的 state 存到 job.native_pages[page_id]，每次更新後保存到同一份平台工作目錄進度檔；只有已授權紀錄備份時才同步指定 Drive 位置；下一個 appendPage／appendAsset 傳入這份 input.state。pending transaction 也保存在同一處，用來核對逾時前後物件。備忘稿不作為任何工作紀錄儲存區。

`finish` 只返回 READY_FOR_EXPORT；接著呼叫 workflow.py.complete_delivery(job, document, pptx_path)，驗證實際命名文件、開啟證據、完整 PPTX 與已結束的寫入，再保存返回的 DELIVERED job。舊 DELIVERABLE 不能當作完成，先重新 finish。沒有真實檔案就不能回覆完成。

PNG 登記前核對區塊結構與 CRC，只有檔頭或遭截斷的檔案不能登記為已生成。此檢查不等於解碼或內容驗收，仍需開圖檢查。finish 重新核對已確認來源及計畫摘要；計畫被修改須依已授權變更重新確認版本，不能同步改 observed 便冒充原內容驗證通過。
