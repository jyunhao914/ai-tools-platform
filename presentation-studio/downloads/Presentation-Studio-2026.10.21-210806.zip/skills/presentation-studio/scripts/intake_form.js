/* Shared deterministic form and submission contract. No network calls. */
function studioSelection(config, values) {
  const choices = {};
  for (const group of config.groups) {
    if (group.id === "personal_style" && config.groups.some(g => g.id === "style") && values.style !== "SM") continue;
    const option = group.options.find(o => o.id === values[group.id]);
    if (!option) throw new Error("請選擇「" + group.title + "」。");
    choices[group.id] = option.id;
  }
  const result = {schema: 1, request_id: config.request_id, choices};
  if (["O2", "O3"].includes(choices.operation)) {
    const pages = Number(values.target_pages);
    if (!Number.isSafeInteger(pages) || pages < 1)
      throw new Error("請填入大於零的目標頁數。");
    result.target_pages = pages;
  }
  if (choices.style === "SC") {
    const description = (values.custom_style || "").trim();
    if (!description) throw new Error("請填入自訂風格描述。");
    result.custom_style = description;
  }
  if (choices.save_style === "SAVE") {
    const name = (values.style_name || "").trim();
    if (!name) throw new Error("請填入風格名稱。");
    result.style_name = name;
  }
  if (config.catalog_snapshot) result.catalog_snapshot = config.catalog_snapshot;
  return result;
}

function studioPrompt(config, selection) {
  const labels = config.groups.filter(g => g.id in selection.choices).map(g => {
    const code = selection.choices[g.id];
    const label = g.options.find(o => o.id === code).label;
    return g.title + " " + (["SA","SC","SM","SAVE","SKIP"].includes(code) ? label : code + "（" + label + "）");
  });
  return "Presentation Studio 設定：" + labels.join("；") + "。\n" +
    "以下是這次表單送出的設定資料，沿用本次來源；設定齊全就接續原任務。\n" +
    JSON.stringify(selection);
}

function studioStateSaver(getBridge, reportFailure) {
  let latest = 0;
  return async snapshot => {
    const revision = ++latest;
    try {
      const bridge = getBridge();
      if (typeof bridge?.setWidgetState !== "function") throw new Error("State storage unavailable");
      await bridge.setWidgetState(snapshot);
      if (revision === latest) reportFailure(false);
    } catch {
      if (revision === latest) reportFailure(true);
    }
  };
}

function mountStudioIntake(root, config, host) {
  const form = root.querySelector("form");
  const area = root.querySelector("[data-groups]");
  const button = form.querySelector("button");
  const error = root.querySelector("[data-error]");
  const status = root.querySelector("[data-status]");
  const persistence = root.querySelector("[data-persistence]");
  const controls = {};
  const sections = {};
  const styleModes = [];
  const stylePanels = {};
  let sending = false;
  let accepted = null;
  const saveState = studioStateSaver(() => host.openai, failed => {
    persistence.textContent = failed
      ? "平台未能暫存目前選擇；重新整理可能遺失尚未送出的選項。是否已送出，請以對話中收到設定訊息為準。"
      : "";
  });
  function node(tag, text, cls) {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    if (cls) el.className = cls;
    return el;
  }
  function gallery(options, label, collapsed, groupId) {
    const wrapper = node(collapsed ? "details" : "div");
    if (collapsed) wrapper.append(node("summary", label));
    const grid = node("div", null, "studio-gallery");
    for (const option of options.filter(o => o.preview_data)) {
      const item = node("div", null, "studio-style");
      const image = node("img", null, "studio-preview");
      image.src = option.preview_data;
      image.alt = option.id + " " + option.label + " 九頁風格預覽";
      item.append(image, node("p", option.id + " " + option.label));
      grid.append(item);
    }
    wrapper.append(grid);
    return wrapper;
  }
  for (const [index, group] of config.groups.entries()) {
    if (index && !(group.id === "personal_style" && sections.style)) area.append(node("hr"));
    const section = node("section");
    sections[group.id] = section;
    section.setAttribute("aria-label", group.title);
    section.append(node("p", group.title));
    if (group.context) section.append(node("p", group.context, "text-small"));
    if (group.id === "style") {
      for (const [mode, title] of [
        ["auto", "自動"], ["builtin", "預設風格"],
        ["personal", "我的風格庫"], ["custom", "自訂風格"],
      ]) {
        const label = node("label", null, "form-check");
        const radio = node("input", null, "form-check-input");
        radio.type = "radio"; radio.name = "style_mode"; radio.value = mode;
        const code = group.selected;
        radio.checked = mode === (code === "SA" ? "auto" : code === "SM" ? "personal" :
          code === "SC" ? "custom" : /^\d{2}$/.test(code || "") ? "builtin" :
          "");
        label.append(radio, node("span", title, "form-check-label"));
        section.append(label);
        styleModes.push(radio);
      }
      for (const mode of ["builtin", "personal", "custom"]) {
        stylePanels[mode] = node("div");
        stylePanels[mode].hidden = true;
        section.append(stylePanels[mode]);
      }
      if (!config.groups.some(g => g.id === "personal_style")) {
        stylePanels.personal.append(node("p", "需先讀取你的風格庫；套用後接續讀取並顯示款式。"));
      }
    }
    const isSelect = group.id === "style" || group.id === "personal_style";
    controls[group.id] = [];
    if (isSelect) {
      const input = node("select", null, "form-select");
      input.name = group.id; input.setAttribute("aria-label", group.title);
      const blank = node("option", "請選擇"); blank.value = ""; input.append(blank);
      for (const option of group.options) {
        if (group.id === "style" && !/^\d{2}$/.test(option.id)) continue;
        const entry = node("option", ["SA","SC","SM"].includes(option.id) ? option.label : option.id + " " + option.label);
        entry.value = option.id; input.append(entry);
      }
      input.value = group.selected || "";
      controls[group.id].push(input);
      if (group.id === "style") {
        stylePanels.builtin.append(input, gallery(group.options, "展開內建 15 款風格", true, group.id));
      } else section.append(input, gallery(group.options, "展開我的風格預覽（" + group.options.length + " 款）", true, group.id));
    } else {
      const grid = group.id === "personal_style" ? node("div", null, "viz-grid") : section;
      if (grid !== section) section.append(grid);
      for (const option of group.options) {
        const item = node("div", null, "studio-style");
        if (group.id === "personal_style" && option.preview_data) {
          const preview = node("img", null, "studio-preview");
          preview.src = option.preview_data;
          preview.alt = option.id + " " + option.label + " 預覽";
          item.append(preview);
        }
        const label = node("label", null, "form-check");
        const input = node("input", null, "form-check-input");
        input.type = "radio"; input.name = group.id; input.value = option.id;
        input.checked = group.selected === option.id;
        label.append(input, node("span", ["SAVE","SKIP"].includes(option.id) ? option.label : option.id + " · " + option.label, "form-check-label"));
        controls[group.id].push(input); item.append(label); grid.append(item);
      }
    }
    if (group.id === "personal_style" && stylePanels.personal) stylePanels.personal.append(section);
    else area.append(section);
  }
  const pages = form.elements.namedItem("target_pages");
  const custom = form.elements.namedItem("custom_style");
  const styleName = form.elements.namedItem("style_name");
  if (stylePanels.custom) stylePanels.custom.append(root.querySelector("[data-custom]"));
  pages.value = config.target_pages || "";
  custom.value = config.custom_style || "";
  styleName.value = config.suggested_style_name || "";
  function values() {
    const state = {target_pages: pages.value, custom_style: custom.value, style_name: styleName.value};
    for (const group of config.groups) {
      const inputs = controls[group.id];
      state[group.id] = inputs[0].tagName === "SELECT" ? inputs[0].value :
        (inputs.find(input => input.checked)?.value || "");
    }
    if (styleModes.length) {
      state.style_mode = styleModes.find(input => input.checked)?.value || "";
      state.style = {auto: "SA", personal: "SM", custom: "SC"}[state.style_mode] ||
        (state.style_mode === "builtin" ? state.style : "");
    }
    return state;
  }
  function refresh() {
    const v = values();
    root.querySelector("[data-pages]").hidden = !["O2", "O3"].includes(v.operation);
    root.querySelector("[data-custom]").hidden = v.style !== "SC";
    root.querySelector("[data-style-name]").hidden = !sections.save_style || v.save_style === "SKIP";
    styleName.disabled = v.save_style === "SKIP";
    if (sections.personal_style && sections.style) sections.personal_style.hidden = v.style !== "SM";
    for (const [mode, panel] of Object.entries(stylePanels)) panel.hidden = v.style_mode !== mode;
    const same = accepted === JSON.stringify(v);
    button.disabled = sending || same;
    button.textContent = sending ? "送出中…" : same ? "設定已送出" :
      sections.save_style ? (v.save_style === "SKIP" ? "略過儲存" : "確認儲存風格") : "套用設定並繼續 →";
  }
  function restore(snapshot) {
    const state = snapshot?.modelContent;
    if (!state || state.request_id !== config.request_id || state.form_id !== root.id) return;
    for (const group of config.groups) {
      const code = state.values?.[group.id];
      if (!group.options.some(o => o.id === code)) continue;
      for (const input of controls[group.id]) {
        if (input.tagName === "SELECT") input.value = code;
        else input.checked = input.value === code;
      }
    }
    if (styleModes.length) {
      const v = state.values || {};
      const mode = v.style === "SA" ? "auto" : v.style === "SM" ? "personal" :
        v.style === "SC" ? "custom" : /^\d{2}$/.test(v.style || "") ? "builtin" : v.style_mode;
      for (const input of styleModes) input.checked = input.value === mode;
    }
    pages.value = state.values?.target_pages || "";
    custom.value = state.values?.custom_style || "";
    styleName.value = state.values?.style_name ?? config.suggested_style_name ?? "";
    refresh();
  }
  restore(host.openai?.widgetState);
  host.addEventListener("openai:set_globals", e => {
    if (!sending) restore(e.detail?.globals?.widgetState);
  });
  form.addEventListener("input", () => {
    error.textContent = ""; status.textContent = ""; refresh();
    const snapshot = {modelContent: {request_id: config.request_id, form_id: root.id, values: values()}};
    void saveState(snapshot);
  });
  async function submit(event) {
    event.preventDefault();
    if (sending || button.disabled) return;
    error.textContent = "";
    const v = values();
    let selection;
    try { selection = studioSelection(config, v); }
    catch (e) { error.textContent = e.message; return; }
    if (typeof host.openai?.sendFollowUpMessage !== "function") {
      error.textContent = "此畫面目前沒有提供表單送出功能，設定尚未送出；已保留目前選擇。";
      return;
    }
    sending = true; refresh();
    // Freeze controls until the exact clicked selection is acknowledged.
    for (const input of form.querySelectorAll("input,select,textarea")) input.disabled = true;
    try {
      await host.openai.sendFollowUpMessage({
        prompt: studioPrompt(config, selection), title: "套用簡報製作設定"
      });
      accepted = JSON.stringify(v);
      status.textContent = "設定已送交對話；請在對話中查看接續結果。";
    } catch {
      error.textContent = "設定未能送出，已保留你的選擇，可再按一次送出。";
    } finally {
      sending = false;
      for (const input of form.querySelectorAll("input,select,textarea")) input.disabled = false;
      refresh();
    }
  }
  button.addEventListener("click", submit);
  form.addEventListener("submit", submit);
  refresh();
}

if (typeof module !== "undefined") module.exports = {studioSelection, studioPrompt, studioStateSaver};
