"""Validate existing or cloud-retrieved personal styles without executing data."""
import hashlib
import json
import struct
import uuid
import io
import zipfile
import zlib

FIELDS = {'name','concept','background','palette','typography','imagery','materials',
          'layout','components','cover','content_pages','transitions','ending','prohibited'}


def validate(manifest_bytes, preview_bytes, folder_name):
    if len(manifest_bytes)>256*1024 or len(preview_bytes)>10*1024*1024:
        raise ValueError('風格資料過大')
    data=json.loads(manifest_bytes)
    uuid.UUID(data['id'])
    if not isinstance(data.get('name'),str) or not data['name'].strip():
        raise ValueError('風格名稱不可空白')
    profile=data.get('profile')
    if data.get('schema_version')!=1 or not isinstance(profile,dict) or any(not profile.get(k) for k in FIELDS):
        raise ValueError('風格設定不完整')
    if hashlib.sha256(preview_bytes).hexdigest()!=data['preview_sha256']:
        raise ValueError('預覽摘要不符，先重新同步')
    if not preview_bytes.startswith(b'\x89PNG\r\n\x1a\n') or len(preview_bytes)<33:
        raise ValueError('預覽不是有效 PNG')
    width,height=struct.unpack('>II',preview_bytes[16:24])
    if not width or not height or width*height>100_000_000:
        raise ValueError('預覽尺寸錯誤')
    _check_png(preview_bytes)
    try:
        uuid.UUID(folder_name)
    except ValueError:
        if folder_name.strip():
            data['name']=folder_name
            data['profile']['name']=folder_name
    return data


def _check_png(data):
    """Catch truncated/corrupt preview files before displaying a broken thumbnail."""
    offset=8
    seen=[]
    while offset<len(data):
        if len(data)-offset<12:
            raise ValueError('預覽 PNG 不完整')
        length=struct.unpack('>I',data[offset:offset+4])[0]
        end=offset+length+12
        if end>len(data):
            raise ValueError('預覽 PNG 不完整')
        kind=data[offset+4:offset+8]
        payload=data[offset+8:offset+8+length]
        expected=struct.unpack('>I',data[offset+8+length:end])[0]
        if zlib.crc32(kind+payload)&0xffffffff!=expected:
            raise ValueError('預覽 PNG 校驗失敗')
        if not seen and (kind!=b'IHDR' or length!=13):
            raise ValueError('預覽 PNG 缺少標頭')
        if kind==b'IHDR' and seen:
            raise ValueError('預覽 PNG 重複標頭')
        seen.append(kind)
        offset=end
        if kind==b'IEND':
            if length or offset!=len(data) or b'IDAT' not in seen:
                raise ValueError('預覽 PNG 結尾錯誤')
            return
    raise ValueError('預覽 PNG 缺少結尾')


def import_archive(archive_bytes):
    """Read the original Presentation Maker ZIP contract without extracting paths."""
    if len(archive_bytes)>11*1024*1024:
        raise ValueError('風格壓縮檔過大')
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        names=archive.namelist()
        pairs=[('style.json','preview.png'),('風格設定.json','預覽.png')]
        pair=next((p for p in pairs if sorted(names)==sorted(p)),None)
        if not pair:
            raise ValueError('風格 ZIP 須只包含一份設定與預覽；不接受路徑或重複檔案')
        if archive.getinfo(pair[0]).file_size>256*1024 or archive.getinfo(pair[1]).file_size>10*1024*1024:
            raise ValueError('風格資料過大')
        manifest,preview=(archive.read(n) for n in pair)
    data=validate(manifest,preview,'')
    return data,preview


def export_archive(manifest_bytes,preview_bytes,folder_name):
    """Preserve the UUID while exporting the current Drive folder display name."""
    data=validate(manifest_bytes,preview_bytes,folder_name)
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('style.json',json.dumps(data,ensure_ascii=False,indent=2))
        archive.writestr('preview.png',preview_bytes)
    return output.getvalue()


def resolve_import(incoming,existing):
    """Use freshly listed manifests; never overwrite a conflicting UUID."""
    matches=[s for s in existing if s['id']==incoming['id']]
    if len(matches)>1:
        raise ValueError('雲端有重複風格 ID，先確認要使用哪一份')
    if matches:
        old=matches[0]
        content=lambda s:{k:v for k,v in s['profile'].items() if k!='name'}
        if content(old)!=content(incoming) or old['preview_sha256']!=incoming['preview_sha256']:
            raise ValueError('同 ID 的風格內容不同，保留兩份來源，不自動覆蓋')
        return {'action':'USE_EXISTING','id':old['id'],'name':old['name']}
    names={s['name'] for s in existing}
    name=incoming['name'];suffix=2
    while name in names:
        name=f"{incoming['name']}（{suffix}）";suffix+=1
    return {'action':'CREATE','id':incoming['id'],'name':name}
