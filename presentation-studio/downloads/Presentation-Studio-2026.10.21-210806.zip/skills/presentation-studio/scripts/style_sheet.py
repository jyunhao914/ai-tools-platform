"""Nine-slide previews: compose verified renders, never duplicate a lone page."""
import argparse
import hashlib
import json
from pathlib import Path

LAYOUTS = ["封面", "章節頁", "文字重點", "圖文並排", "三欄資訊",
           "步驟流程", "數據比較", "引言重點", "結尾"]


def plan(source_count):
    if not isinstance(source_count, int) or isinstance(source_count, bool) or source_count < 1:
        raise ValueError("Read at least one actual source slide")
    indices = list(range(source_count)) if source_count <= 9 else [
        round(i * (source_count - 1) / 8) for i in range(9)]
    entries = [{"kind": "source", "source_index": i, "slot": slot}
               for slot, i in enumerate(indices)]
    for slot in range(len(entries), 9):
        entries.append({"kind": "style_demo", "layout": LAYOUTS[slot], "slot": slot})
    return entries


def compose(entries, output):
    """Input nine actual source/demo PNG paths with explicit provenance."""
    from PIL import Image, ImageOps
    if len(entries) != 9 or sorted(e["slot"] for e in entries) != list(range(9)):
        raise ValueError("A style preview requires exactly nine different slots")
    hashes, provenance = set(), []
    canvas = Image.new("RGB", (1488, 846), "#eef2f7")
    for entry in sorted(entries, key=lambda e: e["slot"]):
        if entry.get("kind") not in {"source", "style_demo"}:
            raise ValueError("Keep source/demo provenance")
        if entry["kind"] == "style_demo" and not entry.get("layout"):
            raise ValueError("A demo needs a distinct layout")
        path = Path(entry["path"])
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest in hashes:
            raise ValueError("Do not repeat the same render to fill nine slides")
        hashes.add(digest)
        with Image.open(path) as original:
            image = ImageOps.contain(original.convert("RGB"), (480, 270))
            index = entry["slot"]
            x, y = 8 + (index % 3) * 496, 8 + (index // 3) * 282
            canvas.paste("white", (x, y, x + 480, y + 270))
            canvas.paste(image, (x + (480-image.width)//2, y + (270-image.height)//2))
        provenance.append({**{k: v for k, v in entry.items() if k != "path"},
                           "render_sha256": digest})
    canvas.save(output, "PNG", optimize=True)
    return {"layout": "nine-slide-grid", "page_count": 9, "pages": provenance,
            "preview_sha256": hashlib.sha256(Path(output).read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    print(json.dumps(compose(json.loads(args.input.read_text())["pages"], args.output),
                     ensure_ascii=False))
