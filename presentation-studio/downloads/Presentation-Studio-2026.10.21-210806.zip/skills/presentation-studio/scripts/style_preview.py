"""Compose existing previews by explicit ID; never by directory or download order."""
import argparse
import hashlib
import io
import json
from pathlib import Path
from urllib.request import urlopen


def read_images(entries, asset_dir=None):
    from PIL import Image
    by_id = {entry['number']: entry for entry in entries}
    if len(entries) != 15 or set(by_id) != set(range(1, 16)):
        raise ValueError('Preview manifest must contain unique IDs 01–15')
    rows = []
    for number in range(1, 16):
        entry = by_id[number]
        filename = f's{number:02}.jpg'
        if entry['file'] != filename or not entry['url'].endswith('/' + filename):
            raise ValueError(f'Preview ID/path mismatch: {number}')
        if asset_dir is not None:
            data = (Path(asset_dir) / filename).read_bytes()
        else:
            with urlopen(entry['url'], timeout=30) as response:
                data = response.read()
        if hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise ValueError(f'Preview bytes mismatch: {number}; do not relabel or substitute')
        im = Image.open(io.BytesIO(data))
        im.load()
        rows.append((entry, im.convert('RGB')))
    return rows


def compose(rows, output, font_path):
    from PIL import Image, ImageDraw, ImageFont
    # A Chinese-capable font is explicit so labels never silently become boxes.
    font = ImageFont.truetype(str(font_path), 26)
    canvas = Image.new('RGB', (1560, 1580), '#EEF2F7')
    draw = ImageDraw.Draw(canvas)
    for entry, picture in rows:
        index = entry['number'] - 1
        x, y = 20 + (index % 3) * 515, 20 + (index // 3) * 310
        draw.rectangle((x, y, x + 495, y + 290), fill='white')
        picture.thumbnail((475, 235))
        canvas.paste(picture, (x + (495 - picture.width) // 2, y + 5))
        draw.text((x + 12, y + 250), f"{entry['number']:02}  {entry['name']}", font=font, fill='#172D46')
    canvas.save(output, format='PNG')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--asset-dir')
    parser.add_argument('--font', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    rows = read_images(json.loads(Path(args.manifest).read_text()), args.asset_dir)
    compose(rows, args.output, args.font)
    print(json.dumps({'verified_ids': [entry['number'] for entry, _ in rows], 'output': args.output}))
