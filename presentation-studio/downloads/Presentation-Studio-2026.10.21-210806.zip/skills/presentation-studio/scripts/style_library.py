"""Build a private style menu from fresh, complete Drive readbacks.

The host lists folders and downloads files using authenticated Drive tools.
No credentials, private URLs or executable instructions are accepted here.
"""
import copy
import base64
import hashlib
import io
import json
import unicodedata
from collections import Counter

from style_package import validate


def preview_upgrade_reason(data):
    """Old previews remain intact until nine verified renders replace them."""
    if data.get('preview_layout') != 'nine-slide-grid' or data.get('preview_page_count') != 9:
        return '舊預覽尚非九頁九宮格'
    pages = data.get('preview_pages', [])
    if (not isinstance(pages, list) or len(pages) != 9
        or any(not isinstance(p, dict) for p in pages)):
        return '缺少九頁預覽來源記錄'
    if (sorted(p.get('slot', -1) for p in pages) != list(range(9))
        or len({p.get('render_sha256') for p in pages}) != 9
        or any(not p.get('render_sha256') or p.get('kind') not in {'source', 'style_demo'}
               for p in pages)):
        return '九頁預覽來源記錄不完整'
    return None


def catalog(records, *, complete):
    """records: folder_id, folder_name, manifest_bytes, preview_bytes.

    Call only after scanning the configured style root, excluding trashed
    folders. Explicit errors stay visible; incomplete scans never imply empty.
    """
    if complete is not True:
        raise ValueError('風格庫尚未讀取完整；不能顯示為空或沿用舊選單')
    valid, warnings = [], []
    for record in records:
        try:
            if record.get('error'):
                raise ValueError(record['error'])
            if not record.get('folder_id') or not record.get('folder_name', '').strip():
                raise ValueError('缺少雲端資料夾識別或名稱')
            data = validate(record['manifest_bytes'], record['preview_bytes'], record['folder_name'])
            valid.append({
                'folder_id': record['folder_id'], 'style_id': data['id'],
                'name': data['name'], 'profile': data['profile'],
                'preview_sha256': data['preview_sha256'],
                'preview_bytes': record['preview_bytes'],
                'preview_upgrade_reason': preview_upgrade_reason(data),
                'preview_metadata': {k: copy.deepcopy(data.get(k)) for k in
                                     ('preview_layout', 'preview_page_count', 'preview_pages')},
            })
        except (ValueError, KeyError, TypeError) as error:
            warnings.append({'name': record.get('folder_name', ''), 'error': str(error)})
    ids = Counter(item['style_id'] for item in valid)
    folders = Counter(item['folder_id'] for item in valid)
    unique = []
    for item in valid:
        if ids[item['style_id']] > 1 or folders[item['folder_id']] > 1:
            warnings.append({'name': item['name'], 'error': '重複風格 ID 或資料夾，請先確認；不自動選取'})
        else:
            unique.append(item)
    unique.sort(key=lambda item: (item['name'].casefold(), item['folder_id']))
    for index, item in enumerate(unique, 1):
        item['code'] = f'M{index:02}'
    fingerprint = [{k: v for k, v in item.items() if k != 'preview_bytes'} for item in unique]
    token = hashlib.sha256(json.dumps(fingerprint, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    upgrades = [{k: item[k] for k in ('folder_id', 'style_id', 'name', 'preview_upgrade_reason')}
                for item in unique if item['preview_upgrade_reason']]
    return {'snapshot': token, 'items': unique, 'warnings': warnings, 'preview_upgrades': upgrades,
            'state': 'READY' if unique else ('UNAVAILABLE' if warnings else 'EMPTY')}


def select(menu, reply, *, snapshot):
    """A code is scoped to the displayed snapshot, never a permanent identity."""
    if snapshot != menu['snapshot']:
        raise ValueError('風格庫已更新，請重新顯示預覽與代碼再選擇')
    key = unicodedata.normalize('NFKC', reply).strip().casefold()
    matches = [item for item in menu['items']
               if key in (item['code'].casefold(), unicodedata.normalize('NFKC', item['name']).casefold())]
    if len(matches) != 1:
        raise ValueError('請選擇具體風格代碼；名稱不存在或同名不唯一')
    item = matches[0]
    return {
        'selection': 'PERSONAL', 'user_choice': reply, 'style_id': item['style_id'],
        'folder_id': item['folder_id'], 'name': item['name'], 'profile': copy.deepcopy(item['profile']),
        'preview_sha256': item['preview_sha256'], 'catalog_snapshot': menu['snapshot'],
    }


def form_group(menu):
    """Embed actual private thumbnail bytes; never private URLs or public uploads."""
    from PIL import Image
    if not menu['items']:
        raise ValueError('風格庫沒有可選款式；顯示實際 EMPTY／UNAVAILABLE 原因')
    if menu.get('preview_upgrades'):
        names = '、'.join(item['name'] for item in menu['preview_upgrades'])
        raise ValueError('先依 drive-styles.md 完成九頁預覽升級並回讀，再顯示表單：' + names)
    options = []
    for item in menu['items']:
        with Image.open(io.BytesIO(item['preview_bytes'])) as source:
            image = source.convert('RGB')
            buffer = io.BytesIO()
            image.save(buffer, 'WEBP', lossless=True, method=6)
            if len(buffer.getvalue()) > 500000:
                raise ValueError('預覽過大，請分批或獨立呈現原解析度預覽；不可縮小至模糊')
        options.append({'id': item['code'], 'label': item['name'],
                        'preview_metadata': copy.deepcopy(item['preview_metadata']),
                        'preview_width': image.width, 'preview_height': image.height,
                        'preview_data': 'data:image/webp;base64,' +
                        base64.b64encode(buffer.getvalue()).decode('ascii')})
    return {'id': 'personal_style', 'title': '我的風格庫', 'options': options}


def refresh_selection(selection, fresh_menu):
    """Bind again by UUID+folder, keeping Drive rename but detecting deletion."""
    matches = [item for item in fresh_menu['items']
               if item['style_id'] == selection['style_id'] and item['folder_id'] == selection['folder_id']]
    if len(matches) != 1:
        raise ValueError('所選風格已移除、移出風格庫或無法讀取，請重新選擇')
    item = matches[0]
    if (item['preview_sha256'] != selection['preview_sha256']
        or {k: v for k, v in item['profile'].items() if k != 'name'}
        != {k: v for k, v in selection['profile'].items() if k != 'name'}):
        raise ValueError('所選風格內容已變更，請顯示新預覽後重新選擇')
    result = select(fresh_menu, item['code'], snapshot=fresh_menu['snapshot'])
    result['user_choice'] = selection['user_choice']
    return result


def compose(menu, output, font_path):
    """Private PNG contact sheet; no browser/public hosting needed."""
    from PIL import Image, ImageDraw, ImageFont, ImageOps
    if not menu['items']:
        raise ValueError('沒有可顯示的風格；請顯示 EMPTY 或 UNAVAILABLE 原因')
    font = ImageFont.truetype(str(font_path), 24)
    canvas = Image.new('RGB', (1000, 350 * ((len(menu['items']) + 1) // 2)), '#eef2f7')
    draw = ImageDraw.Draw(canvas)
    for i, item in enumerate(menu['items']):
        x, y = (i % 2) * 500, (i // 2) * 350
        picture = Image.open(io.BytesIO(item['preview_bytes'])).convert('RGB')
        picture = ImageOps.contain(picture, (460, 245))
        canvas.paste(picture, (x + (500-picture.width)//2, y + 12))
        # Wrap long Chinese names rather than truncating identification.
        text = item['code'] + '｜' + item['name']
        lines, line = [], ''
        for char in text:
            if draw.textlength(line + char, font=font) > 460:
                lines.append(line); line = ''
            line += char
        lines.append(line)
        if len(lines) > 3:
            raise ValueError('風格名稱太長，請以單張預覽及完整文字顯示')
        for row, line in enumerate(lines):
            draw.text((x+20, y+260+row*28), line, font=font, fill='#172d46')
    canvas.save(output, 'PNG')
