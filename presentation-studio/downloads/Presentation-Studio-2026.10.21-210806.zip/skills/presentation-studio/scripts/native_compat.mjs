// Scope this compatibility bridge to one complete desktop Artifact Session run (including asset save).
// No SDK files, permissions, document IDs or authorization checks are changed.
// Old native-record codecs reject host-cloned plain objects from another realm.
export async function withNativeRecordCompatibility(operation) {
  const original = globalThis.structuredClone;
  if (typeof original !== 'function') throw new Error('structuredClone is unavailable');
  const probe = original({});
  if (Object.getPrototypeOf(probe) === Object.prototype || Object.getPrototypeOf(probe) === null) {
    return await operation();
  }
  function normalizeRecords(value, seen = new WeakSet()) {
    if (value === null || typeof value !== 'object' || seen.has(value)) return value;
    seen.add(value);
    const tag = Object.prototype.toString.call(value);
    if (tag === '[object Object]') {
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== null && prototype.constructor?.name === 'Object') {
        Object.setPrototypeOf(value, Object.prototype);
      }
      for (const key of Object.keys(value)) normalizeRecords(value[key], seen);
    } else if (Array.isArray(value) || tag === '[object Set]') {
      for (const item of value) normalizeRecords(item, seen);
    } else if (tag === '[object Map]') {
      for (const [key, item] of value) {
        normalizeRecords(key, seen);
        normalizeRecords(item, seen);
      }
    }
    return value;
  }
  const bridge = (value, options) => normalizeRecords(original(value, options));
  globalThis.structuredClone = bridge;
  try {
    return await operation();
  } finally {
    globalThis.structuredClone = original;
  }
}

// Include asynchronous image hydration and commit, not only the author callback.
export async function runNativeSession(client, callback, options) {
  return await withNativeRecordCompatibility(() => client.run(callback, options));
}
