// Portable callbacks: one text page OR one PNG per durable tool call.
// Call with timeout_ms: 60000. Never loop over image writes inside one tool call.
export const NATIVE_WRITE_TIMEOUT_MS = 60000;
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value==='object') return Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])]));
  return value;
}
const equal=(a,b)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
function validateFrame(value) {
  if (!value || ['left','top','width','height'].some(k=>!Number.isFinite(value[k])) || value.left<0 || value.top<0 || value.width<=0 || value.height<=0 || value.left+value.width>1280 || value.top+value.height>720)
    throw new Error('Invalid frame or element outside slide');
  return value;
}
function layout(input) {
  return canonical({colors:input.colors,textBoxes:input.mode==='EDITABLE'?input.page.textBoxes:[],
    decorations:input.page.decorations??[],slots:input.page.slots,notesPolicy:input.notesPolicy??'EMPTY',
    notes:input.notesPolicy==='REQUESTED'?(input.page.notes??''):''});
}
function preflight(input) {
  const {page,mode}=input;
  if (!page?.id || !Array.isArray(page.texts) || page.texts.some(t=>typeof t!=='string') || !Array.isArray(page.slots)) throw new Error('Missing page plan');
  if (!['EDITABLE','IMAGE'].includes(mode)) throw new Error('Unknown output mode');
  if (mode==='EDITABLE' && (!Array.isArray(page.textBoxes) || page.textBoxes.length!==page.texts.length)) throw new Error('Text plan is incomplete');
  if (new Set(page.slots.map(s=>s.id)).size!==page.slots.length || page.slots.some(s=>!s.id)) throw new Error('Duplicate or missing image slots');
  if (mode==='IMAGE' && page.slots.length!==1) throw new Error('Image mode requires one full-page slot');
  if (mode==='EDITABLE') {
    for (const box of page.textBoxes) {validateFrame(box?.position);if (!Number.isFinite(box.size)||box.size<=0) throw new Error('Invalid text size');}
    for (const slot of page.slots) validateFrame(slot.position);
  }
  for (const config of page.decorations??[]) {if (config.text) throw new Error('Visible text must be included in the source text plan');validateFrame(config.position);}
}
// State belongs in the separate job ledger, never in speaker notes or alt text.
function readState(input) {
  return input.state ? structuredClone(input.state) : null;
}
function inspectImages(slide, state) {
  const actual=slide.toSnapshot().images.map(x=>x.aid).sort();
  const expected=Object.values(state.assets).map(x=>x.image_id).sort();
  if (JSON.stringify(actual)!==JSON.stringify(expected))
    throw new Error('Unreconciled images; read back the prior transaction and update the external ledger before writing');
}
function receipt(slide, state, reused) {
  return {page_id:state.page_id, slide_id:slide.toSnapshot().aid, elements:state.elements,
    bindings:Object.values(state.assets), pending_slots:state.slots.filter(id => !state.assets[id]), state:structuredClone(state), reused};
}
function exactPage(slide, state, page, mode) {
  const shapes = slide.toSnapshot().shapes;
  const texts = mode==='EDITABLE'?page.texts:[];
  return state?.page_id === page.id && state.mode === mode && JSON.stringify(state.texts) === JSON.stringify(texts) &&
    JSON.stringify(state.slots) === JSON.stringify(page.slots.map(x=>x.id)) &&
    shapes.length === texts.length+(page.decorations??[]).length &&
    state.elements.length === texts.length && state.elements.every((id, i) => {
      const actual=shapes.find(x=>x.aid===id);
      return actual?.text===texts[i] && equal(actual.frame??actual.position,page.textBoxes[i].position);
    });
}
export async function appendPage({presentation, input}) {
  preflight(input);
  const {page, index, mode, colors, expectedCount} = input;
  if (!page.id || !Array.isArray(page.texts) || !Array.isArray(page.slots)) throw new Error('Missing page plan');
  if (!['EDITABLE', 'IMAGE'].includes(mode)) throw new Error('Unknown output mode');
  if (mode === 'EDITABLE' && page.textBoxes.length !== page.texts.length) throw new Error('Text plan is incomplete');
  if (new Set(page.slots.map(x => x.id)).size !== page.slots.length) throw new Error('Duplicate image slots');
  const current = presentation.slides.items.length;
  // Reconcile an unknown response against the persisted page before creating anything.
  if (index < current) {
    const prior = presentation.slides.getItem(index);
    let saved = readState(input);
    // A text commit can be reconciled by its native object names after a lost receipt.
    if (!saved && mode === 'EDITABLE' && page.texts.length) {
      const q=prior.toSnapshot();
      const named=page.texts.map((_,i)=>q.shapes.filter(x=>x.name===page.id+'-source-text-'+i));
      if (named.every(xs=>xs.length===1)) saved={page_id:page.id,slide_id:q.aid,mode,texts:page.texts,
        elements:named.map(xs=>xs[0].aid),slots:page.slots.map(x=>x.id),assets:{}};
    }
    if (saved) {
      if (saved.slide_id !== prior.toSnapshot().aid || !exactPage(prior, saved, page, mode)) throw new Error('Existing page differs; inspect before writing');
      if (saved.layout && !equal(saved.layout,layout(input))) throw new Error('Existing layout differs; use reviseLayout for an authorized layout change');
      inspectImages(prior,saved);
      return receipt(prior, saved, true);
    }
  }
  if (current !== expectedCount) throw new Error('Document changed; inspect before a new write');
  let slide;
  if (index === 0 && current === 1) {
    slide = presentation.slides.getItem(0);
    const s = slide.toSnapshot();
    if (s.shapes.length || s.images.length || s.tables.length || s.charts.length) throw new Error('First page is not empty; preserve existing work');
  } else {
    if (index !== current) throw new Error('Do not skip or repeat a slide');
    slide = presentation.slides.add({width:1280,height:720});
  }
  slide.background.fill = colors.background;
  for (const config of page.decorations ?? []) {
    if (config.text) throw new Error('Visible text must be included in the source text plan');
    slide.shapes.add(config);
  }
  const elements = [];
  if (mode === 'EDITABLE') {
    for (let i=0;i<page.texts.length;i++) {
      const box = page.textBoxes[i];
      const shape = slide.shapes.add({geometry:'textbox',name:page.id+'-source-text-'+i,position:box.position,fill:box.fill??'none',line:{fill:'none',width:0}});
      shape.text = page.texts[i];
      shape.text.style = {fontSize:box.size,typeface:colors.font,color:box.color??(i===0?colors.title:colors.text),bold:box.bold??i===0,alignment:box.alignment??'left'};
      elements.push(shape.toSnapshot().aid);
    }
  }
  const state = {page_id:page.id, slide_id:slide.toSnapshot().aid, mode, texts:mode==='EDITABLE'?page.texts:[], elements, slots:page.slots.map(x=>x.id), assets:{},layout:layout(input)};
  // Generated pages have empty notes unless the user explicitly requested a script.
  if (input.notesPolicy === 'REQUESTED') slide.speakerNotes.text = page.notes ?? ''; 
  return receipt(slide,state,false);
}

// Exactly one already-generated PNG per call; any number of calls/slots per page.
export async function appendAsset({presentation, input}) {
  const {slideId, pageId, slot, asset} = input;
  if ((!asset?.path && !asset?.blob) || !asset.sha256) throw new Error('Missing actual generated asset');
  const slide = presentation.resolve(slideId), state = readState(input);
  if (!state || state.slide_id !== slideId || state.page_id !== pageId || !state.slots.includes(slot.id)) throw new Error('Image does not belong to this page plan');
  inspectImages(slide,state);
  const frame = state.mode==='IMAGE'?{left:0,top:0,width:1280,height:720}:slot.position;
  validateFrame(frame);
  if (state.layout && !equal(slot,state.layout.slots.find(s=>s.id===slot.id))) throw new Error('Image layout differs from the confirmed page plan');
  const prior = state.assets[slot.id];
  if (prior) {
    const found = slide.toSnapshot().images.find(x => x.aid === prior.image_id);
    if (!found || prior.sha256 !== asset.sha256) throw new Error('Image changed or missing; inspect before replacement');
    return {...prior, slide_id:slideId,state:structuredClone(state), reused:true};
  }
  const source = asset.blob ? {blob:asset.blob,contentType:'image/png'} : {path:asset.path};
  const image = slide.images.add({...source,fit:'contain',position:frame,alt:slot.alt});
  const record = {slot_id:slot.id,image_id:image.toSnapshot().aid,sha256:asset.sha256};
  state.assets[slot.id] = record;
  return {...record,slide_id:slideId,state:structuredClone(state),reused:false};
}

// Explicit reflow keeps native IDs and generated PNGs. It is never a replay of appendPage.
export async function reviseLayout({presentation,input}) {
  preflight(input);
  const state=readState(input), {page,mode,colors,revision}=input;
  if (!revision?.id || !revision.reason?.trim() || !state?.layout || state.page_id!==page.id || state.mode!==mode)
    throw new Error('Layout change requires a confirmed revision and reconciled page state');
  if (!equal(state.texts,mode==='EDITABLE'?page.texts:[]) || !equal(state.slots,page.slots.map(s=>s.id)) || !equal(state.layout.decorations,page.decorations??[]))
    throw new Error('Layout revision cannot alter source text, slots or decoration inventory');
  const slide=presentation.resolve(state.slide_id);
  const previous={...page,textBoxes:state.layout.textBoxes,decorations:state.layout.decorations};
  if (!exactPage(slide,state,previous,mode)) throw new Error('Native content or layout differs; reconcile user changes first');
  inspectImages(slide,state);
  const next=layout(input);
  if (equal(state.layout,next)) return receipt(slide,state,true);
  if (state.last_layout_revision===revision.id) throw new Error('Revision ID already used for a different layout');
  // Validate every dependency before making the first change.
  const shapes=state.elements.map(id=>presentation.resolve(id));
  const images=Object.entries(state.assets).map(([id,asset])=>({image:presentation.resolve(asset.image_id),slot:page.slots.find(s=>s.id===id)}));
  slide.background.fill=colors.background;
  for(let i=0;i<shapes.length;i++) {
    const box=page.textBoxes[i],shape=shapes[i];
    shape.position=box.position;
    shape.fill=box.fill??'none';
    shape.text.style={fontSize:box.size,typeface:colors.font,color:box.color??(i===0?colors.title:colors.text),bold:box.bold??i===0,alignment:box.alignment??'left'};
  }
  for(const {image,slot} of images) image.position=mode==='IMAGE'?{left:0,top:0,width:1280,height:720}:slot.position;
  if(input.notesPolicy==='REQUESTED') slide.speakerNotes.text=page.notes??'';
  state.layout=next; state.last_layout_revision=revision.id;
  return receipt(slide,state,false);
}
