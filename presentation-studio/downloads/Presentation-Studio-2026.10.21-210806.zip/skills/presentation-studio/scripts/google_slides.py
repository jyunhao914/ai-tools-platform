"""Compile a layout plan into native Google Slides requests, without API credentials.

Send output through the connected Drive batch_update_presentation tool. Coordinates
use the same 1280x720 design space as native.mjs. No file rendering is performed.
"""
import hashlib
import math
import re
from pathlib import Path


def check_asset(asset):
    """Validate actual upload bytes, not a caller-supplied checksum alone."""
    if not asset.get('path') or not re.fullmatch('[0-9a-f]{64}', asset.get('sha256', '')):
        raise ValueError('Actual image and SHA256 required')
    if hashlib.sha256(Path(asset['path']).read_bytes()).hexdigest() != asset['sha256']:
        raise ValueError('Upload bytes differ from selected asset')


def rgb(value):
    if not re.fullmatch(r'#[0-9a-fA-F]{6}', value):
        raise ValueError('Expected an RGB hex color')
    return dict(zip(('red', 'green', 'blue'), (int(value[i:i+2], 16)/255 for i in (1, 3, 5))))


def compile_page(page, *, job_id, mode, colors, assets, width_pt=720, height_pt=405):
    if mode not in {'EDITABLE', 'IMAGE'}:
        raise ValueError('Unknown output mode')
    if not math.isclose(width_pt / height_pt, 16/9, rel_tol=1e-5):
        raise ValueError('This layout requires a 16:9 destination')
    scale = width_pt / 1280
    prefix = 'ps_' + hashlib.sha256((job_id + ':' + page['id']).encode()).hexdigest()[:20]
    slide_id = prefix + '_slide'
    requests = [{'createSlide': {'objectId': slide_id, 'slideLayoutReference': {'predefinedLayout': 'BLANK'}}},
                {'updatePageProperties': {'objectId': slide_id, 'pageProperties': {'pageBackgroundFill': {'solidFill': {'color': {'rgbColor': rgb(colors['background'])}, 'alpha': 1}}}, 'fields': 'pageBackgroundFill'}}]
    bindings = []
    image_paths = []
    text_bindings = []
    table_bindings = []

    def props(frame):
        if any(not isinstance(frame.get(k), (int, float)) or not math.isfinite(frame[k]) for k in ('left', 'top', 'width', 'height')):
            raise ValueError('Invalid frame')
        if frame['width'] <= 0 or frame['height'] <= 0 or frame['left'] < 0 or frame['top'] < 0 or frame['left'] + frame['width'] > 1280 or frame['top'] + frame['height'] > 720:
            raise ValueError('Element outside slide')
        return {'pageObjectId': slide_id, 'size': {'width': {'magnitude': frame['width']*scale, 'unit': 'PT'}, 'height': {'magnitude': frame['height']*scale, 'unit': 'PT'}},
                'transform': {'scaleX': 1, 'scaleY': 1, 'translateX': frame['left']*scale, 'translateY': frame['top']*scale, 'unit': 'PT'}}

    if mode == 'EDITABLE':
        if len(page['texts']) != len(page['textBoxes']):
            raise ValueError('Incomplete text layout')
        table_indices = set()
        for table in page.get('tables', []):
            rows = table['text_indices']
            if table.get('merges'):
                raise ValueError('Merged tables require an explicit native merge plan; do not flatten or discard cells')
            if not rows or not rows[0] or any(len(row) != len(rows[0]) for row in rows):
                raise ValueError('Table grid must be rectangular')
            for row in rows:
                for index in row:
                    if type(index) is not int or not 0 <= index < len(page['texts']) or index in table_indices:
                        raise ValueError('Invalid or duplicated table text index')
                    table_indices.add(index)
        for i, (value, box) in enumerate(zip(page['texts'], page['textBoxes'])):
            if i in table_indices:
                if box is not None:
                    raise ValueError('Table cell must not also be rendered as a text box')
                continue
            if box is None:
                raise ValueError('Text has neither a table cell nor a text box')
            object_id = prefix + '_text_' + str(i)
            text_bindings.append({'text_index': i, 'object_id': object_id})
            requests.extend([
                {'createShape': {'objectId': object_id, 'shapeType': 'TEXT_BOX', 'elementProperties': props(box['position'])}},
                {'insertText': {'objectId': object_id, 'text': value, 'insertionIndex': 0}},
                {'updateTextStyle': {'objectId': object_id, 'textRange': {'type': 'ALL'}, 'style': {'fontFamily': colors.get('google_font', 'Noto Sans TC'), 'fontSize': {'magnitude': box['size']*scale, 'unit': 'PT'}, 'foregroundColor': {'opaqueColor': {'rgbColor': rgb(box.get('color', colors['title'] if i == 0 else colors['text']))}}, 'bold': box.get('bold', i == 0)}, 'fields': 'fontFamily,fontSize,foregroundColor,bold'}}])
            if box.get('alignment'):
                alignments={'left':'START','start':'START','center':'CENTER','right':'END','end':'END','justify':'JUSTIFIED','justified':'JUSTIFIED'}
                alignment=alignments.get(box['alignment'].lower())
                if alignment is None:
                    raise ValueError('Unsupported text alignment')
                requests.append({'updateParagraphStyle': {'objectId':object_id,'textRange':{'type':'ALL'},'style':{'alignment':alignment},'fields':'alignment'}})
            if box.get('fill') and box['fill']!='none':
                requests.append({'updateShapeProperties':{'objectId':object_id,'shapeProperties':{'shapeBackgroundFill':{'solidFill':{'color':{'rgbColor':rgb(box['fill'])},'alpha':1}}},'fields':'shapeBackgroundFill'}})
        for number, table in enumerate(page.get('tables', [])):
            object_id = prefix + '_table_' + str(number)
            rows = table['text_indices']
            requests.append({'createTable': {'objectId': object_id, 'rows': len(rows), 'columns': len(rows[0]), 'elementProperties': props(table['position'])}})
            table_bindings.append({'object_id': object_id, 'text_indices': rows})
            for ri, row in enumerate(rows):
                header = ri < table.get('header_rows', 1)
                fill = colors.get('table_header', colors['title']) if header else colors.get('table_body', colors['background'])
                requests.append({'updateTableCellProperties': {'objectId': object_id,
                    'tableRange': {'location': {'rowIndex': ri, 'columnIndex': 0}, 'rowSpan': 1, 'columnSpan': len(row)},
                    'tableCellProperties': {'tableCellBackgroundFill': {'solidFill': {'color': {'rgbColor': rgb(fill)}, 'alpha': 1}}}, 'fields': 'tableCellBackgroundFill'}})
                for ci, index in enumerate(row):
                    location = {'rowIndex': ri, 'columnIndex': ci}
                    text_bindings.append({'text_index': index, 'object_id': object_id, 'cell_location': location})
                    if not page['texts'][index]:
                        # Google rejects updateTextStyle on an empty table cell.
                        # Keep it genuinely empty instead of inserting a space.
                        continue
                    requests.append({'insertText': {'objectId': object_id, 'cellLocation': location, 'text': page['texts'][index], 'insertionIndex': 0}})
                    requests.append({'updateTextStyle': {'objectId': object_id, 'cellLocation': location, 'textRange': {'type': 'ALL'},
                        'style': {'fontFamily': colors.get('google_font', 'Noto Sans TC'), 'fontSize': {'magnitude': table.get('size', 24)*scale, 'unit': 'PT'},
                                  'foregroundColor': {'opaqueColor': {'rgbColor': rgb(colors.get('table_header_text', '#FFFFFF') if header else colors['text'])}}, 'bold': header},
                        'fields': 'fontFamily,fontSize,foregroundColor,bold'}})
    if mode == 'IMAGE' and len(page['slots']) != 1:
        raise ValueError('Image mode requires one full-page asset')
    for i, slot in enumerate(page['slots']):
        asset = assets[slot['id']]
        check_asset(asset)
        object_id = prefix + '_image_' + str(i)
        frame = {'left': 0, 'top': 0, 'width': 1280, 'height': 720} if mode == 'IMAGE' else slot['position']
        # Google fits the intrinsic image ratio into this box without distortion.
        requests.append({'createImage': {'objectId': object_id, 'url': asset['path'], 'elementProperties': props(frame)}})
        requests.append({'updatePageElementAltText': {'objectId': object_id, 'title': slot.get('alt', ''), 'description': 'asset-sha256:' + asset['sha256']}})
        image_paths.append(asset['path'])
        bindings.append({'slot_id': slot['id'], 'image_id': object_id, 'sha256': asset['sha256']})
    return {'slide_id': slide_id, 'requests': requests, 'image_paths': image_paths, 'bindings': bindings,
            'text_bindings': text_bindings, 'table_bindings': table_bindings}


def recover(observed_slide_ids, planned_slide_id):
    """A timeout requires readback, never a blind retry with new object IDs."""
    return 'INSPECT_CONTENT' if planned_slide_id in observed_slide_ids else 'NOT_FOUND'


def tool_batches(compiled):
    """The current connector accepts ONE actual path in image_uris per call."""
    batches, pending, path = [], [], None
    for request in compiled['requests']:
        image_request = request.get('createImage') or request.get('replaceImage')
        if image_request:
            if path is not None:
                batches.append({'requests': pending, 'image_uris': path})
                pending = []
            path = image_request['url']
        pending.append(request)
    if pending:
        batch = {'requests': pending}
        if path is not None:
            batch['image_uris'] = path
        batches.append(batch)
    return batches


def replace_asset(binding, asset, observed_slide, *, alt=''):
    """Compile a version change using fresh readback and stable object IDs.

    Caller sends the result with the same readback's requiredRevisionId, then
    verifies again before binding the ledger. A timeout is not a new request.
    """
    check_asset(asset)
    if observed_slide['objectId'] != binding['slide_id']:
        raise ValueError('Replacement targets the wrong slide')
    image = next((e for e in observed_slide.get('pageElements', []) if e['objectId'] == binding['image_id']), None)
    if image is None or 'image' not in image:
        raise ValueError('Image no longer exists; inspect user changes')
    old = 'asset-sha256:' + binding['sha256']
    new = 'asset-sha256:' + asset['sha256']
    actual = image.get('description')
    if actual not in {old, new}:
        raise ValueError('Image changed since last binding; reconcile before replacement')
    updated = dict(binding, sha256=asset['sha256'])
    if actual == new:
        return {'requests': [], 'bindings': [updated], 'readback_required': True}
    return {'requests': [
        {'replaceImage': {'imageObjectId': binding['image_id'], 'url': asset['path'], 'imageReplaceMethod': 'CENTER_INSIDE'}},
        {'updatePageElementAltText': {'objectId': binding['image_id'], 'title': alt, 'description': new}}
    ], 'bindings': [updated], 'readback_required': True}


def verify_page(page, compiled, observed_slide, mode):
    """Verify the durable readback, not merely a successful mutation response."""
    if observed_slide['objectId'] != compiled['slide_id']:
        raise ValueError('Wrong destination slide')
    elements = observed_slide.get('pageElements', [])
    if 'text_bindings' in compiled:
        return _verify_bound_page(page, compiled, elements, mode)
    texts = []
    for element in elements:
        if 'shape' in element:
            raw = ''.join(t.get('textRun', {}).get('content', '') for t in element['shape'].get('text', {}).get('textElements', []))
            # Slides appends one structural newline to every native text box.
            texts.append(raw[:-1] if raw.endswith('\n') else raw)
    if texts != (page['texts'] if mode == 'EDITABLE' else []):
        raise ValueError('Native text content differs from the confirmed plan')
    images = {e['objectId']: e for e in elements if 'image' in e}
    if set(images) != {b['image_id'] for b in compiled['bindings']}:
        raise ValueError('Missing or unexpected image object')
    for binding in compiled['bindings']:
        if images[binding['image_id']].get('description') != 'asset-sha256:' + binding['sha256']:
            raise ValueError('Image binding metadata differs; inspect actual image bytes too')
    return {'slide_id': compiled['slide_id'], 'texts': texts, 'images': len(images)}


def _verify_bound_page(page, compiled, elements, mode):
    def content(text):
        raw = ''.join(t.get('textRun', {}).get('content', '') for t in text.get('textElements', []))
        return raw[:-1] if raw.endswith('\n') else raw
    by_id = {e['objectId']: e for e in elements}
    expected = {b['object_id'] for b in compiled['text_bindings']} | {b['image_id'] for b in compiled['bindings']}
    if set(by_id) != expected:
        raise ValueError('Missing or unexpected native object')
    texts = [None] * len(page['texts']) if mode == 'EDITABLE' else []
    for binding in compiled['text_bindings']:
        element = by_id[binding['object_id']]
        if 'cell_location' in binding:
            loc = binding['cell_location']
            row = element['table']['tableRows'][loc['rowIndex']]
            cell = next((c for c in row['tableCells'] if c.get('location', {}).get('columnIndex', 0) == loc['columnIndex']), None)
            if cell is None:
                raise ValueError('Missing native table cell')
            text = cell.get('text', {})
        else:
            text = element['shape'].get('text', {})
        texts[binding['text_index']] = content(text)
    if texts != (page['texts'] if mode == 'EDITABLE' else []):
        raise ValueError('Native text content differs from the confirmed plan')
    for table in compiled['table_bindings']:
        actual = by_id[table['object_id']]['table']
        if actual['rows'] != len(table['text_indices']) or actual['columns'] != len(table['text_indices'][0]):
            raise ValueError('Native table dimensions differ')
    for binding in compiled['bindings']:
        actual = by_id[binding['image_id']]
        if 'image' not in actual or actual.get('description') != 'asset-sha256:' + binding['sha256']:
            raise ValueError('Image binding metadata differs; inspect actual image bytes too')
    return {'slide_id': compiled['slide_id'], 'texts': texts, 'images': len(compiled['bindings']), 'tables': len(compiled['table_bindings'])}
