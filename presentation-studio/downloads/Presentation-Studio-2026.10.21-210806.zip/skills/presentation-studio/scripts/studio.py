"""Portable, stdlib-only content and asset ledger for a hosted skill sandbox.

The caller uploads job JSON and assets to Google Drive. This module does not
store credentials, call private platform endpoints, or require a local daemon.
"""
import argparse
import hashlib
import json
import posixpath
from pathlib import Path, PurePosixPath
import re
import struct
import zlib
import uuid
import zipfile
import xml.etree.ElementTree as ET

POLICIES = {'NONE', 'REUSE', 'REDRAW', 'GENERATE'}
OPERATIONS = {'PRESERVE', 'CONDENSE', 'EXPAND'}
NS = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}


def digest(value):
    if not isinstance(value, bytes):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(value).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + str(uuid.uuid4()))
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def outline(text):
    """Only standalone headings define pages; inline page citations remain text."""
    slides, current = [], None
    for line in text.splitlines():
        match = re.fullmatch(r'\s*#{0,6}\s*第\s*(\d+)\s*頁\s*[｜|:：]\s*(.+?)\s*', line)
        if match:
            current = {'id': str(uuid.uuid4()), 'label': match[1], 'texts': [match[2]], 'instructions': [], 'images': []}
            slides.append(current)
        elif line.strip():
            if current is None:
                raise ValueError('來源缺少獨立行的頁標題，先確認分頁，不默認頁數')
            value = re.sub(r'^\s*[-*]\s+', '', line)
            value = value.replace('**', '')
            if value.startswith('視覺建議：'):
                current['instructions'].append(value)
            else:
                current['texts'].append(value)
    if not slides:
        raise ValueError('沒有可確認的頁面')
    return slides


def paragraph_text(paragraph):
    # Soft line breaks are not a:t runs; joining only text nodes loses content structure.
    return ''.join('\n' if n.tag == '{' + NS['a'] + '}br' else (n.text or '')
                   for n in paragraph.iter() if n.tag in {'{' + NS['a'] + '}br', '{' + NS['a'] + '}t'})


def slide_text_and_tables(node):
    texts, cell_indices = [], {}

    def walk(n):
        if n.tag == '{' + NS['a'] + '}tc':
            cell_indices[id(n)] = len(texts)
            texts.append('\n'.join(paragraph_text(p) for p in n.findall('.//a:p', NS)))
        elif n.tag == '{' + NS['p'] + '}txBody':
            value = '\n'.join(paragraph_text(p) for p in n.findall('a:p', NS))
            if value:
                texts.append(value)
        elif n.tag == '{' + NS['a'] + '}p':
            value = paragraph_text(n)
            if value:
                texts.append(value)
        else:
            for child in n:
                walk(child)
    walk(node)
    tables = []
    for table in node.findall('.//a:tbl', NS):
        rows, merges = [], []
        for ri, row in enumerate(table.findall('a:tr', NS)):
            cells = row.findall('a:tc', NS)
            rows.append([cell_indices[id(c)] for c in cells])
            for ci, cell in enumerate(cells):
                attrs = {k: cell.attrib[k] for k in ('gridSpan', 'rowSpan', 'hMerge', 'vMerge') if k in cell.attrib}
                if attrs:
                    merges.append({'row': ri, 'column': ci, **attrs})
        tables.append({'text_indices': rows, 'merges': merges,
                       'column_widths_emu': [int(c.attrib['w']) for c in table.findall('a:tblGrid/a:gridCol', NS)]})
    return texts, tables


def pptx(path):
    """Keep exact text runs per paragraph, table cell order and source images."""
    slides = []
    with zipfile.ZipFile(path) as archive:
        presentation = ET.fromstring(archive.read('ppt/presentation.xml'))
        rels = ET.fromstring(archive.read('ppt/_rels/presentation.xml.rels'))
        relationships = {r.attrib['Id']: r.attrib['Target'] for r in rels}
        for index, item in enumerate(presentation.findall('p:sldIdLst/p:sldId', NS), 1):
            target = relationships[item.attrib['{' + NS['r'] + '}id']]
            name = target.lstrip('/') if target.startswith('/') else posixpath.normpath('ppt/' + target)
            node = ET.fromstring(archive.read(name))
            texts, tables = slide_text_and_tables(node)
            images = []
            relpath = str(PurePosixPath(name).parent / '_rels' / (PurePosixPath(name).name + '.rels'))
            if relpath in archive.namelist():
                mappings = {r.attrib['Id']: r.attrib for r in ET.fromstring(archive.read(relpath))}
                for pic in node.findall('.//p:pic', NS):
                    blip = pic.find('.//a:blip', NS)
                    key = None if blip is None else blip.attrib.get('{' + NS['r'] + '}embed')
                    rel = mappings.get(key, {})
                    image = {'relationship_id': key, 'target': rel.get('Target'), 'external': rel.get('TargetMode') == 'External'}
                    if image['target'] and not image['external']:
                        part = image['target'].lstrip('/') if image['target'].startswith('/') else posixpath.normpath(posixpath.dirname(name) + '/' + image['target'])
                        image.update(source_part=part, sha256=digest(archive.read(part)))
                    images.append(image)
            slides.append({'id': str(uuid.uuid4()), 'label': str(index), 'texts': texts, 'images': images, 'tables': tables, 'source_part': name})
    return slides


def new_job(slides, mode, policy, style, operation='PRESERVE', target_pages=None):
    if not isinstance(style, dict) or not style.get('selection') or not style.get('user_choice'):
        raise ValueError('請先取得風格選擇，並保存 selection 與使用者原話 user_choice；未選不能默認自動')
    if re.fullmatch(r'M\d+', str(style['selection']).upper()) or str(style['selection']).upper() in {'SM', 'MY', 'MY_STYLES', '我的風格', '我的風格庫'}:
        raise ValueError('我的風格庫只是入口，請先列出預覽並選擇個別風格')
    if str(style['selection']).upper() == 'PERSONAL':
        if not all(style.get(key) for key in ('style_id', 'folder_id', 'profile', 'preview_sha256', 'catalog_snapshot')):
            raise ValueError('個人風格未完整讀取與選定；請使用 style_library.select')
    if mode not in {'EDITABLE', 'IMAGE'} or policy not in POLICIES or operation not in OPERATIONS:
        raise ValueError('Invalid mode, image policy or operation')
    if operation != 'PRESERVE' and (type(target_pages) is not int or target_pages < 1):
        raise ValueError('縮減／擴增必須先確認目標頁數')
    if not slides or any(not s.get('id') or not isinstance(s.get('texts'), list) for s in slides):
        raise ValueError('逐頁來源不完整')
    if len({s['id'] for s in slides}) != len(slides):
        raise ValueError('Duplicate source slide IDs')
    return {'schema_version': 1, 'id': str(uuid.uuid4()), 'mode': mode, 'policy': policy,
            'operation': operation, 'target_pages': target_pages, 'style': style,
            'source': slides, 'source_hash': digest(slides), 'plan': [], 'requests': {},
            'bindings': {}, 'status': 'PLANNING', 'cloud': {'provider': 'google-drive'}}


def series_requirements(slides):
    """Extract explicit arrow sequences and caller-identified visual series.

    General bullets are not automatically illustrations. Non-arrow comparisons
    and steps can be recorded in source.visual_series after reading the source.
    """
    groups = []
    for source in slides:
        candidates = list(source.get('visual_series', []))
        for text in source['texts']:
            if '→' not in text:
                continue
            value = re.split(r'[:：]', text, maxsplit=1)[-1].strip()
            members = [v.strip() for v in value.split('→')]
            if len(members) >= 2 and all(members):
                candidates.append({'kind': 'sequence', 'members': members})
        seen = set()
        for item in candidates:
            members = item.get('members', [])
            if len(members) < 2 or any(not isinstance(x, str) or not x.strip() for x in members):
                raise ValueError('系列圖必須包含至少兩個明確項目')
            key = tuple(members)
            if key in seen:
                continue
            seen.add(key)
            groups.append({'id': source['id'] + '-series-' + str(len(seen)),
                           'source_id': source['id'], 'kind': item.get('kind', 'sequence'), 'members': members})
    return groups


def validate_series(job, page):
    if job['mode'] != 'EDITABLE' or job['policy'] != 'GENERATE':
        return
    # Preserve mode retains the source's actual series; rewritten jobs use their
    # approved page text/visual_series, not a sequence that may have been removed.
    sources = ([s for s in job['source'] if s['id'] in page['source_ids']]
               if job['operation'] == 'PRESERVE' else [page])
    required = series_requirements(sources)
    mappings = page.get('series_bindings', [])
    slots = {s['id']: s for s in page['slots']}
    used = set()
    for group in required:
        matches = [m for m in mappings if m.get('members') == group['members']]
        if len(matches) != 1:
            raise ValueError('系列圖缺少逐項配圖計畫，不能以流程框或單張圖片代替')
        ids = matches[0].get('slot_ids', [])
        if len(ids) != len(group['members']) or len(set(ids)) != len(ids):
            raise ValueError('系列圖每個項目必須有不同的獨立圖片實例')
        if any(s not in slots or slots[s]['action'] != 'GENERATE' or s in used for s in ids):
            raise ValueError('系列圖實例缺少、重複或不符合生成配圖政策')
        used.update(ids)


def plan(job, pages):
    if digest(job['source']) != job['source_hash']:
        raise ValueError('來源已變動，請建立新 job')
    if job['operation'] == 'PRESERVE':
        if len(pages) != len(job['source']):
            raise ValueError('保留模式不允許增減頁面')
        for source, page in zip(job['source'], pages):
            if page['source_ids'] != [source['id']] or page['texts'] != source['texts']:
                raise ValueError('保留模式不得增減、改寫或跨頁挪移文字')
    elif len(pages) != job['target_pages']:
        raise ValueError('修訂頁數與使用者確認不符')
    source_ids = {s['id'] for s in job['source']}
    ids = set()
    for page in pages:
        if page['id'] in ids or not set(page['source_ids']) <= source_ids:
            raise ValueError('計畫頁 ID 重複或來源對應錯誤')
        ids.add(page['id'])
        if len({s['id'] for s in page['slots']}) != len(page['slots']):
            raise ValueError('同頁圖片實例 ID 不得重複')
        if job['mode'] == 'IMAGE' and len(page['slots']) != 1:
            raise ValueError('圖像式每頁須有一個整頁生成實例')
        if job['mode'] == 'EDITABLE' and job['policy'] == 'NONE' and page['slots']:
            raise ValueError('不用圖片不得新增一般配圖')
        for slot in page['slots']:
            if slot.get('action') not in {'GENERATE', 'REUSE', 'REDRAW'}:
                raise ValueError('圖片實例處理方式不完整')
            if slot['action'] == 'REUSE' and not slot.get('source_asset'):
                raise ValueError('沿用圖片必須指定原資產')
            if job['policy'] == 'REUSE' and job['mode'] == 'EDITABLE' and slot['action'] != 'REUSE':
                raise ValueError('直接沿用原圖不得生成新配圖')
        validate_series(job, page)
    job['plan'] = pages
    job['plan_hash'] = digest(pages)
    job['status'] = 'PRODUCING'
    return job


def dispatch(job, page_id, slot_id, prompt, revision=None, retry_of=None):
    if digest(job['plan']) != job['plan_hash']:
        raise ValueError('計畫已修改，必須重新確認後保存')
    page = next(p for p in job['plan'] if p['id'] == page_id)
    slot = next(s for s in page['slots'] if s['id'] == slot_id)
    if slot['action'] == 'REUSE':
        raise ValueError('沿用原圖不應呼叫 ImageGen')
    previous = [r for r in job['requests'].values() if r['page_id'] == page_id and r['slot_id'] == slot_id]
    if any(r['status'] == 'DISPATCHED' for r in previous):
        raise ValueError('同一實例仍有未知結果，先恢復，不可換提示詞重送')
    if revision is not None and (not revision.get('id') or not revision.get('reason', '').strip()):
        raise ValueError('修改須有已保存的使用者修改請求 ID 與原因')
    if retry_of:
        old = job['requests'].get(retry_of, {})
        if old not in previous or old.get('status') != 'REFUSED' or old.get('retry_of') or old.get('safe_retry_id'):
            raise ValueError('合規調整必須對應實際拒絕且不可重複')
    elif previous and previous[-1]['status'] == 'REFUSED':
        raise ValueError('拒絕後必須走 safe_retry 或局部素材組版，不能換提示詞直接重送')
    if any(r['status'] == 'READY' for r in previous) and revision is None and not retry_of:
        raise ValueError('已有可用圖片；只有明確修改請求才建立新版本')
    identity = {'job': job['id'], 'page': page_id, 'slot': slot_id, 'prompt': prompt}
    if revision is not None:
        identity['revision_id'] = revision['id']
    key = digest(identity)
    if key in job['requests']:
        raise ValueError('已有相同請求，先恢復結果或查看錯誤，不重複生圖')
    job['requests'][key] = {'id': key, 'page_id': page_id, 'slot_id': slot_id, 'prompt': prompt,
                            'status': 'DISPATCHED', 'versions': []}
    if revision is not None:
        job['requests'][key]['revision'] = revision
    job['status'] = 'PRODUCING'
    return key


def register(job, request_id, file_path, drive_file_id=None, library_reference=None):
    request = job['requests'][request_id]
    if request['status'] != 'DISPATCHED':
        raise ValueError('只有待回傳的生成請求可以登記；拒絕或已結案不能冒充成功')
    data = Path(file_path).read_bytes()
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('生成結果必須是真正 PNG')
    # Inspect all chunk boundaries and CRCs before registering a durable success.
    offset, kinds = 8, []
    while offset < len(data):
        if len(data)-offset < 12:
            raise ValueError('生成 PNG 不完整')
        length=struct.unpack('>I',data[offset:offset+4])[0]
        end=offset+length+12
        if end>len(data):
            raise ValueError('生成 PNG 不完整')
        kind=data[offset+4:offset+8]
        if zlib.crc32(data[offset+4:end-4])&0xffffffff != struct.unpack('>I',data[end-4:end])[0]:
            raise ValueError('生成 PNG 校驗失敗')
        if not kinds and (kind!=b'IHDR' or length!=13):
            raise ValueError('生成 PNG 缺少標頭')
        kinds.append(kind); offset=end
        if kind==b'IEND':
            if length or offset!=len(data):
                raise ValueError('生成 PNG 結尾錯誤')
            break
    if not kinds or kinds[-1]!=b'IEND' or b'IDAT' not in kinds:
        raise ValueError('生成 PNG 不完整')
    sha = digest(data)
    if any(v['sha256'] == sha for v in request['versions']):
        raise ValueError('同一結果已登記，不重複保存')
    if not drive_file_id:
        raise ValueError('完全雲端模式須先上傳 Drive 取得持久 file ID')
    version = {'sha256': sha, 'drive_file_id': drive_file_id, 'library_reference': library_reference}
    request['versions'].append(version)
    request['selected'] = len(request['versions']) - 1
    request['status'] = 'READY'
    job.setdefault('selections', {})[request['page_id'] + ':' + request['slot_id']] = {'request_id': request_id, 'version': request['selected']}
    job['status'] = 'PRODUCING'
    return version


def register_reuse(job, page_id, slot_id, file_path, drive_file_id):
    """Retain original bytes without calling image generation."""
    if digest(job['plan']) != job['plan_hash']:
        raise ValueError('計畫已修改，必須先保存確認後的計畫')
    page = next(p for p in job['plan'] if p['id'] == page_id)
    slot = next(s for s in page['slots'] if s['id'] == slot_id)
    source = slot.get('source_asset', {})
    if slot['action'] != 'REUSE' or not isinstance(source, dict):
        raise ValueError('此實例未指定沿用原素材')
    source_page = next((p for p in job['source'] if p['id'] == source.get('source_id')), None)
    if not source_page or source_page['id'] not in page['source_ids']:
        raise ValueError('素材來源不屬於此頁對應來源')
    sha = digest(Path(file_path).read_bytes())
    if sha != source.get('sha256') or not any(a.get('sha256') == sha for a in source_page['images']):
        raise ValueError('沿用素材與原始來源不一致')
    if not drive_file_id:
        raise ValueError('沿用素材須保存持久 Drive ID')
    key = digest({'job': job['id'], 'page': page_id, 'slot': slot_id, 'source': sha})
    if key in job['requests']:
        return key
    job['requests'][key] = {'id': key, 'page_id': page_id, 'slot_id': slot_id, 'status': 'READY', 'kind': 'REUSE',
                            'selected': 0, 'versions': [{'sha256': sha, 'drive_file_id': drive_file_id, 'library_reference': None}]}
    job.setdefault('selections', {})[page_id + ':' + slot_id] = {'request_id': key, 'version': 0}
    job['status'] = 'PRODUCING'
    return key


def select_version(job, page_id, slot_id, request_id, version=0):
    request = job['requests'][request_id]
    if request['status'] != 'READY' or (request['page_id'], request['slot_id']) != (page_id, slot_id):
        raise ValueError('不能選擇其他頁或未完成圖片')
    if type(version) is not int or not 0 <= version < len(request['versions']):
        raise ValueError('找不到指定版本')
    request['selected'] = version
    job.setdefault('selections', {})[page_id + ':' + slot_id] = {'request_id': request_id, 'version': version}
    job['status'] = 'PRODUCING'


def bind(job, page_id, slot_id, request_id, slide_id, image_id):
    request = job['requests'][request_id]
    if request['page_id'] != page_id or request['slot_id'] != slot_id or request['status'] != 'READY':
        raise ValueError('資產跨頁、跨實例或尚未完成')
    selected = job.get('selections', {}).get(page_id + ':' + slot_id)
    if selected and selected != {'request_id': request_id, 'version': request['selected']}:
        raise ValueError('此圖片不是目前選定版本；指定舊版請先 select_version')
    job['bindings'][page_id + ':' + slot_id] = {'request_id': request_id, 'slide_id': slide_id, 'image_id': image_id,
                                               'asset': request['versions'][request['selected']]}


def refusal(job, request_id, evidence):
    if not evidence or not evidence.get('tool_call_id') or evidence.get('category') != 'safety_refusal':
        raise ValueError('只有實際安全拒絕可進入合規調整')
    request = job['requests'][request_id]
    if request['status'] != 'DISPATCHED':
        raise ValueError('此請求不可重複結案')
    request['status'] = 'REFUSED'
    request['error'] = evidence


def safe_retry(job, refused_id, revised_prompt, change_reason):
    request = job['requests'][refused_id]
    if request['status'] != 'REFUSED' or request.get('safe_retry_id') or request.get('retry_of'):
        raise ValueError('僅可一次實質合規調整')
    if not change_reason.strip() or revised_prompt == request['prompt']:
        raise ValueError('不得重送原遭拒內容')
    key = dispatch(job, request['page_id'], request['slot_id'], revised_prompt, retry_of=refused_id)
    request['safe_retry_id'] = key
    job['requests'][key]['retry_of'] = refused_id
    job['requests'][key]['change_reason'] = change_reason
    return key


def finish(job, observed_texts, page_ids, committed, visual_reviewed):
    if digest(job['source']) != job['source_hash'] or digest(job['plan']) != job['plan_hash']:
        raise ValueError('來源或計畫變動，必須重新核對確認，不能直接交付')
    if not committed or not visual_reviewed or len(page_ids) != len(job['plan']) or len(set(page_ids)) != len(page_ids):
        raise ValueError('尚未完成雲端保存、全部頁面或實際視覺驗收')
    if job['mode'] == 'EDITABLE' and observed_texts != [p['texts'] for p in job['plan']]:
        raise ValueError('原生文字讀回不一致')
    if any(r['status'] == 'DISPATCHED' for r in job['requests'].values()):
        raise ValueError('仍有未知結果的生成請求，不能交付舊版本')
    for index, page in enumerate(job['plan']):
        for slot in page['slots']:
            binding = job['bindings'].get(page['id'] + ':' + slot['id'])
            if not binding or binding['slide_id'] != page_ids[index]:
                raise ValueError('仍有未綁定圖片或錯頁')
            request = job['requests'][binding['request_id']]
            selected = job.get('selections', {}).get(page['id'] + ':' + slot['id'], {'request_id': request['id'], 'version': request['selected']})
            if binding['request_id'] != selected['request_id'] or binding['asset'] != job['requests'][selected['request_id']]['versions'][selected['version']]:
                raise ValueError('原生簡報仍綁定舊版本，必須更新圖片後再驗收')
    job['status'] = 'READY_FOR_EXPORT'
    return job


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    source = sub.add_parser('source')
    source.add_argument('input', type=Path)
    source.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.command == 'source':
        slides = pptx(args.input) if args.input.suffix.lower() == '.pptx' else outline(args.input.read_text())
        write_json(args.output, {'slides': slides, 'source_sha256': digest(args.input.read_bytes())})


if __name__ == '__main__':
    main()
