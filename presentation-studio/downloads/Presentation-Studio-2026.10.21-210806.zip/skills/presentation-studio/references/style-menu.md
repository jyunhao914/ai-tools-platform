# 表單內風格預覽

呼叫 `studio_open_intake`。15 款內建預覽已內嵌於 MCP App 的介面資源，不經主機資源代理、不外連網站，不用模型讀取、重畫或重新編碼內建圖片。

自動排第一；預設風格、我的風格庫、自訂風格同階。只顯示所選入口。內建與個人風格共用等寬縮圖格；預設收合，展開立即顯示，不用載入、翻頁或放大按鈕。

個人風格先完整讀回使用者自己的 Google Drive。依 `style_library.catalog → form_group` 產生真實九頁預覽，使用 `mcp_intake.arguments` 將選項轉為工具的 `personal_styles`，保留當次 `catalog_snapshot`。縮圖經工具私有 metadata 送至介面，不能上傳公開網站。缺檔、未連接、讀取錯誤不可偽稱空庫。
