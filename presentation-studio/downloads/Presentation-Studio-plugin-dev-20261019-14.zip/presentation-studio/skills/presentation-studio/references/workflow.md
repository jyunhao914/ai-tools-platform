# 選單、寫入恢復與交付

`scripts/workflow.py` 是標準 Python 輔助程式，可在平台託管沙箱執行，不需要使用者安裝。不會呼叫模型、改權限、生成圖片或自動宣稱成功。呼叫端根據真實工具回覆提供證據並執行它返回的下一步。

## 短選單

`intake(groups)` 或 `python workflow.py intake input.json` 產生每個選項獨立一行的選單。每組包含 title、options（id、label），已確認的項目填 selected，會自動省略。不要再把輸出改寫成斜線串接的長句。不使用橫向表格，避免窄側欄難閱讀。

只有大綱且形式未選時：

**製作形式**

- A．可編輯＋生成配圖
- B．可編輯、不用圖片
- C．整頁圖像式

**風格**

先顯示可開啟的縮圖總覽，再列以下每行一項：內建 01–15、自動、自訂、我的風格。只問尚缺設定；風格已選就不再顯示整份選單。缺頁內容、是否准許改字各自清楚說明，不把多項授權混在一個推薦選項。可以一次回覆「A、02、保留原文」。當前 host 有原生選項工具時可使用，但沒有就用此垂直文字格式，不假造可點擊按鈕。

## 外層保存錯誤

`Artifact Session viewer flush failed` 可能出現在工具回傳外層，不在 callback 的 try/catch 內。必須檢查完整工具結果的 isError／content；callback 返回 image ID 不代表已保存。不能只修改 callback 然後聲稱處理了外層同步失敗。

每筆寫入前 `begin_write(document_id, operation_id, expected, before)`：記下真實文件 ID、固定操作 ID、預期文字或已選 PNG 的 SHA256／slot，以及讀回的頁與物件基線。保存至 job.write_operations。失敗、讀回與重送都使用同一個操作紀錄，不能重設 attempts 或改 key。

工具失敗後，將 message、receipt_id（實際呼叫識別）、必要時 transaction_id，連同 document_id／operation_id 送入 `recover_write(state, evidence)`；CLI 可用 `python workflow.py recover recovery-input.json`。保存返回 state，依 phase 執行：

| phase | 下一步 |
| --- | --- |
| CHECK_TRANSACTION | 用原交易查狀態，pending／unknown 不寫入；先依工具指示解決交易。 |
| RECONNECT | 對同一 Page 重新連接，再讀回；不另建文件。 |
| READ_BACK | 查原文件的真實內容，確認操作已結束，核對當頁文字、image ID、PNG 與基線。 |
| RETRY_SAME_WRITE | 上一筆已結束、確定未保存且基線未變：將 dispatched 事件登記後，補寫同一頁或同一張已生成 PNG 一次。 |
| COMPLETE | 本筆操作已核對保存，更新 native state／binding，直接處理下一筆，不結束整份任務。 |
| CONFLICT | 內容不符或有人修改：核對差異，不覆蓋、不重插。 |
| INSPECT_ERROR | 未知錯誤先查其真實原因，不把它當成可重試錯誤。 |
| BLOCKED | 真正權限／額度拒絕，或同筆補寫後仍未保存：保留實際證據，說明阻塞。 |

readback 事件的 comparison 必須來自實際讀回：MATCH＝指定內容已保存；ABSENT＝仍與 before 相同；CONFLICT＝內容異動或不吻合。帶上相同 expected、receipt_id、settled:true；ABSENT 另提供 observed 基線。只有確認前一操作結束才能 settled:true。committed 交易卻讀不到內容是衝突，不重送。重新寫入即使再次報錯，也要讀回確認，避免已保存卻被誤判失敗。

此程序只處理寫入，不能以寫入失敗重新呼叫 ImageGen。一次讀回可恢復不能宣稱平台底層不再發生錯誤。

## 文件名稱與可開啟交付

封面的文字和文件名稱是不同欄位。新建 Google／Spaces 文件傳入主題名稱；已有空白名稱時，用平台支援的文件命名工具或 UI 命名，再讀回 metadata。`artifactSession.run` 的 title 選項只在建立時使用，對既有文件忽略，不能用它假裝改名。不得為改名重建 Page、換 ID 或改正文；沒有支援的命名介面就明說名稱尚未修復。

內容完成後，先 `studio.finish` 核對正文、頁序、圖片綁定。再實際開啟原生文件，檢查文件 title、完整頁數與圖像，最後取得 PPTX。`verify_delivery(document, pptx_path, expected_pages)` 核對真正 ZIP／投影片關聯及頁數，拒絕空名、未命名卡片、未開啟文件、缺失或不完整 PPTX。document 包含 id、title、url、pages、readback_receipt、opened、open_evidence；數值只能來自實際開啟與讀回。`VERIFIED_PACKAGE` 只表示包結構驗證，仍需實際逐頁視覺檢查與可編輯物件檢查。

若 Spaces 的直接下載失敗，按正式工具／UI 使用 Google Slides 匯出副本（有已授權的 Drive 才可執行）並下載 PPTX，保留原 Page 與對應 ID。這是匯出副本，不將原件改成另一份作業。若已明確指定只留在 Spaces，或不允許 Google，不能默默轉移。沒有可用匯出路徑要報告「未取得 PPTX」，不可把圖片資料夾或殘缺卡片當成完成。

交付需要明確名稱、能開啟的原生入口及實際 PPTX 附件／持久下載入口；工作紀錄資料夾不能取代這兩者。

`studio.finish` 完成後狀態為 READY_FOR_EXPORT。呼叫 `complete_delivery(job, document, pptx_path)` 或 CLI `complete input.json`，由程式實際檢查下載並拒絕未結束的寫入，再保存返回的 DELIVERED job。舊版 DELIVERABLE 需重新 finish，不直接升級為已交付。
