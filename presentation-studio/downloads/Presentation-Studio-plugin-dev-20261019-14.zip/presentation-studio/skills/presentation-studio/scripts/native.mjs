// Portable callbacks: one text page OR one PNG per durable tool call.
// Call with timeout_ms: 60000. Never loop over image writes inside one tool call.
export const NATIVE_WRITE_TIMEOUT_MS = 60000;
// State belongs in the separate job ledger, never in speaker notes or alt text.
function readState(input) {
  return input.state ? structuredClone(input.state) : null;
}
function inspectImages(slide, state) {
  const actual=slide.toSnapshot().images.map(x=>x.aid).sort();
  const expected=Object.values(state.assets).map(x=>x.image_id).sort();
  if (JSON.stringify(actual)!==JSON.stringify(expected))
    throw new Error('Unreconciled images; read back the prior transaction and update the external ledger before writing');
}
function receipt(slide, state, reused) {
  return {page_id:state.page_id, slide_id:slide.toSnapshot().aid, elements:state.elements,
    bindings:Object.values(state.assets), pending_slots:state.slots.filter(id => !state.assets[id]), state:structuredClone(state), reused};
}
function exactPage(slide, state, page, mode) {
  const shapes = slide.toSnapshot().shapes;
  const texts = mode==='EDITABLE'?page.texts:[];
  return state?.page_id === page.id && state.mode === mode && JSON.stringify(state.texts) === JSON.stringify(texts) &&
    JSON.stringify(state.slots) === JSON.stringify(page.slots.map(x=>x.id)) &&
    state.elements.length === texts.length && state.elements.every((id, i) => shapes.find(x => x.aid === id)?.text === texts[i]);
}
export async function appendPage({presentation, input}) {
  const {page, index, mode, colors, expectedCount} = input;
  if (!page.id || !Array.isArray(page.texts) || !Array.isArray(page.slots)) throw new Error('Missing page plan');
  if (!['EDITABLE', 'IMAGE'].includes(mode)) throw new Error('Unknown output mode');
  if (mode === 'EDITABLE' && page.textBoxes.length !== page.texts.length) throw new Error('Text plan is incomplete');
  if (new Set(page.slots.map(x => x.id)).size !== page.slots.length) throw new Error('Duplicate image slots');
  const current = presentation.slides.items.length;
  // Reconcile an unknown response against the persisted page before creating anything.
  if (index < current) {
    const prior = presentation.slides.getItem(index);
    let saved = readState(input);
    // A text commit can be reconciled by its native object names after a lost receipt.
    if (!saved && mode === 'EDITABLE' && page.texts.length) {
      const q=prior.toSnapshot();
      const named=page.texts.map((_,i)=>q.shapes.filter(x=>x.name===page.id+'-source-text-'+i));
      if (named.every(xs=>xs.length===1)) saved={page_id:page.id,slide_id:q.aid,mode,texts:page.texts,
        elements:named.map(xs=>xs[0].aid),slots:page.slots.map(x=>x.id),assets:{}};
    }
    if (saved) {
      if (saved.slide_id !== prior.toSnapshot().aid || !exactPage(prior, saved, page, mode)) throw new Error('Existing page differs; inspect before writing');
      inspectImages(prior,saved);
      return receipt(prior, saved, true);
    }
  }
  if (current !== expectedCount) throw new Error('Document changed; inspect before a new write');
  let slide;
  if (index === 0 && current === 1) {
    slide = presentation.slides.getItem(0);
    const s = slide.toSnapshot();
    if (s.shapes.length || s.images.length || s.tables.length || s.charts.length) throw new Error('First page is not empty; preserve existing work');
  } else {
    if (index !== current) throw new Error('Do not skip or repeat a slide');
    slide = presentation.slides.add({width:1280,height:720});
  }
  slide.background.fill = colors.background;
  for (const config of page.decorations ?? []) {
    if (config.text) throw new Error('Visible text must be included in the source text plan');
    slide.shapes.add(config);
  }
  const elements = [];
  if (mode === 'EDITABLE') {
    for (let i=0;i<page.texts.length;i++) {
      const box = page.textBoxes[i];
      const shape = slide.shapes.add({geometry:'textbox',name:page.id+'-source-text-'+i,position:box.position,fill:box.fill??'none',line:{fill:'none',width:0}});
      shape.text = page.texts[i];
      shape.text.style = {fontSize:box.size,typeface:colors.font,color:box.color??(i===0?colors.title:colors.text),bold:box.bold??i===0,...(box.alignment?{alignment:box.alignment}:{})};
      elements.push(shape.toSnapshot().aid);
    }
  }
  const state = {page_id:page.id, slide_id:slide.toSnapshot().aid, mode, texts:mode==='EDITABLE'?page.texts:[], elements, slots:page.slots.map(x=>x.id), assets:{}};
  // Generated pages have empty notes unless the user explicitly requested a script.
  if (input.notesPolicy === 'REQUESTED') slide.speakerNotes.text = page.notes ?? ''; 
  return receipt(slide,state,false);
}

// Exactly one already-generated PNG per call; any number of calls/slots per page.
export async function appendAsset({presentation, input}) {
  const {slideId, pageId, slot, asset} = input;
  if ((!asset?.path && !asset?.blob) || !asset.sha256) throw new Error('Missing actual generated asset');
  const slide = presentation.resolve(slideId), state = readState(input);
  if (!state || state.slide_id !== slideId || state.page_id !== pageId || !state.slots.includes(slot.id)) throw new Error('Image does not belong to this page plan');
  inspectImages(slide,state);
  const prior = state.assets[slot.id];
  if (prior) {
    const found = slide.toSnapshot().images.find(x => x.aid === prior.image_id);
    if (!found || prior.sha256 !== asset.sha256) throw new Error('Image changed or missing; inspect before replacement');
    return {...prior, slide_id:slideId,state:structuredClone(state), reused:true};
  }
  const source = asset.blob ? {blob:asset.blob,contentType:'image/png'} : {path:asset.path};
  const frame = state.mode==='IMAGE'?{left:0,top:0,width:1280,height:720}:slot.position;
  const image = slide.images.add({...source,fit:'contain',position:frame,alt:slot.alt});
  const record = {slot_id:slot.id,image_id:image.toSnapshot().aid,sha256:asset.sha256};
  state.assets[slot.id] = record;
  return {...record,slide_id:slideId,state:structuredClone(state),reused:false};
}
