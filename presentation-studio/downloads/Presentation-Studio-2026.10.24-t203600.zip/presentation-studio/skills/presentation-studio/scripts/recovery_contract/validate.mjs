import fs from 'node:fs';
import {validateWorkflowConfig} from './lib/config-validator.mjs';
import {WORKFLOW_VERSION} from './canonical/version.mjs';

try {
  const {config, previews} = JSON.parse(fs.readFileSync(0, 'utf8'));
  if (config?.version !== WORKFLOW_VERSION) throw Error('Canonical form version mismatch');
  validateWorkflowConfig(config, previews);
  process.stdout.write(JSON.stringify({valid: true, version: WORKFLOW_VERSION}));
} catch (error) {
  process.stderr.write(error.message + '\n');
  process.exitCode = 1;
}
