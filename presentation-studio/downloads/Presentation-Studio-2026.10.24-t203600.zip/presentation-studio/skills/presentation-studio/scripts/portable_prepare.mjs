// Private portable route: reuse the unchanged service canonical contract.
// This prepares a form, never a submission, receipt, or production action.
import fs from 'node:fs';

const DIAGNOSTICS = Object.freeze({
  PORTABLE_INPUT_INVALID: 64,
  PORTABLE_MODULE_LOAD_FAILED: 65,
  PORTABLE_INPUT_READ_FAILED: 66,
  PORTABLE_NODE_FAILED: 70,
});

function fail(code) {
  // Fixed codes only: never echo source text, previews, property names or exceptions.
  const safeCode = Object.prototype.hasOwnProperty.call(DIAGNOSTICS, code) ? code : 'PORTABLE_NODE_FAILED';
  process.stdout.write(JSON.stringify({error: safeCode}) + '\n');
  process.stderr.write(safeCode + '\n');
  process.exitCode = DIAGNOSTICS[safeCode];
}

async function main() {
  let prepareWorkflow, validateWorkflowConfig;
  try {
    // Catch missing files, unsupported module syntax and module initialization errors
    // separately from data validation; the canonical modules themselves are unchanged.
    ({prepareWorkflow} = await import('./recovery_contract/lib/workflow-config.mjs'));
    ({validateWorkflowConfig} = await import('./recovery_contract/lib/config-validator.mjs'));
    if (typeof prepareWorkflow !== 'function' || typeof validateWorkflowConfig !== 'function') {
      fail('PORTABLE_MODULE_LOAD_FAILED');
      return;
    }
  } catch {
    fail('PORTABLE_MODULE_LOAD_FAILED');
    return;
  }
  let raw;
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch {
    fail('PORTABLE_INPUT_READ_FAILED');
    return;
  }
  let config;
  try {
    const input = JSON.parse(raw);
    config = prepareWorkflow(input);
    const previews = Object.fromEntries((input.personal_styles || []).map(style => [style.id, style.preview_data]));
    validateWorkflowConfig(config, previews);
  } catch {
    fail('PORTABLE_INPUT_INVALID');
    return;
  }
  process.stdout.write(JSON.stringify(config));
}

main().catch(() => fail('PORTABLE_NODE_FAILED'));
