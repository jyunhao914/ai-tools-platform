// Verify preparation only; never send, claim a receipt, or authorize production.
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {prepareWorkflow} from './recovery_contract/lib/workflow-config.mjs';
import {validateWorkflowConfig} from './recovery_contract/lib/config-validator.mjs';
import {WORKFLOW_VERSION} from './recovery_contract/canonical/version.mjs';

const stable=value=>Array.isArray(value)?value.map(stable):value&&typeof value==='object'
  ?Object.fromEntries(Object.keys(value).sort().map(key=>[key,stable(value[key])])):value;
function comparable(config) {
  const copy=structuredClone(config);
  for (const group of copy.groups) for (const option of group.options) delete option.preview_data;
  return JSON.stringify(stable(copy));
}

export function verifyConnectedResult(input,result) {
  // Pin identity before the call, rather than accepting a server-chosen request.
  if (!input?.request_id || result?.isError) throw Error('CONNECTED_RESULT_INVALID');
  const data=result?.structuredContent;
  if (data?.kind!=='studio-workflow-v2' || data.version!==WORKFLOW_VERSION ||
      data.config?.version!==WORKFLOW_VERSION) throw Error('CONNECTED_RESULT_INVALID');
  // Official tool results separate preview pixels into host-only metadata. Do
  // not preserve injected pixels in the receipt snapshot merely because the
  // shared validator intentionally ignores display-only preview_data fields.
  if (data.config.groups?.some(group=>group.options?.some(option=>'preview_data' in option)))
    throw Error('CONNECTED_RESULT_INVALID');
  const expected=prepareWorkflow(input);
  const previews=Object.fromEntries((input.personal_styles||[]).map(style=>[style.id,style.preview_data]));
  validateWorkflowConfig(data.config,previews);
  if (comparable(data.config)!==comparable(expected)) throw Error('CONNECTED_RESULT_INVALID');
  return {status:'validated',contract_version:WORKFLOW_VERSION,job_id:data.config.job_id,
    request_id:data.config.request_id,source_revision:data.config.source_revision,
    mode:input.mode||'intake',phase:data.config.phase??null};
}

if (process.argv[1] && import.meta.url===pathToFileURL(process.argv[1]).href) {
  try {
    if (process.argv.length!==4) throw Error('arguments');
    const read=path=>JSON.parse(fs.readFileSync(path,'utf8'));
    process.stdout.write(JSON.stringify(verifyConnectedResult(read(process.argv[2]),read(process.argv[3])))+'\n');
  } catch {
    // Fixed diagnostic only: do not disclose private source, previews or paths.
    process.stderr.write('CONNECTED_RESULT_INVALID\n');
    process.exitCode=1;
  }
}
