#!/usr/bin/env python3
"""Pin the current package's form-only runtime in an agent-owned job directory.

Only fixed sibling resources are copied. No client-selected code, network,
receipt, selection, authorization or production action is involved.
"""
import argparse
import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile

sys.dont_write_bytecode = True
SOURCE_ROOT = Path(__file__).resolve().parent.parent
REQUIRED_FILES = (
    'scripts/stage_form_runtime.py',
    'scripts/intake_form.py', 'scripts/intake_form.js', 'scripts/accept_intake.cjs',
    'scripts/portable_intake.py', 'scripts/portable_prepare.mjs',
    'scripts/recovery_contract/lib/workflow-config.mjs',
    'scripts/recovery_contract/lib/config-validator.mjs',
    'scripts/recovery_contract/canonical/intake-options.json',
    'scripts/recovery_contract/canonical/version.mjs',
    'assets/intake-form.html', 'assets/builtin-previews.json',
)
# The connected variant adds this pure validator. Never accept an arbitrary
# include path, a client-specified executable, or files outside the same package.
OPTIONAL_FILES = ('scripts/verify_connected_result.mjs',)
CACHE_NAME = '.presentation-studio-runtime'
MANIFEST_NAME = 'runtime-manifest.json'
RECORD_NAME = 'runtime-record.json'
MAX_FILE_BYTES = 8_000_000
MAX_RUNTIME_BYTES = 12_000_000


class RuntimeStageError(ValueError):
    pass


def fail(code):
    # Diagnostics contain no source content, user paths or arbitrary exceptions.
    raise RuntimeStageError(code)


def _plain_path(path):
    if not path.is_absolute() or '..' in path.parts:
        fail('FORM_RUNTIME_PATH_INVALID')
    for parent in (path, *path.parents):
        if parent.is_symlink():
            fail('FORM_RUNTIME_SYMLINK_REJECTED')


def _read_regular(path):
    _plain_path(path)
    try:
        descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
        with os.fdopen(descriptor, 'rb') as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_FILE_BYTES:
                fail('FORM_RUNTIME_FILE_INVALID')
            value = stream.read(MAX_FILE_BYTES + 1)
            after = os.fstat(stream.fileno())
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns) or len(value) != before.st_size:
            fail('FORM_RUNTIME_SOURCE_CHANGED')
        return value
    except FileNotFoundError:
        fail('FORM_RUNTIME_FILE_MISSING')


def _encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')


def _snapshot():
    names = list(REQUIRED_FILES)
    names.extend(name for name in OPTIONAL_FILES if (SOURCE_ROOT / name).exists() or (SOURCE_ROOT / name).is_symlink())
    payloads = {name: _read_regular(SOURCE_ROOT / name) for name in sorted(names)}
    if sum(map(len, payloads.values())) > MAX_RUNTIME_BYTES:
        fail('FORM_RUNTIME_TOO_LARGE')
    entries = {name: {'sha256': hashlib.sha256(value).hexdigest(), 'bytes': len(value)}
               for name, value in payloads.items()}
    runtime_id = hashlib.sha256(_encode({'schema': 1, 'files': entries})).hexdigest()
    manifest = {'schema': 1, 'runtime_id': runtime_id, 'files': entries}
    return payloads, manifest


def _verify(directory, manifest):
    _plain_path(directory)
    if not directory.is_dir():
        fail('FORM_RUNTIME_CACHE_INVALID')
    expected = set(manifest['files']) | {MANIFEST_NAME}
    observed = set()
    for item in directory.rglob('*'):
        if item.is_symlink():
            fail('FORM_RUNTIME_SYMLINK_REJECTED')
        if item.is_file():
            observed.add(item.relative_to(directory).as_posix())
        elif not item.is_dir():
            fail('FORM_RUNTIME_CACHE_INVALID')
    if observed != expected:
        fail('FORM_RUNTIME_CACHE_INVALID')
    if _read_regular(directory / MANIFEST_NAME) != _encode(manifest):
        fail('FORM_RUNTIME_CACHE_INVALID')
    for name, metadata in manifest['files'].items():
        value = _read_regular(directory / name)
        if len(value) != metadata['bytes'] or hashlib.sha256(value).hexdigest() != metadata['sha256']:
            fail('FORM_RUNTIME_HASH_MISMATCH')


def _write_new(path, value):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(value)
        stream.flush()
        os.fsync(stream.fileno())


def stage_runtime(job_directory):
    """Return trusted local paths. Caller must persist them as job metadata."""
    job_directory = Path(job_directory)
    if not job_directory.is_absolute() or '..' in job_directory.parts:
        fail('FORM_RUNTIME_PATH_INVALID')
    if job_directory.is_symlink():
        fail('FORM_RUNTIME_SYMLINK_REJECTED')
    # Resolve OS aliases (e.g. macOS /var -> /private/var) once. All returned
    # paths and cache checks then use this fixed, agent-owned canonical location.
    job_directory = job_directory.resolve()
    _plain_path(job_directory)
    payloads, manifest = _snapshot()
    cache = job_directory / CACHE_NAME
    _plain_path(cache)
    cache.mkdir(parents=True, exist_ok=True, mode=0o700)
    _plain_path(cache)
    record = cache / RECORD_NAME
    expected_record = _encode({'schema': 1, 'runtime_id': manifest['runtime_id']})
    if record.exists() or record.is_symlink():
        if _read_regular(record) != expected_record:
            fail('FORM_RUNTIME_VERSION_CONFLICT')
    destination = cache / manifest['runtime_id']
    if destination.exists() or destination.is_symlink():
        _verify(destination, manifest)
    else:
        temporary = Path(tempfile.mkdtemp(prefix='.staging-', dir=cache))
        try:
            for name, value in payloads.items():
                target = temporary / name
                target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                _write_new(target, value)
            _write_new(temporary / MANIFEST_NAME, _encode(manifest))
            _verify(temporary, manifest)
            # Re-read exactly the same trusted files before publication. A package
            # changing mid-copy is a failure, not a mixture of executable versions.
            if any(_read_regular(SOURCE_ROOT / name) != value for name, value in payloads.items()):
                fail('FORM_RUNTIME_SOURCE_CHANGED')
            try:
                os.rename(temporary, destination)
            except OSError as error:
                if error.errno not in (errno.EEXIST, errno.ENOTEMPTY):
                    raise
                _verify(destination, manifest)
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
    # Pin this job to one complete runtime. Atomic exclusive link never replaces
    # an existing record, including concurrent initialization by another process.
    temporary_record = cache / ('.record-' + os.urandom(16).hex())
    try:
        _write_new(temporary_record, expected_record)
        try:
            os.link(temporary_record, record)
        except FileExistsError:
            if _read_regular(record) != expected_record:
                fail('FORM_RUNTIME_VERSION_CONFLICT')
    finally:
        temporary_record.unlink(missing_ok=True)
    _verify(destination, manifest)
    paths = {'prepare': str(destination / 'scripts/portable_intake.py'),
             'accept': str(destination / 'scripts/accept_intake.cjs'),
             'stage': str(destination / 'scripts/stage_form_runtime.py')}
    if 'scripts/verify_connected_result.mjs' in manifest['files']:
        paths['verify_connected_result'] = str(destination / 'scripts/verify_connected_result.mjs')
    return {'runtime_schema': 1, 'runtime_id': manifest['runtime_id'],
            'runtime_root': str(destination), 'runtime_manifest': str(destination / MANIFEST_NAME),
            'runtime_record': str(record), 'runtime_paths': paths}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('job_directory', type=Path,
                        help='Absolute persistent job directory chosen by the agent, never by a form response.')
    args = parser.parse_args()
    print(json.dumps(stage_runtime(args.job_directory), ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except RuntimeStageError as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
    except OSError:
        print('FORM_RUNTIME_FILE_IO_FAILED', file=sys.stderr)
        sys.exit(1)
