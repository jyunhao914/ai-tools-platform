"""Prepare a display-only recovery of a saved canonical form, never a receipt."""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
VERSION = '2026.10.24-t094000'


def _read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _failure_report(evidence):
    """Validate report shape, not the authenticity of a caller's observation.

    A host report must be transcribed from an actual host UI diagnostic tied
    to this request. A JSON object cannot prove that provenance; the agent
    must keep its named tool/result reference and check the actual result.
    """
    if evidence.get('kind') == 'native_form_not_visible':
        if not isinstance(evidence.get('user_quote'), str) or not evidence['user_quote'].strip():
            raise ValueError('An actual report that the native form was not visible is required')
        return
    if evidence.get('kind') != 'host_display_failure':
        raise ValueError('An actual user report or explicit host display failure is required')
    if set(evidence) != {'kind', 'job_id', 'request_id', 'source_revision', 'diagnostic'}:
        raise ValueError('Host display evidence must use its diagnostic branch, not a user quote or inferred flags')
    diagnostic = evidence.get('diagnostic')
    expected = {'source', 'status', 'tool_name', 'observation_reference', 'message'}
    if not isinstance(diagnostic, dict) or set(diagnostic) != expected:
        raise ValueError('An explicit named host UI diagnostic and observation reference are required')
    if diagnostic.get('source') != 'host_ui' or diagnostic.get('status') not in ('load_error', 'render_error'):
        raise ValueError('Only explicit host UI load_error or render_error reports permit display recovery')
    tool_name = diagnostic.get('tool_name')
    if not isinstance(tool_name, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.:/-]{0,255}', tool_name):
        raise ValueError('Host diagnostic tool_name must name the actual tool that exposed the observation')
    for key, limit in (('observation_reference', 2000), ('message', 8000)):
        value = diagnostic.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > limit or '\x00' in value:
            raise ValueError('Host diagnostic ' + key + ' must be a nonempty recorded string')


def _identity(config, state, evidence):
    if not all(isinstance(value, dict) for value in (config, state, evidence)):
        raise ValueError('Config, current state and actual failure evidence must be objects')
    if config.get('version') != VERSION:
        raise ValueError('Saved canonical form version does not match this recovery package')
    if not isinstance(config.get('groups'), list) or any(
            not isinstance(g, dict) or not isinstance(g.get('id'), str) or
            not isinstance(g.get('options'), list) or
            any(not isinstance(o, dict) or not isinstance(o.get('id'), str) for o in g['options'])
            for g in config['groups']):
        raise ValueError('Saved canonical form groups are invalid')
    for key in ('job_id', 'request_id', 'source_revision'):
        value = config.get(key)
        if not isinstance(value, str) or not value.strip() or evidence.get(key) != value:
            raise ValueError('Failure evidence does not match saved ' + key)
    if state.get('job_id') != config['job_id'] or state.get('source_revision') != config['source_revision']:
        raise ValueError('Saved form does not match the current job/source revision')
    if state.get('active_request_id') != config['request_id']:
        raise ValueError('Saved form is not the current active request')
    _failure_report(evidence)
    saving = any(group.get('id') == 'save_style' for group in config.get('groups', []))
    if saving and state.get('phase') in ('producing', 'pending'):
        raise ValueError('Production is still pending; do not redisplay its later save-style form')
    if state.get('phase') in ('producing', 'delivered') and not saving:
        raise ValueError('This content stage has already advanced; do not redisplay its old form')


def _receipt_snapshot(directory, config, state):
    directory = Path(directory)
    recorded = state.get('receipts_directory')
    if not isinstance(recorded, str) or not recorded.strip():
        raise ValueError('Current job state has no verified receipt directory; recover its actual ledger location first')
    if Path(recorded).resolve() != directory.resolve():
        raise ValueError('Receipt directory does not match the current job state')
    if not directory.is_dir():
        raise ValueError('The current job receipt directory must be available before display recovery')
    snapshot = {}
    # iterdir raises if the directory cannot be read; glob can silently ignore
    # directory access errors and incorrectly make an unknown ledger look empty.
    for path in directory.iterdir():
        if path.suffix != '.json':
            continue
        raw = path.read_bytes()
        try:
            receipt = json.loads(raw)
        except (ValueError, UnicodeError) as error:
            raise ValueError('A receipt is incomplete; inspect current job before display recovery') from error
        if not isinstance(receipt, dict) or not receipt.get('job_id') or not receipt.get('request_id') or not isinstance(receipt.get('selection'), dict):
            raise ValueError('A receipt is incomplete; inspect current job before display recovery')
        snapshot[str(path.resolve())] = hashlib.sha256(raw).hexdigest()
        if receipt['job_id'] != config['job_id']:
            continue
        if receipt['request_id'] == config['request_id']:
            raise ValueError('This request already has a receipt; resume the received work, do not redisplay')
        selection = receipt['selection']
        saving = any(group['id'] == 'save_style' for group in config['groups'])
        if (not saving and receipt.get('source_revision') == config['source_revision'] and
                selection.get('next_action') == 'produce' and not selection.get('settings_only')):
            raise ValueError('Production is already claimed for this source revision; inspect the existing job')
    return snapshot


def _preview_copy(config, original_input):
    """Use real saved preview pixels, matched against the canonical catalog."""
    display = copy.deepcopy(config)
    personal = next((g for g in display['groups'] if g['id'] == 'personal_style'), None)
    if not personal:
        return display, {}
    if not isinstance(original_input, dict):
        raise ValueError('The original verified personal preview input is required; no images were substituted')
    for key in ('job_id', 'source_revision', 'catalog_snapshot'):
        if not config.get(key) or original_input.get(key) != config[key]:
            raise ValueError('Original preview input does not match saved ' + key)
    if 'request_id' in original_input and original_input['request_id'] != config['request_id']:
        raise ValueError('Original preview input belongs to another request')
    styles = original_input.get('personal_styles')
    if not isinstance(styles, list) or len(styles) != len(personal['options']):
        raise ValueError('Original preview input must contain the complete saved catalog')
    by_id = {style.get('id'): style for style in styles if isinstance(style, dict)}
    if len(by_id) != len(styles) or set(by_id) != {o['id'] for o in personal['options']}:
        raise ValueError('Original preview catalog identifiers do not match')
    previews = {}
    for option in personal['options']:
        source = by_id[option['id']]
        without_pixels = {key: value for key, value in source.items() if key != 'preview_data'}
        if without_pixels != option or not isinstance(source.get('preview_data'), str):
            raise ValueError('Original preview metadata does not match the saved canonical option')
        previews[option['id']] = source['preview_data']
        option['preview_data'] = source['preview_data']
    return display, previews


def prepare_display(config, state, evidence, *, original_input=None, node='node'):
    _identity(config, state, evidence)
    display, previews = _preview_copy(config, original_input)
    checked = subprocess.run([node, str(ROOT / 'recovery_contract/validate.mjs')],
        input=json.dumps({'config': config, 'previews': previews}, ensure_ascii=False),
        text=True, capture_output=True, timeout=30)
    if checked.returncode:
        raise ValueError('Canonical validation failed: ' + checked.stderr.strip())
    if json.loads(checked.stdout) != {'valid': True, 'version': VERSION}:
        raise ValueError('Canonical validation did not return a valid result')
    spec = importlib.util.spec_from_file_location('recovery_intake_form', ROOT / 'intake_form.py')
    renderer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(renderer)
    # No prepare(), UUID generation, snapshot write, receipt or side effect.
    return renderer.render(display)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config', type=Path)
    parser.add_argument('state', type=Path)
    parser.add_argument('failure_report', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--original-input', type=Path)
    parser.add_argument('--receipts-dir', type=Path, required=True)
    parser.add_argument('--node', default='node')
    args = parser.parse_args()
    inputs = [args.config, args.state, args.failure_report] + ([args.original_input] if args.original_input else [])
    if not args.output.is_absolute() or args.output.resolve() in {p.resolve() for p in inputs}:
        raise ValueError('Use a separate absolute output path; original records are read-only')
    before = {p: p.read_bytes() for p in inputs}
    config, state, evidence = (_read(p) for p in inputs[:3])
    _identity(config, state, evidence)
    receipts_before = _receipt_snapshot(args.receipts_dir, config, state)
    html = prepare_display(config, state, evidence,
        original_input=_read(args.original_input) if args.original_input else None, node=args.node)
    if any(p.read_bytes() != content for p, content in before.items()):
        raise ValueError('Source records changed during preparation; no display was written')
    if _receipt_snapshot(args.receipts_dir, config, state) != receipts_before:
        raise ValueError('Receipts changed during preparation; inspect the current job before display recovery')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Create privately and exclusively. Never overwrite the original form or
    # publish private preview pixels to a website, shared ZIP or network path.
    fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        stream.write(html)
    # Match packaged_intake: JSON escapes literal visualization delimiters,
    # quotes, newlines and non-ASCII path characters inside the reference.
    reference_path = json.dumps({'path': str(args.output.resolve())})
    reference = 'visualize' + reference_path + ''
    print(json.dumps({'display_status': 'prepared', 'recovery': 'same-canonical-form',
        'display_reference': reference,
        'display_instruction': 'Emit display_reference as a standalone reference in this turn\'s final response to show the recovered form. Prepared HTML is not evidence of rendering or submission. Wait for an actual user submission and validate it against the ORIGINAL saved config and freshly read current job state.',
        'request_id': config['request_id'], 'job_id': config['job_id'], 'source_revision': config['source_revision'],
        'version': config['version'], 'canonical_sha256': hashlib.sha256(before[args.config]).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        raise SystemExit(str(error))
