/* Shared deterministic form and submission contract. No network calls. */
function studioSelection(config, values) {
  function invalid(message, field) {
    const error = new Error(message);
    error.field = field;
    throw error;
  }
  const saving = config.groups.some(g => g.id === "save_style");
  const action = saving ? undefined : (values.next_action || config.next_action || "produce");
  if (action && !(config.phase === "entry" ? ["select_mode"] : ["produce", "edit_outline"]).includes(action)) invalid("請選擇有效的下一步。", "next_action");
  const contentFields = ["audience", "purpose", "target_pages", "duration_minutes", "outline_input"];
  const contentChanged = contentFields.some(key => String(values[key] ?? "").trim() !== String(config[key] ?? "").trim());
  const operationChanged = config.groups.some(g => g.id === "operation" && g.selected !== values.operation);
  const drafting = action === "edit_outline" || config.phase === "requirements" || config.phase === "outline_review" ||
    (config.phase === "settings" && (contentChanged || operationChanged));
  const analysisOnly = config.groups.some(g => g.id === "operation") && ["O4", "O5"].includes(values.operation);
  if (!drafting && !analysisOnly && values.style === "SM" && !config.groups.some(g => g.id === "personal_style" && g.options.length))
    throw new Error(config.library_message || (config.library_status === "empty" ? "你的風格庫尚未儲存款式，請先選擇內建、自動或自訂風格。" : "尚未取得可用的個人風格；請先連接自己的 Google Drive 並讀取風格庫。"));
  const choices = {};
  for (const group of config.groups) {
    if (analysisOnly && group.id !== "operation") continue;
    if (group.id === "personal_style" && config.groups.some(g => g.id === "style") && values.style !== "SM") continue;
    const option = group.options.find(o => o.id === values[group.id]);
    if (!option) {
      if (drafting && !["operation", "outline_decision"].includes(group.id) && !values[group.id]) continue;
      invalid("請選擇「" + group.title + "」。", group.id);
    }
    choices[group.id] = option.id;
  }
  const result = {schema: 1, request_id: config.request_id, choices};
  if (!saving) {
    result.requested_action = action;
    result.next_action = action;
    for (const [key, limit] of (analysisOnly ? [] : [["audience", 200], ["purpose", 1000], ["outline_input", 20000]])) {
      if (config.phase === "outline_review" && choices.outline_decision === "USE" && key === "outline_input") continue;
      const text = String(values[key] || "").trim();
      if (text.length > limit) invalid(key === "audience" ? "適用對象請控制在 200 字內。" : key === "purpose" ? "用途請控制在 1,000 字內。" : "大綱過長，請改在對話附加文件或貼上網址。", key);
      if (text) result[key] = text;
    }
  }
  const hasPages = values.target_pages != null && String(values.target_pages).trim() !== "";
  if (!saving && !analysisOnly && ((action !== "edit_outline" && ["O2", "O3"].includes(choices.operation)) || hasPages)) {
    const pages = Number(values.target_pages);
    if (!Number.isSafeInteger(pages) || pages < 1)
      invalid("請填入大於零的目標頁數。", "target_pages");
    result.target_pages = pages;
  }
  if (!saving && !analysisOnly && values.duration_minutes != null && String(values.duration_minutes).trim() !== "") {
    const minutes = Number(values.duration_minutes);
    if (!Number.isSafeInteger(minutes) || minutes < 1) invalid("請填入大於零的時間長度。", "duration_minutes");
    result.duration_minutes = minutes;
  }
  if (config.phase === "requirements") {
    if (!result.audience) invalid("請填寫適用對象。", "audience");
    if (!result.purpose) invalid("請填寫用途。", "purpose");
    if (!result.target_pages && !result.duration_minutes) invalid("請填寫預計頁數或時間長度。", "target_pages");
  }
  if (config.source_pages && result.target_pages && !analysisOnly) {
    if (choices.operation === "O2" && result.target_pages >= config.source_pages) invalid("縮減後頁數須少於原稿頁數。", "target_pages");
    if (choices.operation === "O3" && result.target_pages <= config.source_pages) invalid("擴增後頁數須多於原稿頁數。", "target_pages");
  }
  if (choices.style === "SC" && (!drafting || values.custom_style)) {
    const description = (values.custom_style || "").trim();
    if (!description) invalid("請填入自訂風格描述。", "custom_style");
    result.custom_style = description;
  }
  if (choices.save_style === "SAVE") {
    const name = (values.style_name || "").trim();
    if (!name) invalid("請填入風格名稱。", "style_name");
    result.style_name = name;
  }
  if (config.catalog_snapshot) result.catalog_snapshot = config.catalog_snapshot;
  if (config.job_id) result.job_id = config.job_id;
  if (config.source_revision) result.source_revision = config.source_revision;
  if (config.settings_only === true) result.settings_only = true;
  if (!saving) {
    result.phase = config.phase || "settings";
    const changed = ["audience", "purpose", "target_pages", "duration_minutes", "outline_input"].some(
      key => String(result[key] ?? "").trim() !== String(config[key] ?? "").trim());
    const changedOperation = config.groups.some(g => g.id === "operation" && g.selected !== choices.operation);
    result.next_action = config.phase === "entry" ? "select_mode" : config.phase === "outline_review" ? (choices.outline_decision === "USE" ? "configure_settings" : "review_content") :
      config.phase === "requirements" ? "prepare_outline" :
      choices.operation === "O4" ? "extract_outline" : choices.operation === "O5" ? "analyze_style" :
      config.phase === "operation" ? "review_content" : action === "edit_outline" || changed || changedOperation ? "review_content" :
      config.content_confirmed === true ? "produce" : "review_content";
  }
  return result;
}

function studioPrompt(config, selection) {
  if (config.phase === "entry") {
    const mode = config.groups.find(g => g.id === "workflow_mode")?.options.find(o => o.id === selection.choices.workflow_mode)?.label;
    return "我選擇「" + mode + "」。請沿用本對話已提供的來源與需求，進入對應流程，只補尚缺資料。這次只選擇模式，尚未授權製作成品；主題或一般資料先確認對象、用途、頁數或時間，現成大綱不重抄。\n" + JSON.stringify(selection);
  }
  if (config.settings_only === true) {
    return "Presentation Studio 設定：本次僅收集並保存這次選值，不製作簡報、不生圖、不寫入 Drive；等待人類後續要求。\n" + JSON.stringify({...selection, settings_only: true});
  }
  const next = selection.next_action;
  if (config.phase === "outline_review") {
    return (next === "configure_settings"
      ? "我確認採用這份原始大綱，請保留原文與頁序，接續尚缺的製作設定。不要重抄大綱；本次只確認內容，製作設定摘要送出前不生成成品。"
      : "我要修改這份大綱，暫不製作。已有修改需求就只修改受影響部分；尚未提供時只詢問要改什麼，不重貼全文。") + "\n" + JSON.stringify(selection);
  }
  if (["prepare_outline", "review_content"].includes(next)) {
    return "Presentation Studio 需求：" + (next === "prepare_outline"
      ? "依已確認對象、用途與篇幅產生有實際內容的逐頁大綱，供討論確認。"
      : "依最新來源、目標與修改要求核對內容。保留重製先確認保留範圍；縮減或擴增先交付修訂大綱。保留已選製作設定。") +
      "暫不製作投影片或生圖；確認內容後顯示已預填的製作設定摘要與『確認並開始製作』，除非人類已明確要求立即製作。\n" + JSON.stringify(selection);
  }
  const labels = config.groups.filter(g => g.id in selection.choices).map(g => {
    const code = selection.choices[g.id];
    const label = g.options.find(o => o.id === code).label;
    return g.title + " " + (["SA","SC","SM","SAVE","SKIP"].includes(code) ? label : code + "（" + label + "）");
  });
  if (selection.target_pages) labels.push("預計頁數 " + selection.target_pages);
  if (selection.audience) labels.push("適用對象 " + selection.audience);
  return "Presentation Studio 設定：" + labels.join("；") + "。\n" +
    (selection.choices.save_style ? "這是我的風格保存選擇，請只依本次選擇保存或略過，不重複製作。\n" : selection.choices.operation === "O4" ? "請還原來源的完整逐頁大綱，接著可繼續修改；本次不製作投影片，不要求製作形式或風格。\n" : selection.choices.operation === "O5" ? "請偵測來源風格並提供預覽與保存選擇；本次不重製簡報，不要求製作形式或選另一種風格。\n" : "請按畫面已確認的來源、內容與製作設定開始製作。先核對 job_id、request_id 與 source_revision；對話若有最新要求或暫停，依最新要求處理，不能以舊設定覆寫。\n") +
    JSON.stringify(selection);
}

function studioStateSaver(getBridge, reportFailure, timers = {setTimeout, clearTimeout}) {
  let latest = 0;
  let pending = null;
  let running = false;
  let disposed = false;
  let activeTimer;
  let releaseDrain;
  const waiters = [];
  async function drain() {
    running = true;
    while (pending && !disposed) {
      const {snapshot, revision} = pending;
      pending = null;
      let failed = false;
      // A slow save must not freeze the form or silently imply that a refresh is safe.
      // Keep the write serialized even after the warning: releasing it could let an
      // older, uncancellable host write overwrite the newer snapshot later.
      const timer = timers.setTimeout(() => { if (!disposed) reportFailure(true); }, 5000);
      activeTimer = timer;
      try {
        const bridge = getBridge();
        if (typeof bridge?.setWidgetState !== "function") throw new Error("State storage unavailable");
        const retired = new Promise(resolve => { releaseDrain = resolve; });
        await Promise.race([bridge.setWidgetState(snapshot), retired]);
      } catch { failed = true; }
      finally { timers.clearTimeout(timer); activeTimer = undefined; releaseDrain = undefined; }
      if (!disposed && revision === latest) reportFailure(failed);
      while (waiters.length && waiters[0].revision <= revision) waiters.shift().resolve();
    }
    running = false;
  }
  const save = snapshot => new Promise(resolve => {
    if (disposed) { resolve(); return; }
    const revision = ++latest;
    pending = {snapshot, revision};
    waiters.push({revision, resolve});
    if (!running) void drain();
  });
  save.dispose = () => {
    if (disposed) return;
    disposed = true; pending = null;
    timers.clearTimeout(activeTimer); activeTimer = undefined;
    while (waiters.length) waiters.shift().resolve();
    releaseDrain?.();
  };
  return save;
}

async function studioSend(bridge, message, timers) {
  let timer, unregister;
  const retired = new Promise((_, reject) => {
    unregister = timers.onDispose?.(() => reject(new Error("FORM_DISPOSED")));
  });
  try {
    return await Promise.race([
      // Invoke inside the click's activation scope, before yielding to a promise.
      bridge.sendFollowUpMessage(message),
      new Promise((_, reject) => {
        timer = timers.setTimeout(() => reject(new Error("Submission acknowledgement timed out")), 45000);
      }),
      retired
    ]);
  } finally { timers.clearTimeout(timer); unregister?.(); }
}

function mountStudioIntake(root, config, host) {
  const eventDocument = root.ownerDocument || document;
  const form = root.querySelector("form");
  const area = root.querySelector("[data-groups]");
  const button = form.querySelector("[data-submit]");
  const error = root.querySelector("[data-error]");
  const status = root.querySelector("[data-status]");
  const persistence = root.querySelector("[data-persistence]");
  error.id = root.id + "-error";
  const controls = {};
  const sections = {};
  const styleModes = [];
  const stylePanels = {};
  let disposed = false;
  let retired = false;
  let finalDraft;
  const cancellationHandlers = new Set();
  const timers = {
    setTimeout: (fn, ms) => (host.setTimeout || setTimeout)(fn, ms),
    clearTimeout: id => (host.clearTimeout || clearTimeout)(id),
    onDispose(callback) {
      cancellationHandlers.add(callback);
      return () => cancellationHandlers.delete(callback);
    }
  };
  let sending = false;
  let accepted = null;
  let dirty = false;
  let bridgeUnavailable = false;
  const saveState = studioStateSaver(() => host.openai, failed => {
    if (disposed || retired) return;
    persistence.textContent = failed
      ? "重新整理可能遺失未送出的選項。"
      : "";
  }, timers);
  function node(tag, text, cls) {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    if (cls) el.className = cls;
    return el;
  }
  function gallery(group) {
    const wrapper = node("div");
    wrapper.append(node("p", "點選預覽圖即可選擇風格。", "studio-hint"));
    const grid = node("div", null, "studio-gallery");
    for (const option of group.options.filter(o => group.id !== "style" || /^\d{2}$/.test(o.id))) {
      const item = node("label", null, "studio-preview-choice");
      const input = node("input", null, "form-check-input");
      input.type = "radio"; input.name = group.id; input.value = option.id;
      input.checked = group.selected === option.id;
      const caption = node("span", null, "studio-preview-caption");
      caption.append(input, node("span", option.id + " " + option.label));
      item.append(caption);
      if (option.preview_data) {
        const image = node("img", null, "studio-preview");
        image.src = option.preview_data;
        image.alt = option.label + " 九頁風格預覽";
        item.append(image);
      }
      controls[group.id].push(input);
      grid.append(item);
    }
    wrapper.append(grid);
    return wrapper;
  }
  for (const [index, group] of config.groups.entries()) {
    const section = node("section");
    sections[group.id] = section;
    section.setAttribute("aria-label", group.title);
    section.append(node("h3", group.title));
    if (group.context) section.append(node("p", group.context, "text-small"));
    if (group.id === "style") {
      const modeGrid = node("div", null, "studio-options");
      section.append(modeGrid);
      for (const [mode, title] of [
        ["auto", "自動"], ["builtin", "預設風格"],
        ["personal", "我的風格庫"], ["custom", "自訂風格"],
      ]) {
        const label = node("label", null, "form-check studio-option");
        const radio = node("input", null, "form-check-input");
        radio.type = "radio"; radio.name = "style_mode"; radio.value = mode;
        const code = group.selected;
        radio.checked = mode === (code === "SA" ? "auto" : code === "SM" ? "personal" :
          code === "SC" ? "custom" : /^\d{2}$/.test(code || "") ? "builtin" :
          "");
        label.append(radio, node("span", title, "form-check-label"));
        modeGrid.append(label);
        styleModes.push(radio);
      }
      for (const mode of ["builtin", "personal", "custom"]) {
        stylePanels[mode] = node("div");
        stylePanels[mode].hidden = true;
        section.append(stylePanels[mode]);
      }
      if (config.library_message || !config.groups.some(g => g.id === "personal_style")) {
        stylePanels.personal.append(node("p", config.library_message || (config.library_status === "empty" ? "你的風格庫目前尚未儲存款式。" : "尚未取得你的風格庫，請先連接自己的 Google Drive。")));
      }
    }
    const isSelect = group.id === "style" || group.id === "personal_style";
    controls[group.id] = [];
    if (isSelect) {
      if (group.id === "style") {
        stylePanels.builtin.append(gallery(group));
      } else section.append(gallery(group));
    } else {
      const grid = node("div", null, "studio-options");
      if (grid !== section) section.append(grid);
      let auxiliaryGrid;
      if (group.id === "workflow_mode") {
        const auxiliary = node("details");
        auxiliary.append(node("summary", "輔助功能：還原大綱、分析風格"));
        auxiliaryGrid = node("div", null, "studio-options");
        auxiliary.append(auxiliaryGrid); section.append(auxiliary);
      }
      for (const option of group.options) {
        const item = node("div", null, "studio-style");
        if (group.id === "personal_style" && option.preview_data) {
          const preview = node("img", null, "studio-preview");
          preview.src = option.preview_data;
          preview.alt = option.id + " " + option.label + " 預覽";
          item.append(preview);
        }
        const label = node("label", null, "form-check studio-option");
        const input = node("input", null, "form-check-input");
        input.type = "radio"; input.name = group.id; input.value = option.id;
        input.checked = group.selected === option.id;
        const caption = node("span", null, "form-check-label");
        caption.append(node("strong", option.label));
        const hints = {O1: "保留內容與順序，可依目標頁數重新分頁", O2: "精簡重點，先確認縮減後的大綱", O3: "補充內容，先確認擴增後的大綱", O4: "整理成逐頁文字大綱，不製作簡報", O5: "分析配色、字體與版面，不製作簡報", EDIT: "提出修改，確認後再選製作設定", USE: "保留這份大綱，接著選製作設定", K: "文字內容維持原樣", T: "允許潤飾措辭，不擅自改變重點", E: "文字與物件可在簡報中編輯", I: "每頁以完整圖像呈現", P0: "以文字、圖表與版面呈現，不加入插圖", P1: "直接使用來源中已有的圖片", P2: "依來源圖片重新繪製", P3: "依內容與選定風格製作新圖片"};
        if (hints[option.id]) caption.append(node("small", hints[option.id]));
        const modeHints = {TOPIC: "先確認需求，再規劃簡報大綱", OUTLINE: "沿用現成大綱，可先修改再製作", MATERIAL: "從報告、PDF、海報或圖片整理簡報內容", REDESIGN: "保留、精簡或擴充既有投影片內容", EXTRACT: "只整理逐頁大綱，不製作成品", ANALYZE: "只分析來源風格，可選擇儲存"};
        if (group.id === "workflow_mode") caption.append(node("small", modeHints[option.id]));
        label.append(input, caption);
        controls[group.id].push(input); item.append(label);
        (auxiliaryGrid && ["EXTRACT", "ANALYZE"].includes(option.id) ? auxiliaryGrid : grid).append(item);
      }
    }
    if (group.id === "personal_style" && stylePanels.personal) stylePanels.personal.append(section);
    else area.append(section);
  }
  const pages = form.elements.namedItem("target_pages");
  const pagesField = root.querySelector("[data-pages]");
  const goal = node("section");
  goal.setAttribute("aria-label", "製作目標");
  goal.setAttribute("data-goal", "");
  goal.append(node("h3", "製作目標"));
  if (config.source_pages) goal.append(node("p", "原稿頁數：" + config.source_pages + " 頁"));
  const goalFields = node("div", null, "studio-goal-fields");
  goal.append(goalFields);
  goalFields.append(pagesField);
  if (sections.operation) sections.operation.after(goal);
  else area.prepend(goal);
  const custom = form.elements.namedItem("custom_style");
  const styleName = form.elements.namedItem("style_name");
  const audience = form.elements.namedItem("audience");
  const purpose = form.elements.namedItem("purpose");
  const duration = form.elements.namedItem("duration_minutes");
  const outlineInput = form.elements.namedItem("outline_input");
  const nextAction = form.elements.namedItem("next_action");
  root.querySelector("[data-planning]").hidden = !!sections.save_style;
  if (stylePanels.custom) stylePanels.custom.append(root.querySelector("[data-custom]"));
  pages.value = config.target_pages || "";
  custom.value = config.custom_style || "";
  styleName.value = config.suggested_style_name || "";
  audience.value = config.audience || "";
  outlineInput.value = config.outline_input || "";
  purpose.value = config.purpose || "";
  duration.value = config.duration_minutes || "";
  root.querySelector("[data-source]").textContent = [config.source_name,
    config.source_pages ? "原稿 " + config.source_pages + " 頁" : ""].filter(Boolean).join(" · ");
  root.querySelector("[data-action]").hidden = config.phase !== "settings";
  const phaseLabel = config.phase === "entry" ? "選擇這次的工作" : sections.save_style ? "儲存風格（可略過）" :
    config.phase === "requirements" ? "2 · 確認基本需求 → 4 · 討論內容" :
    config.phase === "operation" ? "3 · 選擇處理方式 → 4 · 討論內容" :
    config.phase === "outline_review" ? "4 · 討論內容" :
    "5 · 確認製作設定 → 6 · 明確授權製作";
  root.querySelector("[data-phase]").textContent = phaseLabel;
  const heading = config.phase === "entry" ? ["這次想做什麼？", "選擇目標後，只確認尚缺的資料。已提供的來源與需求會保留。"] : sections.save_style ? ["保留這次的風格", "可儲存這次的風格供下次使用，也可以略過。"] :
    config.phase === "requirements" ? [config.source_layout === "document" ? "把這份資料整理成簡報" : "先確認簡報需求", "確認對象、用途與簡報篇幅後，再規劃大綱。已提供的資料會直接帶入。"] :
    config.phase === "operation" ? ["這份檔案要如何處理？", "先選擇處理方式，再確認內容；這一步不會開始製作。"] :
    config.phase === "outline_review" ? ["已收到你的大綱", "沿用原稿，不重複抄寫。請選擇修改內容，或接著選製作設定。"] :
    ["確認製作設定", "確認下方摘要後再開始製作。修改內容或篇幅時，會先回到內容確認。"];
  root.querySelector("[data-title]").textContent = heading[0];
  root.querySelector("[data-intro]").textContent = heading[1];
  const planning = root.querySelector("[data-planning]");
  let adjustments;
  if (config.phase === "settings") {
    adjustments = node("details");
    adjustments.setAttribute("data-adjustments", "");
    adjustments.append(node("summary", "調整對象、用途、內容或處理方式"));
    planning.before(adjustments); adjustments.append(planning);
    if (sections.operation) adjustments.append(sections.operation);
  }
  form.setAttribute("aria-label", sections.save_style ? "儲存簡報風格" :
    config.phase === "requirements" ? "簡報基本需求" : config.phase === "operation" ? "來源處理方式" : config.phase === "outline_review" ? "確認大綱下一步" : "簡報製作設定");
  root.querySelector("[data-outline]").hidden = config.phase === "requirements";
  root.querySelector("[data-duration]").hidden = !!sections.save_style;
  pagesField.after(root.querySelector("[data-duration]"));
  nextAction.value = config.next_action || "produce";
  function values() {
    const state = {target_pages: pages.value, custom_style: custom.value, style_name: styleName.value,
      audience: audience.value, purpose: purpose.value, duration_minutes: duration.value, outline_input: outlineInput.value, next_action: nextAction.value};
    for (const group of config.groups) {
      const inputs = controls[group.id];
      state[group.id] = inputs[0]?.tagName === "SELECT" ? inputs[0].value :
        (inputs.find(input => input.checked)?.value || "");
    }
    if (styleModes.length) {
      state.style_mode = styleModes.find(input => input.checked)?.value || "";
      state.style = {auto: "SA", personal: "SM", custom: "SC"}[state.style_mode] ||
        (state.style_mode === "builtin" ? state.style : "");
    }
    return state;
  }
  function refresh() {
    if (disposed || retired) return;
    const v = values();
    const analysisOnly = !!sections.operation && ["O4", "O5"].includes(v.operation);
    for (const id of ["outline_format", "source_format", "image_policy", "content", "style", "personal_style"]) {
      if (sections[id]) sections[id].hidden = analysisOnly;
    }
    const reviewing = config.phase === "outline_review";
    const operationPhase = config.phase === "operation";
    const editingOutline = reviewing && v.outline_decision === "EDIT";
    root.querySelector("[data-planning]").hidden = config.phase === "entry" || !!sections.save_style || analysisOnly || (reviewing && !editingOutline);
    root.querySelector("[data-audience]").hidden = reviewing || operationPhase;
    root.querySelector("[data-purpose]").hidden = reviewing || operationPhase;
    root.querySelector("[data-outline]").hidden = config.phase === "requirements" ||
      (operationPhase && !["O2", "O3"].includes(v.operation)) || (reviewing && !editingOutline);
    goal.hidden = config.phase === "entry" || !!sections.save_style || analysisOnly || reviewing || (operationPhase && !v.operation);
    if (adjustments && v.next_action === "edit_outline") adjustments.open = true;
    root.querySelector("[data-outline-label]").textContent = operationPhase ? "內容調整方向（可留白）" : "修改需求（可留白）";
    if (operationPhase || reviewing) area.after(planning);
    root.querySelector("[data-duration]").hidden = goal.hidden || operationPhase;
    pagesField.hidden = goal.hidden;
    pages.required = ["O2", "O3"].includes(v.operation);
    pagesField.querySelector("[data-pages-label]").textContent = config.phase === "requirements"
      ? "目標頁數（可與時間擇一）" : v.operation === "O1"
      ? "目標頁數（可重新分頁；留白沿用原稿）" : ["O2", "O3"].includes(v.operation)
      ? "目標頁數（必填）" : "目標頁數";
    root.querySelector("[data-custom]").hidden = analysisOnly || v.style !== "SC";
    root.querySelector("[data-style-name]").hidden = !sections.save_style || v.save_style === "SKIP";
    styleName.disabled = v.save_style === "SKIP";
    if (sections.personal_style && sections.style) sections.personal_style.hidden = analysisOnly || v.style !== "SM";
    for (const [mode, panel] of Object.entries(stylePanels)) panel.hidden = v.style_mode !== mode;
    let selection;
    try { selection = studioSelection(config, v); } catch {}
    root.querySelector("[data-summary]").textContent = config.phase !== "settings" ? "" : "製作前確認\n" +
      [config.source_name, v.audience, v.purpose, v.target_pages ? "目標 " + v.target_pages + " 頁" : "",
       v.duration_minutes ? v.duration_minutes + " 分鐘" : "",
       ...config.groups.filter(g => g.id !== "personal_style" || v.style === "SM").map(g => g.options.find(o => o.id === v[g.id])?.label)].filter(Boolean).join(" · ");
    const same = accepted === JSON.stringify(v);
    button.disabled = sending;
    button.textContent = sending ? "送出中…" : same ? "未接續時重試送出 →" :
      config.phase === "entry" ? "選擇此模式 →" :
      config.phase === "outline_review" ? (v.outline_decision === "EDIT" ? "確認修改大綱 →" : v.outline_decision === "USE" ? "確認大綱，選擇製作設定 →" : "確認大綱下一步 →") :
      sections.save_style ? (v.save_style === "SKIP" ? "略過儲存" : "確認儲存風格") :
      v.operation === "O4" ? "還原逐頁大綱 →" : v.operation === "O5" ? "分析風格 →" :
      config.settings_only ? "確認並保存測試設定 →" :
      config.phase === "requirements" ? "確認需求，產生大綱 →" :
      selection?.next_action === "produce" ? "確認並開始製作 →" :
      config.phase === "operation" && v.operation === "O1" ? "確認處理方式與保留範圍 →" :
      config.phase === "operation" && ["O2", "O3"].includes(v.operation) ? "確認目標，調整大綱 →" :
      config.phase === "settings" ? "確認修改，重新討論內容 →" : config.phase === "operation" ? "確認處理方式 →" : "確認需求，討論內容 →";

  }
  function restore(snapshot) {
    if (disposed || retired) return;
    const state = snapshot?.modelContent;
    if (!state || state.request_id !== config.request_id || state.form_id !== root.id) return;
    for (const group of config.groups) {
      const code = state.values?.[group.id];
      if (!group.options.some(o => o.id === code)) continue;
      for (const input of controls[group.id]) {
        if (input.tagName === "SELECT") input.value = code;
        else input.checked = input.value === code;
      }
    }
    if (styleModes.length) {
      const v = state.values || {};
      const mode = v.style === "SA" ? "auto" : v.style === "SM" ? "personal" :
        v.style === "SC" ? "custom" : /^\d{2}$/.test(v.style || "") ? "builtin" : v.style_mode;
      for (const input of styleModes) input.checked = input.value === mode;
    }
    pages.value = state.values?.target_pages || "";
    custom.value = state.values?.custom_style || "";
    styleName.value = state.values?.style_name ?? config.suggested_style_name ?? "";
    purpose.value = state.values?.purpose ?? config.purpose ?? "";
    duration.value = state.values?.duration_minutes ?? config.duration_minutes ?? "";
    audience.value = state.values?.audience ?? config.audience ?? "";
    // Large pasted outlines remain in this live form; don't truncate or rely on host state storage.
    if (state.values?.outline_input !== undefined) outlineInput.value = state.values.outline_input;
    nextAction.value = state.values?.next_action || config.next_action || "produce";
    refresh();
  }
  restore(host.openai?.widgetState);
  function onGlobals(e) {
    if (disposed || retired) return;
    if (!sending && !dirty) restore(e.detail?.globals?.widgetState);
    updateBridgeStatus();
  }
  host.addEventListener("openai:set_globals", onGlobals);
  function updateBridgeStatus() {
    if (disposed || retired) return;
    if (bridgeUnavailable && typeof host.openai?.sendFollowUpMessage === "function") {
      bridgeUnavailable = false;
      error.textContent = "";
      status.textContent = "傳送功能已恢復。設定仍保留，請按確認按鈕送出。";
    }
  }
  host.addEventListener("pageshow", updateBridgeStatus);
  eventDocument.addEventListener("visibilitychange", updateBridgeStatus);
  function onInput() {
    if (disposed || retired) return;
    dirty = true; error.textContent = ""; status.textContent = "";
    for (const input of form.querySelectorAll('[aria-invalid="true"]')) {
      input.removeAttribute("aria-invalid"); input.removeAttribute("aria-describedby");
    }
    refresh();
    const saved = values();
    if (JSON.stringify(saved).length > 3000) delete saved.outline_input;
    const snapshot = {modelContent: {request_id: config.request_id, form_id: root.id, values: saved}};
    void saveState(snapshot);
  }
  form.addEventListener("input", onInput);
  async function submit(event) {
    event.preventDefault();
    if (disposed || retired || sending || button.disabled) return;
    error.textContent = ""; status.textContent = "";
    const v = values();
    let selection;
    try { selection = studioSelection(config, v); }
    catch (e) {
      error.textContent = e?.message || "無法確認設定，內容仍保留。請檢查選項後重試。";
      const name = e?.field === "style" && !values().style_mode ? "style_mode" : e?.field;
      const field = Array.from(form.elements).find(input => input.name === name && !input.closest("[hidden]"));
      if (field) {
        field.setAttribute("aria-invalid", "true");
        field.setAttribute("aria-describedby", error.id);
        const details = field.closest("details");
        if (details) details.open = true;
        field.focus();
      }
      return;
    }
    sending = true; refresh();
    // Freeze controls until the exact clicked selection is acknowledged.
    for (const input of form.querySelectorAll("input,select,textarea")) input.disabled = true;
    // Only this attempt's local check can establish that no send was invoked.
    // A host rejection with the same text must remain an uncertain delivery.
    const unavailable = new Error("HOST_BRIDGE_UNAVAILABLE");
    try {
      // Do not queue a delayed automatic send: a newly ready bridge needs a fresh click.
      const bridge = host.openai;
      if (typeof bridge?.sendFollowUpMessage !== "function") throw unavailable;
      bridgeUnavailable = false;
      await studioSend(bridge, {
        prompt: studioPrompt(config, selection), title: sections.save_style ? "確認風格儲存選擇" :
          config.phase === "requirements" ? "確認簡報基本需求" :
          config.phase === "operation" ? "確認來源處理方式" : "套用簡報製作設定"
      }, timers);
      if (disposed || retired) return;
      accepted = JSON.stringify(v);
      status.textContent = "已請求傳送，等待對話接收並接續；目前尚未確認完成。若對話沒有收到，可按同一按鈕重試。";
    } catch (e) {
      if (disposed || retired) return;
      bridgeUnavailable = e === unavailable;
      error.textContent = bridgeUnavailable
        ? "此畫面目前無法傳送到對話，尚未送出。填寫內容仍保留；傳送功能恢復後可按同一按鈕重試。"
        : "尚未確認送達，設定仍保留。請先查看對話；若未收到，可按同一按鈕重試。";
    } finally {
      if (!disposed && !retired) {
        sending = false;
        for (const input of form.querySelectorAll("input,select,textarea")) input.disabled = false;
        refresh();
      }
    }
  }
  button.addEventListener("click", submit);
  form.addEventListener("submit", submit);
  refresh();
  function snapshotDraft() {
    const snapshot = finalDraft || {schema: "studio-intake-draft-v1", values: values()};
    if (!finalDraft) {
      for (const key of ["job_id", "request_id", "source_revision", "version", "phase",
                         "source_kind", "source_layout", "source_name", "source_pages"]) {
        if (config[key] !== undefined) snapshot[key] = config[key];
      }
    }
    // Keep the complete in-memory draft, including large outlines deliberately
    // omitted from host widgetState. Never merge it into another source's form.
    return JSON.parse(JSON.stringify(snapshot));
  }
  function stopPendingWork() {
    saveState.dispose();
    for (const cancel of cancellationHandlers) cancel();
    cancellationHandlers.clear();
  }
  function retire() {
    if (disposed || retired) return;
    finalDraft = snapshotDraft();
    retired = true;
    stopPendingWork();
    for (const input of form.querySelectorAll("button,input,select,textarea")) {
      if (input.tagName === "TEXTAREA" || (input.tagName === "INPUT" && !["radio", "checkbox"].includes(input.type))) {
        input.disabled = false;
        input.readOnly = true;
      } else input.disabled = true;
    }
    status.textContent = "這份表單已停止送出，內容保留供查看。";
  }
  return {snapshotDraft, retire, dispose() {
    if (disposed) return;
    finalDraft ||= snapshotDraft();
    disposed = true;
    host.removeEventListener?.("openai:set_globals", onGlobals);
    host.removeEventListener?.("pageshow", updateBridgeStatus);
    eventDocument.removeEventListener("visibilitychange", updateBridgeStatus);
    form.removeEventListener("input", onInput);
    form.removeEventListener("submit", submit);
    button.removeEventListener("click", submit);
    stopPendingWork();
    for (const input of form.querySelectorAll("button,input,select,textarea")) input.disabled = true;
  }};
}

if (typeof module !== "undefined") module.exports = {studioSelection, studioPrompt, studioStateSaver, studioSend, mountStudioIntake};
