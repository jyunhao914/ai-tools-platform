"""Render the packaged form. No network, MCP registration or Drive writes."""
import argparse
import copy
import json
from pathlib import Path
import re
import uuid
import intake_form

VERSION = "2026.10.24-t094000"


def production_choices(selected):
    """Expand an old combined choice without replacing newer explicit choices."""
    if selected is None:
        return {}
    if not isinstance(selected, dict):
        raise ValueError("selected must be an object")
    result = copy.deepcopy(selected)
    if "outline_format" in result:
        legacy = result.pop("outline_format")
        mapping = {"A": ("E", "P3"), "B": ("E", "P0"), "C": ("I", "P3")}
        if not isinstance(legacy, str) or legacy not in mapping:
            raise ValueError("Invalid legacy outline_format")
        output, images = mapping[legacy]
        # An explicit blank means the caller intentionally cleared this choice.
        # Never restore an old choice over a present new-format field.
        result.setdefault("source_format", output)
        result.setdefault("image_policy", images)
    return result


def prepare(data, *, job_id, mode="intake"):
    if not isinstance(job_id, str) or not job_id.strip() or len(job_id) > 300:
        raise ValueError("A current presentation job_id is required")
    for key in ("request_id", "previous_request_id"):
        if key in data:
            value = data[key]
            if not isinstance(value, str) or len(value) > 80 or re.fullmatch(r"[a-zA-Z0-9-]+", value) is None:
                raise ValueError("Invalid " + key)
    request_id = data["request_id"] if "request_id" in data else str(uuid.uuid4())
    config = {"request_id": request_id, "job_id": job_id, "version": VERSION}
    if "previous_request_id" in data:
        if data["previous_request_id"] == request_id:
            raise ValueError("previous_request_id must identify a different request")
        config["previous_request_id"] = data["previous_request_id"]
    if "replacement" in data:
        replacement = data["replacement"]
        required = {"from_request_id", "from_source_revision", "reason", "authorization_quote"}
        if not isinstance(replacement, dict) or not required <= replacement.keys() or replacement.keys() - required - {"receipt_id"}:
            raise ValueError("Invalid replacement fields")
        if "previous_request_id" in data:
            raise ValueError("replacement and previous_request_id are mutually exclusive")
        previous = replacement["from_request_id"]
        if not isinstance(previous, str) or len(previous) > 80 or re.fullmatch(r"[a-zA-Z0-9-]+", previous) is None:
            raise ValueError("Invalid replacement.from_request_id")
        if previous == request_id:
            raise ValueError("replacement must identify a different request")
        for key, value, limit in (("from_source_revision", replacement["from_source_revision"], 200),
                                  ("authorization_quote", replacement["authorization_quote"], 1000),
                                  ("source_revision", data.get("source_revision"), 200)):
            if not isinstance(value, str) or not value.strip() or len(value.encode("utf-16-le", "surrogatepass")) // 2 > limit:
                raise ValueError("Invalid replacement " + key)
        reason = replacement["reason"]
        if not isinstance(reason, str) or reason not in {"conversation_recovery", "source_changed", "settings_changed"}:
            raise ValueError("Invalid replacement.reason")
        if (reason == "conversation_recovery") != ("receipt_id" in replacement):
            raise ValueError("Only conversation_recovery requires its actual receipt_id")
        if "receipt_id" in replacement:
            receipt = replacement["receipt_id"]
            if not isinstance(receipt, str) or re.fullmatch(r"[a-f0-9]{64}", receipt) is None:
                raise ValueError("Invalid replacement.receipt_id")
        if reason == "source_changed" and replacement["from_source_revision"] == data["source_revision"]:
            raise ValueError("A changed source requires a new source_revision")
        config["replacement"] = copy.deepcopy(replacement)
    if mode == "save":
        name = data.get("suggested_style_name", "").strip()
        if not name or len(name) > 120:
            raise ValueError("Suggest a descriptive style name from the completed design")
        revision = data.get("source_revision")
        if not isinstance(revision, str) or not revision.strip() or len(revision) > 200:
            raise ValueError("Style saving requires the completed source_revision")
        config["source_revision"] = revision
        config.update(suggested_style_name=name, groups=[{
            "id": "save_style", "title": "是否存入我的風格庫？", "options": [
                {"id": "SAVE", "label": "存入我的風格庫"},
                {"id": "SKIP", "label": "這次不儲存"}]}])
        return config
    file_kinds = {"slides", "pdf", "pptx", "image", "document"}
    if mode != "intake" or data.get("source_kind") not in {"unknown", "topic", "outline"} | file_kinds:
        raise ValueError("Use intake with source_kind unknown/topic/outline/pdf/pptx/slides/image/document, or save")
    kind = data["source_kind"]
    layout = data.get("source_layout", "document" if kind in {"image", "document"} else "slides" if kind in file_kinds else None)
    if "source_layout" in data and (layout not in {"slides", "document"} or kind not in file_kinds):
        raise ValueError("File source_layout must be slides or document")
    if layout is not None:
        config["source_layout"] = layout
    material = layout == "document"
    deck = kind in file_kinds and not material
    selected = production_choices(data.get("selected"))
    has_images = data.get("source_has_images", True if kind == "image" else False if kind in {"topic", "outline"} else None)
    if "source_has_images" in data and not isinstance(has_images, bool):
        raise ValueError("source_has_images must be a verified boolean")
    if has_images is not None:
        config["source_has_images"] = has_images
    phase = data.get("phase", "entry" if kind == "unknown" else "requirements" if kind == "topic" else
                     "settings" if material and data.get("content_confirmed") else "requirements" if material else
                     "operation" if deck else "settings" if data.get("content_confirmed") else "outline_review")
    if phase not in {"entry", "requirements", "operation", "outline_review", "settings"}:
        raise ValueError("Invalid intake phase")
    if kind == "unknown" and phase != "entry":
        raise ValueError("Unknown source_kind is allowed only in entry phase")
    if phase == "requirements" and kind != "topic" and not material:
        raise ValueError("Requirements phase is for a new topic or source material")
    if phase == "operation" and not deck:
        raise ValueError("Operation phase requires an existing slide deck, not source material")
    if phase == "outline_review" and kind != "outline":
        raise ValueError("Outline decision requires the current supplied outline")
    config.update(source_kind=kind, phase=phase)
    confirmed = data.get("content_confirmed", False)
    if not isinstance(confirmed, bool):
        raise ValueError("content_confirmed must be boolean")
    if phase == "entry" and confirmed:
        raise ValueError("Entry only selects a workflow; it cannot confirm content")
    if confirmed and (not data.get("source_revision") or not data.get("confirmation_quote")):
        raise ValueError("Confirmed content requires its revision and human confirmation quote")
    config["content_confirmed"] = confirmed
    if phase == "settings" and data.get("next_action", "produce") == "produce":
        if not confirmed:
            raise ValueError("Confirm the current content before opening production settings")
        if kind == "topic" or material:
            if not str(data.get("audience", "")).strip() or not str(data.get("purpose", "")).strip():
                raise ValueError("Collect audience and purpose in requirements first")
            if not data.get("target_pages") and not data.get("duration_minutes"):
                raise ValueError("Collect target pages or duration in requirements first")
        if deck:
            operation = selected.get("operation")
            if operation not in {"O1", "O2", "O3"}:
                raise ValueError("Choose a production operation first; O4/O5 use operation phase only")
    for key in ("source_name", "purpose", "confirmation_quote"):
        if key in data:
            value = data[key]
            if not isinstance(value, str) or len(value) > 1000:
                raise ValueError("Invalid " + key)
            config[key] = value
    if "duration_minutes" in data:
        minutes = data["duration_minutes"]
        if isinstance(minutes, str):
            minutes = minutes.strip()
            if minutes:
                if not minutes.isascii() or not minutes.isdigit():
                    raise ValueError("duration_minutes must be a positive integer")
                minutes = int(minutes)
        if minutes != "" and (isinstance(minutes, bool) or not isinstance(minutes, int) or minutes < 1):
            raise ValueError("duration_minutes must be a positive integer")
        config["duration_minutes"] = minutes
    if "source_pages" in data:
        count = data["source_pages"]
        if isinstance(count, bool) or not isinstance(count, int) or count < 1:
            raise ValueError("source_pages must be a verified positive integer")
        config["source_pages"] = count
    status = data.get("library_status")
    if phase != "settings":
        status = None
    if phase == "settings" and status not in {"ready", "empty", "not_connected", "error"}:
        raise ValueError("Read the current user's Drive library and supply its actual status")
    personal = data.get("personal_styles") or []
    if status == "ready" and not personal:
        raise ValueError("A ready library must include its real styles and previews")
    if personal and status != "ready":
        raise ValueError("Personal styles require a verified ready library")
    catalog = json.loads((Path(__file__).parent.parent / "references/intake-options.json").read_text())
    ids = (["workflow_mode"] if phase == "entry" else [] if phase == "requirements" else ["operation"] if phase == "operation" else ["outline_decision"] if phase == "outline_review" else
           ["operation", "source_format", "image_policy", "content", "style"]
           if deck else ["source_format", "image_policy", "content", "style"])
    groups = [copy.deepcopy(next(g for g in catalog["groups"] if g["id"] == gid)) for gid in ids]
    for group in groups:
        if group["id"] == "image_policy" and has_images is False:
            group["options"] = [o for o in group["options"] if o["id"] in {"P0", "P3"}]
            group["context"] = "目前沒有可用原圖，可選擇不使用配圖或生成新配圖。提供原圖後才能沿用或重繪。"
        for option in group["options"]:
            option.pop("aliases", None)
        if group["id"] in selected:
            value = selected[group["id"]]
            if value in (None, ""):
                continue
            if value not in {o["id"] for o in group["options"]}:
                if group["id"] == "image_policy" and value in {"P1", "P2"} and has_images is False:
                    raise ValueError("沿用或重繪需要已確認可用的原圖；請先提供原圖或重新選擇圖片處理方式")
                raise ValueError("Invalid selected option: " + group["id"])
            group["selected"] = value
    if personal:
        if len(personal) > 50 or not data.get("catalog_snapshot"):
            raise ValueError("Personal styles require a current catalog snapshot and at most 50 entries")
        group = {"id": "personal_style", "title": "我的風格庫", "options": copy.deepcopy(personal)}
        if "personal_style" in selected:
            group["selected"] = selected["personal_style"]
        groups.append(group)
        config["catalog_snapshot"] = data["catalog_snapshot"]
    config.update(groups=groups, library_status=status)
    if "settings_only" in data:
        if not isinstance(data["settings_only"], bool):
            raise ValueError("settings_only must be a boolean")
        config["settings_only"] = data["settings_only"]
    if data.get("library_message"):
        config["library_message"] = str(data["library_message"])[:1000]
    if "target_pages" in data:
        pages = data["target_pages"]
        if isinstance(pages, bool) or not isinstance(pages, int) or pages < 1:
            raise ValueError("target_pages must be a positive integer")
        config["target_pages"] = pages
    if "custom_style" in data:
        config["custom_style"] = str(data["custom_style"])[:3000]
    for key, limit in (("audience", 200), ("outline_input", 20000), ("source_revision", 200)):
        if key in data:
            value = data[key]
            if not isinstance(value, str) or len(value) > limit:
                raise ValueError(f"Invalid or oversized {key}")
            config[key] = value
    action = data.get("next_action", "select_mode" if phase == "entry" else "produce")
    if phase == "entry":
        if action != "select_mode":
            raise ValueError("Entry next_action must be select_mode")
    elif action not in {"produce", "edit_outline"}:
        raise ValueError("next_action must be produce or edit_outline outside entry")
    config["next_action"] = action
    return config


def render(data, *, job_id, mode="intake"):
    config = prepare(data, job_id=job_id, mode=mode)
    return config, intake_form.render(config)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--mode", choices=["intake", "save"], default="intake")
    parser.add_argument("--config-output", type=Path, required=True)
    args = parser.parse_args()
    config, fragment = render(json.loads(args.input.read_text()), job_id=args.job_id, mode=args.mode)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.config_output.parent.mkdir(parents=True, exist_ok=True)
    args.config_output.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n")
    args.output.write_text(fragment)
    # Preparing a file does not render it in the host. Return the exact native
    # visualization reference so the caller cannot confuse a file path with
    # the required final-response display handoff. JSON escaping also keeps
    # quotes, newlines and marker-like characters in a path inside the path.
    display_reference = "visualize" + json.dumps({"path": str(args.output.resolve())}) + ""
    print(json.dumps({"html": str(args.output.resolve()), "config": str(args.config_output.resolve()),
                      "request_id": config["request_id"], "job_id": config["job_id"],
                      "version": VERSION, "bytes": len(fragment.encode()),
                      "display_status": "prepared",
                      "display_reference": display_reference,
                      "display_instruction": "The form file is prepared, not displayed. Read back the fragment, then include display_reference exactly on its own line in this turn's final response, without a code fence or Markdown link. Do not infer host rendering or submission from file generation. If the host has no supported visualization surface, report the missing display capability and continue only through the documented failure recovery."}))
