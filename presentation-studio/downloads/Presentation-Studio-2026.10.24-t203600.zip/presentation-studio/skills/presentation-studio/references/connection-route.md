# 依本回合實際連接選擇表單（私人未驗證候選）

本包沒有 MCP／App 宣告，不會替帳號建立連接，也不保證手機已能送出。只使用宿主當回合正式提供的能力；封裝、工具交接、畫面可見、同對話收件及跨裝置驗收分開記錄。原 pure-portable 實驗另行保留。

## 選一次路徑，不做無關前置盤點

先使用本回合已提供的工具描述及 schema，必要時才用正式工具發現功能。只選目前連接的 Presentation Studio 正式工具；保存工具完整識別及實際描述／schema 來源。名稱相同不是同一連接或同版契約的證據，不混用另一安裝、帳號、舊快取或來源不明的工具。多個候選無法確認哪個屬於目前連接時，不猜測，進隨包路徑。不能把本地 JSON、自填能力旗標、網站 HTTP 成功或安裝成功當成宿主提供工具的證據。

1. 當回合確實提供 `studio_open_workflow_v2`，其 schema 支援本次完整輸入（mode、phase、source_kind、job_id、source_revision、request_id，以及實際需要的 previous_request_id／replacement 等）時，優先使用這個正式 MCP App 入口。不得刪除必要欄位或更改來源來迎合舊 schema。工具名稱與輸入可通過 schema 都還不是回傳契約已驗證。
2. 直接 v2 不可用或 schema 不匹配時，只在**同一實際連接的正式工具描述或已核實的同版服務契約明示支援 v2 封套**，且當回合提供相容 `studio_open_intake` schema 時，使用下列完整封套。只有舊工具名稱、舊 outline/slides 選項或另一連接的部署紀錄，都不夠。沒有明示支援就不可試投新版資料。

```json
{"source_kind":"outline","selected":{"workflow_v2_config":"<完整原始 v2 input 的 JSON 字串>"}}
```

外層 outline 只供已明示的封套入口分派；內層保留真實 source_kind、phase、mode、所有需求、來源修訂及接續欄位，不改成 legacy 選值。舊 `studio_open_style_save` 不能承接本版儲存流程；save 同樣使用通過核對的 v2 或 v2 封套。
3. 沒有以上契約匹配工具時，依 [隨包路徑](portable-route.md) 單次執行 portable_intake.py，再交接正式 visualize 參照。Visualize 是正式技能，不要求工具清單有同名函式；未驗收也不代表能力不存在。先查實際技能與執行能力，不猜測瀏覽器或手機支援情況。

初次 entry／requirements 不預查 Python／Node 版本、Pillow、Drive、圖片生成或簡報編輯器；直接執行當前選中路徑。已讀且版本未變的規則及同一 source_revision 已確認資料直接沿用。只有實際錯誤才針對該步診斷。製作設定需要預覽時仍完整讀取及驗證預覽，不能為速度刪除安全檢查。

## 正式工具回傳必須與原輸入完全相符

新 job 第一次表單前，從宿主正式技能來源取得當前 skill_root，將可信同版最小 runtime 保存到固定 job 目錄，避免下回合暫時 plugin mount 消失後找不到收件器。正式工具路徑先執行一次：

```sh
python3 <當前可信skill_root>/scripts/stage_form_runtime.py <固定job目錄>
```

保存實際回傳的 runtime_id、runtime_root、runtime_manifest、runtime_record 與 runtime_paths；後續準備／收件／回傳核對優先用 runtime_paths.prepare、runtime_paths.accept、runtime_paths.verify_connected_result 的絕對路徑，不自行拼舊 mount。正式工具路徑必須已取得 verify_connected_result 路徑才能呼叫；不存在就先處理該缺檔，不聲稱可在之後補驗證。隨包 portable_intake.py 會自動做同一 staging，明確帶入 `--job-directory <固定job目錄>`；接續依同版 pin 驗證，不能以重建另一目錄繞過失效或缺少紀錄。只解析需要的同版檔案，不做全磁碟、Plugin Management／Plugin Creator 掃描；失效時由當前正式技能清單重新定位，不能信任另一執行環境留下的絕對路徑。

呼叫前保存本階段完整 input.json；建立一次 request_id 並保存，工具重試沿用該 ID 與原輸入。新 job 第一次表單前建立固定 receipts 目錄並記入 intake-state.receipts_directory；既有工作沿用實際收件目錄。正常下一階段先取得前一 request 的真正 accepted 收件；previous／replacement、來源更新和內容確認依 [互動契約](interactive-intake.md)，不可先改 active request 掩蓋未收件。

將**實際工具結果**保存為 result.json，執行本包只讀核對器：

```sh
node <已驗證的runtime_paths.verify_connected_result> <input.json> <result.json>
```

核對器拒絕 isError、legacy kind、錯版，以及任何與原輸入的 canonical config 不符的來源、job、request、階段、選項、頁數、確認或 replacement。它使用本包未修改的 prepareWorkflow／config-validator，不能以服務回傳任意 config 自我驗證。私人預覽使用原輸入已驗證資料核對；這不證明宿主已收到或顯示預覽。

僅成功輸出 `status=validated` 後，將**工具回傳原樣 structuredContent.config** 保存為 config.json，再把其 request_id 記入 active_request_id。核對器輸出只是準備驗證，不是 selection、receipt、畫面可見或製作授權。不能重建 config 取代工具結果、改欄位迎合錯誤，或把核對器結果當成人類回覆。

正式工具結果由宿主呈現註冊的 MCP App；正常交接不另外產生 visualize 副本。UI 以官方 App.connect／message.text 能力及 App.sendMessage 提交；它不是在隨包 HTML 注入 window.openai。隨包路徑仍使用宿主真正提供的 sendFollowUpMessage。兩者都保留宿主傳送確認，不猜測 postMessage、不操控聊天輸入欄、不偽造 bridge、不安排背景補送。

## 失敗接續與重試

- 回傳核對失敗、宿主拒絕或明確載入／傳送失敗時保存真實停點，不宣稱表單可用或成功。已交接但可見性未知不等於失敗，不反覆另開表單。可用原 config 的未顯示案件只依 interactive-intake.md「原生表單未顯示時的同設定重顯示」完整檢查及 recover_display.py CLI 恢復，不繞過 receipts 檢查或重建新 request。
- 已有畫面但送出能力缺少時，不以換路徑保證恢復；同畫面保留欄位、顯示未送出並可重試。逾時結果不明先查同對話與同 job 收件，不直接自動再送。當前正式能力無法完成時，在同一對話用簡短問答只補缺少的欄位，沿用**實際已收到**的資料。不得聲稱自動取得另一畫面未送出的選值、草稿或已保存未知資料；不要求手動複製轉貼。
- 人類在對話實際回答的資料另記錄真實原話，依既有對話接續與授權流程處理，不能偽造成表單 selection／SDK ack。備援成功不等於原表單已修復。缺少製作授權時只補該項；已授權且仍對應最新來源時不重複詢問。
- 真正同對話收到 selection 後，依原 config、最新 intake-state 與固定 receipts 目錄執行未修改的 accept_intake.cjs；只有 accepted 才執行對應動作，resume 讀回原工作。入口、需求、內容確認不授權製作；還原大綱／分析風格只完成對應工作。頁數、圖片處理、來源修訂與最新內容確認規則不因選路徑而改變。

此候選僅修正路由與回傳核對；尚未取得有效 App binding 的帳號不會因安裝本包而獲得該連接。正式服務註冊、手機實際顯示／送出、改頁數、間隔操作與壓力穩定驗收仍須各自完成，未驗證不發布或更換網站下載。
