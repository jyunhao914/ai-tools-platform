# 表單內風格預覽

內建 15 款預覽來自同包 `assets/builtin-previews.json`。正式 App SDK 表單使用同版內建資產；隨包 visualize 路徑由 `intake_form.py` 將完整預覽嵌入表單。依 [互動表單](interactive-intake.md) 的 connection-route.md 的實際契約匹配工具 → 明示 v2 封套 → 隨包 visualize 順序選擇入口，不因需要預覽而跳過正式工具。兩條呈現路徑均不需要另建公開圖片網址或額外讀取回合。

自動排第一；預設風格、我的風格庫、自訂風格同階。兩組預覽在各自所屬選項正下方，預設收合，展開立即顯示；不加載入、翻頁或放大按鈕。可直接點選預覽圖或以鍵盤選擇該款，選中後清楚標示並同步表單摘要及既有選值；選風格本身不會送出或開始製作。切換至其他風格類型後不把隱藏的舊款式一起送出。

私人風格先完整讀回目前使用者自己的 Google Drive，依 `style_library.catalog → form_group` 驗證九頁預覽。`intake_data.arguments` 將當次清單轉為 `personal_styles` 並保留 `catalog_snapshot`，再依所選正式入口傳入。App SDK 的直接 v2 與封套入口都透過工具結果 `_meta.personal_previews` 將已驗證像素交給 UI，canonical config 只保留款式 ID 與驗證 metadata，不另把像素補回收件 config。隨包 visualize 路徑則由同版渲染器嵌入已驗證的顯示副本。公開表單端點只處理這次請求，不取得 Drive 權限或保存風格庫；這不等於將私人預覽發布成公開網站資產。私人縮圖只用於目前工作檔與表單，不上傳公開圖片主機、不包進外掛。缺檔、未連接、讀取錯誤不能偽稱空庫。
