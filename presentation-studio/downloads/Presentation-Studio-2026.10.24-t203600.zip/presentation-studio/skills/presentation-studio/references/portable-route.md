# 無契約匹配工具時的隨包路徑（未驗證）

先由 [本回合連接路由](connection-route.md) 判斷沒有匹配工具，才使用本節；已有正式工具結果時不得另開複本，明確未顯示的恢復依 interactive-intake.md。本包只供隔離實測，沒有 MCP 或雲端 App 宣告。不是公開發布包，也沒有任何帳號、桌面、網頁或手機已通過的承諾。封裝版本與原 canonical 表單契約版本分開記錄；不可為了改安裝版號而修改選值版本或驗證器。

## 啟動表單：未知不等於不可用

表單需要宿主提供可執行本包腳本的 Python、Node，以及正式 visualize 顯示能力；製作設定的預覽圖另需 Pillow 解碼與驗證。能力來自目前宿主，不來自開發者電腦。本包不內含這些執行環境，也不要求使用者安裝。

先查看本回合正式提供的技能與執行工具。若有 visualize 技能，讀取其 SKILL.md，依它的規範完成下列產檔與最終回覆交接；不要只因這是私人候選，或尚未實測這個帳號，就先回覆「表單無法顯示」。Visualize 是技能與顯示參照流程，不要求工具清單中有名為 visualize 的函式。若技能未列出，只使用宿主明確提供的技能發現／載入功能尋找；不可猜測隱藏介面、偽造已啟用或繞過明確拒絕。

將能力狀態分開：正式技能與執行器可用，就實際準備並交接；尚未取得正式能力時記為「未取得」，不推定 Safari 或帳號不支援；宿主明確拒絕或實際執行失敗時，保存該步驟的實際結果並停止該路徑。不因瀏覽器控制工具不可用就判定對話表單無法顯示，兩者不同。

`window.openai.sendFollowUpMessage` 由顯示中的宿主表單取得，不能從助理的工具清單或尚未顯示的 HTML 判定不存在。它不是產檔或首次顯示前的必要探測；顯示後由原表單檢查並處理送出失敗。不得注入或模擬正式 bridge。缺少已證實必要的能力時不能聲稱載入完成、反覆等不存在的能力，或略過圖片驗證。

已依 connection-route.md 確認沒有契約匹配工具時，同包 canonical `prepareWorkflow` 負責準備設定；直接走下列路徑，不重複探測、不要求連接私人 App，不混用另一份安裝或舊工作目錄的腳本。其餘來源讀取、圖片生成、Google Drive、Slides、Spaces 與下載仍各依目前宿主實際工具；沒有 MCP 宣告不代表所有功能離線可用。

## 首次選單直接執行，不做無關的前置盤點

- 讀取本階段必要的正式技能與契約後，直接單次執行下列 `portable_intake.py`。不先另跑 Python／Node 版本檢查、import 測試或全部套件盤點；helper 成功已證明本次產檔使用的 runtime 可執行，仍不代表宿主顯示或送出已通過。
- entry／requirements 不含預覽，不預查 Pillow、不讀取私人風格庫、不測試生圖、簡報編輯器或 Drive。製作設定真正包含預覽時，原渲染器仍必須實際解碼與驗證圖片；缺少能力時保留錯誤，不能刪除預覽或跳過檢查。
- 已在本次上下文讀取且版本未變的正式技能及流程文件直接沿用。保留同一 source_revision 已確認的檔名、頁數、可讀範圍、來源內容與人類需求，不為顯示選單重新解析同一份來源。來源變更、資料缺漏或內容不確定時只補需要核對的部分，不能把尚未讀取的內容說成已讀取。
- 成功時直接完成原樣 config 保存、HTML 檢查與正式參照交接。只有實際失敗才依 helper 的錯誤分類診斷缺少的 runtime、輸入或預覽；若 Python 根本無法啟動，才針對執行器診斷。不做無關的整套環境掃描，不改用另一份舊腳本，不略過來源、收件或授權檢查。
- 製作與交付規則在主技能對應章節連結中按階段讀取；第一份選單不因尚未到達的製作功能而延後交接。重試仍沿用原 config／request／HTML，不能用新的工作或請求掩蓋失敗。

## 每次表單準備與正式交接

1. 新 job 在第一次表單前選定宿主可持久保留的固定 job 目錄，建立 receipts 目錄並將實際絕對路徑保存至 intake-state.receipts_directory。接續工作讀回原紀錄，不另建空目錄掩蓋先前收件。下列 helper 會在此 job 的 `.presentation-studio-runtime` 保存可信同包的最小表單程式與資產，依全部內容雜湊定版並驗證完整性；同一 job 不覆寫或混入別版。
2. 依 source-to-deck.md 判定來源與階段。已知資料預填；來源、用途或篇幅有變則使受影響的內容確認失效。輸入採同包 `recovery_contract/lib/workflow-config.mjs` 的完整 WORKFLOW_SCHEMA，必含真實 job_id、source_revision；request_id 可省略由 canonical 準備器產生。
3. 將本次輸入保存至該 job 的 input.json，在宿主提供的執行器執行：

```sh
python3 <本技能>/scripts/portable_intake.py <input.json> <本次工作絕對路徑/form.html> --config-output <本次工作絕對路徑/config.json> --job-directory <固定job絕對路徑>
```

4. 保存輸出的原樣 config，與同一 job 的 active_request_id 綁定；同時將 helper 回傳的 runtime_id、runtime_record、runtime_manifest、runtime_paths 原樣記入 intake-state.form_runtime。這些是助理由可信同包產生的本地路徑，不從表單選值、文件內容或使用者貼入的程式路徑取用。後續準備一律使用 `runtime_paths.prepare`，收件使用 `runtime_paths.accept`；不要再搜尋暫時 plugin 掛載、其他已安裝版本、Plugin Creator 或 Drive 來找腳本。不能改 config 迎合回傳。準備器不會建立收件、寫入 Drive 或開始製作。只有第一次新表單才能產生新 request；相同表單重試讀回原 config 與 HTML，不重跑以取代它。私人預覽只留在本次工作目錄，不上傳公開網站或加入安裝包。
5. 讀回 HTML 並核對小於 1 MB。已讀取本回合可用的正式 visualize 技能且產檔成功時，依該技能將程式返回的 display_reference 原樣獨立一行放在**同回合最後回覆**；不可放在進度訊息、程式碼區塊或改成檔案連結。不另外要求先證明「畫面已看見」才交接，因為顯示發生在交接之後。只產檔或輸出路徑不算交接。
6. 分開紀錄「設定已準備」「參照已交接」「畫面已看見」「同對話已收件」。後兩者須由真正宿主觀察／使用者回報與收件器結果證實；離線測試、模擬點擊、腳本成功、無錯誤或沉默都不是實機證據。

每次下一回合收件前，先用已保存的 `runtime_paths.stage` 對同一固定 job 目錄做完整性核對，再執行同一回傳的收件腳本：

```sh
python3 <已保存runtime_paths.stage> <固定job絕對路徑>
node <已保存runtime_paths.accept> <原config.json> <真正收到的selection.json> <目前intake-state.json> <原receipts目錄>
```

這個核對不需要重新掛載外掛，也不需要網路、Python／Node 版本盤點或預查 Pillow。`FORM_RUNTIME_*` 失敗時保留 job、原 config 與真實選值，定向檢查已保存檔案；不能改跑任意舊版驗證器、補造 receipt、把返回路徑視為製作授權，或重新掃描外掛服務掩蓋遺失。宿主若連 job 持久檔案也不可讀，據實記錄該限制；本地保存不代表跨主機自動同步。

## 無法完成時保留可查證的停點

工作紀錄保留當回合實際技能來源、準備是否執行及退出結果、產生的 config／HTML 路徑、最終回覆是否包含正式參照，以及實際宿主錯誤或使用者回報。沒有執行的步驟記為「未執行」；沒有觀察到的結果記為「未知」。不記錄私人來源全文、預覽像素或未經清理的錯誤輸出，也不把主機能力猜測寫成測試結果。

正式能力確實未取得、產檔失敗，或真正收到無法顯示／送出的回報時，沿用已收到的資料在同一對話補當階段缺項；只說明有證據的停點，不籠統聲稱 Safari 不支援。若已有相同表單 config／HTML，保留同一 request；不得藉重建新 job 掩蓋失敗。備援不是表單驗收成功，不要求手動轉貼。這份紀錄不是收件憑證或製作授權。

## 接續、修訂與安全檢查

- 正常下一階段只在前一份真實選值進入同一對話，且 `accept_intake.cjs` 回傳 accepted 後才建立；previous_request_id 精確指前一 config.request_id，新的 request 必須不同。不能虛構 ack 或選值。
- 使用者在未送出時明確換來源／設定，使用 canonical replacement 契約，保留原 request、來源修訂、真實人類原話及原因；與 previous_request_id 互斥。conversation_recovery 必須引用實際收件紀錄的 receipt_id。不能把 receipt ID 當製作授權。
- 新正式表單與舊表單分開，不能聲稱保存了看不到的未提交草稿。保存原資料與草稿；最新 active request 的驗證會阻止舊表單覆寫最新工作。來源與內容確認仍逐次核對。
- 互動表單只呼叫宿主正式提供的 `window.openai.sendFollowUpMessage`。存在與否、傳送確認及同對話接續都尚待實機測試；本包不注入 bridge、不操控聊天輸入欄、不猜測 postMessage、不繞過宿主拒絕，也不安排背景補送。
- 傳送失敗保留選值、顯示未送達並可按原按鈕重試。無 bridge 時不能以重試保證恢復。送出結果不明先查同一對話／job；真正收到才用未修改的 accept_intake.cjs 檢查身分、來源修訂、active request、同份選值契約、內容確認與去重。正常選值不要求手動轉貼。
- 還原大綱／分析風格止於對應工作；入口、需求、內容確認都不授權製作。只有最新內容已確認的合法 produce 或等效真實人類明確授權才開始成品。Drive 儲存風格必須在交付或分析後取得獨立 SAVE 選擇；SKIP 不寫入，Drive 不可用仍交付可用成品。

主題、大綱、PDF 文件、投影片 PDF、PPTX、海報的初次載入、改目標、直接送出、間隔操作及穩定性均標為未驗證，必須在目標帳號／宿主的真實流程取證，不能以本包可解壓或離線測試取代。
